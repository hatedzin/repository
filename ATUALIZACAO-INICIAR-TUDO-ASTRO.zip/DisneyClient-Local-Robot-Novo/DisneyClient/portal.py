"""First-party account portal on the existing aiohttp/MySQL backend."""
import asyncio
import hashlib
import hmac
import json
import os
import re
import secrets
import smtplib
import ssl
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from urllib.parse import urlsplit
from aiohttp import web
from asyncmy.errors import IntegrityError, OperationalError
from cryptography.fernet import InvalidToken
from database import AuthError, digest, utcnow
from portal_store import PortalStore, audit, hash_password, verify_password, PASSWORDS

COOKIE='astro_account'
CSRF='astro_csrf'

class Problem(Exception):
    def __init__(self, message, status=400):self.message,self.status=message,status

def public(row):
    return {k:row[k] for k in ('id','user_id','username','email','role','status','must_change_password')}

def json_response(data=None, **kw):
    return web.json_response(data or {}, dumps=lambda v:json.dumps(v,default=lambda x:x.isoformat(timespec='seconds')+'Z' if isinstance(x,datetime) else str(x),ensure_ascii=False),**kw)

def cookie(response, request, name, value, max_age=28800):
    response.set_cookie(name,value,httponly=True,secure=request.secure or os.getenv('PORTAL_COOKIE_SECURE')=='1',samesite='Strict',max_age=max_age,path='/')

async def body(request):
    if request.content_type!='application/json':raise Problem('Envie os dados em JSON.',415)
    if request.content_length and request.content_length>32768:raise Problem('Solicitação muito grande.',413)
    value=await request.json()
    if not isinstance(value,dict):raise Problem('Dados inválidos.')
    return value

def text(data,key,maximum=255,required=True):
    value=data.get(key,'')
    if not isinstance(value,str) or len(value)>maximum or (required and not value.strip()):raise Problem('Campo inválido: '+key)
    return value if key.endswith("password") else value.strip()

def password(data,key='password'):
    value=data.get(key)
    if not isinstance(value,str) or (not 12<=len(value)<=128 or not value.strip()):raise Problem('Use uma senha de 12 a 128 caracteres.')
    return value

def email(value):
    if not isinstance(value,str) or len(value)>254 or not re.fullmatch(r'[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+',value):raise Problem('Informe um email válido.')
    return value.strip().casefold()

def integer(data,key,default=1,maximum=100):
    v=data.get(key,default)
    if isinstance(v,bool) or not isinstance(v,int) or not 1<=v<=maximum:raise Problem('Valor inválido: '+key)
    return v

async def rate(request,action,key=None,limit=8,seconds=900):
    ok=await request.app['portal'].throttle(action,key or request.remote or 'local',limit,seconds)
    if not ok:raise Problem('Muitas tentativas. Aguarde alguns minutos e tente novamente.',429)

async def identity(request,roles=None,change_allowed=False):
    row=await request.app['portal'].session(request.cookies.get(COOKIE))
    if not row:raise Problem('Entre na sua conta para continuar.',401)
    if row['must_change_password'] and not change_allowed:raise Problem('Troque sua senha inicial antes de continuar.',428)
    if roles and row['role'] not in roles:raise Problem('Você não tem permissão para esta operação.',403)
    return row

async def locked_actor(cur,who):
    await cur.execute("SELECT a.role,a.must_change_password,u.status FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE a.id=%s FOR UPDATE",(who['id'],))
    latest=await cur.fetchone()
    if not latest or latest['status']!='active' or latest['must_change_password'] or latest['role'] not in ('GM','ADM'):
        raise Problem('Permissão alterada. Entre novamente.',403)
    who['role']=latest['role']

async def record(request,actor,action,kind,target=None,detail=None):
    async with request.app['db'].transaction() as cur:await audit(cur,actor,action,kind,target,detail,request.remote)

@web.middleware
async def protection(request,handler):
    is_api=request.path.startswith('/api/account/')
    if is_api:
        try:
            if request.method not in ('GET','HEAD','OPTIONS'):
                expected=request.cookies.get(CSRF,'');actual=request.headers.get('X-CSRF-Token','')
                if len(expected)<32 or not hmac.compare_digest(expected,actual):raise Problem('A sessão do formulário expirou. Atualize a página.',419)
                origin=request.headers.get('Origin')
                if origin and urlsplit(origin).netloc!=request.host:raise Problem('Origem não autorizada.',403)
                if request.headers.get('Sec-Fetch-Site')=='cross-site':raise Problem('Origem não autorizada.',403)
            response=await handler(request)
        except Problem as e:response=json_response({'error':e.message},status=e.status)
        except (ValueError,TypeError,KeyError,json.JSONDecodeError):response=json_response({'error':'Dados inválidos.'},status=400)
        except IntegrityError:response=json_response({'error':'Não foi possível concluir: cadastro ou valor já existente.'},status=409)
        except OperationalError:
            response=json_response({'error':'O banco não concluiu a operação. Tente novamente.'},status=503)
        except InvalidToken:response=json_response({'error':'A chave de criptografia desta instalação não corresponde às licenças. Restaure o arquivo .private/portal.key.'},status=503)
        response.headers['Cache-Control']='no-store'
    else:response=await handler(request)
    if is_api or request.path in PAGES or request.path in ('/dashboard','/data/soft') or request.path.startswith('/public/portal/'):
        response.headers.update({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'"})
    return response

async def bootstrap(request):
    token=request.cookies.get(CSRF)
    if not token or not 32<=len(token)<=128:token=secrets.token_urlsafe(32)
    who=await request.app['portal'].session(request.cookies.get(COOKIE))
    response=json_response({'csrf':token,'user':public(who) if who else None,'recovery_enabled':bool(os.getenv('SMTP_HOST'))})
    cookie(response,request,CSRF,token)
    return response

async def register(request):
    await rate(request,'register',limit=5,seconds=3600)
    data=await body(request)
    if set(data)-{'username','email','password'}:raise Problem('Campos não permitidos.')
    name=text(data,'username',32)
    if not re.fullmatch('[a-zA-Z0-9_]{3,32}',name) or name.casefold()=='gmaccount':raise Problem('Escolha um usuário de 3 a 32 letras, números ou sublinhado.')
    address=email(text(data,'email',254));encoded=await hash_password(password(data))
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT id FROM users WHERE username=%s',(name,))
        if await cur.fetchone():raise Problem('Esse usuário não está disponível.',409)
        await cur.execute('INSERT INTO users(username) VALUES(%s)',(name,));uid=cur.lastrowid
        await cur.execute("INSERT INTO portal_accounts(user_id,email,password_hash,role) VALUES(%s,%s,%s,'USER')",(uid,address,encoded));aid=cur.lastrowid
        await audit(cur,aid,'account.registered','account',aid,ip=request.remote)
    return json_response({'message':'Conta criada. Entre para acessar seu painel.'},status=201)

async def login(request):
    await rate(request,'login-ip',limit=20)
    data=await body(request);name=text(data,'username',128);value=text(data,'password',128)
    await rate(request,'login-user',name.casefold(),limit=8)
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT a.*,u.username,u.status FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE u.username=%s',(name,));row=await cur.fetchone()
    # Unknown users perform the same password work; never expose whether an account exists.
    valid=await verify_password(row['password_hash'] if row else request.app['portal_dummy_hash'],value)
    if not row or not valid or row['status']!='active':
        await record(request,None,'account.login_denied','account')
        raise Problem('Usuário ou senha inválidos.',401)
    raw=secrets.token_urlsafe(32)
    async with request.app['db'].transaction() as cur:
        # Recheck under a lock so a simultaneous password reset/block cannot race a login.
        await cur.execute('SELECT a.password_hash,u.status FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE a.id=%s FOR UPDATE',(row['id'],));latest=await cur.fetchone()
        if latest['password_hash']!=row['password_hash'] or latest['status']!='active':raise Problem('Usuário ou senha inválidos.',401)
        await cur.execute('DELETE FROM portal_sessions WHERE expires_at<=UTC_TIMESTAMP(6)')
        await cur.execute('INSERT INTO portal_sessions(account_id,token_hash,expires_at,ip_address,user_agent) VALUES(%s,%s,%s,%s,%s)',(row['id'],digest(raw),utcnow()+timedelta(hours=8),request.remote or 'local',request.headers.get('User-Agent','')[:255]))
        await cur.execute('UPDATE users SET last_login=UTC_TIMESTAMP(6) WHERE id=%s',(row['user_id'],))
        if PASSWORDS.check_needs_rehash(row['password_hash']):await cur.execute('UPDATE portal_accounts SET password_hash=%s WHERE id=%s',(await hash_password(value),row['id']))
        await audit(cur,row['id'],'account.login','account',row['id'],ip=request.remote)
    row['user_id']=row['user_id'];response=json_response({'user':public(row)})
    cookie(response,request,COOKIE,raw);return response

async def logout(request):
    who=await identity(request,change_allowed=True)
    async with request.app['db'].transaction() as cur:
        await cur.execute('DELETE FROM portal_sessions WHERE id=%s AND account_id=%s',(who['session_id'],who['id']))
    response=json_response({'message':'Você saiu da conta.'});response.del_cookie(COOKIE,path='/');return response

async def change_password(request):
    who=await identity(request,change_allowed=True);await rate(request,'password',str(who['id']),6)
    data=await body(request);new=password(data,'new_password');old=text(data,'current_password',128)
    if new==old:raise Problem('A nova senha precisa ser diferente da atual.')
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT password_hash FROM portal_accounts WHERE id=%s',(who['id'],));previous=(await cur.fetchone())['password_hash']
    if not await verify_password(previous,old):raise Problem('Senha atual incorreta.',400)
    encoded=await hash_password(new);raw=secrets.token_urlsafe(32)
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT password_hash FROM portal_accounts WHERE id=%s FOR UPDATE',(who['id'],))
        if (await cur.fetchone())['password_hash']!=previous:raise Problem('Sua senha foi alterada. Entre novamente.',409)
        if data.get('email'):await cur.execute('UPDATE portal_accounts SET email=%s WHERE id=%s',(email(data['email']),who['id']))
        await cur.execute('UPDATE portal_accounts SET password_hash=%s,must_change_password=FALSE WHERE id=%s',(encoded,who['id']))
        await cur.execute('DELETE FROM portal_sessions WHERE account_id=%s AND id<>%s',(who['id'],who['session_id']))
        await cur.execute('UPDATE portal_sessions SET token_hash=%s WHERE id=%s',(digest(raw),who['session_id']))
        await cur.execute('DELETE FROM sessions WHERE user_id=%s',(who['user_id'],))
        await cur.execute('UPDATE portal_recovery SET used_at=UTC_TIMESTAMP(6) WHERE account_id=%s AND used_at IS NULL',(who['id'],))
        await audit(cur,who['id'],'account.password_changed','account',who['id'],ip=request.remote)
    response=json_response({'message':'Senha atualizada. Os outros acessos foram encerrados.'});cookie(response,request,COOKIE,raw);return response

async def profile(request):
    who=await identity(request);await rate(request,'profile-password',str(who['id']),6);data=await body(request);address=email(text(data,'email',254));current=text(data,'current_password',128)
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT password_hash FROM portal_accounts WHERE id=%s',(who['id'],));previous=(await cur.fetchone())['password_hash']
    if not await verify_password(previous,current):raise Problem('Senha atual incorreta.')
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT password_hash FROM portal_accounts WHERE id=%s FOR UPDATE',(who['id'],))
        if (await cur.fetchone())['password_hash']!=previous:raise Problem('Entre novamente.',401)
        await cur.execute('UPDATE portal_accounts SET email=%s WHERE id=%s',(address,who['id']))
        await cur.execute('UPDATE portal_recovery SET used_at=UTC_TIMESTAMP(6) WHERE account_id=%s AND used_at IS NULL',(who['id'],))
        await audit(cur,who['id'],'account.email_changed','account',who['id'],ip=request.remote)
    return json_response({'message':'Email atualizado.'})

def send_recovery(recipient,raw):
    origin=os.getenv('PORTAL_ORIGIN','http://127.0.0.1:8080').rstrip('/')
    mail=EmailMessage();mail['Subject']='Redefinir senha — ASTRO';mail['From']=(os.getenv('SMTP_FROM') or os.getenv('SMTP_USER') or 'noreply@localhost');mail['To']=recipient
    mail.set_content('Uma redefinição de senha foi solicitada. O link é válido por 30 minutos e pode ser usado uma vez.\n\n'+origin+'/nova-senha#token='+raw+'\n\nSe não foi você, ignore esta mensagem.')
    host=os.environ['SMTP_HOST'];port=int(os.getenv('SMTP_PORT','587'))
    transport=smtplib.SMTP_SSL if os.getenv('SMTP_SSL')=='1' else smtplib.SMTP
    kwargs={'timeout':15}
    if transport is smtplib.SMTP_SSL:kwargs['context']=ssl.create_default_context()
    with transport(host,port,**kwargs) as smtp:
        if transport is smtplib.SMTP and os.getenv('SMTP_STARTTLS','1')=='1':smtp.starttls(context=ssl.create_default_context())
        if os.getenv('SMTP_USER'):smtp.login(os.environ['SMTP_USER'],os.getenv('SMTP_PASSWORD',''))
        smtp.send_message(mail)

async def deliver_recovery(app,address,raw,aid):
    try:await asyncio.to_thread(send_recovery,address,raw)
    except (OSError,smtplib.SMTPException,ValueError):
        async with app['db'].transaction() as cur:
            await cur.execute('DELETE FROM portal_recovery WHERE token_hash=%s',(digest(raw),))
            await audit(cur,None,'recovery.delivery_failed','account',aid)

async def finish_mail(app):
    tasks=list(app.get('portal_mail_tasks',set()))
    if tasks:await asyncio.gather(*tasks,return_exceptions=True)

async def recover(request):
    await rate(request,'recover',limit=5);data=await body(request);address=email(text(data,'email',254))
    await rate(request,'recover-address',digest(address),3)
    async with request.app['db'].transaction() as cur:
        await cur.execute("SELECT a.id FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE a.email=%s AND u.status='active'",(address,));who=await cur.fetchone()
    if who and os.getenv('SMTP_HOST'):
        raw=secrets.token_urlsafe(32)
        async with request.app['db'].transaction() as cur:
            await cur.execute('UPDATE portal_recovery SET used_at=UTC_TIMESTAMP(6) WHERE account_id=%s AND used_at IS NULL',(who['id'],))
            await cur.execute('INSERT INTO portal_recovery(token_hash,account_id,expires_at) VALUES(%s,%s,%s)',(digest(raw),who['id'],utcnow()+timedelta(minutes=30)))
        task=asyncio.create_task(deliver_recovery(request.app,address,raw,who['id']))
        request.app['portal_mail_tasks'].add(task)
        task.add_done_callback(request.app['portal_mail_tasks'].discard)
    return json_response({'message':'Se o email estiver cadastrado e o envio estiver configurado, você receberá um link de recuperação.'})

async def reset(request):
    await rate(request,'reset',limit=8);data=await body(request);raw=text(data,'token',256);encoded=await hash_password(password(data,'new_password'))
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT * FROM portal_recovery WHERE token_hash=%s AND expires_at>UTC_TIMESTAMP(6) AND used_at IS NULL FOR UPDATE',(digest(raw),));row=await cur.fetchone()
        if not row:raise Problem('O link é inválido ou expirou. Solicite outro.')
        await cur.execute('SELECT user_id FROM portal_accounts WHERE id=%s FOR UPDATE',(row['account_id'],));uid=(await cur.fetchone())['user_id']
        await cur.execute('UPDATE portal_accounts SET password_hash=%s,must_change_password=FALSE WHERE id=%s',(encoded,row['account_id']))
        await cur.execute('UPDATE portal_recovery SET used_at=UTC_TIMESTAMP(6) WHERE account_id=%s',(row['account_id'],))
        await cur.execute('DELETE FROM portal_sessions WHERE account_id=%s',(row['account_id'],));await cur.execute('DELETE FROM sessions WHERE user_id=%s',(uid,))
        await audit(cur,None,'account.password_recovered','account',row['account_id'],ip=request.remote)
    response=json_response({'message':'Senha redefinida. Entre novamente.'});response.del_cookie(COOKIE,path='/');return response

async def sessions(request):
    who=await identity(request,change_allowed=True)
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT id,created_at,last_seen,expires_at,ip_address,user_agent FROM portal_sessions WHERE account_id=%s AND expires_at>UTC_TIMESTAMP(6) ORDER BY last_seen DESC LIMIT 100',(who['id'],));rows=await cur.fetchall()
    return json_response({'items':[dict(r,current=r['id']==who['session_id']) for r in rows]})

async def client_sessions(request):
    who=await identity(request)
    async with request.app['db'].transaction() as cur:
        await cur.execute("SELECT s.id,s.license_id,s.created_at,s.expires_at,s.ip_address,LEFT(s.device_hash,12) AS device,COALESCE(p.key_prefix,CONCAT('LEGACY-',l.id)) AS key_prefix FROM sessions s JOIN license_keys l ON l.id=s.license_id LEFT JOIN portal_licenses p ON p.license_id=l.id WHERE s.user_id=%s AND s.expires_at>UTC_TIMESTAMP(6) ORDER BY s.id DESC LIMIT 100",(who['user_id'],));rows=await cur.fetchall()
    return json_response({'items':rows})

async def revoke_client_session(request):
    who=await identity(request);sid=request.match_info['id']
    async with request.app['db'].transaction() as cur:
        if sid=='all':await cur.execute('DELETE FROM sessions WHERE user_id=%s',(who['user_id'],))
        elif sid.isdecimal():await cur.execute('DELETE FROM sessions WHERE user_id=%s AND id=%s',(who['user_id'],int(sid)))
        else:raise Problem('Sessão inválida.')
        await audit(cur,who['id'],'client.session_revoked','account',who['id'],ip=request.remote)
    return json_response({'message':'A autorização do client foi encerrada.'})

async def revoke_session(request):
    who=await identity(request,change_allowed=True);sid=request.match_info['id']
    async with request.app['db'].transaction() as cur:
        if sid=='all':
            await cur.execute('DELETE FROM portal_sessions WHERE account_id=%s',(who['id'],))
            await cur.execute('DELETE FROM sessions WHERE user_id=%s',(who['user_id'],))
        elif sid.isdecimal():await cur.execute('DELETE FROM portal_sessions WHERE account_id=%s AND id=%s',(who['id'],int(sid)))
        else:raise Problem('Sessão inválida.')
        await audit(cur,who['id'],'account.session_revoked','account',who['id'],ip=request.remote)
    response=json_response({'message':'Acesso encerrado.'})
    if sid=='all' or sid==str(who['session_id']):response.del_cookie(COOKIE,path='/')
    return response

LICENSE_SELECT="""SELECT l.id,l.user_id,u.username,l.created_at,l.expires_at,l.status AS stored_status,l.max_activations,l.last_used,
 COALESCE(p.blocked,FALSE) AS blocked,COALESCE(p.connection_limit,u.connection_limit) AS connection_limit,
 (p.key_encrypted IS NULL) AS needs_key_link,COALESCE(p.client_level,u.level) AS client_level,COALESCE(p.key_prefix,CONCAT('LEGACY-',l.id)) AS key_prefix,COALESCE(p.label,'') AS label,p.issued_by,
 (SELECT COUNT(*) FROM license_activations v WHERE v.license_id=l.id) AS devices,
 (SELECT COUNT(*) FROM sessions v WHERE v.license_id=l.id AND v.expires_at>UTC_TIMESTAMP(6)) AS connections,
 CASE WHEN l.status='revoked' THEN 'revoked' WHEN COALESCE(p.blocked,FALSE) THEN 'blocked' WHEN l.expires_at<=UTC_TIMESTAMP(6) THEN 'expired' ELSE 'active' END AS status
 FROM license_keys l JOIN users u ON u.id=l.user_id LEFT JOIN portal_licenses p ON p.license_id=l.id"""

async def own_licenses(request):
    who=await identity(request)
    try:page=int(request.query.get('page','1'))
    except ValueError:raise Problem('Página inválida.')
    if not 1<=page<=100000:raise Problem('Página inválida.')
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT COUNT(*) AS n FROM license_keys WHERE user_id=%s',(who['user_id'],));total=(await cur.fetchone())['n']
        await cur.execute(LICENSE_SELECT+' WHERE l.user_id=%s ORDER BY l.id DESC LIMIT 30 OFFSET %s',(who['user_id'],(page-1)*30));rows=await cur.fetchall()
    return json_response({'items':rows,'page':page,'pages':max(1,(total+29)//30),'total':total})

async def license_access(cur,who,lid,admin=False):
    await cur.execute('SELECT l.*,p.key_encrypted,COALESCE(p.connection_limit,u.connection_limit) AS connection_limit,COALESCE(p.blocked,FALSE) AS blocked,COALESCE(a.role,\'USER\') AS owner_role FROM license_keys l JOIN users u ON u.id=l.user_id LEFT JOIN portal_licenses p ON p.license_id=l.id LEFT JOIN portal_accounts a ON a.user_id=l.user_id WHERE l.id=%s FOR UPDATE',(lid,));row=await cur.fetchone()
    if not row:raise Problem('Licença não encontrada.',404)
    if admin:
        if who['role'] not in ('GM','ADM'):raise Problem('Sem permissão.',403)
        if row['owner_role']=='ADM' and who['role']!='ADM':raise Problem('Somente ADM pode gerenciar esta licença.',403)
    elif who['user_id']!=row['user_id']:raise Problem('Sem permissão.',403)
    return row

async def link_key(request):
    who=await identity(request);await rate(request,'link-key',str(who['id']),8)
    data=await body(request);raw=text(data,'key',256);lid=int(request.match_info['id'])
    async with request.app['db'].transaction() as cur:
        row=await license_access(cur,who,lid)
        if not hmac.compare_digest(digest(raw),row['key_hash']):raise Problem('O código não corresponde a esta licença.')
        encrypted=request.app['portal'].encryption().encrypt(raw.encode()).decode()
        await cur.execute('INSERT INTO portal_licenses(license_id,key_encrypted,key_prefix,connection_limit) VALUES(%s,%s,%s,%s) ON DUPLICATE KEY UPDATE key_encrypted=VALUES(key_encrypted),key_prefix=VALUES(key_prefix)',(lid,encrypted,raw[:14],row['connection_limit']))
        await audit(cur,who['id'],'license.linked','license',lid,ip=request.remote)
    return json_response({'message':'Key vinculada. O código original e os dados do client foram preservados.'})

async def reveal(request):
    who=await identity(request);lid=int(request.match_info['id'])
    async with request.app['db'].transaction() as cur:
        row=await license_access(cur,who,lid,admin=who['role'] in ('GM','ADM'))
        if not row['key_encrypted']:raise Problem('Key legada: use o código original ou emita uma nova licença.',409)
        raw=request.app['portal'].encryption().decrypt(row['key_encrypted'].encode()).decode()
        await audit(cur,who['id'],'license.revealed','license',lid,ip=request.remote)
    return json_response({'key':raw})

async def activation_history(request):
    who=await identity(request);lid=int(request.match_info['id'])
    async with request.app['db'].transaction() as cur:
        await license_access(cur,who,lid,admin=who['role'] in ('GM','ADM'))
        query='SELECT id,created_at,ip_address,LEFT(device_hash,12) AS device FROM portal_activation_events WHERE license_id=%s'
        args=[lid]
        if who['role']=='USER':query+=' AND user_id=%s';args.append(who['user_id'])
        await cur.execute(query+' ORDER BY id DESC LIMIT 100',args);rows=await cur.fetchall()
    return json_response({'items':rows})

async def legacy_client_status(request):
    from api.common import authorize
    from client_runtime import availability
    await authorize(request)
    ready,reason=await availability(request.app)
    return json_response({'ready':ready,'message':reason},headers={'Cache-Control':'no-store'})

async def launch(request):
    who=await identity(request);data=await body(request);lid=integer(data,'license_id',maximum=2**63-1)
    async with request.app['db'].transaction() as cur:
        row=await license_access(cur,who,lid)
        if not row['key_encrypted']:raise Problem('Use o acesso por key para esta licença legada.',409)
        raw=request.app['portal'].encryption().decrypt(row['key_encrypted'].encode()).decode()
    from client_runtime import availability
    ready,reason=await availability(request.app)
    if not ready:raise Problem(reason,503)
    device=request.cookies.get('browser_access_token') or secrets.token_urlsafe(32)
    try:session,access,level=await request.app['db'].authenticate(raw,device,request.remote or 'local')
    except AuthError as e:
        messages={'invalid key':'Licença inválida.','access blocked':'A licença ou a conta está bloqueada.','expired key':'A licença expirou.','client access disabled':'O acesso ao client está desativado para esta conta.','activation limit exceeded':'Limite de dispositivos atingido.','connection limit exceeded':'Limite de conexões atingido. Encerre um acesso em Sessões.'}
        raise Problem(messages.get(str(e),'Não foi possível autorizar o acesso.'),403)
    response=json_response({'url':'/transformice?access_token='+access,'tools_url':'/dashboard','level':level})
    cookie(response,request,'session',session,10800);cookie(response,request,'browser_access_token',device,31536000)
    return response

async def admin_list(request):
    who=await identity(request,('GM','ADM'));data=await body(request)
    category=data.get('resource','licenses');q=text(data,'query',128,False)
    page=integer(data,'page',1,100000);offset=(page-1)*30
    async with request.app['db'].transaction() as cur:
        if category=='users':
            where=' WHERE (u.username LIKE %s OR CAST(a.id AS CHAR)=%s OR CAST(u.id AS CHAR)=%s)';args=['%'+q+'%',q,q]
            await cur.execute('SELECT COUNT(*) AS n FROM portal_accounts a JOIN users u ON u.id=a.user_id'+where,args);total=(await cur.fetchone())['n']
            await cur.execute('SELECT a.id,a.user_id,u.username,a.email,a.role,a.must_change_password,u.status,a.created_at,u.last_login,(SELECT COUNT(*) FROM license_keys l WHERE l.user_id=u.id) AS licenses FROM portal_accounts a JOIN users u ON u.id=a.user_id'+where+' ORDER BY a.id DESC LIMIT 30 OFFSET %s',(*args,offset))
        elif category=='licenses':
            where=' WHERE (u.username LIKE %s OR CAST(l.id AS CHAR)=%s OR p.key_prefix LIKE %s OR l.key_hash=%s)';args=['%'+q+'%',q,'%'+q+'%',digest(q)]
            await cur.execute('SELECT COUNT(*) AS n FROM license_keys l JOIN users u ON u.id=l.user_id LEFT JOIN portal_licenses p ON p.license_id=l.id'+where,args);total=(await cur.fetchone())['n']
            await cur.execute(LICENSE_SELECT+where+' ORDER BY l.id DESC LIMIT 30 OFFSET %s',(*args,offset))
        elif category=='audit':
            await cur.execute("SELECT COUNT(*) AS n FROM portal_audit p LEFT JOIN portal_accounts a ON a.id=p.actor_id LEFT JOIN users u ON u.id=a.user_id WHERE p.action LIKE %s OR u.username LIKE %s OR CAST(p.target_id AS CHAR)=%s",('%'+q+'%','%'+q+'%',q));total=(await cur.fetchone())['n']
            await cur.execute("SELECT p.id,p.action,p.target_type,p.target_id,p.detail,p.created_at,p.ip_address,u.username AS actor FROM portal_audit p LEFT JOIN portal_accounts a ON a.id=p.actor_id LEFT JOIN users u ON u.id=a.user_id WHERE p.action LIKE %s OR u.username LIKE %s OR CAST(p.target_id AS CHAR)=%s ORDER BY p.id DESC LIMIT 30 OFFSET %s",('%'+q+'%','%'+q+'%',q,offset))
        else:raise Problem('Lista inválida.')
        rows=await cur.fetchall()
    return json_response({'items':rows,'page':page,'total':total,'pages':max(1,(total+29)//30)})

async def stats(request):
    await identity(request,('GM','ADM'))
    async with request.app['db'].transaction() as cur:
        await cur.execute('SELECT status,COUNT(*) AS n FROM ('+LICENSE_SELECT+') classified GROUP BY status');counts={r['status']:r['n'] for r in await cur.fetchall()}
        await cur.execute('SELECT COUNT(*) AS n FROM portal_accounts');counts['users']=(await cur.fetchone())['n']
        await cur.execute("SELECT COUNT(*) AS n FROM portal_audit WHERE action IN ('license.created','license.assigned') AND created_at>UTC_TIMESTAMP(6)-INTERVAL 30 DAY");counts['distributions_30d']=(await cur.fetchone())['n']
    return json_response(counts)

async def recipient(cur,uid,who):
    await cur.execute('SELECT a.id,a.role,u.status,u.username FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE u.id=%s FOR UPDATE',(uid,));row=await cur.fetchone()
    if not row:raise Problem('Escolha um usuário cadastrado.',404)
    if row['status']!='active':raise Problem('O usuário está bloqueado.')
    if row['role']=='ADM' and who['role']!='ADM':raise Problem('Somente ADM pode entregar uma licença para esta conta.',403)
    return row

async def create_license(request):
    who=await identity(request,('GM','ADM'));await rate(request,'generate',str(who['id']),100,3600);data=await body(request)
    uid=integer(data,'user_id',maximum=2**63-1);devices=integer(data,'max_devices');connections=integer(data,'connection_limit',2)
    days=data.get('days',30)
    if isinstance(days,bool) or not isinstance(days,int) or not 0<=days<=36500:raise Problem('Validade inválida. Use 0 para permanente.')
    level=data.get('client_level') or None
    if level=='GOLD_I':level='GOLD'
    if level not in (None,'GOLD','GOLD_II','PLATINUM'):raise Problem('Perfil do client inválido.')
    label=text(data,'label',120,False);raw='ASTRO-'+secrets.token_urlsafe(32);encrypted=request.app['portal'].encryption().encrypt(raw.encode()).decode()
    expiry=utcnow()+timedelta(days=days) if days else None
    async with request.app['db'].transaction() as cur:
        await locked_actor(cur,who)
        await recipient(cur,uid,who)
        await cur.execute('INSERT INTO license_keys(user_id,key_hash,expires_at,max_activations) VALUES(%s,%s,%s,%s)',(uid,digest(raw),expiry,devices));lid=cur.lastrowid
        await cur.execute('INSERT INTO portal_licenses(license_id,issued_by,key_encrypted,key_prefix,label,connection_limit,client_level) VALUES(%s,%s,%s,%s,%s,%s,%s)',(lid,who['id'],encrypted,raw[:14],label,connections,level))
        await audit(cur,who['id'],'license.created','license',lid,{'user_id':uid,'days':days,'max_devices':devices,'connection_limit':connections},request.remote)
    return json_response({'id':lid,'key':raw,'message':'Licença criada e entregue ao usuário.'},status=201)

async def mutate_license(request):
    who=await identity(request,('GM','ADM'));data=await body(request);lid=int(request.match_info['id']);action=data.get('action')
    async with request.app['db'].transaction() as cur:
        await locked_actor(cur,who)
        row=await license_access(cur,who,lid,admin=True)
        await cur.execute("INSERT INTO portal_licenses(license_id,key_prefix,connection_limit) VALUES(%s,%s,%s) ON DUPLICATE KEY UPDATE license_id=VALUES(license_id)",(lid,'LEGACY-'+str(lid),row['connection_limit']))
        detail={}
        if action in ('block','unblock'):
            if row['status']=='revoked':raise Problem('Licença revogada não pode ser reativada.',409)
            await cur.execute('UPDATE portal_licenses SET blocked=%s WHERE license_id=%s',(action=='block',lid))
        elif action=='revoke':await cur.execute("UPDATE license_keys SET status='revoked' WHERE id=%s",(lid,))
        elif action=='renew':
            if row['status']=='revoked':raise Problem('Emita outra licença para substituir a revogada.',409)
            days=data.get('days',30)
            if isinstance(days,bool) or not isinstance(days,int) or not 0<=days<=36500:raise Problem('Validade inválida.')
            expiry=max(utcnow(),row['expires_at'] or utcnow())+timedelta(days=days) if days else None
            await cur.execute('UPDATE license_keys SET expires_at=%s WHERE id=%s',(expiry,lid));detail={'days':days}
        elif action=='reset-devices':
            await cur.execute('DELETE FROM license_activations WHERE license_id=%s',(lid,))
        elif action=='limits':
            devices=integer(data,'max_devices');connections=integer(data,'connection_limit')
            await cur.execute('SELECT COUNT(*) AS n FROM license_activations WHERE license_id=%s',(lid,))
            if (await cur.fetchone())['n']>devices:raise Problem('Redefina os dispositivos cadastrados antes de reduzir esse limite.',409)
            if 'client_level' in data:
                level=data['client_level'] or None
                if level=='GOLD_I':level='GOLD'
                if level not in (None,'GOLD','GOLD_II','PLATINUM'):raise Problem('Perfil do client inválido.')
                await cur.execute('UPDATE portal_licenses SET client_level=%s WHERE license_id=%s',(level,lid))
            await cur.execute('UPDATE license_keys SET max_activations=%s WHERE id=%s',(devices,lid))
            await cur.execute('UPDATE portal_licenses SET connection_limit=%s WHERE license_id=%s',(connections,lid));detail={'max_devices':devices,'connection_limit':connections}
        elif action=='assign':
            uid=integer(data,'user_id',maximum=2**63-1);await recipient(cur,uid,who)
            raw='ASTRO-'+secrets.token_urlsafe(32);encrypted=request.app['portal'].encryption().encrypt(raw.encode()).decode()
            await cur.execute('UPDATE license_keys SET user_id=%s,key_hash=%s WHERE id=%s',(uid,digest(raw),lid))
            await cur.execute('UPDATE portal_licenses SET key_encrypted=%s,key_prefix=%s WHERE license_id=%s',(encrypted,raw[:14],lid))
            await cur.execute('DELETE FROM license_activations WHERE license_id=%s',(lid,));detail={'previous_user_id':row['user_id'],'user_id':uid}
        else:raise Problem('Operação inválida.')
        await cur.execute('DELETE FROM sessions WHERE license_id=%s',(lid,))
        await audit(cur,who['id'],'license.'+{'assign':'assigned','renew':'renewed','block':'blocked','unblock':'unblocked','revoke':'revoked','limits':'limits_changed','reset-devices':'devices_reset'}[action],'license',lid,detail,request.remote)
    return json_response({'message':'Licença atualizada.'})

async def mutate_user(request):
    who=await identity(request,('GM','ADM'));data=await body(request);aid=int(request.match_info['id']);action=data.get('action')
    async with request.app['db'].transaction() as cur:
        # Lock the administrative group first, in stable order, to protect the last active ADM.
        await cur.execute("SELECT a.id,u.status FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE a.role='ADM' ORDER BY a.id FOR UPDATE");admins=await cur.fetchall()
        await locked_actor(cur,who)
        await cur.execute('SELECT a.*,u.status FROM portal_accounts a JOIN users u ON u.id=a.user_id WHERE a.id=%s FOR UPDATE',(aid,));target=await cur.fetchone()
        if not target:raise Problem('Usuário não encontrado.',404)
        if action=='role':
            if who['role']!='ADM':raise Problem('Somente ADM pode alterar permissões.',403)
            role=data.get('role')
            if role not in ('USER','GM','ADM'):raise Problem('Cargo inválido.')
            if target['role']=='ADM' and role!='ADM' and target['status']=='active' and len([a for a in admins if a['status']=='active'])<=1:raise Problem('Mantenha pelo menos um ADM ativo.',409)
            await cur.execute('UPDATE portal_accounts SET role=%s WHERE id=%s',(role,aid));detail={'from':target['role'],'to':role}
        elif action=='status':
            status=data.get('status')
            if status not in ('active','blocked'):raise Problem('Status inválido.')
            if who['role']=='GM' and target['role']!='USER':raise Problem('Somente ADM pode gerenciar contas administrativas.',403)
            if target['role']=='ADM' and status=='blocked' and target['status']=='active' and len([a for a in admins if a['status']=='active'])<=1:raise Problem('Mantenha pelo menos um ADM ativo.',409)
            await cur.execute('UPDATE users SET status=%s WHERE id=%s',(status,target['user_id']));detail={'status':status}
        else:raise Problem('Operação inválida.')
        await cur.execute('DELETE FROM portal_sessions WHERE account_id=%s',(aid,));await cur.execute('DELETE FROM sessions WHERE user_id=%s',(target['user_id'],))
        await audit(cur,who['id'],'account.'+action+'_changed','account',aid,detail,request.remote)
    return json_response({'message':'Usuário atualizado. As sessões anteriores foram encerradas.'})

PAGES={'/','/entrar','/cadastro','/recuperar','/nova-senha','/conta','/licencas','/sessoes','/administracao'}
async def page(request):
    if request.path in ('/conta','/licencas','/sessoes','/administracao'):
        who=await request.app['portal'].session(request.cookies.get(COOKIE))
        if not who:return web.Response(status=302,headers={'Location':'/entrar'})
        if request.path=='/administracao':
            if who['must_change_password']:return web.Response(status=302,headers={'Location':'/conta'})
            if who['role'] not in ('GM','ADM'):raise web.HTTPForbidden()
    response=web.FileResponse(request.app['root']/'public/portal/index.html');response.headers['Cache-Control']='no-store';return response

async def startup(app):
    app['portal'].encryption()
    app['portal_dummy_hash']=await hash_password(secrets.token_urlsafe(32))

def install(app):
    app['portal']=PortalStore(app['db'],app['root'])
    app['portal_mail_tasks']=set()
    app.middlewares.append(protection)
    for p in PAGES:app.router.add_get(p,page)
    app.router.add_get('/client-status',legacy_client_status)
    endpoints=[('GET','bootstrap',bootstrap),('POST','register',register),('POST','login',login),('POST','logout',logout),('POST','password',change_password),('POST','profile',profile),('POST','recover',recover),('POST','reset',reset),('GET','client-sessions',client_sessions),('POST','client-sessions/{id}/revoke',revoke_client_session),('GET','sessions',sessions),('POST','sessions/{id}/revoke',revoke_session),('GET','licenses',own_licenses),('POST','licenses/{id:\\d+}/link-key',link_key),('POST','licenses/{id:\\d+}/reveal',reveal),('GET','licenses/{id:\\d+}/activations',activation_history),('POST','launch',launch),('POST','admin/list',admin_list),('GET','admin/stats',stats),('POST','admin/licenses',create_license),('POST','admin/licenses/{id:\\d+}',mutate_license),('POST','admin/users/{id:\\d+}',mutate_user)]
    for method,path,handler in endpoints:app.router.add_route(method,'/api/account/'+path,handler)
