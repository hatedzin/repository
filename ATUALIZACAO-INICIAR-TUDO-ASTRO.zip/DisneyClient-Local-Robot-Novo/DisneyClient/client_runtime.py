"""Check the existing local parser before handing a game URL to the user."""
import aiohttp
import infrastructure

async def availability(app):
    endpoint=app.get('parser_url','')
    if not endpoint:
        return False,'O parser do jogo não foi iniciado. Abra INICIAR_TUDO.bat.'
    try:
        async with infrastructure.get_session().get(endpoint+'/api/tfm_keys',headers={'Authorization':'Bearer '+app.get('parser_token','')},timeout=aiohttp.ClientTimeout(total=3)) as response:
            if response.status in (401,403):
                return False,'O backend não conseguiu autenticar no parser. Confira a configuração local e logs-client/parser.log.'
            if response.status!=200:
                return False,'O parser ainda não preparou o jogo ou encontrou um erro. Aguarde a janela do iniciador ou consulte logs-client/parser.log.'
            data=await response.json()
            if not isinstance(data,dict) or not all(isinstance(data.get(k),str) and data[k] for k in ('player','ui_element_class_name','packet_handler_class_name')):
                return False,'O parser respondeu sem os símbolos necessários ao jogo. Consulte logs-client/parser.log.'
        return True,None
    except (aiohttp.ClientError,TimeoutError,ValueError):
        return False,'O parser do jogo está indisponível. Inicie pelo INICIAR_TUDO.bat e aguarde a preparação.'
