// ActionScript 3 / BackgroundTests.as / Ruffle AVM2 / preserve native login controls while replacing artwork
package disney {
 import flash.display.MovieClip;import flash.display.Sprite;import flash.display.Bitmap;import flash.text.TextField;import flash.utils.setTimeout;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;private static function check(ok:Boolean,n:String):void{if(!ok)throw new Error(n);count++;}
  public static function run(display:MovieClip):void{
   var root:MovieClip=new MovieClip();display.addChild(root);var game:Sprite=new Sprite();root.addChild(game);root["tfm"]=game;
   var login:MovieClip=new MovieClip();game.addChild(login);var forest:Sprite=new Sprite();forest.graphics.beginFill(0x478B32);forest.graphics.drawRect(0,0,800,600);login.addChild(forest);login["x_fond"]=forest;
   var pass:TextField=new TextField();pass.type="input";pass.displayAsPassword=true;pass.background=true;pass.backgroundColor=0xE7D8AD;pass.width=150;pass.height=24;pass.x=65;pass.y=155;login.addChild(pass);login["x_pos_mdp"]=pass;
   var email:TextField=new TextField();email.type="input";email.text="E-mail ou Apelido";email.background=true;email.backgroundColor=0xE7D8AD;email.width=150;email.height=24;email.x=65;email.y=118;login.addChild(email);
   var button:Sprite=new Sprite();button.graphics.beginFill(0xAC8349);button.graphics.drawRect(0,0,150,28);button.x=65;button.y=200;login.addChild(button);login["x_btnValider"]=button;
   var theme:AstroLoginBackground=new AstroLoginBackground(root);
   setTimeout(function():void{var result:String;try{theme.update(1000);var bg:Sprite=login.getChildByName("sddsAstroLoginBackground") as Sprite;check(bg!=null,"native login artwork recognized");check(!forest.visible,"old background hidden");check(bg.mouseEnabled==false && bg.mouseChildren==false,"background does not intercept input");check(login.getChildIndex(bg)==0,"background behind all controls");check(pass.visible && pass.type=="input" && button.parent===login,"native password and login button preserved");var image:Bitmap=bg.getChildAt(0) as Bitmap;check(image!=null && image.width==800 && image.height<600,"art fitted without stretching or cropping");theme.update(2000);check(login.getChildByName("sddsAstroLoginBackground")===bg,"no duplicate background");game.removeChild(login);theme.update(3000);check(forest.visible && bg.parent==null,"leaving login restores detached native screen");game.addChild(login);theme.update(4000);check(login.getChildByName("sddsAstroLoginBackground")!=null,"returning to login reapplies artwork");result="PASS: "+count+" Astro login background checks";}catch(e:Error){result="FAIL: "+e.message+" #"+e.errorID;}ExternalInterface.call("recordTest",result);},500);
  }
 }
}
