# Compatibilidade Pgiex V6

| Secao | Controle | Estado |
|---|---|---|
| Padrao | Teleport [F] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Fake teleport [V] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Fly [W] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Mostrar / ocultar queijo [H] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Vitoria instantanea [X] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Morrer [DEL] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Imortalidade (legado) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Ocultar meu rato (visual) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Tentar entrada instantanea | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Morrer agora | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Remover espera inicial | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Robot atual | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Padrao | Titulo do rato | Este controle existe apenas desativado no codigo original; nao ha adaptador de titulo. |
| Padrao | Visual compartilhado Pgiex | Requer o servico antigo de roupas do Pgiex; nao esta integrado. |
| Atributos | Velocidade | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Altura do pulo | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Agilidade / massa | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Macro | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Tamanho visual do rato | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Tamanho visual do queijo | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Ocultar outros jogadores (visual) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atributos | Opacidade do menu | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Vencer automaticamente | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Morrer automaticamente | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Mover automaticamente | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Vencer; morrer quando shaman | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Morrer; vencer quando shaman | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Lealdade ao shaman | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Intervalo do farm (ms) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Iniciar farm | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Parar farm | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Minimo de jogadores | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Maximo de jogadores | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Limite de vitorias confirmadas | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Morrer nestes mapas | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Avisar nestes mapas | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Alternar coleta de caixas (Farm) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Alternar bloqueio de inventario (Farm) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Farm | Defilante: vitoria | Modo Defilante do Pgiex sem implementacao de rodada correspondente nesta versao. |
| Farm | Defilante: morte | Modo Defilante do Pgiex sem implementacao de rodada correspondente nesta versao. |
| Shaman | Rocket mouse | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Velocidade do balao | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Criacao rapida | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Transformacao em gato | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Conjuracao ao arrastar o mouse | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Portais [T / R] | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Kill all (portais, como no original) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Shaman | Asas | O simbolo nativo das asas do Pgiex nao foi mapeado neste jogo. |
| Shaman | Criar em qualquer lugar | O simbolo de distancia de invocacao do Pgiex nao foi mapeado neste jogo. |
| Itens | Selecionar item por ID e armar clique | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Angulo do item | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Item transparente | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Repetir enquanto segura o mouse | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Desarmar criacao de itens | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Spirit | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Balao | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Runa | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Caixa pequena | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Caixa grande | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Bigorna | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Tabua pequena | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Tabua grande | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Canhao | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Trampolim | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Portal azul | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Portal laranja | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Galinha | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Orbe | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Peixe | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Abobora | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Aviao de papel | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Bola de papel | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Baiacu | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Bola de neve | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Lapide | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Bola | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Maca | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Bolha | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Nuvem | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Tabua de chocolate | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Tabua de gelo | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Caixa de coracao | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Tabua minuscula | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Tabua gigante | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Objeto S | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Triangulo | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Runa fixa | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Itens | Selecionar: Ovelha | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Copiar codigo de roupa | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Salvar perfil 1 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Carregar perfil 1 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Copiar perfil 1 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Salvar perfil 2 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Carregar perfil 2 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Copiar perfil 2 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Salvar perfil 3 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Carregar perfil 3 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Copiar perfil 3 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Roupas | Aplicar roupa compartilhada | Depende do antigo servidor bolcorp.icu/mice. Perfis locais salvam e copiam codigos, mas nao aplicam aparencia. |
| Roupas | Roupas de outros usuarios Pgiex | Depende do antigo servidor de roupas; nao foi migrado. |
| Roupas | Abrir comando /dressing | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Enviar uma mensagem na sala | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Enviar mensagem privada | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Copiar nomes desta sala | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Mudar de sala | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Mensagem 1 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Mensagem 2 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Mensagem 3 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Mensagem 4 | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Intervalo das mensagens (ms) | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Iniciar fila na sala atual | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Parar fila | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Ordem aleatoria | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Enviar todas as mensagens ativas | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Mensagens | Consultar jogadores de outra sala | A consulta usada no original depende de integracao antiga ausente neste client. |
| Mensagens | Flood em varias salas | A lista de salas e integracao de mensagens do Pgiex nao foram migradas. |
| Mensagens | Fila privada em massa | A fila privada do Pgiex nao foi migrada; envio individual esta disponivel. |
| Atalhos | Tecla de teleport | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Tecla de fake teleport | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Tecla de fly | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Tecla de queijo | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Tecla de vitoria | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Tecla de morte | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Salvar valores e atalhos | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Carregar valores e atalhos | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
| Atalhos | Desligar todas as opcoes Pgiex | Adaptador incluido; sujeito aos simbolos e comportamento do jogo atual |
