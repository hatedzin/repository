ABA PGIEX — ADAPTACAO DO PGIEX V6

Abra Menu > Pgiex. As oito secoes sao Padrao, Atributos, Farm, Shaman, Itens, Roupas, Mensagens e Atalhos. Use a roda do mouse dentro da lista para ver os controles restantes.
Esta entrega adapta recursos do codigo Pgiex TFM de Jpn (2018–2022), enviado pelo usuario. Nao e uma portagem integral: recursos de servicos externos e simbolos nativos ainda nao adaptados aparecem indisponiveis e explicam o motivo. Nao basta ativar uma caixa para tornar esses recursos funcionais.

Padrao: teleport, fake teleport, fly, queijo visual, tentativas de vitoria e morte, Robot atual e remocao de espera. As tentativas usam os codigos capturados pelo observador nativo: aguarde a proxima rodada depois de abrir o client. Elas nao chamam as rotinas aposentadas do client e nao simulam uma vitoria confirmada. Imortalidade antiga depende da propriedade tempsPartieZero existir no jogo; caso contrario nao e ativada.
Atributos: controles existentes de velocidade, pulo, massa e macro; tamanho VISUAL de rato e queijo, ocultacao visual e opacidade do menu. Esses ajustes visuais nao prometem mudar colisoes ou outras telas de jogadores.
Farm: iniciar/parar; vencer, morrer ou mover; alternar por papel de shaman; lealdade; intervalo; min/max jogadores e limite de vitorias confirmadas; mapas para morte ou aviso visual. Regras de limite pausam o farm. Robot encerra o farm para evitar disputa de controles. Os botoes Alternar coleta e Alternar bloqueio acionam os controles legados atuais; o estado desses controles e gerenciado na aba Farm e nao e alterado pelo reset Pgiex; se o controle ainda nao existir, abra Farm uma vez.
Shaman: funcoes de habilidade por processamento local, gato, conjuracao ao arrastar, portais e tentativa Kill All por portais conforme o original. A aceitação e o resultado real dependem do jogo/servidor.
Itens: 34 seletores do original e campo livre de ID; angulo, transparencia, repeticao ao segurar e botao de desarmar. Selecione o item e clique NO MAPA para cria-lo. Cliques no menu nao criam objetos. A selecao usa IDs fixos; skins alternativas podem ser escolhidas pelo campo de ID.
Roupas: salvar/carregar/copiar tres perfis LOCAIS de codigos e /dressing. Aplicar roupas compartilhadas e consultar usuarios Pgiex dependiam do antigo servidor externo e nao foram migrados. Carregar um codigo nao muda a aparencia do rato.
Mensagens: envio individual na sala, envio individual privado, copiar nomes da sala, mudar de sala, quatro textos, fila na sala atual, ordem sequencial/aleatoria e envio conjunto. A fila comeca apenas ao clicar Iniciar e pode ser parada; nasce desligada. Filas globais/privadas em massa e consulta de outra sala nao foram migradas.
Atalhos: configurar as letras/codigos de tecla, salvar/carregar valores locais e desligar opcoes. Salvar configuracao nao ativa automacoes na proxima abertura.

INCOMPATIBILIDADES EXPLICITAS
- Titulo do rato: Este controle existe apenas desativado no codigo original; nao ha adaptador de titulo.
- Visual compartilhado Pgiex: Requer o servico antigo de roupas do Pgiex; nao esta integrado.
- Defilante: vitoria: Modo Defilante do Pgiex sem implementacao de rodada correspondente nesta versao.
- Defilante: morte: Modo Defilante do Pgiex sem implementacao de rodada correspondente nesta versao.
- Asas: O simbolo nativo das asas do Pgiex nao foi mapeado neste jogo.
- Criar em qualquer lugar: O simbolo de distancia de invocacao do Pgiex nao foi mapeado neste jogo.
- Aplicar roupa compartilhada: Depende do antigo servidor bolcorp.icu/mice. Perfis locais salvam e copiam codigos, mas nao aplicam aparencia.
- Roupas de outros usuarios Pgiex: Depende do antigo servidor de roupas; nao foi migrado.
- Consultar jogadores de outra sala: A consulta usada no original depende de integracao antiga ausente neste client.
- Flood em varias salas: A lista de salas e integracao de mensagens do Pgiex nao foram migradas.
- Fila privada em massa: A fila privada do Pgiex nao foi migrada; envio individual esta disponivel.

O atualizador, o sistema de anuncios/aprovacao, login premium e executaveis C# do projeto original nao sao funcoes da nova aba e nao foram incorporados. Nenhuma conexao com esses servicos antigos e iniciada.

INSTALACAO
Completo: extraia, preserve sua .env e use INICIAR_CLIENT.bat (Python 3.11+). Endereco 127.0.0.1:8080. O pacote inclui a correcao do pip e o observador nativo do Follow.
Atualizacao menor: exige o client com observador nativo corrigido. Feche Flash e iniciador; extraia o ZIP ao lado de INICIAR_CLIENT.bat, substituindo a SWF em DisneyClient-Local-Robot-Novo/DisneyClient/public.
Validacao: testes simulados no Ruffle e verificacao de que apenas o ponto de inicializacao existente foi alterado. Falta validacao com Adobe Flash conectado ao servidor real. Nao ha garantia de vitoria, coleta ou efeitos aceitos pelo servidor.
Fontes e catalogo de compatibilidade em fontes-pgiex/.
