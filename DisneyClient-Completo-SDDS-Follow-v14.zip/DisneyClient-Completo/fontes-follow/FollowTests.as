// ActionScript 3 / FollowTests.as / Ruffle AVM2 / no vertical control writes after initial teleport
package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.geom.Point;import flash.utils.ByteArray;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;private static function check(ok:Boolean,n:String):void{if(!ok)throw new Error(n);count++;}
  private static function signed(b:ByteArray):int{var v:int=0;var shift:int=0;var part:int;do{part=b.readUnsignedByte();v|=(part&127)<<shift;shift+=7;}while(part&128);if(shift<32 && (part&64))v|=(-1)<<shift;return v;}
  public static function run(display:MovieClip):void{
   var result:String;
   try{
    var r:MovieClip=new MovieClip();display.addChild(r);r.stage.focus=r.stage;var pressed:Object={};var up:int=0;var chats:Array=[];var teleports:int=0;
    r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{pressed[e.keyCode]=true;if(e.keyCode==38)up++;});r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{pressed[e.keyCode]=false;});
    var body:Object={velocity:{vx:7,vy:9},place:function(p:Object,a:Number):void{throw new Error("Unexpected continuous pose write");}};
    var local:Object={nick:"Self#0001",x:10,y:20,dead:false,clip:true,body:body,cheese:false,jumpMode:function(v:Boolean):void{throw new Error("Unexpected jump-mode write");}};
    var target:Object={nick:"Target#0000",x:300,y:150,dead:false,clip:false,cheese:false,left:false,right:true,jumpActive:true,body:{velocity:{vx:3,vy:-8}}};
    r["Keys"]={player:"self",player_list:"players",player_name:"nick",is_dead:"dead",player_clip:"clip",player_cheese:"cheese",chat_message:"chat",player_physics:"body",bot_set_position:"place",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",player_moving_left:"left",player_moving_right:"right",is_jumping:"jumpActive",jump:"jumpMode",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{return Point;}}},b2vec2:"Point",packet_handler_class:{receive:function(b:ByteArray):void{b.readUnsignedByte();b.readUnsignedByte();local.x=signed(b);local.y=signed(b);teleports++;}},packet_handler:"receive",map_class:{current:{number:{code:1}}},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"code"};
    r["tfm"]={self:local,players:[target],chat:function(text:String):void{chats.push(text);}};
    var follow:FollowController=new FollowController(r);follow.command("/follow Target#0000");follow.update(0);
    check(teleports==1 && local.y==150,"initial native teleport retained");check(chats.length==1,"local welcome retained");check(pressed[39] && up==0,"horizontal direction without UP input");
    target.y=-300;target.x=500;follow.update(20);check(local.y==150 && local.x==300,"continuous position writes removed");check(body.velocity.vx==7 && body.velocity.vy==9,"all live velocity components left untouched");
    local.y=170;body.velocity.vy=4;follow.update(40);check(local.y==170 && body.velocity.vy==4,"normal falling state preserved");check(up==0 && teleports==1,"no repeated vertical teleport or jump impulse");
    target.left=true;target.right=false;follow.update(60);check(pressed[37] && !pressed[39],"native direction reversal retained");target.jumpActive=false;follow.update(80);check(local.y==170,"target jump-mode release does not change local pose");
    target.cheese=true;follow.update(100);check(!pressed[37] && chats.length==2,"cheese mismatch pauses with local message");local.cheese=true;follow.update(120);check(pressed[37],"normal cheese acquisition resumes");target.cheese=false;follow.update(140);check(!pressed[37],"target cheese loss pauses");
    follow.command("/follow off");follow.update(160);check(!pressed[37] && !pressed[39],"off releases only owned controls");check(up==0,"no automatic jump input through full run");
    result="PASS: "+count+" vertical-control removal checks";
   }catch(e:Error){result="FAIL: "+e.message+" #"+e.errorID;}
   ExternalInterface.call("recordTest",result);
  }
 }
}
