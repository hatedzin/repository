// Java 21 + FFDec / original and proposed host-expression variant in isolated SWFs.
import com.jpexs.decompiler.flash.*;
import com.jpexs.decompiler.flash.tags.*;
import com.jpexs.decompiler.flash.abc.*;
import com.jpexs.decompiler.flash.abc.types.*;
import com.jpexs.decompiler.flash.abc.avm2.*;
import com.jpexs.decompiler.flash.abc.avm2.instructions.*;
import com.jpexs.decompiler.flash.abc.avm2.parser.script.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
class BuildHttpFixture {
 public static void main(String[] args)throws Exception{
  SWF swf=new SWF(new FileInputStream(args[0]),false);DoABC2Tag tag=null;
  for(Tag candidate:swf.getTags())if(candidate instanceof DoABC2Tag && ((DoABC2Tag)candidate).getABC().findClassByName("ChargeurTransformice_fla.MainTimeline")>=0)tag=(DoABC2Tag)candidate;
  ABC abc=tag.getABC();var index=swf.getAbcIndex();index.selectAbc(abc);
  for(String source:List.of(args[1],args[2]))new ActionScript3Parser(index).addScript(Files.readString(Path.of(source)),"FollowHttpFixture.as",abc.instance_info.size(),abc.script_info.size(),swf.getDocumentClass(),abc);
  int main=abc.findClassByName("ChargeurTransformice_fla.MainTimeline"),test=abc.findClassByName("disney.RgbMouseTests");
  var body=abc.findBody(abc.instance_info.get(main).iinit_index);var code=new AVM2Code();
  code.code=new ArrayList<>(List.of(new AVM2Instruction(0,0xd0,new int[]{}),new AVM2Instruction(0,0x30,new int[]{}),new AVM2Instruction(0,0xd0,new int[]{}),new AVM2Instruction(0,0x49,new int[]{0}),new AVM2Instruction(0,0x60,new int[]{abc.instance_info.get(test).name_index}),new AVM2Instruction(0,0xd0,new int[]{}),new AVM2Instruction(0,0x4f,new int[]{abc.constants.getQnameId("run",0x16,"",true),1}),new AVM2Instruction(0,0x47,new int[]{})));
  body.setCode(code);body.exceptions=new ABCException[0];body.max_stack=2;body.setModified();tag.setModified(true);swf.setModified(true);
  try(var output=new FileOutputStream(args[3])){swf.saveTo(output);}System.out.println("HTTP fixture built: "+Path.of(args[3]).getFileName());
 }
}
