// Actual AS3 URLLoader POST capture. Only fake credentials are used; none are logged.
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
const {chromium}=require('playwright');
(async()=>{
 const root=__dirname,ruffle=path.resolve(root,'../../follow-v11/ruffle');let active='',requests={original_absolute:[],original_relative:[],fixed_absolute:[],fixed_relative:[],fixed_directory:[],fixed_remote:[],fixed_noauth:[],fixed_unexpected:[],fixed_error:[],fixed_timeout:[]},statuses={};
 const server=http.createServer((request,response)=>{
  const address=new URL(request.url,'http://127.0.0.1');
  if(address.pathname==='/client_diagnostics' || address.pathname==='/nested/client_diagnostics'){
   let body='';request.on('data',chunk=>body+=chunk);request.on('end',()=>{
    const form=Object.fromEntries(new URLSearchParams(body));
    const authValid=address.searchParams.get('access_token')==='fixture-access-token' && address.searchParams.get('flash_token')==='fixture-flash-token';
    requests[active].push({method:request.method,authValid,path:address.pathname,form});
    if(active==='fixed_timeout')return;
    response.writeHead(active==='fixed_error'?500:authValid?200:401,{'Content-Type':'application/json'}).end(JSON.stringify({saved:authValid && active!=='fixed_unexpected'}));
   });return;
  }
  const asset=address.pathname.startsWith('/ruffle/')?path.resolve(ruffle,'.'+address.pathname.slice('/ruffle'.length)):path.resolve(root,'.'+decodeURIComponent(address.pathname.replace(/^\/nested\//,'/')));
  if(!asset.startsWith(root+'/') && !asset.startsWith(ruffle+'/')){response.writeHead(403).end();return;}
  fs.readFile(asset,(error,data)=>{if(error){response.writeHead(404).end();return;}response.setHeader('Content-Type',asset.endsWith('.wasm')?'application/wasm':asset.endsWith('.js')?'application/javascript':asset.endsWith('.swf')?'application/x-shockwave-flash':'text/html');response.end(data);});
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser;
 try{
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  for(const variant of Object.keys(requests)){
   const [source,host]=variant.split('_');active=variant;const page=await browser.newPage();page.on('pageerror',error=>console.log('PAGE_ERROR',error.message));
   await page.goto('http://127.0.0.1:'+server.address().port+'/http-test.html?case='+source+'&host='+host);
   await page.waitForFunction(()=>window.testResult,null,{timeout:60000});
   await new Promise(resolve=>setTimeout(resolve,variant==='fixed_timeout'?7000:2300));
   const values=await page.evaluate(()=>({result:window.testResult,probe:window.probe,status:window.diagnosticStatus}));statuses[variant]=values.status;
   console.log(variant,JSON.stringify({...values,postCount:requests[variant].length,reasons:requests[variant].map(item=>item.form.reason)}));
   await page.close();
  }
  for(const item of Object.entries(requests).filter(([name])=>name.startsWith('fixed_')).flatMap(([,items])=>items)){
   assert.equal(item.method,'POST');assert.equal(item.authValid,true);
   assert.equal(item.form.event,'follow');assert.equal(item.form.build,'sdds-follow-observe-v12');assert.equal(item.form.channel,'client');
   assert(!JSON.stringify(item.form).includes('PRIVATE-FIXTURE-TEXT'));assert(!JSON.stringify(item.form).includes('fixture-access-token'));assert(!JSON.stringify(item.form).includes('fixture-flash-token'));
  }
  const report=Object.fromEntries(Object.entries(requests).map(([name,items])=>[name,{status:statuses[name],count:items.length,forms:items.map(item=>item.form)}]));
  fs.writeFileSync(path.join(root,'http-result.json'),JSON.stringify(report,null,2)+'\n');
  assert.equal(requests.original_absolute.length,4);assert.equal(requests.original_relative.length,0);
  for(const variant of ['fixed_absolute','fixed_relative','fixed_directory']){
   assert.equal(requests[variant].length,4);assert.deepEqual(requests[variant].map(item=>item.form.reason).sort(),['error','ready','sample','start']);
   const sample=requests[variant].find(item=>item.form.reason==='sample').form;assert.equal(sample.frame_count,'7');assert.equal(sample.vy,'-3250');assert.equal(sample.alive,'1');
   assert.equal(statuses[variant],'salvo');
  }
  assert(requests.fixed_directory.every(item=>item.path==='/nested/client_diagnostics'));
  assert.equal(requests.fixed_remote.length,0);assert.equal(statuses.fixed_remote,'base indisponivel');
  assert.equal(requests.fixed_noauth.length,0);assert.equal(statuses.fixed_noauth,'autenticacao ausente');
  assert.equal(statuses.fixed_unexpected,'resposta inesperada');assert.equal(statuses.fixed_error,'falha de envio');assert.equal(statuses.fixed_timeout,'tempo esgotado');
  console.log('PASS: original relative-host failure reproduced; v12 absolute/relative/directory POSTs, acknowledgments, rejection, errors and timeout verified');
 }catch(error){console.log(String(error));process.exitCode=1;}finally{if(browser)await browser.close();server.close();}
})();
