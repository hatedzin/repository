// End-to-end AS3 URLLoader diagnostics requests with fixture-only credentials.
package disney {
 import flash.display.MovieClip;
 import flash.external.ExternalInterface;
 import flash.net.SharedObject;
 import flash.utils.setTimeout;
 public class RgbMouseTests {
  public static function run(display:MovieClip):void {
   try {
    var root:MovieClip=display;
    root["host_url"]=String(ExternalInterface.call("diagnosticBase"));
    root["access_token"]=Boolean(ExternalInterface.call("diagnosticAuth")) ? "fixture-access-token" : "";
    var preferences:SharedObject=SharedObject.getLocal("sdds-follow-http-fixture");preferences.data.flash_token="fixture-flash-token";
    root["tfmdisney"]=preferences;
    var actual:String=String(root["host_url"]);
    var expression:String=String(root["host_url"] || "");
    ExternalInterface.call("recordProbe",{hostValid:/^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::[0-9]{1,5})?\/$/i.test(actual),expression:expression,hostEqual:expression==actual,loadedFromLoopback:/^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::[0-9]{1,5})?\//i.test(String(root.loaderInfo.url))});
    var diagnostics:FollowDiagnostics=new FollowDiagnostics(root);
    diagnostics.emit("ready",0,"idle");
    diagnostics.emit("start",0,"search");
    diagnostics.emit("sample",0,"active",{frame_count:7,sync_count:1,up_count:0,down_count:0,jump_state:1,x:100,y:120,target_x:100,target_y:120,vx:2500,vy:-3250,alive:true,symbol_available:true,nickname:"PRIVATE-FIXTURE-TEXT",payload:"PRIVATE-FIXTURE-TEXT",access_token:"PRIVATE-FIXTURE-TEXT"});
    diagnostics.emit("error",2204,"position",null,"client");
    var report:Function=function():void{var status:String="ausente";try{status=String(Object(diagnostics)["status"]);}catch(ignored:Error){}ExternalInterface.call("recordStatus",status);};
    report();setTimeout(report,1500);setTimeout(report,6500);
    ExternalInterface.call("recordTest","EMITTED");
   }catch(error:Error){ExternalInterface.call("recordTest","FAIL: "+error.errorID);}
  }
 }
}
