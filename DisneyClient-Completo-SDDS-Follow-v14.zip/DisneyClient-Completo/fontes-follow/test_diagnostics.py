"""Follow telemetry validation against the real aiohttp POST route, offline.

Run: python -m unittest discover -s /workspace/work/follow-v11/diag-backend -v
The tiny common-module stub makes this copy runnable without a database or
application configuration. Authorization is still exercised at the route edge.
"""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import AsyncMock, Mock, patch

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer


SOURCE = Path(__file__).with_name('diagnostics.py')
PACKAGE = '_follow_diagnostics_test'
package = types.ModuleType(PACKAGE)
package.__path__ = [str(SOURCE.parent)]
common = types.ModuleType(PACKAGE + '.common')
common.authorize = AsyncMock(side_effect=web.HTTPUnauthorized())
sys.modules[PACKAGE] = package
sys.modules[PACKAGE + '.common'] = common
spec = importlib.util.spec_from_file_location(PACKAGE + '.diagnostics', SOURCE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class DiagnosticsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.root = Path(self.folder.name) / 'DisneyClient'
        self.root.mkdir()
        self.log = self.root.parent / 'logs-client' / 'flash-diagnostics.jsonl'
        self.app = web.Application()
        self.app.update(root=self.root, diagnostics_rate={})
        self.app.router.add_view('/client_diagnostics', mod.Diagnostics)
        self.client = TestClient(TestServer(self.app))
        await self.client.start_server()
        self.auth_patch = patch.object(mod, 'authorize', AsyncMock(return_value={'user_id': 7}))
        self.authorize = self.auth_patch.start()

    async def asyncTearDown(self):
        self.auth_patch.stop()
        await self.client.close()
        self.folder.cleanup()

    def values(self, **updates):
        values = dict(event='follow', channel='client', code='0', elapsed='123',
                      options='', build='sdds-follow-observe-v12', reason='start')
        values.update(updates)
        return values

    async def post(self, values=None, **updates):
        response = await self.client.post('/client_diagnostics',
                                          data=self.values(**updates) if values is None else values)
        await response.read()
        return response

    def rows(self):
        return [json.loads(line) for line in self.log.read_text().splitlines()] if self.log.exists() else []

    async def test_every_follow_reason_and_native_channel_is_accepted(self):
        reasons = {'ready', 'start', 'stop', 'initial_sync', 'sample', 'paused',
                   'error', 'watch', 'socket_close', 'io_error', 'security_error'}
        self.assertEqual(mod.FOLLOW_REASONS, reasons)
        for reason in sorted(reasons):
            for channel in ('client', 'main', 'bulle'):
                with self.subTest(reason=reason, channel=channel):
                    response = await self.post(reason=reason, channel=channel)
                    self.assertEqual(response.status, 200)
        self.assertEqual(len(self.rows()), len(reasons) * 3)
        self.assertEqual(self.rows()[0]['build'], 'sdds-follow-observe-v12')

    async def test_missing_or_unrecognized_required_metadata_is_rejected(self):
        for name in ('build', 'reason'):
            values = self.values()
            del values[name]
            self.assertEqual((await self.post(values)).status, 400, name)
        for updates in ({'build': ''}, {'build': 'sdds-follow-other'},
                        {'reason': ''}, {'reason': 'private text'},
                        {'event': 'unknown'}, {'channel': 'unknown'}):
            with self.subTest(updates=updates):
                self.assertEqual((await self.post(**updates)).status, 400)
        self.assertFalse(self.log.exists())
        self.assertEqual(self.app['diagnostics_rate'], {})

    async def test_optional_numeric_boundaries_are_saved_as_integers(self):
        counts = ('frame_count', 'sync_count', 'up_count', 'down_count')
        positions = ('x', 'y', 'target_x', 'target_y', 'vx', 'vy')
        for low in (True, False):
            values = {name: '0' if low else '1000000000' for name in counts}
            values.update({name: '-10000000' if low else '10000000' for name in positions})
            values.update(jump_state='0' if low else '1',
                          alive='0' if low else '1', symbol_available='0' if low else '1')
            self.assertEqual((await self.post(**values)).status, 200)
            row = self.rows()[-1]
            for name in counts + positions + ('jump_state',):
                self.assertIs(type(row[name]), int)
                self.assertEqual(row[name], int(values[name]))
            self.assertIs(row['alive'], not low)
            self.assertIs(row['symbol_available'], not low)

    async def test_malformed_or_out_of_range_numeric_context_is_rejected(self):
        failures = []
        for name in ('frame_count', 'sync_count', 'up_count', 'down_count'):
            failures.extend(({name: '-1'}, {name: '1000000001'}))
        for name in ('x', 'y', 'target_x', 'target_y', 'vx', 'vy'):
            failures.extend(({name: '-10000001'}, {name: '10000001'}, {name: 'NaN'}))
        failures.extend([{'jump_state': '-1'}, {'jump_state': '2'},
                         {'frame_count': '1.5'}, {'vx': 'Infinity'},
                         {'elapsed': '2147483648'}, {'code': '65536'}])
        for updates in failures:
            with self.subTest(updates=updates):
                self.assertEqual((await self.post(**updates)).status, 400)
        self.assertEqual(self.rows(), [])

    async def test_boolean_flags_require_zero_or_one(self):
        for name in ('alive', 'symbol_available'):
            for value in ('true', 'false', '', '2', '-1', 'NaN'):
                with self.subTest(name=name, value=value):
                    self.assertEqual((await self.post(**{name: value})).status, 400)
        self.assertEqual(self.rows(), [])

    async def test_phase_accepts_only_fixed_nonidentifying_labels(self):
        for phase in sorted(mod.FOLLOW_PHASES):
            self.assertEqual((await self.post(phase=phase)).status, 200)
        for phase in ('', 'Target#0000', 'http://example.invalid/private'):
            self.assertEqual((await self.post(phase=phase)).status, 400)

    async def test_unknown_sensitive_fields_are_omitted_from_record(self):
        secret = 'PRIVATE-NOT-FOR-LOGS'
        values = self.values(reason='error', code='2204', phase='position',
                             access_token=secret, flash_token=secret,
                             message=secret, payload=secret, packet=secret,
                             nickname=secret, target_name=secret, url=secret,
                             arbitrary=secret)
        response = await self.client.post('/client_diagnostics?access_token=' + secret
                                          + '&flash_token=' + secret, data=values)
        await response.read()
        self.assertEqual(response.status, 200)
        content = self.log.read_text()
        self.assertNotIn(secret, content)
        self.assertEqual(set(self.rows()[0]), {'time', 'event', 'code', 'channel',
                         'elapsed_ms', 'active_options', 'build', 'reason', 'phase'})

    async def test_follow_budget_is_90_per_minute_and_leaves_other_budgets_intact(self):
        with patch.object(mod, 'time', types.SimpleNamespace(monotonic=lambda: 1000)):
            for _ in range(90):
                self.assertEqual((await self.post()).status, 200)
            self.assertEqual((await self.post()).status, 429)
            for _ in range(30):
                self.assertEqual((await self.post(event='socket_close', channel='main')).status, 200)
            self.assertEqual((await self.post(event='socket_close', channel='main')).status, 429)
            for _ in range(120):
                self.assertEqual((await self.post(event='teleport',
                    build='sdds-legacy-teleport-codec-v5', reason='ready')).status, 200)
            self.assertEqual((await self.post(event='teleport',
                build='sdds-legacy-teleport-codec-v5', reason='ready')).status, 429)
        self.assertEqual(len(self.rows()), 240)

    async def test_follow_budget_resets_at_60_seconds_and_is_per_user(self):
        with patch.object(mod, 'time', types.SimpleNamespace(monotonic=lambda: 1000)):
            for _ in range(90):
                self.assertEqual((await self.post()).status, 200)
            self.assertEqual((await self.post()).status, 429)
            self.authorize.return_value = {'user_id': 8}
            self.assertEqual((await self.post()).status, 200)
        self.authorize.return_value = {'user_id': 7}
        with patch.object(mod, 'time', types.SimpleNamespace(monotonic=lambda: 1059.99)):
            self.assertEqual((await self.post()).status, 429)
        with patch.object(mod, 'time', types.SimpleNamespace(monotonic=lambda: 1060)):
            self.assertEqual((await self.post()).status, 200)

    async def test_existing_event_validation_and_record_fields_are_preserved(self):
        for event in ('guard_ready', 'frame_error', 'socket_close', 'io_error', 'security_error'):
            self.assertEqual((await self.post(event=event, channel='bulle', code='17')).status, 200)
            self.assertNotIn('build', self.rows()[-1])
            self.assertNotIn('reason', self.rows()[-1])
        self.assertEqual((await self.post(event='physics', feature='mass', reason='paused_cheese')).status, 200)
        self.assertEqual(self.rows()[-1]['feature'], 'mass')
        self.assertEqual((await self.post(event='physics', feature='mass', reason='untrusted')).status, 400)
        for build in ('sdds-legacy-teleport-diag-v4', 'sdds-legacy-teleport-codec-v5'):
            self.assertEqual((await self.post(event='teleport', build=build, reason='requested',
                            press='3', x='200', alive='1')).status, 200)
            self.assertEqual(self.rows()[-1]['press'], 3)

    async def test_unsupported_option_cannot_write_arbitrary_text(self):
        self.assertEqual((await self.post(options='PRIVATE-NOT-FOR-LOGS')).status, 400)
        self.assertEqual(self.rows(), [])

    async def test_failed_authorization_saves_nothing(self):
        self.authorize.side_effect = web.HTTPUnauthorized()
        self.assertEqual((await self.post()).status, 401)
        self.assertEqual(self.rows(), [])
        self.assertEqual(self.app['diagnostics_rate'], {})

    async def test_nonloopback_is_rejected_before_authorization(self):
        request = Mock(remote='192.0.2.1')
        with self.assertRaises(web.HTTPForbidden):
            await mod.Diagnostics(request).post()
        self.authorize.assert_not_awaited()


if __name__ == '__main__':
    unittest.main()
