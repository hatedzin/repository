@rem Batch / GERAR_HASH.bat / Windows CMD / generate client administrator password hash
@echo off
setlocal
cd /d "%~dp0DisneyClient"
if errorlevel 1 goto fim
"..\.client-runtime\Scripts\python.exe" admin.py hash-password
:fim
echo.
pause
