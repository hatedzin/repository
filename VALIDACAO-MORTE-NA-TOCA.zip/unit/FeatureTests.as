package disney {
 import flash.display.MovieClip;import flash.utils.ByteArray;import flash.external.ExternalInterface;import disney.standalone.DeathOnOtherWin;
 public class FeatureTests {
  private static var count:int=0;private static var deaths:int=0;
  private static function check(ok:Boolean,name:String):void{if(!ok)throw new Error(name);count++;}
  private static function packet(id:int,order:int=1):ByteArray{var b:ByteArray=new ByteArray();b.writeByte(8);b.writeByte(6);b.writeByte(order);b.writeInt(id);b.writeShort(10);b.writeByte(order);b.writeShort(500);b.position=3;return b;}
  public static function run(display:MovieClip):void{try{
   var dispatcher:Object={};var player:Object={id:100,dead:false};var game:Object={player:player};
   game[String.fromCharCode(3,8,4,5,3,2,2,3,6,4,5,1,8)]=function(cmd:String):void{check(cmd=="mort","native mort command");deaths++;};
   var root:Object={Keys:{player:"player",player_id:"id",is_dead:"dead",packet_handler_class:dispatcher},tfm:game,current_round_code:1,insta_death:false};
   var prior:int=0;dispatcher.astroRoomObserverV1=function(b:ByteArray):void{prior++;b.position=b.length;};
   var helper:DeathOnOtherWin=new DeathOnOtherWin(root);check(true,"constructed");helper.update();check(true,"updated");
   var bytes:ByteArray=packet(200);dispatcher.astroRoomObserverV1(bytes);check(deaths==0,"disabled");check(bytes.position==3 && prior==1,"previous observer and cursor preserved");
   root.insta_death=true;helper.observe(packet(100));check(deaths==0,"own victory ignored");
   helper.observe(packet(201));check(deaths==1,"other winner triggers death");helper.observe(packet(201));helper.observe(packet(202));check(deaths==1,"duplicates and repeat death requests blocked");
   player.dead=true;helper.update();player.dead=false;helper.update();helper.observe(packet(201));check(deaths==1,"old winner ignored after respawn");helper.observe(packet(203));check(deaths==2,"new winner after respawn");
   root.current_round_code=2;helper.update();helper.observe(packet(203));check(deaths==3,"same packet allowed in a new round");
   root.current_round_code=3;player.dead=true;helper.update();helper.observe(packet(204));check(deaths==3,"dead character ignored");
   player.dead=false;helper.update();game.player=null;helper.observe(packet(205));check(deaths==3,"missing character ignored");game.player=player;
   var invalid:ByteArray=new ByteArray();invalid.writeByte(8);invalid.writeByte(6);helper.observe(invalid);check(deaths==3,"truncated packet ignored");
   var map:ByteArray=new ByteArray();map.writeByte(5);map.writeByte(2);helper.observe(map);helper.update();helper.observe(packet(206));check(deaths==3,"map transition blocks old winner");
   root.current_round_code=4;helper.update();var rebound:Object={};root.Keys.packet_handler_class=rebound;helper.update();rebound.astroRoomObserverV1(packet(207));check(deaths==4,"dispatcher rebind");
   ExternalInterface.call("recordTest","PASS: "+count+" death-on-other-win assertions");
  }catch(e:Error){ExternalInterface.call("recordTest","FAIL after "+count+": "+e.message+" #"+e.errorID+" "+e.getStackTrace());}}
 }
}
