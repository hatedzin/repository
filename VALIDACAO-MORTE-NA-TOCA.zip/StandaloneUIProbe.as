package disney.standalone {
 import flash.display.*;import flash.text.*;import flash.geom.Point;import flash.external.ExternalInterface;
 public class StandaloneUIProbe {
  private static function find(node:DisplayObject,name:String):DisplayObject{if(!node)return null;if(node.name==name)return node;if(node is DisplayObjectContainer){var c:DisplayObjectContainer=node as DisplayObjectContainer;for(var i:int=0;i<c.numChildren;i++){var result:DisplayObject=find(c.getChildAt(i),name);if(result)return result;}}return null;}
  private static function point(node:DisplayObject,x:Number=60,y:Number=10):Object{if(!node)return null;var p:Point=node.localToGlobal(new Point(x,y));return {x:p.x,y:p.y};}
  public static function install(root:MovieClip):void{if(!ExternalInterface.available)return;
   ExternalInterface.addCallback("probeDeathNative",function():Boolean{return root["tfm"][String.fromCharCode(3,8,4,5,3,2,2,3,6,4,5,1,8)] is Function;});
   ExternalInterface.addCallback("probeNav",function(title:String):Object{var ui:Object=root["Interface"];var panel:DisplayObjectContainer=ui ? ui["menu_ui"] as DisplayObjectContainer : null;if(!panel)return null;for(var i:int=0;i<panel.numChildren;i++){var s:Sprite=panel.getChildAt(i) as Sprite;if(s && s.x==16 && s.numChildren && s.getChildAt(0) is TextField && TextField(s.getChildAt(0)).text==title)return point(s,60,20);}return null;});
   ExternalInterface.addCallback("probeSkin",function():Object{var ui:Object=root["Interface"];var row:DisplayObjectContainer=ui ? find(ui["settings_ui"],"sddsSkin") as DisplayObjectContainer : null;return row ? point(row.getChildAt(1),50,10) : null;});
   ExternalInterface.addCallback("probeChoice",function(index:int):Object{var popup:Sprite=root.stage.getChildByName("sddsFixedDropdown") as Sprite;var layer:DisplayObjectContainer=popup ? Sprite(popup.getChildAt(0)).getChildAt(0) as DisplayObjectContainer : null;return layer ? point(layer.getChildAt(index),70,10) : null;});
   ExternalInterface.addCallback("probeState",function():Object{var ui:Object=root["Interface"];if(!ui)return {ready:false};var preview:Sprite=find(ui["settings_ui"],"astroSkinPreview") as Sprite;var art:DisplayObjectContainer=find(ui["settings_ui"],"astroSkinPreviewArt") as DisplayObjectContainer;return {logicalWidth:root.stage.stageWidth,logicalHeight:root.stage.stageHeight,scaleMode:root.stage.scaleMode,align:root.stage.align,ready:true,tab:ui["last_tab"],preview:preview?TextField(preview.getChildAt(0)).text:"",loaded:art && art.numChildren>0,localRouteButtons:find(ui["bot_ui"],"astroLocalRouteFiles")!=null};});
  }
 }
}
