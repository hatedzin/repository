package disney.standalone {
 import flash.display.MovieClip;
 import flash.events.Event;
 import flash.utils.ByteArray;
 import flash.utils.Dictionary;
 public class DeathOnOtherWin {
  private static var attached:Dictionary=new Dictionary(true);
  private var root:Object; private var bound:Object; private var round:String="";
  private var transition:Boolean=false;private var seen:Object={}; private var requested:Boolean=false; private var aliveBefore:Boolean=false;
  public function DeathOnOtherWin(target:Object){root=target;}
  public static function attach(target:MovieClip):void {
   if(!target || attached[target])return;
   var controller:DeathOnOtherWin=new DeathOnOtherWin(target);attached[target]=controller;
   target.addEventListener(Event.ENTER_FRAME,function(e:Event):void{controller.update();});controller.update();
  }
  public function update():void {
   try {
    var key:String=String(root.current_round_code)+":"+String(root.round_start_time)+":"+String(root.current_map_code);
    if(key!=round){round=key;transition=false;seen={};requested=false;aliveBefore=false;}
    var k:Object=root.Keys; var p:Object=null;
    if(k!=null){if(root.tfm!=null)p=root.tfm[k.player];}
    var alive:Boolean=false;if(p!=null)alive=!p[k.is_dead];
    if(alive && !aliveBefore && !transition)requested=false;aliveBefore=alive;
    var dispatcher:Object=k ? k.packet_handler_class : null;
    if(!dispatcher || dispatcher===bound)return;
    var previous:Function=dispatcher["astroRoomObserverV1"] as Function;
    dispatcher["astroRoomObserverV1"]=function(bytes:ByteArray):void {
     if(!bytes)return;var cursor:uint=bytes.position;
     var failure:Error=null;try{if(previous!=null)previous(bytes);}catch(e:Error){failure=e;}
     bytes.position=0;observe(bytes);bytes.position=cursor;if(failure!=null)throw failure;
    };bound=dispatcher;
   }catch(error:Error){}
  }
  public function observe(bytes:ByteArray):void {
   if(!bytes || bytes.length<2)return;
   var cursor:uint=bytes.position;
   try {
    bytes.position=0;var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
    if(c==5 && cc==2){seen={};transition=true;requested=true;aliveBefore=false;return;}
    if(c!=8 || cc!=6 || bytes.length<12)return;
    var order:int=bytes.readUnsignedByte();var winner:int=bytes.readInt();
    var score:int=bytes.readUnsignedShort();var place:int=bytes.readUnsignedByte();var time:int=bytes.readUnsignedShort();
    var eventId:String=winner+":"+order+":"+place+":"+time;
    if(seen[eventId])return;seen[eventId]=true;
    if(!root.insta_death || requested)return;
    var k:Object=root.Keys;var game:Object=root.tfm;
    var p:Object=null;if(k!=null){if(game!=null)p=game[k.player];}
    if(!p || p[k.is_dead] || p[k.player_id]==null || int(p[k.player_id])==winner)return;
    // Native command dispatcher of the embedded, supplied Transformice SWF.
    var command:String=String.fromCharCode(3,8,4,5,3,2,2,3,6,4,5,1,8);
    if(!(game[command] is Function))return;
    requested=true;game[command]("mort");
   }catch(error:Error){
    try {var status:Object=root.stage.getChildByName("sddsConnectionStatus");if(status)status.text="Morrer na toca: erro #"+error.errorID;}catch(ignored:Error){}
   }finally{bytes.position=cursor;}
  }
 }
}
