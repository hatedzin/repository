package disney {
 import flash.display.MovieClip;import flash.utils.*;import flash.events.*;import flash.net.*;import flash.external.ExternalInterface;import ChargeurTransformice_fla.MainTimeline;import disney.standalone.*;
 public class FeatureTests {
  private static var checks:int=0;private static var prior:Boolean=false;private static var route:Array=[[null,"cheese",0],[null,"hole",100]];
  private static function check(ok:Boolean,name:String):void{if(!ok)throw new Error(name);checks++;}
  private static function json(text:String):*{return com.adobe.serialization.json.JSON.decode(text);}
  private static function finish(value:String):void{if(ExternalInterface.available)ExternalInterface.call("recordTest",value);}
  private static function get(url:String,done:Function,body:Object=null):void{var loader:LocalURLLoader=new LocalURLLoader();var request:URLRequest=new URLRequest("astro:///"+url);if(body){request.method=URLRequestMethod.POST;var data:URLVariables=new URLVariables();for(var k:String in body)data[k]=body[k];request.data=data;}var status:int=0;loader.addEventListener(HTTPStatusEvent.HTTP_STATUS,function(e:HTTPStatusEvent):void{status=e.status;});loader.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void{finish("FAIL: "+e.text);});loader.addEventListener(Event.COMPLETE,function(e:Event):void{try{done(String(loader.data),status);}catch(error:Error){finish("FAIL: "+error.message+" #"+error.errorID);}});loader.load(request);}
  public static function run(display:MovieClip):void{try{
   MainTimeline.instance=display as MainTimeline;MainTimeline.instance.version="1.7";prior=LocalStore.storage().data.routes["@456"]!=null;
   var game:ByteArray=EmbeddedAssets.bytes("game");check(game.length==2035914,"original processed game embedded");check(String.fromCharCode(game[1],game[2])=="WS","game SWF signature");
   for each(var name:String in ["cj","bigsmoke","minecraft","gragas","banho","tortuguita"]){var png:ByteArray=EmbeddedAssets.bytes("l3v3"+name+".png");check(png && png[0]==137 && png[1]==80,"PNG bytes embedded "+name);}
   check(EmbeddedAssets.bytes("not-an-asset")==null,"unknown asset lookup");check(new RegExp("(.*?)(?:transformice|$)").exec("file:///C:/ASTRO-Independente.swf")!=null,"local file path matches safe initializer");
   get("get_keys",function(text:String,status:int):void{var data:Object=json(text);check(status==200 && data.success,"embedded key response");var symbols:Object=LocalStore.unpack(data.keys);check(symbols.player=="851718232374","matching exported symbol map");check(symbols.premium_level=="PLATINUM" && symbols.client_version=="1.7","local UI initialization metadata");
    get("github-routes?method=save",function(text:String,status:int):void{check(status==204,"SAVE only succeeds after local flush");
     get("github-routes?code=%40123",function(text:String,status:int):void{var data:Array=json(text) as Array;check(data && data.length==2 && data[1][1]=="hole","saved route read without HTTP");
      get("github-routes?method=draft",function(text:String,status:int):void{var data:Object=json(text);check(data.code=="@123" && data.route.length==2,"local draft restore");
       get("data",function(text:String,status:int):void{check(status==204,"configuration persisted");
        get("data?config",function(text:String,status:int):void{check(json(text).example==120,"configuration readback");
         get("mapstorage?method=del",function(text:String,status:int):void{check(status==204,"route deletion persisted");
          get("github-routes?code=%40123",function(text:String,status:int):void{check((json(text) as Array).length==0,"deleted route not returned");
           get("github-routes?method=save",function(text:String,status:int):void{check(status==204,"persistence sentinel stored");var canceled:LocalURLLoader=new LocalURLLoader();var called:Boolean=false;canceled.addEventListener(Event.COMPLETE,function(e:Event):void{called=true;});canceled.load(new URLRequest("astro:///data?config"));canceled.close();setTimeout(function():void{try{check(!called,"closed local loader discards stale callback");if(ExternalInterface.available)ExternalInterface.call("recordMeta",{priorPersisted:prior,count:checks});finish("PASS: "+checks+" standalone asset, local route and configuration assertions");}catch(error:Error){finish("FAIL: "+error.message);}},40);},{code:"@456",info:LocalStore.pack(route)});
          });
         },{code:"@123"});
        });
       },{config:'{"example":120}'});
      });
     });
    },{code:"@123",info:LocalStore.pack(route)});
   });
  }catch(error:Error){finish("FAIL: "+error.message+" #"+error.errorID);}}
 }
}
