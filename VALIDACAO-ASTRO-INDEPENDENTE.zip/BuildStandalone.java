import com.jpexs.decompiler.flash.*;import com.jpexs.decompiler.flash.tags.*;import com.jpexs.decompiler.flash.abc.*;import com.jpexs.decompiler.flash.abc.avm2.parser.script.*;import com.jpexs.helpers.ByteArrayRange;import com.jpexs.decompiler.flash.abc.avm2.instructions.AVM2Instruction;import java.io.*;import java.nio.file.*;import java.util.*;
class BuildStandalone {
 public static void main(String[]args)throws Exception{
  SWF swf=new SWF(new FileInputStream(args[0]),false);DoABC2Tag tag=null;for(Tag t:swf.getTags())if(t instanceof DoABC2Tag&&((DoABC2Tag)t).getABC().findClassByName("ChargeurTransformice_fla.MainTimeline")>=0)tag=(DoABC2Tag)t;
  if(tag==null)throw new Exception("Main ABC missing");ABC abc=tag.getABC();var idx=swf.getAbcIndex();idx.selectAbc(abc);int originalMethods=abc.method_info.size();
  SymbolClassTag symbols=new SymbolClassTag(swf);symbols.tags=new ArrayList<>();symbols.names=new ArrayList<>();
  List<Path> assets=Files.list(Path.of(args[1],"assets")).sorted(Comparator.comparingInt(p->Integer.parseInt(p.getFileName().toString()))).toList();
  for(Path asset:assets){int number=Integer.parseInt(asset.getFileName().toString());String name="StandaloneAsset"+number;compile(swf,abc,idx,Path.of(args[1],"src",name+".as"));DefineBinaryDataTag data=new DefineBinaryDataTag(swf);data.tag=swf.getNextCharacterId();data.binaryData=new ByteArrayRange(Files.readAllBytes(asset));swf.addTag(swf.indexOfTag(tag),data);symbols.tags.add(data.tag);symbols.names.add("disney.standalone."+name);}
  for(String name:List.of("EmbeddedAssets","LocalStore","LocalURLLoader","EmbeddedLoader"))compile(swf,abc,idx,Path.of(args[1],"src",name+".as"));
  int url=abc.constants.getQnameId("URLLoader",0x16,"flash.net",false),loader=abc.constants.getQnameId("Loader",0x16,"flash.display",false);
  int newUrl=abc.instance_info.get(abc.findClassByName("disney.standalone.LocalURLLoader")).name_index,newLoader=abc.instance_info.get(abc.findClassByName("disney.standalone.EmbeddedLoader")).name_index;
  int redirects=0;
  for(var body:abc.bodies)if(body.method_info<originalMethods){boolean modified=false;for(int oi=0;oi<body.getCode().code.size();oi++){var op=body.getCode().code.get(oi);int c=op.definition.instructionCode;if((c==0x60||c==0x5d||c==0x5e||c==0x4a)&&op.operands.length>0){if("URLLoader".equals(abc.constants.getString(abc.constants.getMultiname(op.operands[0]).name_index))){replace(body,oi,newUrl);modified=true;redirects++;}else if("Loader".equals(abc.constants.getString(abc.constants.getMultiname(op.operands[0]).name_index))){replace(body,oi,newLoader);modified=true;redirects++;}}}if(modified)body.setModified();}
  if(redirects<10)throw new Exception("Unexpected adapter count "+redirects);
  int fixed=0;for(int i=1;i<abc.constants.getStringCount();i++){String s=abc.constants.getString(i);if("(.*?)transformice".equals(s)){abc.constants.setString(i,"(.*?)(?:transformice|$)");fixed++;}else if("http://127.0.0.1:8080/".equals(s))abc.constants.setString(i,"astro:///");else if(s.contains("no GitHub; reative o Robot"))abc.constants.setString(i,s.replace("no GitHub","neste computador"));else if(s.equals("publicando no GitHub "))abc.constants.setString(i,"salvando neste computador ");else if(s.contains("clique SAVE para publicar"))abc.constants.setString(i,s.replace("para publicar","para salvar"));}
  if(fixed!=1)throw new Exception("File-path initializer not fixed: "+fixed);
  // Add local route file controls after all native helper startup hooks.
  String bridge="package disney.standalone { import flash.display.MovieClip; public class StandaloneReady { public static function attach(root:MovieClip):void { disney.SettingsControlsV5.attach(root); LocalStore.install(root); } } }";
  new ActionScript3Parser(idx).addScript(bridge,"StandaloneReady.as",abc.instance_info.size(),abc.script_info.size(),swf.getDocumentClass(),abc);
  int old=abc.instance_info.get(abc.findClassByName("disney.SettingsControlsV5")).name_index,replacement=abc.instance_info.get(abc.findClassByName("disney.standalone.StandaloneReady")).name_index,count=0;var startup=abc.findBody(86);
  for(var op:startup.getCode().code)if(op.definition.instructionCode==0x60&&op.operands[0]==old){op.operands[0]=replacement;count++;}if(count!=1)throw new Exception("Startup hook mismatch "+count);startup.setModified();
  for(Tag ft:swf.getTags())if(ft instanceof FileAttributesTag){((FileAttributesTag)ft).useNetwork=true;ft.setModified(true);}
  swf.addTag(swf.indexOfTag(tag)+1,symbols);tag.setModified(true);swf.setModified(true);try(var out=new FileOutputStream(args[2])){swf.saveTo(out);}System.out.println("Embedded "+assets.size()+" original assets; redirected "+redirects+" loader operations; standalone startup installed.");
 }
 static void replace(com.jpexs.decompiler.flash.abc.types.MethodBody body,int i,int value){var old=body.getCode().code.get(i);int[] operands=old.operands.clone();operands[0]=value;body.getCode().replaceInstruction(i,new AVM2Instruction(0,old.definition.instructionCode,operands),body);}
 static void compile(SWF swf,ABC abc,com.jpexs.decompiler.flash.abc.avm2.parser.script.AbcIndexing idx,Path p)throws Exception{new ActionScript3Parser(idx).addScript(Files.readString(p),p.getFileName().toString(),abc.instance_info.size(),abc.script_info.size(),swf.getDocumentClass(),abc);}
}
