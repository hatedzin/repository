package disney.standalone {
 import flash.display.Loader;import flash.net.URLRequest;import flash.system.LoaderContext;import flash.utils.ByteArray;
 public class EmbeddedLoader extends Loader {
  override public function load(request:URLRequest,context:LoaderContext=null):void{
   var url:String=request.url.replace(/^astro:\/\/\//,"");var bytes:ByteArray;
   if(url.indexOf("transformice?")==0 && url.indexOf("swf")>=0)bytes=EmbeddedAssets.bytes("game");
   else if(url.indexOf("images/")==0)bytes=EmbeddedAssets.bytes(url.substr(7).split("?")[0]);
   if(bytes){loadBytes(bytes,context);return;}super.load(request,context);
  }
 }
}
