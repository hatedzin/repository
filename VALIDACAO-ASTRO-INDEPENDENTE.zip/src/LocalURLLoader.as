package disney.standalone {
 import flash.net.*;import flash.events.*;import flash.utils.*;
 public class LocalURLLoader extends URLLoader {
  private var local:Boolean=false;private var generation:uint=0;
  public function LocalURLLoader(request:URLRequest=null){super();if(request)load(request);}
  override public function load(request:URLRequest):void{
   local=request.url.indexOf("astro:///")==0 || !/^[a-z]+:\/\//i.test(request.url);if(!local){super.load(request);return;}var turn:uint=++generation;
   setTimeout(function():void{if(turn!=generation)return;try{var answer:Object=LocalStore.route(request);var success:Function=function():void{if(turn!=generation)return;data=String(answer.text);dispatchEvent(new HTTPStatusEvent(HTTPStatusEvent.HTTP_STATUS,false,false,int(answer.status)));if(answer.status>=400){dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,String(answer.text)));return;}dispatchEvent(new ProgressEvent(ProgressEvent.PROGRESS,false,false,String(data).length,String(data).length));dispatchEvent(new Event(Event.COMPLETE));};var failed:Function=function():void{if(turn==generation)dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"O Flash nao autorizou salvar os dados locais."));};if(answer.write)LocalStore.commit(success,failed);else success();}catch(error:Error){dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"Dados locais indisponiveis: "+error.message));}},1);
  }
  override public function close():void{generation++;if(!local)super.close();}
 }
}
