package disney.standalone {
 import flash.net.*;import flash.events.*;import flash.utils.*;import flash.display.*;import flash.text.*;import flash.external.ExternalInterface;import ChargeurTransformice_fla.MainTimeline;import com.hurlant.util.Base64;
 public class LocalStore {
  private static var disk:SharedObject;
  public static function storage():SharedObject{if(!disk)disk=SharedObject.getLocal("astroStandaloneV4");if(!disk.data.routes)disk.data.routes={};if(!disk.data.config)disk.data.config={};if(!disk.data.soft)disk.data.soft={};return disk;}
  public static function pack(value:*):String{var b:ByteArray=new ByteArray();b.writeUTFBytes(com.adobe.serialization.json.JSON.encode(value));b.compress();return Base64.encodeByteArray(b);}
  public static function unpack(value:String):*{var b:ByteArray=Base64.decodeToByteArray(value);b.uncompress();return com.adobe.serialization.json.JSON.decode(b.readUTFBytes(b.length));}
  private static function form(q:URLRequest):Object{if(q.data is URLVariables)return q.data;if(q.data is String)return new URLVariables(q.data);return q.data || {};}
  public static function route(req:URLRequest):Object{
   var url:String=req.url.replace(/^astro:\/\/\//,"");var parts:Array=url.split("?");var path:String=String(parts[0]).replace(/^\//,"");var query:Object={};if(parts.length>1)for each(var item:String in parts.slice(1).join("?").split("&")){if(item=="")continue;var at:int=item.indexOf("=");var key:String=decodeURIComponent((at<0 ? item : item.substr(0,at)).replace(/\+/g," "));query[key]=at<0 ? "" : decodeURIComponent(item.substr(at+1).replace(/\+/g," "));}var payload:Object=form(req);var db:SharedObject=storage();var root:MainTimeline=MainTimeline.instance;
   if(path=="get_keys"){
    if(ExternalInterface.available)try{ExternalInterface.addCallback("astroStandaloneStatus",function():Object{var missing:Array=[];var k:Object=root["Keys"];for each(var name:String in ["ui_element_class","prep_ui_class","prep_ui1_instance","prep_ui4_instance","set_prep_ui","add_ui_element","ui_items_list_class","select_item"])if(!k || !k[name])missing.push(name);var field:TextField=root.stage.getChildByName("disneyMenuStatus") as TextField;return {embeddedGameLoaded:root.game_loaded,menuReady:root["Interface"]!=null && root["Interface"]["menu_ui"]!=null && root["Interface"]["menu_ui"].name=="disneyModernPanel",host:root.host_url,standalone:true,missing:missing,menuStatus:field?field.text:""};});}catch(ignored:Error){}

    var symbols:Object=com.adobe.serialization.json.JSON.decode(EmbeddedAssets.text("symbols"));symbols.maps_allowed=true;symbols.client_version=root.version;symbols.premium_level="PLATINUM";symbols.discord=[];root.soft_list=db.data.soft;return {status:200,text:com.adobe.serialization.json.JSON.encode({success:true,keys:pack(symbols)})};
   }
   if(path=="data"){
    if(req.method==URLRequestMethod.POST){if(payload.config!=null)db.data.config=com.adobe.serialization.json.JSON.decode(String(payload.config));else if(payload.soft!=null)db.data.soft=unpack(String(payload.soft));else return {status:400,text:"{}"};return {status:204,text:"",write:true};}
    if(query.config!=null)return {status:200,text:com.adobe.serialization.json.JSON.encode(db.data.config)};
    if(query["protected"]!=null)return {status:200,text:EmbeddedAssets.text("protected")};
    if(query.record_list!=null)return {status:200,text:EmbeddedAssets.text("record_list")};
    if(query.soft!=null)return {status:200,text:pack(db.data.soft)};
    return {status:200,text:"{}"};
   }
   if(path=="github-routes"){
    if(query.method=="draft")return {status:200,text:com.adobe.serialization.json.JSON.encode(db.data.draft || {})};
    if(query.method=="status")return {status:200,text:com.adobe.serialization.json.JSON.encode({configured:true,reason:"local",draft_saved:db.data.draft!=null})};
    if(query.method=="save"){
     var code:String=String(payload.code);if(!/^@[1-9][0-9]*$/.test(code))return {status:400,text:"{}"};var steps:* =unpack(String(payload.info));if(!(steps is Array) || steps.length==0)return {status:400,text:"{}"};
     db.data.routes[code]=steps;db.data.draft={code:code,route:steps};return {status:204,text:"",write:true};
    }
    var map:String=String(query.code);return {status:200,text:com.adobe.serialization.json.JSON.encode(db.data.routes[map] || [])};
   }
   if(path=="mapstorage"){
    if(query.method=="del"){delete db.data.routes[String(payload.code)];return {status:204,text:"",write:true};}
    if(query.method=="ls"){var list:Array=[];for(var name:String in db.data.routes)list.push(name);return {status:200,text:list.join(", ")};}
    var records:Array=[];for(var key:String in db.data.routes)records.push(key+":"+com.adobe.serialization.json.JSON.encode(db.data.routes[key]));var data:ByteArray=new ByteArray();data.writeUTFBytes(records.join("#"));data.compress();return {status:200,text:Base64.encodeByteArray(data)};
   }
   if(path=="client_diagnostics" || path=="tfmlogin")return {status:204,text:""};
   if(path=="locales")return {status:200,text:"{}"};
   return {status:503,text:com.adobe.serialization.json.JSON.encode({success:false,error:"Disponivel apenas na versao com servidor.",status:"failed",message:"Recurso indisponivel no modo independente."})};
  }
  public static function commit(done:Function,failed:Function):void{
   try{var result:String=storage().flush();if(result==SharedObjectFlushStatus.FLUSHED){done();return;}var onStatus:Function=function(e:NetStatusEvent):void{storage().removeEventListener(NetStatusEvent.NET_STATUS,onStatus);if(e.info.code=="SharedObject.Flush.Success")done();else failed();};storage().addEventListener(NetStatusEvent.NET_STATUS,onStatus);}catch(error:Error){failed();}
  }
  public static function install(root:MovieClip):void{
   if(!root || !root.stage)return;var nextMenu:int=0;var attempts:int=0;root.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{
    var ui:Object=root["Interface"];var built:DisplayObject=ui ? ui["menu_ui"] as DisplayObject : null;
    if(!ui || !built || built.name!="disneyModernPanel"){if(getTimer()>=nextMenu && attempts<60){nextMenu=getTimer()+1000;attempts++;var open:DisplayObject=root.stage.getChildByName("disneyMenuButton");if(open)open.dispatchEvent(new MouseEvent(MouseEvent.CLICK,true));}return;}
    var menuMessage:TextField=root.stage.getChildByName("disneyMenuStatus") as TextField;if(menuMessage)menuMessage.text="";
    var bot:DisplayObjectContainer=ui ? ui["bot_ui"] as DisplayObjectContainer : null;if(!bot || bot.getChildByName("astroLocalRouteFiles"))return;
    var bar:Sprite=new Sprite();bar.name="astroLocalRouteFiles";bar.y=Math.max(230,bot.getBounds(bot).bottom+10);bot.addChild(bar);
    var make:Function=function(title:String,x:Number,callback:Function):void{var b:Sprite=new Sprite();b.x=x;b.graphics.beginFill(0x292C35);b.graphics.drawRoundRect(0,0,146,24,6);b.graphics.endFill();var t:TextField=new TextField();t.defaultTextFormat=new TextFormat("Segoe UI",11,0xE6E8EF);t.text=title;t.x=8;t.y=3;t.width=136;t.height=21;t.mouseEnabled=false;b.addChild(t);b.buttonMode=true;b.mouseChildren=false;b.addEventListener(MouseEvent.CLICK,function(e:MouseEvent):void{callback();e.stopImmediatePropagation();});bar.addChild(b);};
    make("Exportar rotas JSON",0,function():void{try{new FileReference().save(com.adobe.serialization.json.JSON.encode(storage().data.routes),"rotas-astro.json");}catch(ignored:Error){}});
    make("Importar rotas JSON",156,function():void{var file:FileReference=new FileReference();file.addEventListener(Event.SELECT,function(e:Event):void{file.load();});file.addEventListener(Event.COMPLETE,function(e:Event):void{try{var values:Object=com.adobe.serialization.json.JSON.decode(file.data.readUTFBytes(file.data.length));if(!values || values is Array)return;var changed:Object={};for(var key:String in values){if(/^@[1-9][0-9]*$/.test(key) && values[key] is Array){var steps:Array=disney.RobotRoute.validate(values[key] as Array);storage().data.routes[key]=steps;changed[key]=steps;}}storage().flush();disney.RobotControllerV6.get(root).setRoutes(changed);}catch(ignored:Error){}});file.browse([new FileFilter("Rotas JSON","*.json")]);});
   },false,-10000);
  }
 }
}
