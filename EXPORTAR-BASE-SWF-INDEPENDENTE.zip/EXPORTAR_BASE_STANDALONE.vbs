Option Explicit
Dim fso, shell, base, project, pyw, script
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)
project = base
If fso.FolderExists(fso.BuildPath(base, "DisneyClient-Local-Robot-Novo")) Then project = fso.BuildPath(base, "DisneyClient-Local-Robot-Novo")
pyw = fso.BuildPath(project, ".client-runtime\Scripts\pythonw.exe")
script = fso.BuildPath(base, "EXPORTAR_BASE_STANDALONE.pyw")
If fso.FileExists(pyw) Then
  shell.Run """" & pyw & """ """ & script & """", 1, False
Else
  MsgBox "Abra EXPORTAR_BASE_STANDALONE.pyw com o Python instalado, ou coloque estes arquivos ao lado de INICIAR_TUDO.bat na instalacao preparada.", 64, "ASTRO"
End If
