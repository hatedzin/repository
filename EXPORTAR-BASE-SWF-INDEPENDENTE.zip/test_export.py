from pathlib import Path
import importlib.machinery,importlib.util,tempfile,threading,http.server,json,zipfile,hashlib
loader=importlib.machinery.SourceFileLoader('exporter','/workspace/astro-standalone/EXPORTAR_BASE_STANDALONE.pyw');spec=importlib.util.spec_from_loader(loader.name,loader);m=importlib.util.module_from_spec(spec);loader.exec_module(m)
state={'mode':'ok','reads':0,'auth':0}
token='fixture-parser-token-not-for-distribution'
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  if self.headers.get('Authorization')!='Bearer '+token:self.send_error(401);return
  state['auth']+=1
  if self.path=='/api/tfm_keys':
   value={'player':'mouse','ui_element_class_name':'UI','packet_handler_class_name':'Packets'}
   if state['mode']=='changing':state['reads']+=1;value['version']=state['reads']
   if state['mode']=='secret':value['github_token']='unexpected-sensitive-value'
   data=json.dumps(value).encode()
  else:data=b'not a SWF' if state['mode']=='invalid' else b'FWS\x0a\x08\x00\x00\x00'
  self.send_response(200);self.end_headers();self.wfile.write(data)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory(dir='/workspace/astro-standalone') as t:
  p=Path(t);(p/'DisneyClient').mkdir();(p/'DisneyParser').mkdir();(p/'DisneyClient/.env').write_text('CLIENT_PARSER_PORT='+str(server.server_port)+'\nTFM_PARSER_API_TOKEN='+token+'\nMYSQL_PASSWORD=fixture-database-secret\n')
  out=p/'base.zip';manifest=m.export_base(p,out)
  with zipfile.ZipFile(out) as z:
   assert set(z.namelist())=={'Transformice-processado.swf','simbolos-jogo.json','manifesto.json'}
   for name,h in manifest['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==h
   assert all(token.encode() not in z.read(n) and b'fixture-database-secret' not in z.read(n) for n in z.namelist())
  assert state['auth']==3;print('PASS consistent snapshot exported with verified hashes and authenticated local requests')
  print('PASS no account settings, parser token, PAT or database credentials in the ZIP')
  old=out.read_bytes()
  for mode in ['secret','changing','invalid']:
   state['mode']=mode
   try:m.export_base(p,out)
   except m.ExportError:pass
   else:raise AssertionError(mode+' should fail')
   assert out.read_bytes()==old and not out.with_name(out.name+'.partial').exists();print('PASS rejects '+mode+' while preserving existing output')
  assert m.project_at(p)==p;assert m.project_at(p/'not-a-project') is None;print('PASS project detection and invalid-folder handling')
finally:server.shutdown();server.server_close()
