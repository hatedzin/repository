# Exportar a base para montar a SWF independente

Este pacote NAO e a SWF independente. E somente uma coleta temporaria dos arquivos que nao acompanham o ZIP do client.

1. Deixe o client atual aberto e espere o parser ficar pronto.
2. Extraia estes dois arquivos ao lado de INICIAR_TUDO.bat na pasta do client.
3. Abra EXPORTAR_BASE_STANDALONE.vbs. Sera aberta uma janela Python, sem console. Se necessario, abra o .pyw com o Python instalado.
4. Clique em Exportar base, escolha onde salvar e envie BASE-PARA-SWF-INDEPENDENTE.zip na conversa.

A coleta nao inicia servidores nem altera o client. Consulta somente o parser em 127.0.0.1 e exporta o jogo processado, o mapeamento de simbolos correspondente e os hashes. Nao copia .env, tokens do parser, senha MySQL ou PAT do GitHub. Respostas com credenciais inesperadas sao recusadas. Isso sera necessario apenas para preparar a nova versao; nao e um iniciador oculto para o produto final.

O jogo online continuara precisando da internet e dos servidores do jogo mesmo em um arquivo SWF independente. A versao final ainda precisa ser implementada e testada depois da coleta; este exportador nao prova que ela ja funciona.

Validacao: seis verificacoes com servidor HTTP controlado, incluindo consistencia, autenticacao local, exclusao de credenciais, rejeicao de base alterada durante a coleta e preservacao de arquivo anterior. A janela e o VBS ainda nao foram executados no Windows nesta sessao.
