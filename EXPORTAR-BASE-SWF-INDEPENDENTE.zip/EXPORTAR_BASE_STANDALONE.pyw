"""Collect only the processed game and public symbol map; never copy account settings."""
from pathlib import Path
import hashlib,json,queue,threading,urllib.request,urllib.error,zipfile
from datetime import datetime,timezone

REQUIRED=('player','ui_element_class_name','packet_handler_class_name')
class ExportError(Exception):pass

def project_at(path):
    base=Path(path)
    for p in (base,base/'DisneyClient-Local-Robot-Novo'):
        if (p/'DisneyClient').is_dir() and (p/'DisneyParser').is_dir():return p
    return None

def settings(path):
    result={}
    if path.is_file():
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            line=line.strip()
            if not line or line.startswith('#'):continue
            if line.startswith('export '):line=line[7:]
            k,sep,v=line.partition('=')
            if sep:result[k.strip()]=v.strip().strip('"\'')
    return result

def read_local(url,token,limit,timeout=20):
    request=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
    # A local export must never send credentials through a configured web proxy.
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request,timeout=timeout) as response:
        data=response.read(limit+1)
        if len(data)>limit:raise ExportError('Resposta maior que o limite de exportacao.')
        return data

def export_base(project,destination,progress=lambda text:None):
    project=Path(project);env=settings(project/'DisneyClient/.env')
    try:port=int(env.get('CLIENT_PARSER_PORT','8090'))
    except ValueError:raise ExportError('CLIENT_PARSER_PORT invalida no .env.')
    if not 1<=port<=65535:raise ExportError('Porta local invalida.')
    token=env.get('TFM_PARSER_API_TOKEN','')
    if not token:
        try:
            values=json.loads((project/'DisneyParser/tokens.json').read_text(encoding='utf-8-sig'))
            if isinstance(values,list) and values and isinstance(values[0],str):token=values[0]
        except (OSError,ValueError):pass
    if not token:raise ExportError('Abra o client atual primeiro para preparar o parser local.')
    endpoint='http://127.0.0.1:'+str(port)
    def symbols():
        data=json.loads(read_local(endpoint+'/api/tfm_keys',token,2*1024*1024).decode('utf-8-sig'))
        if not isinstance(data,dict) or not all(isinstance(data.get(k),str) and data[k] for k in REQUIRED):raise ExportError('O parser ainda nao terminou de preparar o jogo.')
        return data
    for attempt in range(3):
        progress('Coletando mapeamento da versao atual...');before=symbols()
        progress('Coletando a SWF processada...');game=read_local(endpoint+'/transformice?swf',token,32*1024*1024,40)
        if len(game)<8 or game[:3] not in (b'FWS',b'CWS',b'ZWS'):raise ExportError('O parser nao entregou uma SWF valida.')
        after=symbols()
        if before==after:break
    else:raise ExportError('O jogo foi atualizado durante a coleta. Tente novamente.')
    # Parser responses contain symbol mappings. Reject accidental credentials rather than export them.
    forbidden={'access_token','flash_token','github_token','github_pat','password','mysql_password','tfm_parser_api_token'}
    def credentials(value):
        if isinstance(value,dict):
            return any(str(k).lower() in forbidden or credentials(v) for k,v in value.items())
        if isinstance(value,list):return any(credentials(v) for v in value)
        return isinstance(value,str) and (value==token or 'github_pat_' in value or 'ghp_' in value)
    if credentials(after):raise ExportError('A resposta contem credenciais inesperadas; exportacao cancelada.')
    data=json.dumps(after,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8')
    manifest={'format':'astro-standalone-base-v1','created_utc':datetime.now(timezone.utc).isoformat(),'files':{'Transformice-processado.swf':hashlib.sha256(game).hexdigest(),'simbolos-jogo.json':hashlib.sha256(data).hexdigest()},'symbol_count':len(after),'note':'No account settings, PAT, parser token or .env included.'}
    destination=Path(destination);temporary=destination.with_name(destination.name+'.partial')
    progress('Gerando ZIP sem copiar .env, senhas ou tokens...')
    try:
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as out:
            out.writestr('Transformice-processado.swf',game);out.writestr('simbolos-jogo.json',data);out.writestr('manifesto.json',json.dumps(manifest,indent=2))
        temporary.replace(destination)
    finally:
        if temporary.exists():temporary.unlink()
    return manifest

def main():
    import tkinter as tk
    from tkinter import filedialog,messagebox
    root=tk.Tk();root.title('ASTRO - exportar base da SWF');root.geometry('570x240');root.resizable(False,False);root.configure(bg='#17191f')
    tk.Label(root,text='Base para a SWF independente',font=('Segoe UI',16,'bold'),fg='#f1f2f6',bg='#17191f').pack(anchor='w',padx=24,pady=(24,12))
    tk.Label(root,text='Deixe o client atual aberto e o parser pronto.\nA coleta salva o jogo processado e o mapeamento de simbolos.',justify='left',font=('Segoe UI',10),fg='#b9bdc9',bg='#17191f').pack(anchor='w',padx=24)
    status=tk.StringVar(value='Escolha onde salvar a base e clique em Exportar.')
    tk.Label(root,textvariable=status,wraplength=520,justify='left',font=('Segoe UI',10),fg='#f18a92',bg='#17191f').pack(anchor='w',padx=24,pady=14)
    events=queue.Queue()
    def start():
        project=project_at(Path(__file__).resolve().parent)
        if project is None:
            selected=filedialog.askdirectory(title='Selecione a pasta onde esta INICIAR_TUDO.bat')
            if not selected:return
            project=project_at(selected)
        if project is None:messagebox.showerror('Pasta nao encontrada','Selecione a pasta que contem DisneyClient e DisneyParser.');return
        destination=filedialog.asksaveasfilename(title='Salvar base da SWF',initialfile='BASE-PARA-SWF-INDEPENDENTE.zip',defaultextension='.zip',filetypes=[('Arquivo ZIP','*.zip')])
        if not destination:return
        button.configure(state='disabled')
        def worker():
            try:export_base(project,destination,lambda text:events.put(('progress',text)));events.put(('done',destination))
            except urllib.error.HTTPError as e:events.put(('error','O parser local respondeu HTTP '+str(e.code)+'. Aguarde Client pronto no iniciador atual.'))
            except (urllib.error.URLError,TimeoutError,OSError):events.put(('error','Nao foi possivel consultar o parser local. Deixe o client atual aberto e tente novamente.'))
            except (ValueError,ExportError) as e:events.put(('error',str(e)))
            except Exception:events.put(('error','Falha na coleta. Nenhuma configuracao pessoal foi exportada.'))
        threading.Thread(target=worker,daemon=True).start()
    button=tk.Button(root,text='Exportar base',command=start,font=('Segoe UI',10,'bold'),bg='#b94c58',fg='white',relief='flat',padx=18,pady=6);button.pack(anchor='e',padx=24)
    def poll():
        try:
            while True:
                kind,text=events.get_nowait();status.set(text)
                if kind=='done':button.configure(state='normal');status.set('ZIP criado. Envie esse arquivo na conversa.');messagebox.showinfo('Base exportada','Arquivo criado:\n'+text+'\n\nEnvie esse ZIP na conversa.')
                elif kind=='error':button.configure(state='normal');messagebox.showerror('Nao foi possivel exportar',text)
        except queue.Empty:pass
        root.after(100,poll)
    root.after(100,poll);root.mainloop()
if __name__=='__main__':main()
