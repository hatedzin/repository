"""Original Disney parser, with a separate HTTP/runtime lifecycle."""
