from aiohttp import web
from DisneyClient.swf_assets import inspect_file

class Transformice(web.View):
    async def get(self):
        if 'swf' not in self.request.query:
            raise web.HTTPNoContent()
        path = self.request.app['parser'].swf
        try:
            inspect_file(path)
        except (OSError, ValueError):
            return web.json_response({'error': 'swf_unavailable'}, status=503)
        return web.FileResponse(path, headers={'Content-Type': 'application/x-shockwave-flash', 'Cache-Control': 'no-store'})
