import hmac
from aiohttp import web

class TfmKeys(web.View):
    async def get(self):
        auth = self.request.headers.get('Authorization', '').split()
        if len(auth) != 2 or auth[0].lower() != 'bearer':
            return web.json_response({'error': 'invalid credentials'}, status=400)
        if not any(hmac.compare_digest(auth[1].encode(), token.encode()) for token in self.request.app['tokens']):
            return web.json_response({'error': 'unauthorized token'}, status=401)
        parser = self.request.app['parser']
        status = parser.metadata()
        if not status['symbols_ready']:
            return web.json_response({'error': 'symbols_unavailable', 'reason': status['extractor_error']}, status=503)
        return web.json_response(parser.fetched)
