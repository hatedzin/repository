# Restauração do fluxo original DisneyClient

## Origem e seleção dos arquivos

A aplicação foi restaurada da cópia DisneyClient-corrigido.zip enviada como
funcional. O loader public/ChargeurTransformice.swf permaneceu idêntico, SHA256
b4e7b6e2e999430c5e5ee99d5e68af9e73182fa41535996b1fd448fc8a2321cc.
O NovoClient-base e a source ChargeurTransformice separada não são usados.

A SWF mais nova desse upload produziu 109 símbolos, mas faltaram socket_name e
read_data. O teste real do loader apresentou ReferenceError #1069 em loop_game.
O disassembly mostrou que o código esperava o nome do campo Socket; o extrator
antigo não encontrou esse nome na estrutura da SWF mais nova. Nenhum valor foi
inventado ou preenchido por semelhança.

Comparei a SWF contida no primeiro DisneyClient-main.zip enviado: nela os mesmos
extratores produzem 118 símbolos e os campos de socket estão presentes. O jogo
selecionado é essa cópia anterior, SHA256
06e31fbbee5a18b507f6756b2a822a8b3fec43de182db1f779423439c8d53501.
As versões mais novas foram preservadas intactas em snapshots/newer-upload.
UPLOAD_MANIFEST.json comprova seus hashes. BASELINE_MANIFEST.json e
ASSET_SELECTION.json identificam os arquivos selecionados e sua proveniência.

Essa seleção estabelece uma base antiga compatível com a extração, não uma
versão atualizada aceita pelo servidor oficial. Não foi substituído conteúdo
em silêncio: a seleção e os arquivos originais preservados estão documentados.

## Mudanças de integração

- Reutilizadas página, rotas, autenticação MySQL e loader compilado do Disney.
- Campo da key limitado a 256 caracteres e espaços nas pontas removidos no envio.
- Parser HTTP separado dos imports circulares e dos objetos globais de main.py.
- Parser lê primeiro a SWF local e extrai os símbolos usando os módulos originais,
  sem modificar suas regras nem executar downloads automáticos.
- Subprocesso swfdump passou a ser assíncrono, com timeout e cancelamento/fechamento.
- Perfil é associado ao hash da SWF. Cache incompatível ou mínimo incompleto não é
  apresentado como pronto. O endpoint retorna 503 com diagnóstico nesses casos.
- Perfil real de 118 símbolos incluído em DisneyParser/.cache/symbols.json. Não
  contém credenciais, tokens de sessão ou keys de licença. Permite inicializar
  esse snapshot sem executar o extrator novamente na máquina do usuário.
- Nenhuma SWF foi patchada. Download/atualização automática ficou desativado por
  padrão para não misturar o loader preservado com uma versão nova incompatível.
- Health e diagnóstico local distinguem arquivos, banco, parser e símbolos.
- run_disney.py inicia parser e backend, reutiliza o .env, configura o token local
  sem exibir valores, abre o login e encerra somente os processos que iniciou.
- Não há dependência de Discord, Google Sheets, Adobe Animate ou porta 8082 nesse
  fluxo. Executar SWF ainda requer um runtime compatível com o jogo.

## Evidência executada

28 testes automatizados passaram com Python 3.11 e MySQL 8.4, incluindo os 22
fluxos existentes e seis verificações de parser/loader/restauração. O teste de
contrato HTTP isolado usa símbolos de teste identificados; ele não é evidência de
funcionamento do jogo. Há também validação separada com arquivos e símbolos reais.

A ferramenta nativa swfdump foi compilada do repositório do autor
https://github.com/matthiaskramm/swftools, commit
56a672207ac699e63908557b8888087f33e72fd4, com configure --disable-lame,
make -j2 librfxswf.a libbase.a e make -j2 swfdump. Componentes PDF/imagem não usados
foram desativados pelo configure por falta de bibliotecas; o disassembler compilou.
O swfdump.exe fornecido no upload continua preservado para o Windows. Não houve
alteração de verificação TLS, assinaturas ou checksums para fazer instalação passar.

A extração real foi executada nos dois snapshots. O perfil selecionado contém
118 símbolos; o snapshot mais novo fica marcado como incompleto por faltar os
campos obrigatórios. Evidência em evidence/newer-snapshot-diagnostics.json.

Com uma licença temporária do banco de teste, o launcher iniciou os dois serviços.
O loader original executou no Chromium/Ruffle e fez requisições reais ao backend:
- loader: HTTP 200, hash original;
- /get_keys: HTTP 200, perfil de 118 símbolos realmente extraídos;
- SWF do jogo: HTTP 200, hash do snapshot selecionado;
- configuração, dados protegidos, records e mapas: HTTP 200.
O teste confirmou ausência do #1069 de loop_game no período observado após carregar
o jogo. Isso não substitui um teste longo ou uma partida. O relay de mesma origem
usado pelo harness só facilita o Fetch do emulador; não modifica autenticação,
conteúdo ou respostas do backend. Querystrings/credenciais foram removidas dos logs.

O launcher também foi encerrado por SIGINT e fechou seus dois processos sem avisos
de conexões HTTP abertas. O código tem tratamento para CTRL_BREAK no Windows,
mas esse caminho específico não foi executado em Windows nativo.

## Limitações que permanecem

O teste visual parou na abertura de sockets: Ruffle não tinha proxy WebSocket
para os servidores do jogo. Os downloads externos de imagens também estavam
bloqueados no harness. Não foi validado login, uma partida no servidor oficial,
compatibilidade da versão antiga com o protocolo atual, Fly, salto alto, Robot
ou qualquer outro recurso durante uma partida. A captura do logo não é prova de
jogo funcional; os logs registram as limitações do runtime.

A SWF do jogo tem formato 14, referência Flash 11.1 ou superior. O label Flash
Player 10 visto nas imagens do usuário não comprova suporte a esse jogo. Não foi
incluído executável de Flash de terceiros nem prometida compatibilidade com ele.
Não foram implementados bypasses de proteção, autenticação ou desconexão do servidor.

## Entrega

O pacote não inclui o .env de nenhuma máquina, tokens.json real, credenciais Google,
keys completas, senhas ou dumps do banco. O usuário deve reutilizar seu próprio .env
e banco existentes. Não é necessário recriar o SQL ou gerar novas licenças.
O launcher cria/reutiliza a configuração privada do parser somente na máquina local.
Os exemplos têm campos secretos vazios. A restauração está preparada para repetir
o fluxo original, com os limites acima; não é um cliente novo completo validado.
