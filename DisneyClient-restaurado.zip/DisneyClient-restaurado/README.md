# DisneyClient — retorno ao loader original

Esta entrega retoma o DisneyClient enviado pelo usuário. Não usa o NovoClient-base,
a source ChargeurTransformice separada, a porta 8082 nem o downloader direto do site.
O loader compilado original foi preservado sem alterar nenhum byte.

## Windows / XAMPP

1. Extraia em uma pasta nova.
2. Copie seu `.env` que já funciona para `DisneyClient/.env` dentro desta pasta.
   Mantenha MYSQL_*, ADMIN_PASSWORD_HASH e suas credenciais; não publique o arquivo.
   Se ainda não possui configuração, copie `.env.xampp.example` para `.env` e
   configure o banco local. Não sobrescreva um `.env` existente.
3. Ligue o MySQL no XAMPP. Não precisa recriar o banco nem as keys existentes.
4. Feche os terminais antigos de server.py/main.py para liberar 8080 e 8090.
5. Abra um terminal na raiz desta entrega e execute, um por vez:

```cmd
python -m pip install -r requirements.txt
python run_disney.py
```

O launcher abre a página de login em `http://127.0.0.1:8080`. Também pode usar
`iniciar_disney.cmd` depois da instalação. Entre com sua key existente e use a URL
que a própria página retorna no seu projector Flash compatível.

**Não abra NovoClient.swf e não execute serve_client.py nesse fluxo.**
O programa inicia o parser e o backend juntos. A chave de comunicação do parser é
configurada localmente sem exibi-la e sem sobrescrever o `.env`. Os tokens são
conservados em `DisneyParser/tokens.json`, um arquivo privado gerado localmente.
O launcher mantém esse token nos processos iniciados; para executar manualmente os
serviços, configure os mesmos bindings do jeito descrito no guia Windows anterior.

Ctrl+C encerra os processos iniciados pelo launcher. Ele não encerra servidores
anteriores: se uma porta estiver ocupada, pede para fechar o terminal antigo.

## Par de SWF e perfil escolhido

A cópia mais nova enviada tinha uma SWF cujo parser extraía 109 símbolos, mas não
`socket_name` e `read_data`. O loader original lançava #1069 em loop_game com ela.
A SWF do primeiro ZIP enviado gera 118 símbolos e contém esses campos. Esta é a
referência selecionada para estabelecer novamente o carregamento original.

- Loader: original, SHA256 iniciado por `b4e7b6e2e99`, sem alterações.
- Jogo selecionado: primeiro ZIP, SHA256 iniciado por `06e31fbbee5a`, sem patches.
- Perfil real de 118 símbolos: `DisneyParser/.cache/symbols.json`, ligado ao hash
  dessa SWF. Não é uma key de licença e não contém credenciais do usuário.
- SWFs da cópia mais nova: preservadas intactas em `snapshots/newer-upload`.
- Proveniência e hashes completos: `ASSET_SELECTION.json`, `BASELINE_MANIFEST.json`
  e `UPLOAD_MANIFEST.json`.

**Isso estabelece uma referência antiga, não uma atualização para o jogo atual.**
Não há download automático nem troca silenciosa de SWF. Não é correto afirmar que
essa versão antiga será aceita pelos servidores oficiais atuais.

A SWF do jogo usa formato 14; seu runtime de referência é Flash 11.1 ou superior.
Compatibilidade de loader e compatibilidade do jogo são coisas diferentes. O projeto
não inclui instalador de Flash nem exige Adobe Animate para abrir o loader pronto.

## Verificação

Com os serviços iniciados, abra no navegador:

- `http://127.0.0.1:8080/health`: banco e arquivos.
- `http://127.0.0.1:8080/diagnostics`: parser, símbolos e estado do snapshot.

Para o snapshot selecionado, o esperado é `symbols_ready: true`,
`symbol_count: 118` e `missing_symbols: []`. Isso confirma o perfil mínimo e os
arquivos; não comprova uma partida. Se mudar a SWF, o cache de outro hash não será
aceito. O parser pode tentar extrair de novo com `tools/swfdump.exe` no Windows;
um perfil incompleto gera erro explícito em vez de ser enviado como válido.

Não altere o cache manualmente nem coloque valores de classe inventados.
TFM_REFRESH_SWF fica desativado no launcher para proteger o par selecionado.

## O que foi validado e o que falta

28 testes automatizados passaram. Um teste com o loader original real em
Chromium/Ruffle recebeu 200 do backend para o loader, os símbolos realmente
extraídos, o jogo e os dados de mapas/configuração. O #1069 de loop_game não
apareceu com o par selecionado. Esse teste usou uma licença temporária no MySQL
local de teste, sem mock de símbolos no teste visual.

A partida online não foi validada: Ruffle precisava de proxy de sockets e as
requisições externas do teste estavam bloqueadas. Não foram validados Windows
nativo, login no servidor oficial, Fly, salto alto ou Robot durante uma partida.
Não foram acrescentados hacks ou bypasses. O loader conserva os recursos que já
existiam no binário original; não há garantia de que todos sejam compatíveis.

Detalhes e evidências estão em RESTORATION_REPORT.md e evidence/.
