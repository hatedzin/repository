@echo off
cd /d "%~dp0"
python run_disney.py
if errorlevel 1 pause
