from aiohttp import web
from .common import authorize
from swf_assets import inspect_file

class Transformice(web.View):
    async def get(self):
        root = self.request.app['root']
        if 'swf' in self.request.query:
            path = root / 'tfm.swf'
            try:
                inspect_file(path)
            except (OSError, ValueError):
                return web.json_response({'success': False, 'error': 'SWF not configured'}, status=503)
            return web.FileResponse(path,headers={'Content-Type':'application/x-shockwave-flash','Cache-Control':'no-store'})
        await authorize(self.request)
        return web.FileResponse(root / 'public/ChargeurTransformice.swf',headers={'Cache-Control':'no-store'})
