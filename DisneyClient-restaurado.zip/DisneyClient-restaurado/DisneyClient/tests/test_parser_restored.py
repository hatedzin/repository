"""Parser transport and failure-state tests; no live game behavior is simulated."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import pytest
from aiohttp.test_utils import TestClient, TestServer
from DisneyParser.main import create_app
from DisneyParser.runtime import ParserRuntime

ROOT=Path(__file__).resolve().parents[2]

def prepare(tmp_path,monkeypatch):
    root=tmp_path/'parser';root.mkdir()
    shutil.copy2(ROOT/'DisneyParser/tfm.swf',root/'tfm.swf')
    tokens=root/'tokens.json';tokens.write_text(json.dumps(['test-only-token']))
    monkeypatch.setenv('DISNEY_PARSER_TOKENS_FILE',str(tokens))
    return root

@pytest.mark.asyncio
async def test_parser_authentication_and_actual_uploaded_swf(tmp_path,monkeypatch):
    root=prepare(tmp_path,monkeypatch)
    app=create_app(root)
    async with TestClient(TestServer(app)) as client:
        r=await client.get('/api/tfm_keys');assert r.status==400
        r=await client.get('/api/tfm_keys',headers={'Authorization':'Bearer wrong'});assert r.status==401
        r=await client.get('/transformice?swf');assert r.status==200
        assert hashlib.sha256(await r.read()).digest()==hashlib.sha256((root/'tfm.swf').read_bytes()).digest()
        r=await client.get('/health')
        health=await r.json()
        assert health['swf_ready'] and not health['symbols_ready']

@pytest.mark.asyncio
async def test_absent_extractor_does_not_modify_game(tmp_path,monkeypatch):
    root=prepare(tmp_path,monkeypatch)
    monkeypatch.setenv('PARSER_SWFDUMP',str(tmp_path/'no-such-tool'))
    runtime=ParserRuntime(root)
    before=runtime.swf.read_bytes()
    await runtime.refresh_local()
    assert runtime.error=='swfdump_missing'
    assert not runtime.metadata()['symbols_ready']
    assert runtime.swf.read_bytes()==before

@pytest.mark.asyncio
async def test_wrong_hash_cache_never_becomes_ready(tmp_path,monkeypatch):
    root=prepare(tmp_path,monkeypatch)
    (root/'.cache').mkdir()
    (root/'.cache/symbols.json').write_text(json.dumps({'swf_sha256':'wrong','keys':{'frame_loop_class_name':'fake'}}))
    monkeypatch.setenv('PARSER_SWFDUMP',str(tmp_path/'no-such-tool'))
    runtime=ParserRuntime(root)
    await runtime.refresh_local()
    assert not runtime.fetched
    assert not runtime.metadata()['symbols_ready']

def test_token_bootstrap_preserves_existing_values(tmp_path,monkeypatch):
    spec=importlib.util.spec_from_file_location('run_disney_test',ROOT/'run_disney.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    (tmp_path/'DisneyParser').mkdir()
    path=tmp_path/'DisneyParser/tokens.json'
    path.write_text(json.dumps(['test-old-token']))
    monkeypatch.setattr(module,'ROOT',tmp_path)
    assert module.parser_token({})=='test-old-token'
    assert json.loads(path.read_text())==['test-old-token']
    assert module.parser_token({'TFM_PARSER_API_TOKEN':'test-explicit-token'})=='test-explicit-token'
    assert json.loads(path.read_text())==['test-old-token','test-explicit-token']
