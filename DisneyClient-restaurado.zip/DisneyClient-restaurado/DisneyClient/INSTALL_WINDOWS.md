# Instalação — Windows 10/11, Python 3.11 e MySQL 8.0+ / MariaDB 10.4+ (XAMPP)

O backend funciona sem Discord e sem Google Sheets. O parser do jogo é um serviço
opcional separado: sem ele, login, administração e armazenamento funcionam;
`/get_keys` responde 503. Isso não significa que o jogo está funcionando.

## XAMPP / phpMyAdmin — instalação local

1. Inicie o serviço **MySQL** no painel do XAMPP (normalmente é MariaDB).
2. No phpMyAdmin, importe `setup_xampp.sql` pela aba **Importar**, ou cole o conteúdo
   na aba **SQL**. Ele cria o banco `disneyclient` e as mesmas seis tabelas do SQL
   enviado no chat. Todas as referências incluem o nome do banco, portanto não
   dependem de um banco selecionado. Não há DROP nem exclusão de dados.
3. Na pasta `DisneyClient`, copie `.env.xampp.example` para `.env`. Se já houver
   `.env`, edite-o manualmente sem sobrescrever suas configurações.

```env
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=
MYSQL_DATABASE=disneyclient
SERVER_HOST=127.0.0.1
SERVER_PORT=8080
```

Esse é o padrão LOCAL do XAMPP: root sem senha. Se você configurou uma senha,
preencha-a somente no `.env`; se usa outra porta, ajuste `MYSQL_PORT`. Para
implantação compartilhada/pública, use conta dedicada e senha. O Apache serve o
phpMyAdmin, mas o backend DisneyClient é executado pelo Python separadamente.

Instale as dependências, crie seu hash administrativo, salve-o em
`ADMIN_PASSWORD_HASH` no `.env` e gere sua key:

```powershell
python -m pip install -r requirements.txt
python admin.py hash-password
# Copie o hash scrypt exibido para ADMIN_PASSWORD_HASH no .env
python admin.py create-key --days 30
python server.py
```

Se a tela antiga mostrar `#1046 Nenhum banco de dados foi selecionado`, importe
`setup_xampp.sql` atualizado. Não apague o banco; CREATE TABLE IF NOT EXISTS preserva
as tabelas existentes. Caso já existam tabelas de uma versão anterior, verifique
as colunas antes de migrar: esse script não modifica automaticamente sua estrutura.

## Instalação com conta dedicada

1. Instale Python 3.11 de python.org e MySQL Community Server 8.0/8.4 ou MariaDB 10.4+ pelo XAMPP.
2. Abra PowerShell na pasta `DisneyClient`:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

3. No console administrativo do MySQL, crie um banco NOVO e uma conta dedicada.
   Substitua a senha de exemplo antes de executar:

```sql
CREATE DATABASE disneyclient CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'disneyclient'@'localhost' IDENTIFIED BY 'SUBSTITUA_POR_SENHA_ALEATORIA';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, REFERENCES ON disneyclient.* TO 'disneyclient'@'localhost';
```

4. Preencha `MYSQL_*` no `.env`. Nunca publique `.env` ou
   `service_account_credentials.json`. O banco deve permanecer privado.
5. Gere o hash administrativo com `python admin.py hash-password` e guarde somente
   o resultado `scrypt$...` em `ADMIN_PASSWORD_HASH` no `.env`. Use uma frase secreta
   de pelo menos 12 caracteres. Todos os comandos administrativos seguintes pedem
   essa frase. Não informe senhas em argumentos de linha de comando.

```powershell
python admin.py migrate
python admin.py create-key --days 30 --username alice
python admin.py create-key --days 0 --username lifetime-user
python admin.py list-keys
python admin.py show-key --id 1
python admin.py revoke-key --id 1
python admin.py renew-key --id 1 --days 90
python admin.py list-users
python admin.py block-user --id 1
python admin.py unblock-user --id 1
python admin.py audit
python server.py
```

A key completa é exibida SOMENTE na criação. Guarde-a com segurança e entregue-a
por canal privado ao usuário; listagens e auditoria não permitem recuperá-la.
`--days` aceita 0 (permanente), 1, 7, 30 ou 90. `--max-activations` controla quantos
identificadores de dispositivo podem ativar uma licença. Renovar reativa a licença,
conta a validade a partir de agora e invalida sessões anteriores. Revogar e bloquear
também invalidam sessões imediatamente. Desbloquear não restaura sessões antigas.
Não há autenticação de usuário por senha: a licença é a credencial.

Consulte `/health` localmente para verificar HTTP e MySQL. Ctrl+C encerra a sessão
HTTP, o pool e a tarefa opcional de atualização da SWF. O servidor usa
`SERVER_HOST=127.0.0.1` e `SERVER_PORT=8080` por padrão. Não há WebSocket neste
backend original: a comunicação existente usa HTTP e o loader Flash.

## Cliente e API

As rotas originais são mantidas. `/auth` e `/api/auth` aceitam o formato legado
`Authorization: Basic <base64 da key>` ou `Bearer <key>`. Clientes desktop devem
persistir e enviar `X-Device-ID`; navegadores usam o cookie de dispositivo. Apagar
o identificador consome uma nova ativação. O limite de dispositivos não é DRM de
hardware e não impede clonagem deliberada de identificadores. Não se deve confiar
em um cabeçalho como prova de identidade física.

Login retorna `success`, `access_token`, `level` e `sleep`, e define cookie de
sessão HttpOnly. Sessões duram até três horas, limitadas pela validade da licença.
`/api/fetch` exige autenticação e oculta a key. O dashboard usa o cookie de
sessão; não recupera tokens brutos do banco nem invalida o token do jogo.
`flash_token` é vinculado à sessão quando informado. IPs vêm da conexão TCP;
`X-Forwarded-For` arbitrário não é confiado. Deploy público exige HTTPS e desenho
explícito de proxy confiável; esse cenário não foi validado neste ambiente.

As configurações, mapas privados e dados soft são armazenados por usuário.
O envio de soft continua restrito a PLATINUM. Níveis de armazenamento continuam
em `config.json`. As tabelas auxiliares `license_activations` e `user_data`
complementam as quatro tabelas solicitadas.

## Migração do sistema antigo

A tabela antiga `users` tinha key em texto puro como chave primária. **Não execute
esta migração sobre o banco antigo.** O servidor detecta essa estrutura e interrompe
a inicialização com diagnóstico. Faça backup e crie banco novo. Emita novas keys e
transfira dados de mapas/configurações por exportação revisada, relacionando cada
usuário; não existe importação automática segura de identidades antigas.
Os módulos SQLAlchemy e o bot antigos permanecem como referência histórica, fora
do caminho de execução. Não são compatíveis com o schema novo; não os execute.
`createmariadb.py` agora encaminha para a migração autenticada.

## Parser e SWF

Configure `TFM_PARSER_ENDPOINT` e `TFM_PARSER_API_TOKEN` somente se tiver um parser
compatível autorizado. O backend não depende dele para iniciar. Falhas externas
retornam 502/503; a atualização de SWF preserva o último arquivo e faz substituição
atômica, sem requisições aguardando indefinidamente uma correspondência de tamanho.
Uma SWF autorizada pode ser colocada manualmente como `DisneyClient/tfm.swf`.

O ZIP contém SWFs, mas o número do formato no cabeçalho SWF não identifica a versão
do jogo. Consulte `../SWF_INSPECTION.json`. Não foi validado que sejam Transformice
158. O parser legado depende de ferramentas externas, extração de símbolos e
serviços antigos; ele não foi atualizado nem validado contra um jogo ativo.
Não foram alterados mecanismos de proteção ou autenticação de terceiros.
O browser não possui Flash moderno; o teste HTTP do loader não comprova execução
do jogo. É necessário um runtime Flash/cliente compatível e um ambiente de teste
autorizado para essa validação.

## Testes

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q tests/test_runtime.py
# Crie um banco separado disneyclient_test e configure MYSQL_* para ele.
$env:MYSQL_DATABASE = 'disneyclient_test'
python -m pytest -q
```

Os testes de integração se recusam a executar em banco sem sufixo `_test`.
Eles usam MySQL real, criam usuários aleatórios e conservam os registros para
inspeção no banco de teste; nunca aponte para produção. Sem esse banco, ficam
explicitamente SKIPPED, e não devem ser descritos como aprovados.

Para automação administrativa local, `python admin.py --password-stdin list-keys`
lê uma linha do stdin. Não grave a frase em scripts ou logs.
