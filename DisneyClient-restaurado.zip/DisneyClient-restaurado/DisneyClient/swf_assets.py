"""Read-only validation for the preserved SWF assets."""
import hashlib
from pathlib import Path
import zlib

MAX_SIZE = 64 * 1024 * 1024


def validate_swf(data):
    if len(data) < 8 or data[:3] not in (b'FWS', b'CWS'):
        raise ValueError('not_swf')
    expected = int.from_bytes(data[4:8], 'little')
    if not 8 <= expected <= MAX_SIZE:
        raise ValueError('invalid_swf_size')
    if data[:3] == b'FWS':
        if len(data) != expected:
            raise ValueError('incomplete_swf')
    else:
        try:
            decoder = zlib.decompressobj()
            body = decoder.decompress(data[8:], expected - 8 + 1)
        except zlib.error as exc:
            raise ValueError('invalid_swf_compression') from exc
        if not decoder.eof or decoder.unused_data or len(body) + 8 != expected:
            raise ValueError('incomplete_swf')
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'swf_format': data[3]}


def inspect_file(path):
    path = Path(path)
    if path.stat().st_size > MAX_SIZE:
        raise ValueError('swf_too_large')
    return validate_swf(path.read_bytes())
