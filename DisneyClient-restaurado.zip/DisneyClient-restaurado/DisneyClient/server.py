"""Run with Python 3.11+: python server.py (from any working directory)."""
import asyncio
import contextlib
import binascii
import zlib
import json
import logging
import os
import signal
from pathlib import Path
import aiohttp
from aiohttp import web
import infrastructure
from database import Database
from swf_assets import inspect_file, validate_swf

log = logging.getLogger(__name__)


@web.middleware
async def errors(request, handler):
    try:
        response = await handler(request)
    except web.HTTPException as exc:
        response = web.json_response({'success': False, 'error': exc.reason}, status=exc.status)
    except (ValueError, UnicodeError, binascii.Error, zlib.error):
        response = web.json_response({'success': False, 'error': 'invalid request data'}, status=400)
    if request.path.startswith(('/api/', '/auth', '/get_keys')):
        response.headers['Cache-Control'] = 'no-store'
    return response


async def swf_downloader(app):
    path = app['root'] / 'tfm.swf'
    temporary = path.with_suffix('.swf.tmp')
    while True:
        try:
            async with infrastructure.get_session().get(app['parser_url'] + '/transformice?swf', headers={'Authorization': 'Bearer ' + app['parser_token']}) as response:
                response.raise_for_status()
                content = await response.read()
                validate_swf(content)
                temporary.write_bytes(content)
                temporary.replace(path)
        except (aiohttp.ClientError, TimeoutError, ValueError, OSError) as exc:
            # Do not log URLs or upstream response bodies, which may contain credentials.
            log.warning('SWF refresh failed (%s)', type(exc).__name__)
        await asyncio.sleep(30)


async def lifecycle(app):
    task = None
    try:
        await app['db'].open()
        await app['db'].migrate()
        await infrastructure.init_session()
        if app['parser_url'] and os.getenv('TFM_REFRESH_SWF', '0') == '1':
            task = asyncio.create_task(swf_downloader(app))
        yield
    finally:
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
        await infrastructure.close_session()
        await app['db'].close()


def create_app():
    import api
    import resources
    root = infrastructure.ROOT
    config = json.loads((root / 'config.json').read_text())
    infrastructure.config = config
    app = web.Application(middlewares=[errors], client_max_size=10 * 1024 * 1024)
    app.update(root=root, config=config, db=Database(), attempts={},
               parser_url=os.getenv('TFM_PARSER_ENDPOINT', '').rstrip('/'),
               parser_token=os.getenv('TFM_PARSER_API_TOKEN', ''))
    app.cleanup_ctx.append(lifecycle)
    app.router.add_get('/', resources.index)
    app.router.add_get('/dashboard', resources.dashboard)
    for path, view in [('/auth',api.Auth),('/api/auth',api.Auth),('/get_keys',api.GetKeys),('/tfmlogin',api.TfmLogin),('/transformice',api.Transformice),('/data',api.Data),('/data/soft',api.Soft),('/mapstorage',api.MapStorage),('/api/fetch',api.Fetch),('/api/update',api.Update)]:
        app.router.add_view(path,view)
    # Compatibility metadata route; no Discord API, bot or token is used.
    async def discord_metadata(request):
        return web.json_response({'names': []})
    app.router.add_get('/api/discord', discord_metadata)
    def asset_status():
        result = {}
        for name, rel in [('loader','public/ChargeurTransformice.swf'),('game','tfm.swf')]:
            try:
                result[name] = dict(available=True, **inspect_file(root/rel))
            except (OSError,ValueError):
                result[name] = {'available':False}
        return result
    async def health(request):
        async with request.app['db'].transaction() as cur:
            await cur.execute('SELECT 1')
        return web.json_response({'status':'ok','database':'ok','assets':asset_status()})
    async def diagnostics(request):
        if request.remote not in {'127.0.0.1','::1'}:
            raise web.HTTPForbidden()
        result = {'assets':asset_status(),'external_auto_update':os.getenv('TFM_REFRESH_SWF','0')=='1'}
        if not app['parser_url']:
            result['parser'] = {'status':'not_configured'}
        else:
            try:
                timeout = aiohttp.ClientTimeout(total=3)
                async with infrastructure.get_session().get(app['parser_url']+'/health',timeout=timeout) as response:
                    result['parser'] = await response.json() if response.status==200 else {'status':'http_error','http_status':response.status}
            except (aiohttp.ClientError,TimeoutError,ValueError):
                result['parser'] = {'status':'unreachable'}
        return web.json_response(result,headers={'Cache-Control':'no-store'})
    app.router.add_get('/health',health)
    app.router.add_get('/diagnostics',diagnostics)
    app.router.add_static('/images',root / 'images')
    app.router.add_static('/public',root / 'public')
    return app


def main():
    if hasattr(signal, 'SIGBREAK'):
        def stop(signum, frame):
            raise KeyboardInterrupt()
        signal.signal(signal.SIGBREAK, stop)
    logging.basicConfig(level=logging.INFO)
    # run_app owns one loop, startup hooks and graceful SIGINT/SIGTERM cleanup.
    web.run_app(create_app(), host=os.getenv('SERVER_HOST','127.0.0.1'),
                port=int(os.getenv('SERVER_PORT',os.getenv('PORT','8080'))),
                access_log=None)


if __name__ == '__main__':
    main()
