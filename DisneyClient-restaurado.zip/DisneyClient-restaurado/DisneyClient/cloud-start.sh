#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
exec "${DISNEY_PYTHON:-python3}" run_disney.py --no-browser
