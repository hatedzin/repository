# ASTRO V4 — restauracao do Rato leve nas transicoes

Feche o Flash Player e encerre o inicializador anterior com Ctrl+C. Extraia em uma pasta nova e execute INICIAR_TUDO.bat.
Build: astro-v4-rato-leve-lifecycle-guard-v1.

Mantem a regulagem numerica/slider de 0 a 100% e a compensacao gradual somente com queijo, limitada a referencia normal do cliente.

A nova rotina observa os eventos nativos de sala, mapa, vitoria e renascimento. Restaura o valor escrito antes da troca de sala/mapa, aguarda 500 ms para estabilizar e recomeca gradualmente. A vitoria do proprio personagem bloqueia novas escritas ate novo mapa ou renascimento, mesmo se o sinal local de vivo estiver desatualizado. Vitorias e renascimentos de outros jogadores nao interrompem a regulagem local.

Ao chegar a 40 pixels de uma toca conhecida, a compensacao e restaurada; so volta ao se afastar mais de 80 pixels. Isso evita alternar a fisica repetidamente na borda da toca. A posicao e a lista de tocas sao as do proprio jogo, quando disponiveis.

Se o observador nativo de mapa nao estiver disponivel, a rotina fica pausada em vez de alterar a velocidade sem acompanhamento dos eventos. O menu informa o motivo da pausa.

Nao e um bypass e nao ha confirmacao de que o DC do servidor tenha sido resolvido. Alteracoes de movimento ainda podem ser rejeitadas pelo servidor. Nao foram alterados limites de conexao, anticheat, autenticacao ou pacotes enviados pelo jogo.

Testes em Ruffle: 32 verificacoes de regulagem e ciclo de vida, 24 de FPS e 23 de Auto morte/chat, com objetos e rede simulados. Ainda falta validar a resposta numa sala real no Flash Player do Windows.
Auto Win, Auto morte, contas, keys, parser e skins preservados.
