import os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=r/'fontes-hated-ai';jar=Path(os.environ['FFDEC_JAR']);cp=str(jar)+os.pathsep+str(jar.parent/'lib/*')
def java(script,*args):subprocess.run(['java','-cp',cp,str(script),*map(str,args)],check=True,cwd=r)
out=r/'DisneyClient/public/ChargeurTransformice.swf'
java(s/'BuildHated.java',s/'base-upload.swf',s,out)
java(s/'VerifyHated.java',s/'base-upload.swf',out)
f=s/'tests/fixtures';f.mkdir(exist_ok=True)
for p in sorted((s/'tests').glob('*Tests.as')):java(r/'fontes-rolagem/BuildScrollFixture.java',out,p,f/p.with_suffix('.swf').name)

for src,name in [(r/'fontes-rotas-novas/RecorderTests.as','RecorderRegression'),(r/'fontes-robot/FollowRegressionTests.as','FollowRegression')]:java(r/'fontes-rolagem/BuildScrollFixture.java',out,src,f/(name+'.swf'))
