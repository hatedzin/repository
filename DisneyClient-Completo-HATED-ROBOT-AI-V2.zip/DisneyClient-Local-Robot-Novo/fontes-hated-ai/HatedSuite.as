package disney {import flash.display.MovieClip;public class HatedSuite {public static function attach(root:MovieClip):void{HatedController.attach(root);RouteRecorderV4.attach(root);}}}
