import asyncio,base64,importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import AsyncMock
from aiohttp import web
from aiohttp.test_utils import TestClient,TestServer
ROOT=Path(__file__).resolve().parents[2]/'DisneyClient'
pkg=types.ModuleType('ai_test');pkg.__path__=[str(ROOT/'api')];sys.modules['ai_test']=pkg
common=types.ModuleType('ai_test.common');common.authorize=AsyncMock(return_value={'user_id':1});sys.modules[common.__name__]=common
sys.modules.setdefault('infrastructure',types.ModuleType('infrastructure'))
def load(name):
 s=importlib.util.spec_from_file_location('ai_test.'+name,ROOT/'api'/f'{name}.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
legacy=load('github_routes');ai=load('hated_ai')
def payload():return {'schema':2,'map':'@123','geometry':'abc123','route':{'id':'record','physics':'observed-si-v2','wins':1,'tests':1,'duration':1000,'points':[{'x':10,'y':20,'t':0,'phase':'cheese'},{'x':100,'y':20,'t':1000,'phase':'hole'}]},'physics':None}
class BackendTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'client'
 async def asyncTearDown(self):self.tmp.cleanup()
 async def test_validation_rejects_invalid_states(self):
  for modify in [lambda p:p.update(schema=1),lambda p:p.update(map='../file'),lambda p:p['route'].update(wins=0),lambda p:p['route']['points'][0].update(x=float('inf')),lambda p:p['route']['points'][1].update(t=-1),lambda p:p['route']['points'][1].update(phase='forced_win')]:
   p=payload();modify(p)
   with self.assertRaises(ValueError):ai.validate(p)
 async def test_immutable_local_store_and_isolation(self):
  raw=ai.validate(payload());a=ai.store(self.root,1,raw,'@123');b=ai.store(self.root,1,raw,'@123');self.assertEqual(a,b);ai.store(self.root,2,raw,'@123');self.assertEqual(len(list((self.root/'data/hated-ai-v2/1').glob('*.json'))),1);self.assertEqual((self.root/'data/hated-ai-v2/2'/a[0]).read_bytes(),raw)
 async def test_quota_and_log_rotation(self):
  for n in range(70):
   p=payload();p['route']['duration']=n;ai.store(self.root,1,ai.validate(p),'@123')
  self.assertEqual(len(list((self.root/'data/hated-ai-v2/1').glob('*.json'))),64);self.assertTrue((Path(self.tmp.name)/'logs-client/hated-ai-1.jsonl').is_file())
 async def test_github_creates_new_file_without_sha(self):
  service=types.SimpleNamespace(token='test-only',request=AsyncMock(side_effect=[(404,{}),(201,{})]));raw=ai.validate(payload());result=await ai.publish(service,'test.json',raw);self.assertTrue(result['published']);calls=service.request.call_args_list;self.assertEqual(calls[0].args[0],'GET');self.assertEqual(calls[1].args[0],'PUT');self.assertNotIn('sha',calls[1].kwargs['json']);self.assertEqual(calls[1].args[1],'/contents/hated-ai-v2/test.json')
 async def test_existing_identical_is_idempotent(self):
  raw=ai.validate(payload());service=types.SimpleNamespace(token='test-only',request=AsyncMock(return_value=(200,{'content':base64.b64encode(raw).decode()})));result=await ai.publish(service,'same.json',raw);self.assertTrue(result['unchanged']);service.request.assert_awaited_once()
 async def test_existing_different_never_overwritten(self):
  service=types.SimpleNamespace(token='test-only',request=AsyncMock(return_value=(200,{'content':base64.b64encode(b'different').decode()})))
  with self.assertRaises(legacy.CatalogError):await ai.publish(service,'existing.json',ai.validate(payload()))
  service.request.assert_awaited_once()
 async def test_missing_token_preserves_local_data(self):
  service=types.SimpleNamespace(token='',request=AsyncMock())
  with self.assertRaises(legacy.CatalogError):await ai.publish(service,'new.json',ai.validate(payload()))
  service.request.assert_not_awaited()
 async def test_real_http_storage_validation_and_authorization(self):
  app=web.Application();app['root']=self.root;app.router.add_view('/hated-ai',ai.HatedAI);client=TestClient(TestServer(app));await client.start_server()
  try:
   response=await client.post('/hated-ai',data={'data':json.dumps(payload())});self.assertEqual(response.status,200);self.assertTrue((await response.json())['saved'])
   self.assertEqual((await client.post('/hated-ai',data={'data':'[]'})).status,400)
   common.authorize.side_effect=web.HTTPUnauthorized()
   self.assertEqual((await client.post('/hated-ai',data={'data':json.dumps(payload())})).status,401)
  finally:common.authorize.side_effect=None;await client.close()
if __name__=='__main__':unittest.main(verbosity=2)
