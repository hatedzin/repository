# Fontes e reprodução dos testes

Os sete arquivos `Hated*.as` são a implementação nova. `base-upload.swf` é a SWF extraída exclusivamente do ZIP enviado para esta solicitação. O verificador compara a saída com essa base.

Reconstrução (Java 21 + FFDec externo):

```sh
FFDEC_JAR=/caminho/ffdec.jar python fontes-hated-ai/rebuild.py
```

Testes de SWF (Node/Playwright, Chromium e distribuição web oficial do Ruffle):

```sh
RUFFLE_DIR=/caminho/ruffle TEST_SWF="$PWD/fontes-hated-ai/tests/fixtures/NavigationTests.swf" node fontes-hated-ai/tests/run_tests.cjs
RUFFLE_DIR=/caminho/ruffle TEST_SWF="$PWD/fontes-hated-ai/tests/fixtures/InterfaceTests.swf" node fontes-hated-ai/tests/run_tests.cjs
RUFFLE_DIR=/caminho/ruffle TEST_SWF="$PWD/fontes-hated-ai/tests/fixtures/AsyncTests.swf" node fontes-hated-ai/tests/run_tests.cjs
python fontes-hated-ai/tests/test_backend.py
```

Execute na raiz do projeto, ao lado de `DisneyClient` e `DisneyParser`. `CHROMIUM_PATH` pode apontar para outro Chromium. As fixtures usam estado sintético do jogo e servidor HTTP de teste; não se conectam a uma partida real nem publicam rotas no GitHub real. Não confunda esses resultados com testes no Adobe Flash/Windows.

`RecorderRegression.swf` e `FollowRegression.swf` foram compiladas das fontes de regressão já presentes neste mesmo ZIP, usando `fontes-rolagem/BuildScrollFixture.java`. O mesmo runner aceita essas fixtures via TEST_SWF.

A execução normal do client usa a SWF pronta em `DisneyClient/public/ChargeurTransformice.swf`; não exige FFDec, Node ou Ruffle.
