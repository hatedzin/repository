import com.jpexs.decompiler.flash.*;import com.jpexs.decompiler.flash.tags.*;import com.jpexs.decompiler.flash.abc.*;import com.jpexs.decompiler.flash.abc.types.traits.*;import java.io.*;import java.nio.file.*;import java.util.*;
class AuditSwf {
 public static void main(String[]args)throws Exception{
  var swf=new SWF(new FileInputStream(args[0]),false);var patterns=new LinkedHashMap<String,int[]>();
  for(var line:Files.readAllLines(Path.of(args[1]))){var parts=line.split("\t");patterns.put(parts[0],Arrays.stream(parts[1].split(" ")).mapToInt(t->t.equals("??")?-1:Integer.parseInt(t,16)).toArray());}
  var out=new StringBuilder("Static audit of the loader SWF, not the separately downloaded game.\nAOB matches are candidates only; no memory patch executed.\n");int abcCount=0,classes=0,methods=0,matches=0,statFailures=0;
  for(Tag tag:swf.getTags())if(tag instanceof DoABC2Tag){ABC a=((DoABC2Tag)tag).getABC();abcCount++;classes+=a.instance_info.size();var names=new HashMap<Integer,String>();
   for(int c=0;c<a.instance_info.size();c++){String cn=a.constants.getMultiname(a.instance_info.get(c).name_index).getNameWithNamespace(new HashSet<String>(),a,a.constants,true).toString();names.put(a.instance_info.get(c).iinit_index,cn+" constructor");names.put(a.class_info.get(c).cinit_index,cn+" static initializer");var ts=new ArrayList<Trait>();ts.addAll(a.instance_info.get(c).instance_traits.traits);ts.addAll(a.class_info.get(c).static_traits.traits);for(var t:ts)if(t instanceof TraitMethodGetterSetter)names.put(((TraitMethodGetterSetter)t).method_info,cn+"."+a.constants.getString(a.constants.getMultiname(t.name_index).name_index));}
   for(var b:a.bodies){methods++;byte[] code=b.getCodeBytes();String name=names.getOrDefault(b.method_info,"closure/script #"+b.method_info);out.append("METHOD ABC "+abcCount+" "+b.method_info+" "+name+" bytes="+code.length+"\n");
    try{var st=b.getCode().getStats(a,b,b.init_scope_depth,false);if(st==null||st.maxstack>b.max_stack||st.maxscope>b.max_scope_depth){statFailures++;out.append("  STATS: exceeds declared bounds or unavailable\n");}}catch(Exception e){statFailures++;out.append("  STATS: unavailable\n");}
    for(var pat:patterns.entrySet()){int[] p=pat.getValue();for(int i=0;i+p.length<=code.length;i++){boolean yes=true;for(int j=0;j<p.length;j++)if(p[j]>=0&&(code[i+j]&255)!=p[j]){yes=false;break;}if(yes){matches++;out.append("  AOB "+pat.getKey()+" offset="+i+" (UNVERIFIED SEMANTICS)\n");}}}
   }
  }
  String summary="ABCs="+abcCount+" classes="+classes+" method bodies="+methods+" AOB candidates="+matches+" stats warnings="+statFailures;
  out.append(summary+"\n");Files.writeString(Path.of(args[2]),out.toString());System.out.println(summary);
 }
}
