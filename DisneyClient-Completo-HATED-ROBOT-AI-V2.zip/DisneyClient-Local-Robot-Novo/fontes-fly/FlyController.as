package disney {
 import flash.display.*;import flash.events.*;import flash.text.*;import flash.utils.Dictionary;import flash.utils.getTimer;
 public class FlyController {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var enabled:Boolean=false;private var held:Boolean=false;private var focused:Boolean=true;private var nextPulse:int=0;private var lifePlayer:Object;private var lifeRound:String="";private var row:Sprite;private var indicator:Sprite;private var status:TextField;
  public function FlyController(value:MovieClip){root=value;}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;
   var f:FlyController=new FlyController(value);instances[value]=f;
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,f.down,true,6000);value.stage.addEventListener(KeyboardEvent.KEY_DOWN,f.down,false,6000);
   value.stage.addEventListener(KeyboardEvent.KEY_UP,f.up,true,6000);value.stage.addEventListener(KeyboardEvent.KEY_UP,f.up,false,6000);
   value.stage.addEventListener("astroMotionTerminal",function(e:Event):void{f.held=false;});
   value.stage.addEventListener(Event.DEACTIVATE,function(e:Event):void{f.focused=false;f.held=false;});
   value.stage.addEventListener(Event.ACTIVATE,function(e:Event):void{f.focused=true;});
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{f.update();},false,-100);
  }
  public function setEnabled(value:Boolean):void{if(enabled!=value)LocalServerLog.emit(root,"Fly Y: "+(value?"ativado":"desativado"));enabled=value;held=false;nextPulse=0;paint();}
  private function typing():Boolean{return root.stage && root.stage.focus is TextField && TextField(root.stage.focus).type==TextFieldType.INPUT;}
  private function busy():Boolean{return NativeMotion.get(root).finished() || Boolean(root["auto_play"]) || NativeMotion.get(root).inputBusy();}
  public function down(e:KeyboardEvent):void{
   if(e.keyCode!=89 || !enabled || !focused || typing() || busy() || NativeMotion.isSynthetic(root))return;
   held=true;e.stopImmediatePropagation();
  }
  public function up(e:KeyboardEvent):void{if(e.keyCode==89 && held && !NativeMotion.isSynthetic(root)){held=false;}}
  private function paint():void{
   if(!indicator)return;indicator.graphics.clear();indicator.graphics.lineStyle(1,0x55D6C2);indicator.graphics.beginFill(enabled?0x55D6C2:0x14243A);indicator.graphics.drawCircle(6,11,5);indicator.graphics.endFill();
  }
  private function installRow():void{
   var ui:Object=root["Interface"];var host:DisplayObjectContainer=ui ? ui["general_ui"] as DisplayObjectContainer : null;
   if(!host || (row && row.parent===host))return;
   row=new Sprite();row.name="astroFlyControl";row.y=Math.max(0,host.getBounds(host).bottom)+10;
   indicator=new Sprite();row.addChild(indicator);var label:TextField=new TextField();label.defaultTextFormat=new TextFormat("_sans",12,0xD8E5F2);label.text="Fly [segure Y]";label.x=18;label.width=200;label.height=24;label.mouseEnabled=false;label.selectable=false;row.addChild(label);
   var button:Sprite=new Sprite();button.graphics.beginFill(0,0);button.graphics.drawRect(0,0,220,24);button.graphics.endFill();button.buttonMode=true;row.addChild(button);button.addEventListener(MouseEvent.CLICK,function(e:MouseEvent):void{setEnabled(!enabled);e.stopImmediatePropagation();});
   status=new TextField();status.defaultTextFormat=new TextFormat("_sans",11,0x9BB6CE);status.y=25;status.width=490;status.height=38;status.wordWrap=true;status.selectable=false;status.mouseEnabled=false;row.addChild(status);host.addChild(row);paint();
  }
  // The existing getter returns the live Box2D velocity vector (also used by
  // PhysicsGuardV4). Pgiex MovePlayer(0,-50) represents -5 world units/s.
  // Use resolved fields only, preserving horizontal speed and all coordinates.
  public function impulse():Boolean{
   if(NativeMotion.get(root).finished())return false;
   var k:Object=root["Keys"];var game:Object=root["tfm"];
   var p:Object=k && game && k.player ? game[k.player] : null;
   if(!p || !k.is_dead || !(k.is_dead in p) || p[k.is_dead] || (k.player_clip && !p[k.player_clip]) || !k.player_physics)return false;
   var body:Object=p[k.player_physics];if(!body || !k.get_linear_velocity || !(body[k.get_linear_velocity] is Function) || !k.physics_state_vy)return false;
   var velocity:Object=body[k.get_linear_velocity]();if(!velocity || !(k.physics_state_vy in velocity))return false;
   velocity[k.physics_state_vy]=-5;return true;
  }
  public function update(now:int=-1):void{
   if(now<0)now=getTimer();try{installRow();
    var k:Object=root["Keys"];var game:Object=root["tfm"];var p:Object=k && game && k.player ? game[k.player] : null;
    var round:String=k && game && k.current_round_code ? String(game[k.current_round_code]) : "";
    if(lifePlayer!==p || lifeRound!=round){held=false;lifePlayer=p;lifeRound=round;}
    if(!enabled){if(status)status.text="Ative e segure Y para impulso vertical.";return;}
    if(!focused || typing() || busy()){held=false;if(status)status.text="Fly aguardando: foco, campo de texto ou outro controlador.";return;}
    if(!held){if(status)status.text="Fly ativo: segure Y. Soltar devolve a queda a fisica normal.";return;}
    if(now<nextPulse)return;nextPulse=now+90;
    if(!impulse()){held=false;if(status)status.text="Fly: jogador morto ou mapeamento de fisica indisponivel.";return;}
    if(status)status.text="Fly: impulso vertical nativo, sem alterar coordenadas.";
   }catch(error:Error){held=false;if(status)status.text="Fly: fisica indisponivel #"+error.errorID;}
  }
 }
}
