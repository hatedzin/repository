package disney {
 import flash.display.*;import flash.events.*;import flash.text.*;import flash.external.ExternalInterface;import flash.utils.ByteArray;
 public class RgbMouseTests {
  private static var n:int=0;
  private static function check(ok:Boolean,message:String):void{if(!ok)throw new Error(message);n++;}
  public static function run(display:MovieClip):void{try{
   var r:MovieClip=new MovieClip();display.addChild(r);r.auto_play=false;r.Keys={player:"mouse",is_dead:"dead",player_physics:"body",get_linear_velocity:"velocity",physics_state_vy:"y",current_round_code:"round",player_id:"pid"};
   var v:Object={x:2,y:7};var calls:int=0;var b:Object={velocity:function():Object{calls++;return v;}};var p:Object={pid:7,dead:false,body:b,x:150,y:300};r.tfm={mouse:p,round:1};r.Interface={general_ui:new Sprite()};r.addChild(r.Interface.general_ui);
   var f:FlyController=new FlyController(r);f.update(0);check(r.Interface.general_ui.getChildByName("astroFlyControl")!=null,"Fly row added to existing player tab");f.update(1);check(r.Interface.general_ui.numChildren==1,"no duplicate row");
   f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));f.update(10);check(calls==0,"disabled Fly does nothing");
   f.setEnabled(true);f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));f.update(100);check(v.y==-5 && calls==1,"Y applies upward native velocity");check(v.x==2 && p.x==150 && p.y==300,"position and horizontal speed preserved");
   v.y=8;f.update(120);check(calls==1 && v.y==8,"pulse rate capped");f.update(200);check(calls==2 && v.y==-5,"held Y repeats");f.up(new KeyboardEvent(KeyboardEvent.KEY_UP,true,false,0,89));v.y=9;f.update(300);check(v.y==9,"releasing Y returns gravity control");
   f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));r.auto_play=true;f.update(400);check(v.y==9,"Robot blocks fly");r.auto_play=false;f.update(500);check(v.y==9,"no stale Y after automation");
   f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));r.tfm.round=2;f.update(600);check(v.y==9,"new round releases held Y");
   f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));p.dead=true;f.update(700);check(v.y==9,"dead player not changed");p.dead=false;f.update(800);check(v.y==9,"respawn needs fresh press");
   var input:TextField=new TextField();input.type=TextFieldType.INPUT;r.addChild(input);r.stage.focus=input;f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));f.update(900);check(v.y==9,"typing Y does not fly");r.stage.focus=null;
   delete r.Keys.physics_state_vy;check(!f.impulse(),"unresolved symbols fail closed");r.Keys.physics_state_vy="y";delete b.velocity;check(!f.impulse(),"missing native getter fails closed");
   b.velocity=function():Object{return v;};f.setEnabled(false);check(v.y==9,"disable does not freeze or zero native velocity");
   FlyController.attach(r);FlyController.attach(r);r.stage.dispatchEvent(new Event(Event.ENTER_FRAME));check(r.Interface.general_ui.numChildren==2,"singleton attaches once");
   var active:Sprite=r.Interface.general_ui.getChildAt(1) as Sprite;active.getChildAt(2).dispatchEvent(new MouseEvent(MouseEvent.CLICK,true));r.stage.dispatchEvent(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));r.stage.dispatchEvent(new Event(Event.ENTER_FRAME));check(v.y==-5,"Stage keyboard event reaches attached controller");v.y=6;r.stage.dispatchEvent(new Event(Event.DEACTIVATE));r.stage.dispatchEvent(new Event(Event.ACTIVATE));r.stage.dispatchEvent(new Event(Event.ENTER_FRAME));check(v.y==6,"focus loss cancels held key");
   r.stage.dispatchEvent(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,89));var releases:int=0;r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(e.keyCode==89)releases++;});r.stage.dispatchEvent(new KeyboardEvent(KeyboardEvent.KEY_UP,true,false,0,89));check(releases==1,"native Y release still propagates to old jump/macro listeners");
   var motion:NativeMotion=NativeMotion.get(r);var victory:ByteArray=new ByteArray();victory.writeByte(8);victory.writeByte(6);victory.writeByte(0);victory.writeInt(99);victory.position=1;NativeMotion.observe(r,victory);check(!motion.finished() && victory.position==1,"another player's hole does not stop local flight");
   victory.position=3;victory.writeInt(7);victory.position=1;NativeMotion.observe(r,victory);check(motion.finished() && victory.position==1,"local victory latches before native processing and preserves cursor");
   v.y=4;check(!f.impulse() && v.y==4,"no vertical impulse after confirmed hole");var token:Object={};motion.movement(token,true,false,true);check(!motion.inputBusy(),"completed player cannot reacquire movement keys");motion.place(token,900,900);motion.synchronizeCurrent();check(p.x==150 && p.y==300,"no placement or initial sync after hole");
   p.body=null;check(motion.finished(),"removed victory physics is not treated as respawn");p.body=b;
   var birth:ByteArray=new ByteArray();birth.writeByte(144);birth.writeByte(2);birth.writeUTF("Other#0001");birth.writeInt(99);birth.position=0;NativeMotion.observe(r,birth);check(motion.finished(),"another player's respawn does not unlock movement");
   birth.clear();birth.writeByte(144);birth.writeByte(2);birth.writeUTF("Self#0001");birth.writeInt(7);birth.position=1;NativeMotion.observe(r,birth);check(!motion.finished() && birth.position==1,"own native respawn unlocks same body without editing packet");
   r.Keys.player_clip="clip";p.clip=null;check(!f.impulse(),"absent native clip blocks impulses even before victory packet");p.clip=true;check(f.impulse() && v.y==-5,"ready player can fly after native respawn");
   f.setEnabled(true);f.update(2000);v.y=3;f.down(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,87));f.update(2100);check(v.y==3,"W no longer activates Fly");
   ExternalInterface.call("recordTest","PASS: "+n+" Fly controls and native velocity checks");
  }catch(e:Error){ExternalInterface.call("recordTest","FAIL: fly "+e.message+" #"+e.errorID);}}
 }
}
