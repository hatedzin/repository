package disney {
 import flash.display.MovieClip;

 // Sends ordinary native key transitions. Physics, collisions and jump acceptance
 // belong to the game; recorded coordinates, velocities and animation are read-only.
 public class RobotInput {
  private var root:MovieClip;
  private var bridge:NativeMotion;
  private var ownerPlayer:Object;
  private var ownerBody:Object;
  private var left:Boolean=false;
  private var right:Boolean=false;
  private var pulseHeld:Boolean=false;
  private var downHeld:Boolean=false;
  private var pulseUntil:int=0;
  private var lastPulse:int=-1000000;
  private var previousAir:Boolean=false;
  private var previousVy:Number=NaN;
  private var havePrevious:Boolean=false;
  private var releasing:Boolean=false;

  public function RobotInput(value:MovieClip){root=value;bridge=NativeMotion.get(value);}

  private function current():Object {
   try {
    if(!root || !root.stage || bridge.finished())return null;
    var keys:Object=root["Keys"];
    var game:Object=root["tfm"];
    if(!keys || !game || !keys.player || !keys.player_physics || !keys.player_clip || !keys.is_dead)return null;
    var local:Object=game[keys.player];
    if(!local || !(keys.player_physics in local) || !(keys.player_clip in local) || !(keys.is_dead in local))return null;
    var body:Object=local[keys.player_physics];
    if(!body || !local[keys.player_clip] || Boolean(local[keys.is_dead]))return null;
    return {player:local,body:body};
   }catch(error:Error){return null;}
  }

  public function ready():Boolean{return current()!=null;}

  private function unchanged(snapshot:Object):Boolean {
   var next:Object=current();
   return snapshot && next && next.player===snapshot.player && next.body===snapshot.body && bridge.inputBusy() && !bridge.busyExcept(this);
  }

  public function release():void {
   if(releasing)return;
   releasing=true;
   // The shared driver's terminal handler can release ownership before its
   // observer calls us. A remembered Down press still needs its native keyup
   // when no replacement owner exists.
   var releaseDown:Boolean=downHeld && !bridge.busyExcept(this);
   downHeld=false;left=false;right=false;pulseHeld=false;pulseUntil=0;ownerPlayer=null;ownerBody=null;
   try {
    try {if(releaseDown)bridge.key(40,false);} finally {bridge.release(this);}
   } finally {releasing=false;}
  }

  public function reset():void {
   release();havePrevious=false;previousAir=false;previousVy=NaN;lastPulse=-1000000;
  }

  public function tick(now:int):void {
   if(!ownerPlayer)return;
   var snapshot:Object=current();
   if(!snapshot || snapshot.player!==ownerPlayer || snapshot.body!==ownerBody || bridge.busyExcept(this)){release();return;}
   if(!pulseHeld || now<pulseUntil)return;
   pulseHeld=false;
   bridge.movement(this,left,right,false);
   if(!unchanged(snapshot))release();
  }

  private function apply(l:Boolean,r:Boolean,jump:Boolean,now:int):Boolean {
   tick(now);
   var snapshot:Object=current();
   if(!snapshot){release();return false;}
   // Contradictory recording flags never create opposing held native keys.
   if(l && r){l=false;r=false;}
   var pulse:Boolean=jump && now-lastPulse>=30;
   if(pulse && pulseHeld){
    pulseHeld=false;
    bridge.movement(this,l,r,false);
    if(!unchanged(snapshot)){release();return false;}
   }
   left=l;right=r;
   if(pulse){pulseHeld=true;pulseUntil=now+30;lastPulse=now;}
   bridge.movement(this,left,right,pulseHeld);
   if(!unchanged(snapshot)){release();return false;}
   ownerPlayer=snapshot.player;ownerBody=snapshot.body;
   return pulse;
  }

  public function play(sample:Object,now:int):void {
   if(!sample || !(sample.ml is Boolean) || !(sample.mr is Boolean) || !(sample.jump is Boolean)){release();return;}
   var airborne:Boolean=Boolean(sample.jump);
   var vy:Number=Number(sample.vy);
   var onset:Boolean=airborne && (!havePrevious || !previousAir);
   var renewed:Boolean=airborne && havePrevious && previousAir && isFinite(vy) && isFinite(previousVy) && vy<=-4.5 && previousVy-vy>1;
   // A final non-airborne sample cancels an earlier inferred request; it never
   // forces the player's animation/state or injects a physical impulse.
   var request:Boolean=airborne && (onset || renewed || sample.requestJump===true);
   havePrevious=true;previousAir=airborne;previousVy=vy;
   if(!airborne)pulseHeld=false;
   apply(Boolean(sample.ml),Boolean(sample.mr),request,now);
  }

  public function resume(sample:Object,now:int):void {
   if(!sample || !(sample.ml is Boolean) || !(sample.mr is Boolean) || !(sample.jump is Boolean)){release();return;}
   havePrevious=true;previousAir=Boolean(sample.jump);previousVy=Number(sample.vy);pulseHeld=false;
   apply(Boolean(sample.ml),Boolean(sample.mr),false,now);
  }

  public function crouch(down:Boolean):void {
   var snapshot:Object=current();
   if(!snapshot){release();return;}
   // Claim the same bridge owner before issuing ordinary Down transitions.
   // The native keyboard handlers perform crouch state/animation and networking.
   bridge.movement(this,left,right,pulseHeld);
   if(!unchanged(snapshot)){release();return;}
   ownerPlayer=snapshot.player;ownerBody=snapshot.body;
   if(downHeld==down)return;
   downHeld=down;
   bridge.key(40,down);
   if(!unchanged(snapshot))release();
  }

  public function steer(x:Number,y:Number,now:int):void {
   var snapshot:Object=current();
   if(!snapshot || !isFinite(x) || !isFinite(y)){release();return;}
   var px:Number=Number(snapshot.player.x);
   var py:Number=Number(snapshot.player.y);
   if(!isFinite(px) || !isFinite(py)){release();return;}
   var dx:Number=x-px;
   var dy:Number=y-py;
   var request:Boolean=dy < -12 && Math.abs(dx)<64 && now-lastPulse>=400;
   apply(dx < -5,dx > 5,request,now);
  }
 }
}
