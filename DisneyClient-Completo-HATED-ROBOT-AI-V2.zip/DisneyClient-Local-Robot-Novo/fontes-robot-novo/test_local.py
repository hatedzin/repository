import ast,importlib.util,os,pathlib,tempfile,unittest,sys
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parent.parent
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
class LocalTests(unittest.TestCase):
 def test_python_sources_compile(self):
  for p in ROOT.rglob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
 def test_backend_bind_is_local_even_if_old_env_is_public(self):
  tree=ast.parse((ROOT/'DisneyClient/server.py').read_text());calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='run_app'];self.assertEqual(len(calls),1)
  value=next(x.value for x in calls[0].keywords if x.arg=='host');self.assertIsInstance(value,ast.Constant);self.assertEqual(value.value,'127.0.0.1')
 def test_parser_bind_is_local(self):
  tree=ast.parse((ROOT/'DisneyParser/main.py').read_text());calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='TCPSite'];self.assertEqual(len(calls),1);self.assertEqual(calls[0].args[1].value,'127.0.0.1')
 def test_launcher_browser_and_spawn_environment_are_local(self):
  launch=module('local_launcher',ROOT/'iniciar_client.py');children=[];urls=[]
  class Child:
   def __init__(self,*args,**kwargs):self.kwargs=kwargs;self.stopped=False;children.append(self)
   def poll(self):return 0 if self.stopped else None
   def terminate(self):self.stopped=True
   def wait(self,timeout=None):return 0
  with tempfile.TemporaryDirectory() as folder:
   base=pathlib.Path(folder);client=base/'DisneyClient';parser=base/'DisneyParser';client.mkdir();parser.mkdir();(client/'.env').write_text('SERVER_HOST=0.0.0.0\n');(client/'BUILD-ID.txt').write_text('TEST_LOCAL');(parser/'tokens.json').write_text('["LOCAL_TEST_ONLY"]')
   launch.ROOT=base;launch.CLIENT=client;launch.PARSER=parser;launch.LOGS=base/'logs'
   with patch.dict(os.environ,{'SERVER_HOST':'0.0.0.0','SERVER_PORT':'8080','CLIENT_PARSER_PORT':'8090'},clear=True),patch.object(launch,'http_ok',side_effect=lambda url,token=None:'/api/tfm_keys' in url),patch.object(launch,'listening',return_value=False),patch.object(launch,'wait_ready'),patch.object(launch.subprocess,'Popen',Child),patch.object(launch.webbrowser,'open',side_effect=lambda url:urls.append(url) or True),patch.object(launch.time,'sleep',side_effect=KeyboardInterrupt),patch('builtins.print'):
    self.assertEqual(launch.run(),0)
   self.assertEqual(urls,['http://127.0.0.1:8080']);self.assertEqual(len(children),1);env=children[0].kwargs['env'];self.assertEqual(env['SERVER_HOST'],'127.0.0.1');self.assertEqual(env['TFM_PARSER_ENDPOINT'],'http://127.0.0.1:8090');self.assertTrue(children[0].stopped)
 def test_music_origin_is_set_centrally_using_local_port(self):
  source=(ROOT/'DisneyClient/server.py').read_text();tree=ast.parse(source)
  values=[]
  for node in ast.walk(tree):
   if isinstance(node,ast.Assign):
    for t in node.targets:
     if isinstance(t,ast.Subscript) and isinstance(t.slice,ast.Constant) and t.slice.value=='music_public_url':values.append(node.value)
  self.assertEqual(len(values),1)
  with patch.dict(os.environ,{'SERVER_PORT':'8088'},clear=True):self.assertEqual(eval(compile(ast.Expression(values[0]),'<music-origin>','eval'),{'os':os}),'http://127.0.0.1:8088')
 def test_launcher_does_not_open_legacy_cache(self):
  text=(ROOT/'INICIAR_CLIENT.bat').read_text();self.assertNotIn('LOCALAPPDATA',text);self.assertNotIn('Fisica*.zip',text);self.assertNotIn('Start-Process',text);self.assertIn('DisneyParser\\main.py',text)
 def test_example_env_matches_local_listener(self):
  self.assertIn('SERVER_HOST=127.0.0.1',(ROOT/'DisneyClient/.env.example').read_text());self.assertFalse((ROOT/'DisneyClient/.env').exists());self.assertFalse((ROOT/'DisneyParser/tokens.json').exists())
if __name__=='__main__':unittest.main()
