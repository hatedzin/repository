package disney {
 import flash.display.MovieClip;import flash.display.Sprite;import flash.events.KeyboardEvent;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var checks:int=0;
  private static function check(ok:Boolean,name:String):void{if(!ok)throw new Error(name);checks++;}
  private static function sample(air:Boolean=true,vy:Number=-5,l:Boolean=false,r:Boolean=true):Object{return {ml:l,mr:r,jump:air,vy:vy};}
  private static function fixture(display:MovieClip):Object {
   var root:MovieClip=new MovieClip();display.addChild(root);
   var events:Array=[];var native:Object={attempts:0,accepted:0,canJump:false,onPress:null,downHandler:true};
   var body:Object={velocity:{vx:7,vy:9},setPosition:function(...args):void{throw new Error("Position API must never be used");}};
   var player:Object={x:100,y:200,body:body,clip:true,dead:false,left:false,right:false,down:false,air:false,jump:function(on:Boolean):void{this.air=on;}};
   root["Keys"]={player:"local",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down"};
   root["tfm"]={local:player};
   root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{
    if(!NativeMotion.isSynthetic(root))return;events.push({code:e.keyCode,down:true});
    if(e.keyCode==40 && native.downHandler)player.down=true;
    if(e.keyCode==38){native.attempts++;if(native.canJump){native.accepted++;player.air=true;body.velocity.vy=-5;}if(native.onPress!=null)native.onPress();}
   });
   root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(!NativeMotion.isSynthetic(root))return;events.push({code:e.keyCode,down:false});if(e.keyCode==40 && native.downHandler)player.down=false;});
   return {root:root,player:player,body:body,native:native,events:events,input:new RobotInput(root)};
  }
  public static function run(display:MovieClip):void {
   var result:String;
   try {
    var f:Object=fixture(display);check(f.input.ready(),"live body/clip ready");
    f.input.play(sample(),0);check(f.native.attempts==1 && f.native.accepted==0,"normal native jump rejection is respected");
    check(f.body.velocity.vx==7 && f.body.velocity.vy==9 && f.player.x==100 && f.player.y==200,"rejected jump has no velocity or position fallback");
    f.input.tick(29);check(f.events.length==2,"pulse held for30ms without perframe key spam");f.input.tick(30);check(f.events.length==3 && f.events[2].code==38 && !f.events[2].down,"native key release at pulse deadline");
    f.native.canJump=true;f.input.play(sample(false,0),40);f.input.play(sample(true,-5),70);check(f.native.attempts==2 && f.native.accepted==1 && f.body.velocity.vy==-5,"accepted native handler owns physics impulse");
    f.input.tick(100);f.input.play(sample(true,-4.8),120);check(f.native.attempts==2,"held airborne recording does not repeat keydown");f.input.play(sample(true,-1),150);f.input.play(sample(true,-5),180);check(f.native.attempts==3,"renewed upward impulse requests a new native jump");
    f.input.play(sample(false,0),181);check(f.events[f.events.length-1].code==38 && !f.events[f.events.length-1].down,"final grounded sample cancels held pulse");
    f.input.play(sample(false,0,true,true),220);check(!f.player.left && !f.player.right,"contradictory flags release both horizontal keys");
    f.input.reset();check(!NativeMotion.get(f.root).inputBusy(),"reset releases shared ownership");
    f.input.play(sample(true,-5),250);check(f.native.attempts==4,"reset clears prior inference history");
    f.input.release();var count:int=f.events.length;f.input.tick(400);check(f.events.length==count,"release cancels later pending pulse callbacks");

    f=fixture(display);f.input.steer(110,100,0);check(f.native.attempts==1 && f.player.right,"steer uses horizontal key and native upward request");f.input.tick(30);f.input.steer(110,100,399);check(f.native.attempts==1,"steer jump retries bounded to400ms");f.input.steer(110,100,400);check(f.native.attempts==2,"steer can retry after400ms native rejection");f.input.steer(105,200,450);check(!f.player.left && !f.player.right,"steer stops in five-pixel horizontal dead zone");f.input.steer(400,100,900);check(f.native.attempts==2 && f.player.right,"distant elevated point does not trigger an unrelated jump");

    f=fixture(display);f.input.play(sample(false,0),0);check(!NativeMotion.get(f.root).busyExcept(f.input),"adapter itself is the single shared owner token");f.player.clip=false;f.input.tick(1);check(!f.input.ready() && !NativeMotion.get(f.root).inputBusy() && !f.player.right,"clip removal immediately releases held input");
    f=fixture(display);f.native.onPress=function():void{f.player.clip=false;};f.input.play(sample(),0);check(!NativeMotion.get(f.root).inputBusy(),"native callback removing clip cannot leave controls held");
    f=fixture(display);f.native.onPress=function():void{f.player.body={};};f.input.play(sample(),0);check(!NativeMotion.get(f.root).inputBusy(),"body replacement inside native callback releases previous ownership");
    f=fixture(display);var replacement:Object={body:{},clip:true,dead:false};f.native.onPress=function():void{f.root.tfm.local=replacement;};f.input.play(sample(),0);check(!NativeMotion.get(f.root).inputBusy(),"player replacement during native callback stops adapter");
    f=fixture(display);f.player.dead=true;f.input.play(sample(),0);check(!f.input.ready() && f.events.length==0,"dead player never receives automation input");
    f=fixture(display);delete f.root.Keys.player_clip;f.input.play(sample(),0);check(!f.input.ready() && f.events.length==0,"missing native readiness mappings fail closed");
    f=fixture(display);delete f.root.Keys.physics_state;delete f.root.Keys.physics_state_vx;delete f.root.Keys.physics_state_vy;delete f.root.Keys.get_linear_velocity;delete f.root.Keys.bot_set_position;delete f.root.Keys.b2vec2;f.native.canJump=true;f.input.play(sample(),0);check(f.native.accepted==1 && f.player.right,"adapter does not require coordinate or velocity mappings");
    f=fixture(display);f.native.canJump=true;f.input.resume(sample(true,-5),0);check(f.player.right && f.native.attempts==0,"resume restores direction without inventing a jump");f.input.play(sample(true,-4),40);check(f.native.attempts==0,"resume preserves airborne inference history");var request:Object=sample(true,-4);request.requestJump=true;f.input.play(request,80);check(f.native.attempts==1,"coalesced airborne batch may carry an explicit native request");request=sample(false,0);request.requestJump=true;f.input.play(request,120);check(f.native.attempts==1,"grounded final batch suppresses explicit jump request");f.input.crouch(true);check(f.player.down && !NativeMotion.get(f.root).busyExcept(f.input),"crouch shares the same input owner");f.input.crouch(false);check(!f.player.down,"crouch release uses native bridge");
    f=fixture(display);f.input.crouch(true);check(f.player.down && f.events.length==1 && f.events[0].code==40 && f.events[0].down,"crouch is an ordinary native Down keypress");f.input.crouch(true);check(f.events.length==1,"held crouch does not repeat keydown");f.input.release();check(!f.player.down && f.events.length==2 && f.events[1].code==40 && !f.events[1].down && !NativeMotion.get(f.root).inputBusy(),"release sends native Down keyup before dropping ownership");
    f=fixture(display);f.native.downHandler=false;f.input.crouch(true);check(!f.player.down && f.events[0].code==40 && f.events[0].down,"missing native crouch handler has no direct state fallback");f.input.release();
    f=fixture(display);f.input.crouch(true);NativeMotion.get(f.root).release(f.input);check(!NativeMotion.get(f.root).inputBusy(),"shared terminal handler may release owner before observer callback");f.input.release();check(f.events.length==2 && f.events[1].code==40 && !f.events[1].down,"observer cleanup clears remembered Down key after terminal ownership release");
    result="PASS: "+checks+" fresh RobotInput native-path checks";
   }catch(error:Error){result="FAIL: "+error.message+" #"+error.errorID;}
   ExternalInterface.call("recordTest",result);
  }
 }
}
