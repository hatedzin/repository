package disney {
 public class RobotRouteTests {
  private static var checks:int=0;
  private static function check(ok:Boolean,label:String):void{if(!ok)throw new Error(label);checks++;}
  private static function rejects(callback:Function,label:String):void{var rejected:Boolean=false;try{callback();}catch(error:Error){rejected=true;}check(rejected,label);}
  private static function payload():Object{return {x:4294967295,y:1102,vx:65535,vy:65036,frame:255,mr:true,ml:false,jump:true};}
  public static function run():String {
   checks=0;
   try {
    var p:Object=payload();var original:Array=[[p,"walk",12],["cheese",0],[0,"hole",3600000],[1,"crouch",0],[0,"duck",0],[3,"emote",1]];
    var route:Array=RobotRoute.validate(original);
    check(route.length==6 && route[1].length==3 && route[1][0]===null && route[1][1]=="cheese" && route[1][2]==0,"two-field marker normalization");
    check(route[2][0]===0 && route[2][2]==3600000,"three-field marker and maximum delay preserved");
    route[0][0].x=123;check(p.x==4294967295 && original[1].length==2,"validated movement owns a copy and original markers remain untouched");
    var point:Object=RobotRoute.movement(p);
    check(Math.abs(point.x+0.3)<0.000001 && Math.abs(point.y-330.6)<0.000001,"unsigned int32 positions decode to world pixels");
    check(Math.abs(point.vx+0.01)<0.000001 && point.vy==-5 && point.frame==-1,"unsigned int16 velocity and int8 frame decode with signed wrap");
    var mirrored:Object=RobotRoute.movement(p,true,800);check(Math.abs(mirrored.x-800.3)<0.000001 && Math.abs(mirrored.vx-0.01)<0.000001 && mirrored.ml && !mirrored.mr && mirrored.jump,"mirroring transforms X, horizontal metadata and directions");
    check(p.x==4294967295 && p.vx==65535 && p.mr && !p.ml,"movement conversion never mutates source payload");
    var signedPayload:Object={x:-2147483648,y:2147483647,vx:-32768,vy:32767,frame:-128,mr:false,ml:false,jump:false};var signedPoint:Object=RobotRoute.movement(signedPayload);check(signedPoint.x<0 && signedPoint.y>0 && signedPoint.vx==-327.68 && signedPoint.vy==327.67 && signedPoint.frame==-128,"signed range endpoints remain signed");
    rejects(function():void{RobotRoute.decode('[{"unused":1}]');},"invalid root entry rejected");
   }catch(initialError:Error){return "FAIL: RobotRoute "+initialError.message;}
   try {
    rejects(function():void{RobotRoute.decode('{}');},"JSON object is not a route array");
    rejects(function():void{RobotRoute.validate([]);},"empty route rejected");
    rejects(function():void{RobotRoute.validate(new Array(100001));},"excessive route length rejected before traversing sparse input");
    rejects(function():void{RobotRoute.validate([[null,"walk",0,0]]);},"wrong step arity rejected");
    rejects(function():void{RobotRoute.validate([["dance",0]]);},"unrecognized action rejected");
    rejects(function():void{RobotRoute.validate([[1,0]]);},"non-string action rejected");
    rejects(function():void{RobotRoute.validate([["emote",0]]);},"emote without payload rejected");
    rejects(function():void{RobotRoute.validate([["hole","12"]]);},"numeric string delay rejected");
    rejects(function():void{RobotRoute.validate([["hole",true]]);},"Boolean delay rejected");
    rejects(function():void{RobotRoute.validate([["hole",0.5]]);},"fractional delay rejected");
    rejects(function():void{RobotRoute.validate([["hole",Number.NaN]]);},"non-finite delay rejected");
    rejects(function():void{RobotRoute.validate([["hole",3600001]]);},"oversized delay rejected");
    rejects(function():void{var v:Object=payload();v.x="12";RobotRoute.validate([[v,"walk",0]]);},"numeric string position rejected");
    rejects(function():void{var v:Object=payload();v.y=4294967296;RobotRoute.movement(v);},"int32 overflow rejected");
    rejects(function():void{var v:Object=payload();v.vy=-32769;RobotRoute.movement(v);},"int16 underflow rejected");
    rejects(function():void{var v:Object=payload();v.frame=256;RobotRoute.movement(v);},"int8 overflow rejected");
    rejects(function():void{var v:Object=payload();v.jump=1;RobotRoute.movement(v);},"numeric jump flag rejected");
    rejects(function():void{RobotRoute.validate([[2,"duck",0]]);},"invalid crouch state rejected");
    rejects(function():void{RobotRoute.movement(payload(),true,Number.NaN);},"invalid mirrored map width rejected");
    var valid:Array=RobotRoute.decode('[[{"x":0,"y":0,"vx":0,"vy":0,"frame":0,"mr":false,"ml":false,"jump":false},"walk",0],["cheese",2],["hole",3]]');check(valid.length==3 && valid[0][0].jump===false,"real JSON types decode through independent route model");
    var fallback:Object={x:33,y:44};var xml:String='<C><Z><D><F Y="0"/><F X="" Y="0"/><F X="NaN" Y="1"/><F X="10" Y="20"/><F X="100" Y="200"/><T X="80" Y="90"/></D></Z></C>';
    var nearest:Object=RobotRoute.target(xml,"F",false,800,0,0,fallback);check(nearest.x==10 && nearest.y==20,"nearest descendant cheese chosen while missing, empty, and invalid attributes are ignored");
    var hole:Object=RobotRoute.target(xml,"T",false,800,0,0,fallback);check(hole.x==80 && hole.y==90,"hole target uses T descendants independently");
    nearest=RobotRoute.target(xml,"F",true,800,780,20,fallback);check(nearest.x==790 && nearest.y==20,"mirrored nearest target compares in world coordinates");
    nearest=RobotRoute.target('<C/>',"F",true,800,0,0,fallback);check(nearest.x==33 && nearest.y==44 && nearest!==fallback,"fallback is copied and is not mirrored twice");nearest.x=1;check(fallback.x==33,"caller fallback cannot be changed through returned target");
    nearest=RobotRoute.target('<C><F X="Infinity" Y="1"/></C>',"F",false,800,0,0,fallback);check(nearest.x==33,"non-finite XML coordinate ignored");
    nearest=RobotRoute.target('<C><bad>',"T",false,800,0,0,fallback);check(nearest.x==33,"malformed XML preserves valid fallback");
    nearest=RobotRoute.target(new Array(262146).join('x'),"F",false,800,0,0,fallback);check(nearest.x==33,"oversized XML is not parsed");
    nearest=RobotRoute.target('<!DOCTYPE C SYSTEM "http://invalid.invalid/map.dtd"><C><F X="1" Y="1"/></C>',"F",false,800,0,0,fallback);check(nearest.x==33,"external declaration rejected without resource access");
    check(RobotRoute.target('<C/>',"F",false,800,0,0,null)==null,"missing target and fallback return null");
    return "PASS: "+checks+" independent RobotRoute checks";
   }catch(error:Error){return "FAIL: RobotRoute "+error.message;}
  }
 }
}
