package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.text.TextField;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  public static function run(display:MovieClip):void{var result:String;try{
   var r:MovieClip=new MovieClip();display.addChild(r);r.stage.focus=r.stage;var downs:int=0;var ups:int=0;
   var p:Object={x:30,y:30,body:{},clip:true,dead:false,left:false,right:false,down:false,jump:function(on:Boolean):void{},crouch:function(side:Boolean):void{},stand:function(side:Boolean):void{}};
   r["Keys"]={player:"local",player_id:"id",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",is_down:"down",jump:"jump",crouch:"crouch",crouch2:"stand",map_class:{current:{number:{value:123},container:{mirror:false}},width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",bot_map_width:"width",obj_container:"container",bot_reverse:"mirror",move_class:{free:true},move_free:"free"};
   r["tfm"]={local:p};r["Interface"]={status_field:new TextField()};r["current_round_code"]=1;r["host_url"]="";r["current_map_xml"]="";r["auto_play"]=true;
   r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(r)&&e.keyCode==40){downs++;p.down=true;}});
   r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(r)&&e.keyCode==40){ups++;p.down=false;}});
   var bot:RobotController=new RobotController(r);bot.setRoutes({"@123":[[{x:100,y:100,vx:0,vy:0,mr:false,ml:false,jump:false,frame:0},"walk",0],[1,"crouch",0],[0,"crouch",1000],["hole",1000]]});bot.advance(0);bot.advance(300);
   if(!p.down||downs!=1)throw new Error("native crouch marker");var field:TextField=new TextField();field.type="input";r.addChild(field);r.stage.focus=field;bot.advance(350);if(p.down||ups!=1)throw new Error("chat releases native Down");r.stage.focus=r.stage;bot.advance(400);if(!p.down||downs!=2)throw new Error("chat resume restores held crouch");r["auto_play"]=false;bot.advance(450);if(p.down||ups!=2)throw new Error("disable releases restored native crouch");result="PASS: 4 crouch pause/resume checks";
   }catch(e:Error){result="FAIL: "+e.message+" #"+e.errorID;}ExternalInterface.call("recordTest",result);}
 }
}
