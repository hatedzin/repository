import importlib.util
from pathlib import Path
from unittest.mock import patch,MagicMock
import contextlib
import io
import tempfile
import unittest
import urllib.error

spec=importlib.util.spec_from_file_location('config',Path(__file__).with_name('configurar_github_rotas.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
TOKEN='github_pat_'+'X'*65
class ConfigTests(unittest.TestCase):
 def test_clipboard_formats(self):
  for value in (TOKEN,' '+TOKEN+'\r\n','"'+TOKEN+'"',"'"+TOKEN+"'",'TFM_GITHUB_ROUTES_TOKEN="'+TOKEN+'"','Bearer '+TOKEN,'\ufeff'+TOKEN,TOKEN[:30]+'\r\n'+TOKEN[30:]):
   with self.subTest(kind='clipboard form'):
    self.assertEqual(mod.normalize_token(value),TOKEN)
 def test_invalid_inputs_are_not_echoed(self):
  for value in ('','\x16','["parser_secret"]','parser_secret','not_a_github_secret','github_pat_'):
   with self.subTest(kind='invalid form'),self.assertRaises(ValueError) as captured:mod.normalize_token(value)
   if value:self.assertNotIn(value,str(captured.exception))
 def test_console_retries_empty_then_accepts(self):
  with patch.object(mod.os,'name','posix'),patch.object(mod,'getpass',side_effect=['',TOKEN]),contextlib.redirect_stdout(io.StringIO()) as output:
   self.assertEqual(mod.read_token(),TOKEN)
  self.assertNotIn(TOKEN,output.getvalue())
 def test_windows_uses_gui(self):
  with patch.object(mod.os,'name','nt'),patch.object(mod,'gui_token',return_value=TOKEN) as gui:
   self.assertEqual(mod.read_token(),TOKEN);gui.assert_called_once()
 def test_preserves_config_and_replaces_only_token(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'.env';path.write_text('MYSQL_HOST=127.0.0.1\nTFM_GITHUB_ROUTES_TOKEN=old\n# keep\n')
   mod.save_token(path,TOKEN);value=path.read_text();self.assertIn('MYSQL_HOST=127.0.0.1',value);self.assertIn('# keep',value);self.assertEqual(value.count('TFM_GITHUB_ROUTES_TOKEN='),1)
 def test_rejected_token_does_not_write_config(self):
  error=urllib.error.HTTPError('https://api.github.com',401,'Unauthorized',{},None)
  with patch.object(mod,'read_token',return_value=TOKEN),patch.object(mod.urllib.request,'urlopen',side_effect=error),patch.object(mod,'save_token') as save,contextlib.redirect_stdout(io.StringIO()):
   with self.assertRaisesRegex(ValueError,'HTTP401'):mod.main()
   save.assert_not_called()
if __name__=='__main__':unittest.main(verbosity=2)
