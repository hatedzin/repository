@echo off
setlocal
cd /d "%~dp0DisneyClient"
if exist "C:\ffmpeg\bin\ffmpeg.exe" set "PATH=C:\ffmpeg\bin;%PATH%"
py -3.11 musica_vps.py
echo.
pause
