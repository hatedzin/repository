package disney {import flash.display.MovieClip;public class RobotSuiteV6 {public static function attach(root:MovieClip):void{RobotControllerV6.attach(root);RouteRecorderV4.attach(root);}}}
