import base64
import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import AsyncMock
import zlib
from aiohttp import web
from aiohttp.test_utils import TestServer,TestClient

package=types.ModuleType('empty_test');package.__path__=[str(Path(__file__).parent)];sys.modules['empty_test']=package
common=types.ModuleType('empty_test.common');common.authorize=AsyncMock(return_value={'user_id':1,'level':1});sys.modules[common.__name__]=common
spec=importlib.util.spec_from_file_location('empty_test.map_storage',Path(__file__).with_name('map_storage.py'));module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
class LegacyCatalogTest(unittest.IsolatedAsyncioTestCase):
 async def test_old_account_catalog_is_not_read_or_returned(self):
  app=web.Application();db=types.SimpleNamespace(get_data=AsyncMock(side_effect=AssertionError('Legacy database read forbidden')));app['db']=db;app.router.add_view('/mapstorage',module.MapStorage)
  async with TestClient(TestServer(app)) as client:
   response=await client.get('/mapstorage');self.assertEqual(response.status,200);self.assertEqual(zlib.decompress(base64.b64decode(await response.read())),b'');self.assertEqual(response.headers['Cache-Control'],'no-store');db.get_data.assert_not_awaited()
if __name__=='__main__':unittest.main(verbosity=2)
