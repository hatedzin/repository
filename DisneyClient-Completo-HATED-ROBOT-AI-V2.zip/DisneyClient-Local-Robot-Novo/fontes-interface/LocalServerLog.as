package disney {
 import flash.display.*;import flash.events.*;import flash.text.*;import flash.utils.*;
 public class LocalServerLog {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var queue:Array=[];private var seen:Object={};private var welcomed:Boolean=false;private var chatOwner:Object;private var chosen:Dictionary=new Dictionary(true);private var next:int=0;private var nextSelection:int=0;
  private var labels:Object={auto_play:"Robot",auto_play_disable_on_move:"Parar Robot ao mover",hide_players:"Esconder jogadores",disable_objects:"Esconder objetos",disable_animations:"Desativar animacoes",disable_scoreboard:"Desativar placar",change_movement_speed:"Velocidade",mass_reduction:"Massa reduzida",change_jump_height:"Altura do pulo",change_jump_delay:"Delay do pulo",change_jump_speed:"Velocidade do pulo",born_period:"Delay para nascer",check_anti_leve:"Verificar anti-leve",low_ping:"Ping visual",recording:"Gravacao",get_map_xml:"XML automatico",soft_mode:"Modo soft"};
  public function LocalServerLog(value:MovieClip){root=value;}
  private static function get(value:MovieClip):LocalServerLog{if(!instances[value])instances[value]=new LocalServerLog(value);return instances[value] as LocalServerLog;}
  public static function attach(value:MovieClip):void{if(!value || !value.stage)return;var log:LocalServerLog=get(value);if(log.attached)return;log.attached=true;
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{if(getTimer()>=log.next){log.next=getTimer()+200;log.update();}});
   value.stage.addEventListener(MouseEvent.CLICK,function(e:MouseEvent):void{setTimeout(log.update,0);},true,-5000);
   value.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{setTimeout(log.update,0);},false,-5000);
  }
  private var attached:Boolean=false;
  public static function emit(value:MovieClip,text:String):void{if(!value)return;var log:LocalServerLog=get(value);log.queue.push(text);if(log.queue.length>100)log.queue.shift();log.flush();}
  private static function safe(text:String):String{return text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
  private function ready():Boolean{var k:Object=root["Keys"];var game:Object=root["tfm"];return Boolean(k && game && k.player && game[k.player] && k.chat_class2 && k.chat_message2 && k.chat_class2[k.chat_message2] is Function);}
  public function flush():void{if(!ready())return;var k:Object=root["Keys"];var sent:int=0;while(queue.length && sent<10){try{k.chat_class2[k.chat_message2]("<VP>[ASTRO]</VP> <BL>"+safe(String(queue[0]))+"</BL>");queue.shift();sent++;}catch(error:Error){return;}}}
  private static function isServer(text:String):Boolean{return /^(?:server|serv|serve|serveur|servidor)$/i.test(text.replace(/<[^>]*>/g,"").replace(/&(?:gt|lt|nbsp);/gi,"").replace(/[\s#>\[\]:]/g,""));}
  public function selectServer(force:Boolean=false):Boolean{
   if(!ready())return false;var k:Object=root["Keys"];var chat:Object=k.chat_class && k.chat_instance ? k.chat_class[k.chat_instance] : null;if(!chat)return false;
   if(chat!==chatOwner){chatOwner=chat;chosen=new Dictionary(true);nextSelection=0;}
   if(!force && chosen[chat])return true;if(!force && getTimer()<nextSelection)return false;nextSelection=getTimer()+1000;
   var start:DisplayObjectContainer=chat as DisplayObjectContainer;if(!start && k.chat_container)start=chat[k.chat_container] as DisplayObjectContainer;if(!start)return false;
   var pending:Array=[start];if(start.parent)pending.push(start.parent);if(start.parent && start.parent.parent)pending.push(start.parent.parent);var visited:Dictionary=new Dictionary(true);var count:int=0;var fallback:TextField;
   while(pending.length && count++<1200){var node:DisplayObject=pending.shift() as DisplayObject;if(!node || visited[node])continue;visited[node]=true;
    if(node is TextField){var f:TextField=node as TextField;if(f.type!=TextFieldType.INPUT && f.text.length<=256){
     if(!force && /^\s*\[\s*(?:Server|Serv|Serveur|Servidor)\s*\]\s*:\s*$/i.test(f.text)){chosen[chat]=true;return true;}
     var re:RegExp=/<A\b[^>]*HREF=["']event:([^"']+)["'][^>]*>([\s\S]*?)<\/A>/gi;var match:Object;
     while((match=re.exec(f.htmlText))!=null)if(isServer(String(match[2]))){chosen[chat]=true;var focus:InteractiveObject=root.stage.focus;f.dispatchEvent(new TextEvent(TextEvent.LINK,true,false,String(match[1])));root.stage.focus=focus;return true;}
     if(f.text.length<32 && !/^\s*\[/.test(f.text) && isServer(f.text))fallback=f;
    }}
    if(node is DisplayObjectContainer){var c:DisplayObjectContainer=node as DisplayObjectContainer;for(var i:int=0;i<c.numChildren;i++)pending.push(c.getChildAt(i));}
   }
   if(fallback){var candidate:DisplayObject=fallback;for(var d:int=0;d<3 && candidate;d++){if(candidate.hasEventListener(MouseEvent.MOUSE_DOWN) || candidate.hasEventListener(MouseEvent.CLICK)){chosen[chat]=true;var before:InteractiveObject=root.stage.focus;candidate.dispatchEvent(new MouseEvent(candidate.hasEventListener(MouseEvent.MOUSE_DOWN)?MouseEvent.MOUSE_DOWN:MouseEvent.CLICK,true));root.stage.focus=before;return true;}candidate=candidate.parent;}}
   return false;
  }
  public static function chatInput(value:MovieClip):TextField{try{var k:Object=value["Keys"];var chat:Object=k.chat_class[k.chat_instance];return chat[k.chat_container][k.chat_text_field] as TextField;}catch(error:Error){return null;}}
  private static function shown(node:DisplayObject):Boolean{while(node && !(node is Stage)){if(!node.visible || node.alpha<=0)return false;node=node.parent;}return true;}
  private static function channelState(value:MovieClip):int{
   try{var input:TextField=chatInput(value);if(!input || !input.stage)return -1;var k:Object=value["Keys"];var chat:Object=k.chat_class[k.chat_instance];var start:DisplayObjectContainer=chat[k.chat_container] as DisplayObjectContainer;if(!start)start=chat as DisplayObjectContainer;if(!start)return -1;
    var queue:Array=[start];var parent:DisplayObjectContainer=start.parent;for(var d:int=0;d<3 && parent;d++){queue.push(parent);parent=parent.parent;}var visited:Dictionary=new Dictionary(true);var count:int=0;var inputBox:flash.geom.Rectangle=input.getBounds(value.stage);var best:Number=Number.POSITIVE_INFINITY;var result:int=-1;
    while(queue.length && count++<1800){var node:DisplayObject=queue.shift() as DisplayObject;if(!node || visited[node])continue;visited[node]=true;
     if(node is TextField && node!==input && shown(node)){var f:TextField=node as TextField;var label:String=f.text.replace(/[\u200B-\u200F\u2060\uFEFF]/g,"").replace(/\u00A0/g," ");if(label.length<=64){var match:Object=/^\s*\[\s*([^\]]+)\s*\]\s*:?\s*$/.exec(label);var name:String=match?String(match[1]):label.replace(/^\s+|\s+$/g,"");var known:Boolean=match!=null || /^(?:server|serv|serve|serveur|servidor|sala|room|salon)$/i.test(name);
      if(known){var box:flash.geom.Rectangle=f.getBounds(value.stage);var glyphs:flash.geom.Rectangle=null;for(var ch:int=0;ch<Math.min(f.length,128);ch++){var glyph:flash.geom.Rectangle=f.getCharBoundaries(ch);if(glyph && glyph.width>0 && glyph.height>0)glyphs=glyphs?glyphs.union(glyph):glyph;}if(glyphs){var p0:flash.geom.Point=f.localToGlobal(new flash.geom.Point(glyphs.x,glyphs.y));var p1:flash.geom.Point=f.localToGlobal(new flash.geom.Point(glyphs.right,glyphs.bottom));box=new flash.geom.Rectangle(Math.min(p0.x,p1.x),Math.min(p0.y,p1.y),Math.abs(p1.x-p0.x),Math.abs(p1.y-p0.y));}var dy:Number=Math.abs((box.y+box.height/2)-(inputBox.y+inputBox.height/2));var gap:Number=inputBox.x-box.right;
       if(dy<=Math.max(20,inputBox.height) && gap>=-20 && gap<=240){var score:Number=Math.abs(gap)+dy*4;if(score<best){best=score;result=isServer(name)?1:0;}}
      }
     }}
     if(node is DisplayObjectContainer){var c:DisplayObjectContainer=node as DisplayObjectContainer;for(var i:int=0;i<c.numChildren;i++)queue.push(c.getChildAt(i));}
    }return result;
   }catch(error:Error){return -1;}
  }
  public static function serverActive(value:MovieClip):Boolean{return channelState(value)==1;}
  public static function musicServer(value:MovieClip):Boolean{var state:int=channelState(value);if(state>=0)return state==1;return get(value).selectServer(true);}
  public function update():void{
   for(var key:String in labels){if(!(key in root))continue;var value:Boolean=Boolean(root[key]);if(!(key in seen)){seen[key]=value;continue;}if(Boolean(seen[key])!=value){seen[key]=value;emit(root,labels[key]+": "+(value?"ativado":"desativado"));}}
   if(ready()){try{selectServer();}catch(selectionError:Error){}if(!welcomed){welcomed=true;emit(root,"Bem-vindo ao ASTRO MENU. Avisos locais no SERVER.");}flush();}
  }
 }
}
