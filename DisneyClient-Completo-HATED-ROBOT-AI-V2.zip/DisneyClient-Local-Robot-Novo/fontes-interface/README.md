# Interface do upload (8)

Veja `INTERFACE-PLAYERS-SERVER-LEIA-ME.txt` na raiz para uso, instalação e limites.

- `FollowPlayersPanel.as`: lista baseada nos objetos atuais de Keys.player_list; seleção válida por identidade, busca e rolagem isolada.
- `MenuShell.as`: estrutura do menu, navegação Follow separada da classe nativa selada e preferência de opacidade.
- `LocalServerLog.as`: avisos locais, seleção inicial de SERVER por eventos dos controles nativos e observação de flags conhecidas; não usa sender de sala.
- `SettingsControlsUI.as` e `PerformanceControlsUI.as`: cópias das rotinas da base, com avisos explícitos de ativação.
- `InterfaceTests.as`: seleção por clique, convidados, saída da sala, logs, controles nativos, fila de avisos, opacidade e preservação de abas.

O build copia as fontes para fontes-robot e adiciona as classes ao loader-base original; não sobrescreva esse arquivo base. O verificador compara todos os corpos de métodos já existentes e permite somente as alterações explícitas de inicialização/retirada legada. Robot e NativeMotion da base não são substituídos por outra implementação de movimento.
