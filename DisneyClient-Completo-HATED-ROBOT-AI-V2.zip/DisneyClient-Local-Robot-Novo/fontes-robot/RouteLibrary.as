package disney {
 public class RouteLibrary {
  public var entries:Object={};public var count:int=0;public var done:Boolean=false;public var position:int=0;
  private var tokens:RegExp=/"(?:[^"\\]|\\.)*"|[\[\]{}]/g;private var text:String;private var state:int=-1;private var key:String;private var start:int=0;private var depth:int=0;private var quoted:Boolean=false;private var escaped:Boolean=false;
  public function RouteLibrary(value:String){text=value;}
  public function step(budget:int=32768):Boolean{
   if(done)return true;var end:int=Math.min(text.length,position+budget);
   while(position<end){
    var c:String=text.charAt(position);
    if(state==2){
     tokens.lastIndex=position;var match:Object=tokens.exec(text);
     if(!match)throw new Error("Incomplete route array",2519);
     var token:String=String(match[0]);position=int(tokens.lastIndex);
     if(token.charAt(0)=='"')continue;
     if(token=="[" || token=="{")depth++;else {depth--;if(depth==0){entries[key]=text.substring(start,position);count++;state=3;}}
     continue;
    }
    if(/\s/.test(c)){position++;continue;}
    if(state==-1){if(c!="{")throw new Error("Route dictionary required",2510);state=0;position++;continue;}
    if(state==0){
     if(c=="}" && count==0){position++;state=4;continue;}
     if(c!='"')throw new Error("Expected map key",2511);
     var close:int=text.indexOf('"',position+1);if(close<0)throw new Error("Unterminated map key",2512);
     key=text.substring(position+1,close);if(!/^@(?:[0-9]+|a|v)$/.test(key) || key in entries)throw new Error("Invalid or duplicate map key: "+key,2513);
     position=close+1;state=1;continue;
    }
    if(state==1){if(c!=":")throw new Error("Expected colon",2514);position++;state=5;continue;}
    if(state==5){if(c!="[")throw new Error("Expected route array",2515);start=position;depth=0;quoted=false;escaped=false;state=2;continue;}
    if(state==3){if(c==","){state=0;position++;continue;}if(c=="}"){state=4;position++;continue;}throw new Error("Expected comma or dictionary end",2516);}
    if(state==4)throw new Error("Unexpected trailing data",2517);
   }
   if(position>=text.length){if(state!=4 || count==0)throw new Error("Incomplete or empty route library",2518);done=true;text="";}
   return done;
  }
 }
}
