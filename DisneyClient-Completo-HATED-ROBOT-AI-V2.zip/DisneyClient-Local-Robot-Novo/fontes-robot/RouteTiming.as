package disney {
 public class RouteTiming {
  public var enabled:Boolean;private var state:uint;private var microX:Number=0;private var target:Number=0;private var nextRest:int=0;private var restBudget:int=0;
  public function RouteTiming(seed:uint=1,allow:Boolean=true){state=seed==0 ? 1 : seed;enabled=allow;}
  public function reset(now:int=0):void{microX=0;target=0;restBudget=0;nextRest=now+1500+int(random()*2001);}
  private function random():Number{state^=state<<13;state^=state>>>17;state^=state<<5;return Number(state)/4294967296;}
  public function startDelay():int{return 0;}
  public function idleDelay(now:int):int{return 0;}
  public function restDelay(now:int,eligible:Boolean):int{
   if(!enabled || !eligible || now<nextRest || restBudget+35>1500)return 0;
   var duration:int=16+int(random()*20);restBudget+=duration;nextRest=now+1500+int(random()*2001);return duration;
  }
  public function coordinateX(eligible:Boolean):Number{
   if(!enabled)return 0;
   if(!eligible){microX=0;target=0;return 0;}
   if(Math.abs(target-microX)<0.001)target=(random()*2-1)*0.05;
   microX+=Math.max(-0.01,Math.min(0.01,target-microX));return microX;
  }
 }
}
