package disney {
 import flash.display.*;import flash.events.*;import flash.text.*;import flash.filters.DropShadowFilter;import flash.utils.Dictionary;import flash.utils.getTimer;
 public class AstroVisual {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var panel:Sprite;private var styled:Dictionary=new Dictionary(true);private var botDone:Dictionary=new Dictionary(true);private var title:TextField;private var last:int=-1000;
  public function AstroVisual(value:MovieClip){root=value;}
  public static function attach(value:MovieClip):void{if(!value || !value.stage || instances[value])return;LocalServerLog.attach(value);MusicPlayer.attach(value);FollowAutoBest.attach(value);FlyController.attach(value);var view:AstroVisual=new AstroVisual(value);instances[value]=view;try{view.update();}catch(initialError:Error){}value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{if(getTimer()-view.last>=150){try{view.update();}catch(renderError:Error){}}});value.stage.addEventListener(Event.RESIZE,function(e:Event):void{try{view.fit(false);}catch(resizeError:Error){}});}
  private function field(text:String,size:int,color:uint):TextField{var t:TextField=new TextField();t.defaultTextFormat=new TextFormat("_sans",size,color,true);t.text=text;t.selectable=false;t.mouseEnabled=false;return t;}
  private function top(node:DisplayObject,parent:DisplayObjectContainer):DisplayObject{if(!node)return null;var n:int=0;while(node.parent && node.parent!==parent && n++<20)node=node.parent;return node.parent===parent ? node : null;}
  private function layoutBot(ui:Object):void{
   var bot:DisplayObjectContainer=ui["bot_ui"] as DisplayObjectContainer;if(!bot || botDone[bot])return;
   var auto:DisplayObject=top(ui["auto_play_check_box"] as DisplayObject,bot);var stop:DisplayObject=top(ui["stop_play_check_box"] as DisplayObject,bot);var status:DisplayObject=top(ui["status_field"] as DisplayObject,bot);var buttons:DisplayObject=top(ui["rec_button"] as DisplayObject,bot);var maps:DisplayObject=top(ui["ls_maps_button"] as DisplayObject,bot);
   var parts:Array=[auto,stop,status,buttons,maps];var seen:Dictionary=new Dictionary(true);for each(var node:DisplayObject in parts){if(!node || seen[node])return;seen[node]=true;}
   bot.scrollRect=null;bot.mask=null;var options:DisplayObject=ui["options_ui"] as DisplayObject;if(options)options.scrollRect=null;
   var body:Sprite=new Sprite();body.name="astroRobotContent";
   while(bot.numChildren)bot.removeChildAt(0);
   var ys:Array=[0,32,68,124,160];for(var n:int=0;n<parts.length;n++){node=parts[n];node.x=0;node.y=ys[n];body.addChild(node);}
   var text:TextField=ui["status_field"] as TextField;if(text){text.width=512;text.height=44;text.wordWrap=true;text.multiline=true;text.background=true;text.backgroundColor=0x14243A;}
   var hint:TextField=field("Coordenadas gravadas | sem interpolacao",10,0x8FA6BD);hint.y=200;hint.width=520;hint.height=20;body.addChild(hint);bot.addChild(body);botDone[bot]=true;
   var preview:DisplayObject=ui["preview_button"] as DisplayObject;if(preview){preview.visible=false;if(preview is InteractiveObject)InteractiveObject(preview).mouseEnabled=false;}
  }
  private function paintNav(button:Sprite,id:String,ui:Object):void{var active:Boolean=String(ui["last_tab"])==id;button.graphics.clear();button.graphics.beginFill(active ? 0x293B63 : 0x132039);button.graphics.drawRoundRect(0,0,142,40,8,8);button.graphics.endFill();if(active){button.graphics.beginFill(0x8EA6FF);button.graphics.drawRoundRect(0,10,3,20,3,3);button.graphics.endFill();}var t:TextField=button.numChildren ? button.getChildAt(0) as TextField : null;if(t)t.textColor=active ? 0xEFFFFA : 0xA9BDD2;}
  private function textStyle(node:DisplayObject,depth:int=0):void{
   if(depth>12)return;
   if(node is TextField){var t:TextField=node as TextField;var f:TextFormat=t.getTextFormat();f.font="_sans";if(Number(f.size)<11)f.size=11;f.color=t.type==TextFieldType.INPUT ? 0xF0F6FF : 0xD8E5F2;t.defaultTextFormat=f;t.setTextFormat(f);
    if(t.type==TextFieldType.INPUT){t.background=true;t.backgroundColor=0x0B1626;t.border=true;t.borderColor=0x35526C;}
    else{if(t.text=="DISNEY"){t.text="ASTRO";t.width=110;}if(t.text=="CLIENT / CONTROLE")t.text="MENU DO CLIENTE";if(t.text=="Bot")t.text="Robot";if(t.text.indexOf("Autoplay (")==0)t.text="Robot (2.359 rotas) [F2]";}
   }
   if(node is DisplayObjectContainer){var c:DisplayObjectContainer=node as DisplayObjectContainer;for(var i:int=0;i<c.numChildren;i++)textStyle(c.getChildAt(i),depth+1);}
  }
  public function fit(center:Boolean):void{if(!panel || !root.stage)return;var factor:Number=Math.max(0.2,Math.min(1,(root.stage.stageWidth-24)/760,(root.stage.stageHeight-72)/430));panel.scaleX=factor;panel.scaleY=factor;if(center){panel.x=(root.stage.stageWidth-760*factor)/2;panel.y=Math.max(44,(root.stage.stageHeight-430*factor)/2);}panel.x=Math.max(8,Math.min(panel.x,root.stage.stageWidth-760*factor-8));panel.y=Math.max(44,Math.min(panel.y,root.stage.stageHeight-430*factor-8));if(title)title.x=Math.max(112,(root.stage.stageWidth-title.width)/2);}
  public function update():void{
   last=getTimer();if(!root.stage)return;
   if(!title){title=field("ASTRO MENU",17,0x9AB1FF);title.name="astroClientTitle";title.width=180;title.height=27;title.y=9;var fmt:TextFormat=title.getTextFormat();fmt.align="center";title.setTextFormat(fmt);root.stage.addChild(title);}title.x=Math.max(112,(root.stage.stageWidth-title.width)/2);
   var button:Sprite=root.stage.getChildByName("disneyMenuButton") as Sprite;if(button){button.graphics.clear();button.graphics.lineStyle(1,0x386475);button.graphics.beginFill(0x102438);button.graphics.drawRoundRect(0,0,100,28,8,8);button.graphics.endFill();for(var k:int=0;k<button.numChildren;k++){var label:TextField=button.getChildAt(k) as TextField;if(label){label.text="Menu";label.x=0;label.width=100;var format:TextFormat=new TextFormat("_sans",12,0xE6F6FF,true);format.align="center";label.defaultTextFormat=format;label.setTextFormat(format);}}}
   var ui:Object=root["Interface"];if(!ui)return;var next:Sprite=ui["menu_ui"] as Sprite;if(!next || !next.parent || !next.visible)return;
   if(panel!==next){panel=next;panel.graphics.clear();panel.graphics.lineStyle(1,0x29445E);panel.graphics.beginFill(0x0A1323,0.99);panel.graphics.drawRoundRect(0,0,760,430,16,16);panel.graphics.endFill();panel.graphics.lineStyle(1,0x23394F);panel.graphics.moveTo(0,62);panel.graphics.lineTo(760,62);panel.graphics.moveTo(173,62);panel.graphics.lineTo(173,398);panel.graphics.moveTo(18,398);panel.graphics.lineTo(742,398);panel.graphics.lineStyle();panel.graphics.beginFill(0x8EA6FF);panel.graphics.drawRoundRect(20,21,5,20,4,4);panel.graphics.endFill();panel.graphics.beginFill(0x101E34);panel.graphics.drawRoundRect(187,137,555,250,12,12);panel.graphics.endFill();panel.filters=[new DropShadowFilter(6,90,0,0.35,18,18,1,2)];fit(true);}
   panel.alpha=MenuShell.opacity(root);var badge:TextField=panel.getChildByName("astroSessionBadge") as TextField;if(!badge){badge=field("",10,0x73DFC1);badge.name="astroSessionBadge";badge.x=310;badge.y=24;badge.width=145;badge.height=18;panel.addChild(badge);}var keys:Object=root["Keys"];badge.text=keys && root["tfm"] && root["tfm"][keys.player]?"● CONECTADO":"● CONECTANDO";
   layoutBot(ui);textStyle(panel);
   var ids:Object={"Jogador":"general","Farm":"farm","Bot":"bot","Robot":"bot","Atalhos":"keyboard","Ajustes":"settings","Follow":"follow"};
   for(var i:int=0;i<panel.numChildren;i++){var nav:Sprite=panel.getChildAt(i) as Sprite;if(!nav || nav.x!=16 || !nav.numChildren)continue;var t:TextField=nav.getChildAt(0) as TextField;if(!t || !ids[t.text])continue;paintNav(nav,ids[t.text],ui);if(!styled[nav]){bindNav(nav,String(ids[t.text]),ui);styled[nav]=true;}}
  }
  private function bindNav(nav:Sprite,id:String,ui:Object):void{nav.addEventListener(MouseEvent.MOUSE_OVER,function(e:MouseEvent):void{paintNav(nav,id,ui);},false,-100);nav.addEventListener(MouseEvent.MOUSE_OUT,function(e:MouseEvent):void{paintNav(nav,id,ui);},false,-100);nav.addEventListener(MouseEvent.CLICK,function(e:MouseEvent):void{update();},false,-100);}
 }
}
