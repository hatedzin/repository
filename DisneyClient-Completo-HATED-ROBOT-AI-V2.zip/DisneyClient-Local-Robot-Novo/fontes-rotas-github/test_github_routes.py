import asyncio
import base64
import importlib.util
import json
import sys
import types
import unittest
import zlib
from pathlib import Path
from unittest.mock import AsyncMock
from aiohttp import web, ClientSession
from aiohttp.test_utils import TestServer,TestClient

BASE=Path(__file__).parent
package=types.ModuleType('route_test');package.__path__=[str(BASE)];sys.modules['route_test']=package
common=types.ModuleType('route_test.common');common.authorize=AsyncMock(return_value={'user_id':7,'level':1});sys.modules[common.__name__]=common
infrastructure=types.ModuleType('infrastructure');sys.modules['infrastructure']=infrastructure
spec=importlib.util.spec_from_file_location('route_test.github_routes',BASE/'github_routes.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
setup_spec=importlib.util.spec_from_file_location('route_setup',BASE/'configurar_github_rotas.py');setup=importlib.util.module_from_spec(setup_spec);setup_spec.loader.exec_module(setup)

def route(direction=True):
 return [[{'x':400,'y':1100,'vx':330,'vy':0,'frame':0,'ml':not direction,'mr':direction,'jump':False},'walk',0],[0,'cheese',100],[0,'hole',100]]

def info(value):
 return base64.b64encode(zlib.compress(json.dumps(value).encode())).decode()

class Validation(unittest.TestCase):
 def test_roundtrip(self):self.assertEqual(mod.decode_route(info(route())),route())
 def test_limits_and_types(self):
  for value in ([],{},route()[:-1],[[{'x':0},'walk',0],[0,'hole',0]],[[0,'hole',True]],[[0,'emote',0],[0,'hole',1]]):
   with self.subTest(value=value),self.assertRaises(ValueError):mod.validate_route(value)
  for member in ('jump','mr','ml'):
   bad=route();bad[0][0][member]=1
   with self.assertRaises(ValueError):mod.validate_route(bad)
  bad=route();bad[0][0]['x']=10**2000
  with self.assertRaises(ValueError):mod.validate_route(bad)
 def test_decompression_bomb_and_trailing(self):
  for raw in (zlib.compress(b' '* (mod.MAX_ROUTE+1)),zlib.compress(b'[]')+b'trailing'):
   with self.assertRaises(ValueError):mod.decode_route(base64.b64encode(raw).decode())
 def test_setup_preserves_settings(self):
  import tempfile
  with tempfile.TemporaryDirectory() as directory:
   path=Path(directory)/'.env';path.write_text('DB_HOST=127.0.0.1\nTFM_GITHUB_ROUTES_TOKEN=old\n# comment\n')
   setup.save_token(path,'fixture_token');text=path.read_text();self.assertIn('DB_HOST=127.0.0.1',text);self.assertIn('# comment',text);self.assertEqual(text.count('TFM_GITHUB_ROUTES_TOKEN='),1);self.assertIn('=fixture_token',text)

class GitHubIntegration(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.data={'@9':route(False)};self.revision=1;self.puts=[];self.conflict=False;self.invalid=False;self.denied=False;self.gets=0
  async def content(request):
   self.assertEqual(request.headers.get('Authorization'),'Bearer fixture_token')
   if self.denied:return web.json_response({'message':'sensitive response omitted'},status=403)
   if request.method=='GET':
    self.gets+=1;raw=b'not-json' if self.invalid else json.dumps(self.data).encode()
    return web.json_response({'sha':str(self.revision).zfill(40),'encoding':'base64','content':base64.b64encode(raw).decode()})
   payload=await request.json();self.puts.append(payload)
   if self.conflict:
    self.conflict=False;self.data['@77']=route();self.revision+=1;return web.json_response({},status=409)
   if payload['sha']!=str(self.revision).zfill(40):return web.json_response({},status=409)
   self.assertEqual(payload['branch'],'main');self.data=json.loads(base64.b64decode(payload['content']));self.revision+=1
   return web.json_response({'content':{'sha':str(self.revision).zfill(40)}})
  fake=web.Application();fake.router.add_route('*','/repos/contents/rotas-novas.json',content)
  self.server=TestServer(fake);await self.server.start_server();self.session=ClientSession();self.catalog=mod.Catalog(self.session,'fixture_token',api=str(self.server.make_url('/repos')).rstrip('/'))
  app=web.Application();app['config']={'storage_allowed_levels':[1]};app['github_routes']=self.catalog;app.router.add_view('/github-routes',mod.GitHubRoutes)
  self.client=TestClient(TestServer(app));await self.client.start_server()
 async def asyncTearDown(self):await self.client.close();await self.session.close();await self.server.close()
 async def test_save_preserves_routes_and_get(self):
  response=await self.client.post('/github-routes?method=save',data={'code':'@123','info':info(route())});self.assertEqual(response.status,204);self.assertEqual(self.data['@9'],route(False));self.assertEqual(self.data['@123'],route());self.assertNotIn('fixture_token',json.dumps(self.data))
  loaded=await self.client.get('/github-routes?code=@123');self.assertEqual(loaded.status,200);self.assertEqual(await loaded.json(),route());self.assertEqual(loaded.headers['Cache-Control'],'no-store')
 async def test_conflict_retry_preserves_concurrent_edit(self):
  self.conflict=True;await self.catalog.publish('@123',route());self.assertIn('@77',self.data);self.assertIn('@9',self.data);self.assertEqual(len(self.puts),2);self.assertNotEqual(self.puts[0]['sha'],self.puts[1]['sha'])
 async def test_missing_token_is_explicit(self):
  self.catalog.token='';r=await self.client.post('/github-routes?method=save',data={'code':'@123','info':info(route())});self.assertEqual(r.status,503);self.assertIn('CONFIGURAR', (await r.json())['error']);self.assertFalse(self.puts)
 async def test_invalid_existing_json_never_overwritten(self):
  self.invalid=True
  with self.assertRaises(mod.CatalogError):await self.catalog.publish('@123',route())
  self.assertFalse(self.puts)
 async def test_permission_errors_are_sanitized(self):
  self.denied=True;r=await self.client.post('/github-routes?method=save',data={'code':'@123','info':info(route())});self.assertEqual(r.status,503);body=await r.text();self.assertNotIn('fixture_token',body);self.assertNotIn('sensitive response',body)
 async def test_bad_route_and_code_never_write(self):
  for code,data in (('../x',info(route())),('@123',info([])),('@123','broken')):
   r=await self.client.post('/github-routes?method=save',data={'code':code,'info':data});self.assertEqual(r.status,400)
  self.assertFalse(self.puts)
 async def test_cache_and_missing_code(self):
  await self.catalog.read();await self.catalog.read();self.assertEqual(self.gets,1);r=await self.client.get('/github-routes?code=@999');self.assertEqual(r.status,404)
 async def test_concurrent_local_saves(self):
  await asyncio.gather(self.catalog.publish('@123',route()),self.catalog.publish('@456',route(False)));self.assertEqual(set(self.data),{'@9','@123','@456'})

if __name__=='__main__':unittest.main(verbosity=2)
