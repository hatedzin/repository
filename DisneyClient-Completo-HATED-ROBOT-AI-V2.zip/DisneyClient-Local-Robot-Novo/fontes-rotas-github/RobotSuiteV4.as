package disney {import flash.display.MovieClip;public class RobotSuiteV4 {public static function attach(root:MovieClip):void{RobotControllerV4.attach(root);RouteRecorderV2.attach(root);}}}
