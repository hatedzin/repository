# FollowAutoBest

Fonte canônica: `FollowAutoBest.as`. Consulte `FOLLOWAUTOBEST-LEIA-ME.txt` na raiz para comando, limites e instalação. `AutoBestTests.as` executa o controlador real em Ruffle, com perfis, eventos e física simulados. O build copia o controlador para fontes-robot, compila após RoutePlayerNative e adiciona o filtro de perfil ao início de MainTimeline.handle_packet. Todos os demais pacotes seguem o processamento original com cursor preservado.

A instância gerenciada de RoutePlayer não registra um segundo observador de pacotes nem usa o flag global auto_play. O controle de teclas é compartilhado por NativeMotion; os bloqueios após a vitória continuam ativos. Não acrescente envio de pacotes de queijo, toca ou morte.
