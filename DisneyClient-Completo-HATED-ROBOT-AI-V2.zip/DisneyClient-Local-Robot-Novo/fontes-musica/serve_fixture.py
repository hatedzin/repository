"""Local synthetic-audio fixture. Not the production server; never deploy this."""
import asyncio
import shutil
import tempfile
from pathlib import Path
from aiohttp import web
from test_music import music
async def main():
    tmp=tempfile.TemporaryDirectory();folder=Path(tmp.name);tone=folder/'tone.mp3'
    process=await asyncio.create_subprocess_exec('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=3','-codec:a','libmp3lame','-b:a','128k',str(tone));assert await process.wait()==0
    async def worker(job,dest):
        await asyncio.sleep(.1);shutil.copyfile(tone,dest/'audio.mp3');job['title']='Audio sintetico de teste'
    async def auth(request):
        if request.query.get('access_token')!='TEST' or request.query.get('flash_token')!='FLASH':raise web.HTTPUnauthorized()
        return {'user_id':7}
    music.authorize=auth;app=web.Application();store=music.MusicJobs(folder/'cache',worker);app['music_jobs']=store;app.router.add_view('/music',music.Music);app.router.add_get('/music/audio/{ident}.mp3',music.audio)
    runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();print('Fixture API port:',site._server.sockets[0].getsockname()[1],flush=True)
    try:await asyncio.Event().wait()
    finally:await store.close();await runner.cleanup();tmp.cleanup()
if __name__=='__main__':asyncio.run(main())
