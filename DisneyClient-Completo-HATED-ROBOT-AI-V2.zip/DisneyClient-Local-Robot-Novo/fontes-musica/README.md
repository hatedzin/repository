# Player de música

Consulte `MUSICA-YOUTUBE-LEIA-ME.txt` na raiz para uso e instalação. A função exige o SWF e o backend atualizado, yt-dlp e FFmpeg/ffprobe. O arquivo `.env` existente permanece.

- `DisneyClient/api/music.py`: jobs autenticados, serialização por requisição de criação, extração assíncrona em processo separado, arquivo MP3 privado e cancelamento.
- `fontes-interface/MusicPlayer.as`: comando no chat nativo SERVER, mini painel e Sound/SoundChannel. Não altera movimentação, sockets do jogo ou mensagens da sala.
- `test_music.py`: testes locais, sem banco/.env e sem baixar vídeos.
- `serve_fixture.py`: servidor efêmero local com autenticação fictícia e áudio gerado. Nunca usar em produção.

Resultado atual e escopo da verificação: `VALIDACAO.json`, `RESULTADOS-CLIENTE.txt` e `RESULTADOS-PYTHON.txt`.
