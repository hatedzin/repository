"""Immutable AI V2 learning snapshots; separate from the legacy route catalog."""
import asyncio,base64,hashlib,json,math,re,time,threading
from pathlib import Path
from aiohttp import web
from .common import authorize
from .github_routes import catalog, CatalogError, BRANCH

def validate(value):
 if not isinstance(value,dict) or value.get('schema')!=2:raise ValueError('Schema AI V2 invalido')
 if not re.fullmatch(r'@[1-9][0-9]{0,9}',str(value.get('map',''))):raise ValueError('Mapa invalido')
 if not re.fullmatch(r'[a-f0-9]{1,8}',str(value.get('geometry',''))):raise ValueError('Geometria invalida')
 route=value.get('route');points=route.get('points') if isinstance(route,dict) else None
 if not isinstance(points,list) or not 2<=len(points)<=6000 or route.get('physics')!='observed-si-v2':raise ValueError('Trajeto invalido')
 last=-1
 for p in points:
  if not isinstance(p,dict) or set(p)-{'x','y','t','phase','air','crouch'}:raise ValueError('Ponto invalido')
  if any(type(p.get(k)) not in (int,float) or not math.isfinite(p[k]) or abs(p[k])>1000000 for k in ('x','y')):raise ValueError('Coordenada invalida')
  if type(p.get('t')) not in (int,float) or not math.isfinite(p['t']) or p['t']<last or not 0<=p['t']<=600000:raise ValueError('Tempo invalido')
  if p.get('phase') not in ('cheese','hole'):raise ValueError('Objetivo invalido')
  if any(k in p and type(p[k]) is not bool for k in ('air','crouch')):raise ValueError('Estado de movimento invalido')
  last=p['t']
 if type(route.get('wins')) is not int or route['wins']<1:raise ValueError('Sem vitoria registrada')
 raw=json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
 if len(raw)>1024*1024:raise ValueError('Aprendizado muito grande')
 return raw

LOCK=threading.Lock()
def store(root,uid,raw,code):
 with LOCK:return _store(root,uid,raw,code)
def _store(root,uid,raw,code):
 folder=Path(root)/'data'/'hated-ai-v2'/str(int(uid));folder.mkdir(parents=True,exist_ok=True)
 digest=hashlib.sha256(raw).hexdigest();name=code[1:]+'-'+digest+'.json';path=folder/name
 try:
  with path.open('xb') as f:f.write(raw)
 except FileExistsError:
  if path.read_bytes()!=raw:raise ValueError('Conflito de integridade')
 files=sorted(folder.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
 for old in files[64:]:old.unlink(missing_ok=True)
 logs=Path(root).parent/'logs-client';logs.mkdir(exist_ok=True);log=logs/('hated-ai-'+str(int(uid))+'.jsonl')
 if log.exists() and log.stat().st_size>2*1024*1024:log.replace(log.with_suffix('.previous.jsonl'))
 with log.open('a',encoding='utf-8') as f:f.write(json.dumps({'time':time.time(),'map':code,'sha256':digest,'event':'learning_saved'})+'\n')
 return name,digest

async def publish(service,name,raw):
 if not service.token:raise CatalogError('Configure o token GitHub no configurador existente',503,'missing_token')
 suffix='/contents/hated-ai-v2/'+name
 status,item=await service.request('GET',suffix,params={'ref':BRANCH})
 if status==200:
  try:existing=base64.b64decode(item.get('content',''),validate=False)
  except ValueError:existing=b''
  if existing==raw:return {'published':True,'unchanged':True,'path':'hated-ai-v2/'+name}
  raise CatalogError('Arquivo remoto existente preservado; conflito de integridade',409,'conflict')
 if status!=404:raise CatalogError('Falha ao verificar destino remoto')
 status,item=await service.request('PUT',suffix,json={'message':'Add AI V2 learned route '+name[:20],'branch':BRANCH,'content':base64.b64encode(raw).decode()})
 if status!=201:raise CatalogError('GitHub nao confirmou criacao; arquivo existente nao foi sobrescrito',409,'conflict')
 return {'published':True,'path':'hated-ai-v2/'+name}

class HatedAI(web.View):
 async def post(self):
  user=await authorize(self.request,allow_cookie=True)
  try:
   form=await self.request.post();text=form.get('data','')
   if not isinstance(text,str) or len(text)>1024*1024:raise ValueError('Dados excedem limite')
   value=json.loads(text);raw=validate(value)
   name,digest=await asyncio.to_thread(store,self.request.app['root'],user['user_id'],raw,value['map'])
   result={'saved':True,'sha256':digest}
   if self.request.query.get('publish')=='1':result.update(await publish(catalog(self.request),name,raw))
   return web.json_response(result,headers={'Cache-Control':'no-store'})
  except CatalogError as e:return web.json_response({'saved':True,'published':False,'error':e.message},status=e.status)
  except (ValueError,TypeError,OverflowError):raise web.HTTPBadRequest(reason='Aprendizado AI V2 invalido') from None
