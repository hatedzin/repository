"""Publish validated game routes to one fixed GitHub catalog from the local server."""
import asyncio
import base64
import binascii
import json
import math
import os
import re
import zlib
from pathlib import Path
from dotenv import dotenv_values

import aiohttp
from aiohttp import web
import infrastructure
from .common import authorize

REPOSITORY = 'hatedzin/repository'
BRANCH = 'main'
FILE = 'rotas-novas.json'
API = 'https://api.github.com/repos/' + REPOSITORY
MAX_ROUTE = 262144
MAX_CATALOG = 4 * 1024 * 1024


def number(value, low, high):
    return type(value) in (int, float) and low <= value <= high and math.isfinite(value) and value == int(value)


def validate_route(route):
    if not isinstance(route, list) or not 1 <= len(route) <= 1800:
        raise ValueError('Lista de passos invalida')
    walks = 0
    for step in route:
        if not isinstance(step, list) or len(step) not in (2, 3):
            raise ValueError('Formato de passo invalido')
        action, delay = step[-2:]
        if not isinstance(action, str) or action not in {'walk','cheese','hole','crouch','duck','emote'} or not number(delay, 0, 3600000):
            raise ValueError('Acao ou intervalo invalido')
        payload = step[0] if len(step) == 3 else None
        if action == 'walk':
            if not isinstance(payload, dict):
                raise ValueError('Movimento invalido')
            ranges = {'x':(-2147483648,4294967295),'y':(-2147483648,4294967295),'vx':(-32768,65535),'vy':(-32768,65535),'frame':(-128,255)}
            if any(not number(payload.get(k), *bounds) for k,bounds in ranges.items()) or any(type(payload.get(k)) is not bool for k in ('ml','mr','jump')):
                raise ValueError('Coordenadas ou controles invalidos')
            if set(payload) != set(ranges) | {'ml','mr','jump'}:
                raise ValueError('Campos de movimento desconhecidos')
            walks += 1
        elif action in {'crouch','duck'} and not number(payload,0,1):
            raise ValueError('Estado de agachamento invalido')
        elif len(step) == 2 and action not in {'cheese','hole'}:
            raise ValueError('Passo sem dados')
        elif action in {'cheese','hole','emote'} and payload is not None and not number(payload,0,255):
            raise ValueError('Dados da acao invalidos')
    if walks == 0 or route[-1][-2] != 'hole':
        raise ValueError('Gravacao deve conter movimento e terminar na toca')
    encoded = json.dumps(route, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
    if len(encoded) > MAX_ROUTE:
        raise ValueError('Rota muito grande')
    return route


def decode_route(info):
    if not isinstance(info, str) or len(info) > MAX_ROUTE * 2:
        raise ValueError('Gravacao muito grande')
    raw = base64.b64decode(info, validate=True)
    decoder = zlib.decompressobj()
    text = decoder.decompress(raw, MAX_ROUTE + 1)
    if len(text) > MAX_ROUTE or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
        raise ValueError('Gravacao comprimida invalida')
    return validate_route(json.loads(text))


class CatalogError(Exception):
    def __init__(self, message, status=502, reason="network"):
        self.message, self.status, self.reason = message, status, reason
        super().__init__(message)


class Catalog:
    def __init__(self, session, token='', api=API):
        self.session, self.token, self.api = session, token, api
        self.lock = asyncio.Lock()
        self.cached = None
        self.cached_until = 0

    async def request(self, method, suffix, **kwargs):
        headers = {'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'DisneyClient-Routes'}
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
        try:
            async with self.session.request(method, self.api + suffix, headers=headers, timeout=aiohttp.ClientTimeout(total=20), allow_redirects=False, **kwargs) as response:
                chunks, size = [], 0
                async for chunk in response.content.iter_chunked(65536):
                    size += len(chunk)
                    if size > MAX_CATALOG * 2:
                        raise CatalogError('Catalogo do GitHub muito grande')
                    chunks.append(chunk)
                data = b''.join(chunks)
                status = response.status
                if status in (401,403):
                    raise CatalogError('GitHub recusou a credencial ou o limite de acesso; confira o token e Contents: Read and write',503,'denied')
                if status >= 400 and status not in (404,409,422):
                    raise CatalogError('GitHub indisponivel (HTTP %s)' % status)
                try:
                    result = json.loads(data) if data else {}
                except (ValueError,UnicodeError):
                    raise CatalogError('Resposta invalida do GitHub') from None
                return status, result
        except (aiohttp.ClientError,TimeoutError):
            raise CatalogError('Nao foi possivel conectar ao GitHub') from None

    async def read(self, fresh=False):
        now = asyncio.get_running_loop().time()
        if not fresh and self.cached is not None and now < self.cached_until:
            return self.cached, None
        status, item = await self.request('GET','/contents/' + FILE,params={'ref':BRANCH})
        if status == 404:
            raise CatalogError('rotas-novas.json nao encontrado no GitHub',404)
        if status != 200 or not isinstance(item,dict) or not re.fullmatch(r'[a-f0-9]{40}',str(item.get('sha',''))):
            raise CatalogError('Metadados invalidos do catalogo GitHub')
        sha = item['sha']
        if item.get('encoding') != 'base64':
            status, item = await self.request('GET','/git/blobs/' + sha)
            if status != 200:
                raise CatalogError('Nao foi possivel ler o catalogo GitHub')
        try:
            raw = base64.b64decode(item['content'].replace('\n',''),validate=True)
            if len(raw) > MAX_CATALOG:
                raise ValueError()
            catalog = json.loads(raw)
            if not isinstance(catalog,dict) or any(not re.fullmatch(r'@[1-9][0-9]*',k) for k in catalog):
                raise ValueError()
        except (KeyError,TypeError,ValueError,binascii.Error):
            raise CatalogError('JSON do GitHub invalido; arquivo existente preservado') from None
        self.cached, self.cached_until = catalog, now + 10
        return catalog, sha

    async def publish(self, code, route):
        if not self.token:
            raise CatalogError('GitHub nao configurado: execute CONFIGURAR-GITHUB-ROTAS.bat no computador do client',503,'missing_token')
        validate_route(route)
        async with self.lock:
            for attempt in range(3):
                catalog, sha = await self.read(fresh=True)
                merged = dict(catalog)
                merged[code] = route
                raw = (json.dumps(merged,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
                if len(raw) > MAX_CATALOG:
                    raise CatalogError('Catalogo atingiu o limite de tamanho',413)
                status, result = await self.request('PUT','/contents/' + FILE,json={'message':'Save route ' + code,'content':base64.b64encode(raw).decode(),'sha':sha,'branch':BRANCH})
                if status in (200,201):
                    self.cached, self.cached_until = merged, asyncio.get_running_loop().time()+10
                    return
                if status not in (409,422):
                    raise CatalogError('GitHub nao confirmou o salvamento (HTTP %s)' % status)
            raise CatalogError('Catalogo foi alterado durante o salvamento; tente SAVE novamente',409)


def local_token(request):
    # Re-read the local file, so the configurator works with the server open.
    root = request.app.get('root')
    values = dotenv_values(Path(root) / '.env') if root else {}
    if 'TFM_GITHUB_ROUTES_TOKEN' in values:
        return (values.get('TFM_GITHUB_ROUTES_TOKEN') or '').strip()
    return os.getenv('TFM_GITHUB_ROUTES_TOKEN','').strip()


def catalog(request):
    service = request.app.get('github_routes')
    if service is None:
        service = Catalog(infrastructure.get_session(),local_token(request))
        request.app['github_routes'] = service
    elif 'root' in request.app:
        service.token = local_token(request)
    return service


def draft_path(request, user):
    return Path(request.app['root']) / 'data' / 'rotas-pendentes' / (str(int(user['user_id']))+'.json')


def save_draft(request, user, code, route):
    path = draft_path(request,user)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary = path.with_suffix('.tmp')
    descriptor = os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(descriptor,'w',encoding='utf-8') as stream:
        json.dump({'code':code,'route':route},stream,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    temporary.replace(path)


def load_draft(request, user):
    path = draft_path(request,user)
    if not path.exists():
        return None
    raw = path.read_bytes()
    if len(raw)>MAX_ROUTE+4096:
        raise ValueError('Rascunho muito grande')
    data = json.loads(raw)
    if not re.fullmatch(r'@[1-9][0-9]*',str(data.get('code',''))):
        raise ValueError('Codigo de rascunho invalido')
    validate_route(data.get('route'))
    return data


def report(request, user, reason):
    request.app.setdefault('github_routes_results',{})[int(user['user_id'])]=reason


class GitHubRoutes(web.View):
    async def get(self):
        user = await authorize(self.request,allow_cookie=True)
        method = self.request.query.get('method')
        if method == 'status':
            reason = self.request.app.get('github_routes_results',{}).get(int(user['user_id']),'')
            return web.json_response({'configured':bool(local_token(self.request)),'reason':reason,'draft_saved':draft_path(self.request,user).exists()},headers={'Cache-Control':'no-store'})
        if method == 'draft':
            try:
                data = load_draft(self.request,user)
            except (OSError,ValueError):
                raise web.HTTPBadRequest(reason='Rascunho local invalido') from None
            if data is None:
                raise web.HTTPNotFound(reason='Sem rascunho pendente')
            return web.json_response(data,headers={'Cache-Control':'no-store'})
        code = self.request.query.get('code','')
        if not re.fullmatch(r'@[1-9][0-9]*',code):
            raise web.HTTPBadRequest(reason='Codigo de mapa invalido')
        try:
            routes, _ = await catalog(self.request).read()
            if code not in routes:
                raise web.HTTPNotFound(reason='Rota ainda nao publicada')
            validate_route(routes[code])
            return web.json_response(routes[code],headers={'Cache-Control':'no-store'})
        except CatalogError as exc:
            return web.json_response({'success':False,'error':exc.message},status=exc.status,headers={'Cache-Control':'no-store'})
        except ValueError:
            raise web.HTTPBadGateway(reason='Rota publicada invalida') from None

    async def post(self):
        user = await authorize(self.request,allow_cookie=True)
        if user['level'] not in self.request.app['config'].get('storage_allowed_levels',[]):
            raise web.HTTPForbidden()
        if self.request.query.get('method') != 'save':
            raise web.HTTPBadRequest(reason='Metodo invalido')
        form = await self.request.post()
        code = form.get('code','')
        if not isinstance(code,str) or not re.fullmatch(r'@[1-9][0-9]*',code):
            raise web.HTTPBadRequest(reason='Codigo de mapa invalido')
        try:
            route = decode_route(form.get('info'))
            try:
                save_draft(self.request,user,code,route)
            except OSError:
                raise CatalogError('Nao foi possivel preservar o rascunho no disco local',507,'disk') from None
            async with asyncio.timeout(24):
                await catalog(self.request).publish(code,route)
        except TimeoutError:
            report(self.request,user,'timeout')
            return web.json_response({'success':False,'error':'GitHub demorou a confirmar; confira o catalogo antes de tentar novamente'},status=504)
        except (ValueError,TypeError,binascii.Error,zlib.error):
            raise web.HTTPBadRequest(reason='Gravacao invalida') from None
        except CatalogError as exc:
            report(self.request,user,exc.reason)
            return web.json_response({'success':False,'error':exc.message},status=exc.status,headers={'Cache-Control':'no-store'})
        report(self.request,user,'published')
        try:
            if load_draft(self.request,user)=={'code':code,'route':route}:
                draft_path(self.request,user).unlink(missing_ok=True)
        except (OSError,ValueError):
            pass
        return web.Response(status=204,headers={'Cache-Control':'no-store'})
