"""Authenticated, asynchronous YouTube-to-MP3 jobs for the native Flash player."""
import asyncio
import importlib.util
import json
import re
import shutil
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from aiohttp import web
from .common import authorize

ID = re.compile(r'^[A-Za-z0-9_-]{11}$')
JOB = re.compile(r'^[a-f0-9]{32}$')
MAX_BYTES = 50 * 1024 * 1024


def video_id(value):
    if not isinstance(value, str) or len(value) > 2048:
        raise ValueError('invalid youtube URL')
    p = urlsplit(value.strip())
    if p.scheme != 'https' or p.username or p.password or p.port or p.fragment:
        raise ValueError('use a public HTTPS YouTube video URL')
    host = (p.hostname or '').lower()
    if host == 'youtu.be':
        ident = p.path.lstrip('/')
    elif host in {'youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'}:
        if p.path == '/watch':
            ids = parse_qs(p.query).get('v', [])
            ident = ids[0] if len(ids) == 1 else ''
        else:
            parts = p.path.strip('/').split('/')
            ident = parts[1] if len(parts) == 2 and parts[0] in {'shorts', 'live', 'embed'} else ''
    else:
        raise ValueError('unsupported video host')
    if not ID.fullmatch(ident):
        raise ValueError('invalid video ID')
    return ident


class MusicJobs:
    def __init__(self, folder, worker=None, *, timeout=150):
        self.folder = Path(folder)
        self.worker = worker or self.download
        self.production = worker is None
        self.timeout = timeout
        self.jobs = {}
        self.rates = {}
        self.slots = asyncio.Semaphore(2)
        self.create_lock = asyncio.Lock()

    async def create(self, user, url):
        async with self.create_lock:
            return await self._create(user, url)

    async def _create(self, user, url):
        ident = video_id(url)
        if self.production and (importlib.util.find_spec('yt_dlp') is None or not shutil.which('ffmpeg')):
            raise web.HTTPServiceUnavailable(reason='Instale yt-dlp e FFmpeg na VPS')
        now = time.monotonic()
        history = [t for t in self.rates.get(user, []) if now - t < 60]
        if len(history) >= 6:
            raise web.HTTPTooManyRequests(reason='Aguarde antes de pedir outra musica')
        history.append(now)
        self.rates[user] = history
        await self.prune()
        for old in list(self.jobs.values()):
            if old['user'] == user and old['state'] in {'queued', 'preparing', 'ready'}:
                await self.cancel(old)
        if sum(j['state'] in {'queued', 'preparing'} for j in self.jobs.values()) >= 16:
            raise web.HTTPServiceUnavailable(reason='Fila de musicas cheia; tente novamente')
        if len(self.jobs) >= 128:
            raise web.HTTPServiceUnavailable(reason='Cache de musicas cheio; aguarde a limpeza')
        job = dict(id=uuid.uuid4().hex, user=user, video=ident, state='queued', title='Preparando musica', created=now, seen=now, error='')
        self.jobs[job['id']] = job
        job['task'] = asyncio.create_task(self.run(job))
        return job

    async def run(self, job):
        try:
            async with self.slots:
                job['state'] = 'preparing'
                folder = self.folder / job['id']
                folder.mkdir(parents=True, exist_ok=False)
                async with asyncio.timeout(self.timeout):
                    await self.worker(job, folder)
                path = folder / 'audio.mp3'
                if not path.is_file() or path.is_symlink() or not 0 < path.stat().st_size <= MAX_BYTES:
                    raise ValueError('invalid audio output')
                job.update(path=path, state='ready')
        except asyncio.CancelledError:
            job['state'] = 'cancelled'
            raise
        except TimeoutError:
            job.update(state='error', error='Preparacao demorou demais; tente outro video')
        except Exception:
            # Never expose upstream URLs, process output, paths or credentials.
            job.update(state='error', error='Nao foi possivel preparar este video publico. Confira FFmpeg/yt-dlp e tente outro link')
        finally:
            if job['state'] != 'ready':
                shutil.rmtree(self.folder / job['id'], ignore_errors=True)

    async def download(self, job, folder):
        command = [sys.executable, '-m', 'yt_dlp', '--ignore-config', '--no-playlist', '--quiet', '--no-warnings', '--no-progress', '--no-cache-dir', '--restrict-filenames', '--socket-timeout', '15', '--retries', '1', '--fragment-retries', '1', '--max-filesize', '40M', '--match-filter', '!is_live & duration <= 1200', '-f', 'bestaudio/best', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '128K', '--postprocessor-args', 'ExtractAudio+ffmpeg_o:-ar 44100 -ac 2', '--write-info-json', '--output', str(folder / 'audio.%(ext)s'), 'https://www.youtube.com/watch?v=' + job['video']]
        process = await asyncio.create_subprocess_exec(*command, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
        try:
            while process.returncode is None:
                try:
                    await asyncio.wait_for(process.wait(), 1)
                except TimeoutError:
                    size = sum(p.stat().st_size for p in folder.iterdir() if p.is_file())
                    if size > 80 * 1024 * 1024:
                        raise ValueError('download too large')
            if process.returncode != 0:
                raise ValueError('extractor failed')
            meta = json.loads((folder / 'audio.info.json').read_text(encoding='utf-8'))
            duration = meta.get('duration')
            if not isinstance(duration, (int, float)) or not 0 < duration <= 1200 or meta.get('is_live'):
                raise ValueError('unsupported video duration')
            job['title'] = re.sub(r'[\x00-\x1f]', ' ', str(meta.get('title') or 'Musica do YouTube'))[:180]
            for p in folder.iterdir():
                if p.name != 'audio.mp3' and p.is_file():
                    p.unlink()
        finally:
            if process.returncode is None:
                process.kill()
                await process.wait()

    async def cancel(self, job):
        task = job.get('task')
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        job['state'] = 'cancelled'
        shutil.rmtree(self.folder / job['id'], ignore_errors=True)

    def owned(self, ident, user):
        if not JOB.fullmatch(ident or ''):
            raise web.HTTPNotFound()
        job = self.jobs.get(ident)
        if not job or job['user'] != user:
            raise web.HTTPNotFound()
        return job

    @staticmethod
    def status(job):
        return {key: job[key] for key in ('id', 'state', 'title', 'error')}

    async def prune(self):
        now = time.monotonic()
        for ident, job in list(self.jobs.items()):
            if job['state'] in {'cancelled', 'error'}:
                shutil.rmtree(self.folder / ident, ignore_errors=True)
            if now - job.get('seen', job['created']) > 60 or now - job['created'] > 1800:
                await self.cancel(job)
                shutil.rmtree(self.folder / ident, ignore_errors=True)
                self.jobs.pop(ident, None)
        if self.folder.exists():
            for path in self.folder.iterdir():
                if JOB.fullmatch(path.name) and path.name not in self.jobs and not path.is_symlink() and path.is_dir() and time.time() - path.stat().st_mtime > 1800:
                    shutil.rmtree(path, ignore_errors=True)
        # Bound finished cache to 256 MiB, retaining newest files first.
        total = 0
        for job in sorted(self.jobs.values(), key=lambda j: j['created'], reverse=True):
            if job['state'] == 'ready':
                path = job['path']
                total += path.stat().st_size if path.exists() else 0
                if total > 256 * 1024 * 1024:
                    shutil.rmtree(self.folder / job['id'], ignore_errors=True)
                    self.jobs.pop(job['id'], None)
        for user, times in list(self.rates.items()):
            if not times or now - times[-1] > 60:
                self.rates.pop(user, None)

    async def close(self):
        for job in list(self.jobs.values()):
            await self.cancel(job)
        shutil.rmtree(self.folder, ignore_errors=True)


def response_data(request, store, job):
    result = store.status(job)
    if job['state'] == 'ready':
        base = request.app.get('music_public_url', 'http://127.0.0.1:8080').rstrip('/')
        result['audio_url'] = base + '/music/audio/' + job['id'] + '.mp3'
        result['requires_auth'] = True
    return result


class Music(web.View):
    async def get(self):
        user = (await authorize(self.request))['user_id']
        store = self.request.app['music_jobs']
        job = store.owned(self.request.query.get('id'), user)
        job['seen'] = time.monotonic()
        return web.json_response(response_data(self.request, store, job), headers={'Cache-Control': 'no-store'})

    async def post(self):
        user = (await authorize(self.request))['user_id']
        values = await self.request.post()
        store = self.request.app['music_jobs']
        if values.get('action') == 'cancel':
            job = store.owned(values.get('id'), user)
            await store.cancel(job)
        elif values.get('action') == 'touch':
            job = store.owned(values.get('id'), user)
            job['seen'] = time.monotonic()
        elif values.get('action') == 'prepare':
            try:
                job = await store.create(user, values.get('url'))
            except ValueError:
                raise web.HTTPBadRequest(reason='Link do YouTube invalido')
        else:
            raise web.HTTPBadRequest()
        return web.json_response(response_data(self.request, store, job), headers={'Cache-Control': 'no-store'})


async def audio(request):
    user = (await authorize(request))['user_id']
    store = request.app['music_jobs']
    job = store.owned(request.match_info['ident'], user)
    if job['state'] != 'ready' or not job['path'].is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(job['path'], headers={'Content-Type': 'audio/mpeg', 'Cache-Control': 'private, no-store'})


def install(app):
    app['music_jobs'] = MusicJobs(app['root'] / 'data' / 'music-session')
    app.router.add_view('/music', Music)
    app.router.add_get('/music/audio/{ident}.mp3', audio)

    async def sweep(app):
        async def run():
            while True:
                await asyncio.sleep(5)
                await app['music_jobs'].prune()
        task = asyncio.create_task(run())
        try:
            yield
        finally:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            await app['music_jobs'].close()
    app.cleanup_ctx.append(sweep)
