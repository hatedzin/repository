package disney {import flash.display.MovieClip;public class RobotSuiteV5 {public static function attach(root:MovieClip):void{RobotControllerV5.attach(root);RouteRecorderV3.attach(root);}}}
