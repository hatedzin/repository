package disney {
 import flash.display.MovieClip;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.events.SecurityErrorEvent;import flash.net.URLLoader;import flash.net.URLRequest;import flash.text.TextField;import flash.text.TextFormat;import flash.utils.ByteArray;import flash.utils.Dictionary;import flash.utils.getTimer;import flash.utils.Timer;import flash.events.TimerEvent;
 public class RobotControllerV5 {
  private static var instances:Dictionary=new Dictionary(true);
  public var phase:String="off";public var message:String="Robot novo 5: desligado";
  private var githubRoutes:Object={};private var githubChecked:Object={};private var scheduler:Timer;private var observedDispatcher:Object;
  private var root:MovieClip;private var input:RobotInput;private var hud:TextField;private var enabled:Boolean=false;private var focused:Boolean=true;private var manual:Boolean=false;
  private var map:Object;private var player:Object;private var lifeBody:Object;private var deathSeen:Boolean=false;private var code:String="";private var round:String="";private var localId:int=0;private var idKnown:Boolean=false;
  private var birthPending:Boolean=false;private var newRound:Boolean=false;private var terminal:Boolean=false;private var nativeWon:Boolean=false;private var nativeDead:Boolean=false;private var deathReason:String="";
  private var cache:Object={};private var order:Array=[];private var request:URLLoader;private var requestCode:String="";private var requestError:String="";
  private var route:Array;private var index:int=0;private var clock:Number=0;private var due:Number=0;private var lastNow:int=-1;private var settleUntil:int=0;private var blocked:Boolean=false;
  private var lastSample:Object;private var lastRecord:Object;private var crouched:Boolean=false;private var needsCheese:Boolean=false;private var cheeseKnown:Boolean=false;private var cheeseCount:int=0;
  private var goal:Object;private var goalElapsed:int=0;private var fault:String="";private var mirror:Boolean=false;private var width:Number=800;
  public function RobotControllerV5(value:MovieClip){root=value;input=new RobotInput(value);NativeMotion.get(value).observeWith(receive);}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var bot:RobotControllerV5=new RobotControllerV5(value);instances[value]=bot;
   // Input deadlines use elapsed milliseconds, independently of render FPS.
   bot.scheduler=new Timer(5);
   bot.scheduler.addEventListener(TimerEvent.TIMER,function(e:TimerEvent):void{if(value.stage)bot.advance(getTimer());});
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{if(value.stage)bot.advance(getTimer());});
   value.addEventListener(Event.REMOVED_FROM_STAGE,function(e:Event):void{if(e.target===value){bot.scheduler.stop();bot.input.release();}});
   value.addEventListener(Event.ADDED_TO_STAGE,function(e:Event):void{if(e.target===value){bot.lastNow=-1;bot.scheduler.start();}});
   bot.scheduler.start();
   value.stage.addEventListener(Event.ACTIVATE,function(e:Event):void{bot.focused=true;});value.stage.addEventListener(Event.DEACTIVATE,function(e:Event):void{bot.focused=false;});
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(value) || !value["auto_play"] || !value["auto_play_disable_on_move"])return;var text:TextField=value.stage.focus as TextField;if(text && text.type=="input")return;if([37,38,39,40,65,68,83,87].indexOf(e.keyCode)>=0)bot.pause();},true,2200);
  }
  public static function get(value:MovieClip):RobotControllerV5{attach(value);return instances[value] as RobotControllerV5;}
  public function setFocused(value:Boolean):void{focused=value;}
  public function pause():void{if(!enabled)return;manual=true;input.release();show("pausado pela tecla; desligue e ligue para reiniciar");}
  public function setRoutes(routes:Object):void{if(!routes || routes is Array)throw new Error("Dicionario de rotas requerido");var total:int=0;for(var key:String in routes){if(!/^@[0-9]+$/.test(key))continue;cache[key]=RobotRoute.validate(routes[key] as Array);githubChecked[key]=getTimer();total++;}if(total==0)throw new Error("Nenhuma rota numerica valida");}
  public function installPublished(mapCode:String,steps:Array):void{var valid:Array=RobotRoute.validate(steps);githubRoutes[mapCode]=valid;cache[mapCode]=valid;githubChecked[mapCode]=getTimer();}
  private function githubReady():Boolean{return code in githubChecked && getTimer()-int(githubChecked[code])<10000;}
  private function loadGithub():void{
   if(request)return;var wanted:String=code;var loader:URLLoader=new URLLoader();request=loader;requestCode=wanted;phase="load";
   var finish:Function=function():void{if(request!==loader)return;request=null;requestCode="";githubChecked[wanted]=getTimer();};
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{if(request!==loader)return;try{var text:String=String(loader.data);if(text.length>262144)throw new Error("Rota muito grande");githubRoutes[wanted]=RobotRoute.decode(text);}catch(error:Error){delete githubRoutes[wanted];}finish();});
   var failed:Function=function(e:Event):void{if(request!==loader)return;delete githubRoutes[wanted];finish();};loader.addEventListener(IOErrorEvent.IO_ERROR,failed);loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
   try{var token:String="";if(root["tfmdisney"] && root["tfmdisney"].data)token=String(root["tfmdisney"].data.flash_token);loader.load(new URLRequest(String(root["host_url"])+"github-routes?code="+encodeURIComponent(wanted)+"&access_token="+encodeURIComponent(String(root["access_token"]))+"&flash_token="+encodeURIComponent(token)));}catch(error:Error){failed(new Event("error"));}
  }
  private function cancelRequest():void{if(request){try{request.close();}catch(e:Error){}request=null;}requestCode="";}
  private function load():void{
   if(request || requestError!="" || !code)return;var wanted:String=code;var loader:URLLoader=new URLLoader();request=loader;requestCode=wanted;phase="load";
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{if(request!==loader)return;request=null;requestCode="";try{var text:String=String(loader.data);if(text.length>262144)throw new Error("Rota muito grande");cache[wanted]=RobotRoute.decode(text);loader.data="";order.push(wanted);while(order.length>4){var old:String=String(order.shift());if(old!=wanted)delete cache[old];}}catch(error:Error){if(code==wanted)requestError="rota invalida: "+error.message;}});
   var failed:Function=function(e:Event):void{if(request!==loader)return;request=null;requestCode="";if(code==wanted)requestError="nao foi possivel carregar public/rotas/"+wanted.substr(1)+".json";};
   loader.addEventListener(IOErrorEvent.IO_ERROR,failed);loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
   try{loader.load(new URLRequest(String(root["host_url"])+"public/rotas/"+wanted.substr(1)+".json"));}catch(error:Error){failed(new Event("error"));}
  }
  private function show(text:String):void{
   var nextMessage:String="Robot novo 5: "+text;if(message==nextMessage && ((!hud && !root["auto_play"]) || hud && hud.visible==Boolean(root["auto_play"])))return;message=nextMessage;var ui:Object=root["Interface"];if(ui && ui["status_field"])ui["status_field"].text=message;
   if(!root.stage)return;if(!root["auto_play"]){if(hud)hud.visible=false;return;}
   if(!hud){hud=new TextField();hud.name="robotNovoStatus";hud.defaultTextFormat=new TextFormat("_sans",12,0xA9F7E4);hud.background=true;hud.backgroundColor=0x141B2A;hud.height=24;hud.selectable=false;hud.mouseEnabled=false;root.stage.addChild(hud);}
   hud.text=message;hud.visible=true;hud.x=8;hud.y=Math.max(60,root.stage.stageHeight-48);hud.width=Math.max(100,Math.min(740,root.stage.stageWidth-16));root.stage.setChildIndex(hud,root.stage.numChildren-1);
  }
  private function resetLife(now:int):void{
   input.reset();route=null;index=0;clock=0;due=0;lastSample=null;lastRecord=null;goal=null;goalElapsed=0;fault="";manual=false;terminal=false;nativeWon=false;nativeDead=false;deathReason="";birthPending=false;newRound=false;cheeseKnown=false;cheeseCount=0;deathSeen=false;blocked=false;crouched=false;needsCheese=false;settleUntil=now+250;phase="wait";requestError="";
  }
  private function remember(k:Object,p:Object):void{if(!p || !k.player_id || !(k.player_id in p))return;var value:* =p[k.player_id];if(!(value is Number))return;var id:Number=Number(value);if(isFinite(id) && id==Math.floor(id)){localId=int(id);idKnown=true;}}
  public function receive(bytes:ByteArray):void{
   if(!enabled || !bytes || bytes.bytesAvailable<2)return;var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
   if(c==5 && cc==2){newRound=true;return;}var k:Object=root["Keys"];var g:Object=root["tfm"];if(k && g)remember(k,g[k.player]);if(!idKnown)return;
   if(c==144 && cc==6 && bytes.bytesAvailable>=5){var id:int=bytes.readInt();var count:int=bytes.readByte();if(id==localId){cheeseKnown=true;cheeseCount=count;}return;}
   if(c==144 && cc==2){bytes.readUTF();if(bytes.bytesAvailable>=6){var born:int=bytes.readInt();bytes.readBoolean();var dead:int=bytes.readUnsignedByte();if(born==localId && dead==0)birthPending=true;}return;}
   if(c==8 && cc==6 && bytes.bytesAvailable>=5){bytes.readUnsignedByte();if(bytes.readInt()==localId){nativeWon=true;terminal=true;phase="won";input.release();show("vitoria confirmada; aguardando renascer | "+code);}return;}
   if(c==1 && cc==1){var fields:Array=bytes.readUTF().split(String.fromCharCode(1));var header:String=String(fields[0]);if(header.length==2 && header.charCodeAt(0)==8 && header.charCodeAt(1)==5 && fields.length>1 && /^-?[0-9]+$/.test(String(fields[1])) && int(fields[1])==localId){nativeDead=true;deathReason=fields.length>4 ? " (motivo "+String(fields[4])+")" : "";terminal=true;phase="dead";input.release();show("morte nativa"+deathReason+"; aguardando renascer | "+code);}}
  }
  private function hasCheese(k:Object):Boolean{if(cheeseKnown)return cheeseCount>0;return player && k.player_cheese && k.player_cheese in player && Number(player[k.player_cheese])>0;}
  private function sameLife(k:Object):Boolean{
   try{var g:Object=root["tfm"];var p:Object=g ? g[k.player] : null;var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";
    var valid:Boolean=root["Keys"]===k && !terminal && !nativeWon && !nativeDead && !birthPending && !newRound && p===player && p && p[k.player_physics]===lifeBody && k.map_class[k.map_instance]===map && token==round && input.ready();
    if(valid)return true;
   }catch(error:Error){}input.release();return false;
  }
  private function fail(text:String):void{fault=text;phase="error";input.release();show(text+" | "+code+" | aguarda renascer ou reative");}
  private function bindNative():void{
   try{var k:Object=root["Keys"];var dispatcher:Object=k ? k.packet_handler_class : null;
    if(!dispatcher || dispatcher===observedDispatcher || !("astroRoomObserverV1" in dispatcher))return;
    var previous:Function=dispatcher["astroRoomObserverV1"] as Function;
    dispatcher["astroRoomObserverV1"]=function(bytes:ByteArray):void{
     if(!bytes)return;var cursor:uint=bytes.position;
     try{if(previous!=null)previous(bytes);}catch(ignored:Error){}
     try{bytes.position=0;NativeMotion.observe(root,bytes);}finally{bytes.position=cursor;}
    };observedDispatcher=dispatcher;
   }catch(error:Error){}
  }
  private function point(tag:String):Object{
   var reference:Object=lastSample ? lastSample : player;var k:Object=root["Keys"];var nativePoint:Object;
   try{
    if(tag=="F" && k.clip_fromage){var cheese:Object=map[k.clip_fromage];if(cheese && isFinite(Number(cheese.x)) && isFinite(Number(cheese.y)))nativePoint={x:Number(cheese.x),y:Number(cheese.y)};}
    if(tag=="T" && k.hole_list){var container:Object=map[k.obj_container];var holes:Object=container ? container[k.hole_list] : null;var nearest:Number=Number.POSITIVE_INFINITY;
     if(holes && holes.length%3==0)for(var h:int=0;h<holes.length;h+=3){var x:Number=Number(holes[h+1]);var y:Number=Number(holes[h+2]);if(!isFinite(x)||!isFinite(y))continue;var dx:Number=x-Number(reference.x);var dy:Number=y-Number(reference.y);var distance:Number=dx*dx+dy*dy;if(distance<nearest){nearest=distance;nativePoint={x:x,y:y};}}
    }
   }catch(error:Error){}
   if(nativePoint)return nativePoint;
   return RobotRoute.target(String(root["current_map_xml"]),tag,mirror,width,Number(reference.x),Number(reference.y),null);
  }
  private function startGoal(kind:String,target:Object):void{goal=target;goalElapsed=0;phase=kind;if(!goal){fail("sem referencia para "+kind);return;}show(kind=="cheese" ? "buscando coleta real do queijo | "+code : kind=="hole" ? "aproximando da toca; aguardando vitoria | "+code : "retomando rota pelos controles | "+code);}
  private function resumeInput(k:Object,now:int):Boolean{if(lastSample)input.resume(lastSample,now);else input.release();if(!sameLife(k))return false;if(crouched){input.crouch(true);if(!sameLife(k))return false;}return true;}
  private function nextStep():void{index++;if(index<route.length)due+=Number(route[index][2]);}
  private function goals(k:Object,now:int,dt:int):Boolean{
   if(phase!="cheese" && phase!="hole" && phase!="recover")return false;
   if(phase=="cheese" && hasCheese(k)){if(index<route.length && route[index][1]=="cheese")nextStep();phase="play";goal=null;if(!resumeInput(k,now))return true;return false;}
   if(phase=="recover"){var dx:Number=Number(player.x)-goal.x;var dy:Number=Number(player.y)-goal.y;if(dx*dx+dy*dy<=576){phase="play";goal=null;return false;}}
   goalElapsed+=dt;if(goalElapsed>4000){fail(phase=="cheese" ? "queijo nao confirmado; rota incompativel" : phase=="hole" ? "entrada na toca nao confirmada" : "nao foi possivel retomar a rota");return true;}
   input.steer(goal.x,goal.y,now);if(!sameLife(k))return true;show(phase=="cheese" ? "buscando coleta real do queijo | "+code : phase=="hole" ? "aproximando da toca; aguardando vitoria | "+code : "retomando rota pelos controles | "+code);return true;
  }
  private function play(now:int,dt:int,k:Object):void{
   clock+=dt;var pending:Object;var requestJump:Boolean=false;var steps:int=0;
   while(index<route.length && clock>=due && steps<256){
    var step:Array=route[index];var action:String=String(step[1]);
    if(action=="walk"){
     var sample:Object=RobotRoute.movement(step[0],mirror,width);
     // Preserve input edges across scheduler turns, without shifting the
     // absolute deadlines of the remaining recording.
     if(pending && (sample.ml!=pending.ml || sample.mr!=pending.mr || sample.jump!=pending.jump || (sample.jump && sample.vy<=-4.5 && pending.vy-sample.vy>1)))break;
     var dx:Number=sample.x-Number(player.x);var dy:Number=sample.y-Number(player.y);var distance:Number=Math.sqrt(dx*dx+dy*dy);
     if(!isFinite(distance)){fail("posicao local indisponivel");return;}
     if(distance>(lastSample ? 160 : 96)){if(pending){if(!sameLife(k))return;input.play(pending,now);if(!sameLife(k))return;}if(distance<=224 && Math.abs(dy)<=96)startGoal("recover",{x:sample.x,y:sample.y});else fail("fora da rota por "+Math.round(distance)+"px; sem teleporte");return;}
     if(sample.jump && (!lastRecord || !lastRecord.jump || (sample.vy<=-4.5 && lastRecord.vy-sample.vy>1)))requestJump=true;if(!sample.jump)requestJump=false;
     sample.requestJump=requestJump;pending=sample;lastSample=sample;lastRecord=sample;nextStep();
    }else{
     if(pending)break;
     if(action=="cheese" && !hasCheese(k)){startGoal("cheese",point("F"));return;}
     if(action=="hole"){if(needsCheese && !hasCheese(k))startGoal("cheese",point("F"));else startGoal("hole",point("T"));return;}
     if(action=="crouch" || action=="duck"){crouched=Number(step[0])!=0;input.crouch(crouched);if(!sameLife(k))return;}
     nextStep();
    }
    steps++;
   }
   if(pending){if(!sameLife(k))return;input.play(pending,now);if(!sameLife(k))return;}
   if(index>=route.length){phase="finished";input.release();show("fim da rota; aguardando confirmacao nativa ou proximo mapa | "+code);return;}
   if(steps>=256 && clock>=due){fail("excesso de estados vencidos na rota");return;}
   show("executando "+code+" | "+index+"/"+route.length);
  }
  public function advance(now:int):void{try{update(now);}catch(error:Error){input.release();fail("erro #"+error.errorID+": "+error.message);}}
  private function update(now:int):void{
   if(lastNow==now)return;
   bindNative();
   var raw:int=lastNow<0 ? 0 : Math.max(0,now-lastNow);lastNow=now;var dt:int=raw;
   if(!root["auto_play"]){if(scheduler && scheduler.running)scheduler.stop();if(enabled){cancelRequest();input.reset();}enabled=false;phase="off";show("desligado");return;}
   if(scheduler && !scheduler.running)scheduler.start();
   if(!enabled){enabled=true;manual=false;resetLife(now);FollowControllerV13Shared.stopForRobot(root);LocalServerLog.emit(root,"Robot novo 5: ligado; controles nativos e coleta confirmada");}
   var k:Object=root["Keys"];var g:Object=root["tfm"];if(!k || !g || !k.map_class){input.release();show("aguardando jogo");return;}
   var m:Object=k.map_class[k.map_instance];var n:Object=m && k.bot_map_code_object ? m[k.bot_map_code_object] : null;var number:Number=n ? Number(n[k.bot_map_code_value]) : NaN;
   if(!m || !isFinite(number) || number<=0 || number!=Math.floor(number)){input.release();show("aguardando codigo do mapa");return;}
   var nextCode:String="@"+number.toFixed(0);var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";var p:Object=g[k.player];var b:Object=p && k.player_physics ? p[k.player_physics] : null;
   var alive:Boolean=p && b && (!k.player_clip || p[k.player_clip]) && (!k.is_dead || !p[k.is_dead]);var changed:Boolean=m!==map || nextCode!=code || token!=round;
   var recoveredLife:Boolean=alive && deathSeen && phase!="won" && phase!="confirm" && !nativeWon;
   var replacement:Boolean=alive && lifeBody!=null && (b!==lifeBody || (player && p!==player));
   if(changed || newRound || birthPending || recoveredLife){if(nextCode!=code){cancelRequest();requestError="";}map=m;code=nextCode;round=token;resetLife(now);replacement=false;}
   if(p){player=p;remember(k,p);}if(!alive && p && k.is_dead && p[k.is_dead])deathSeen=true;
   if(alive){lifeBody=b;if(replacement){input.reset();blocked=true;}}
   if(nativeWon || NativeMotion.get(root).finished()){terminal=true;phase="won";input.release();show("vitoria confirmada; aguardando renascer | "+code);return;}
   if(nativeDead){terminal=true;phase="dead";input.release();show("morte nativa"+deathReason+"; aguardando renascer | "+code);return;}
   if(!alive){blocked=true;input.release();if(phase=="hole" || phase=="confirm"){phase="confirm";terminal=true;show("aguardando confirmacao nativa da toca | "+code);}else show("aguardando renascer | "+code);return;}
   if(terminal){input.release();show("aguardando confirmacao nativa ou renascimento | "+code);return;}
   if(manual){input.release();show("pausado pela tecla; desligue e ligue para reiniciar");return;}
   var editing:Boolean=focused && root.stage && root.stage.focus is TextField && TextField(root.stage.focus).type=="input";
   var gate:Boolean=now<settleUntil || !k.move_class || !k.move_class[k.move_free] || (k.timer_class && k.timer_class[k.timer_prop]);
   if(editing || gate){blocked=true;input.release();show(editing ? "pausado para digitar no chat" : "aguardando liberacao da rodada | "+code);return;}
   if(blocked){blocked=false;dt=0;if(phase=="play"){if(!resumeInput(k,now))return;}else if(crouched){input.crouch(true);if(!sameLife(k))return;}}
   input.tick(now);if(!sameLife(k))return;
   width=Number(k.map_class[k.bot_map_width]);if(!isFinite(width)||width<1||width>100000){fail("largura do mapa indisponivel");return;}mirror=Boolean(m[k.obj_container][k.bot_reverse]);
   if(fault!=""){input.release();show(fault+" | "+code+" | aguarda renascer ou reative");return;}
   if(!route){if(!githubReady()){loadGithub();show("consultando rotas-novas.json no GitHub | "+code);return;}var saved:Array=githubRoutes[code] as Array;
    if(!saved && k.maps && k.maps[code]!=null){try{var custom:* =k.maps[code];saved=custom is Array ? RobotRoute.validate(custom as Array) : RobotRoute.decode(String(custom));}catch(customError:Error){fail("rota salva invalida: "+customError.message);return;}}
    if(!saved)saved=cache[code] as Array;if(!saved){load();show(requestError!="" ? requestError+" | "+code : "carregando rota "+code);return;}route=RobotRoute.validate(saved);index=0;clock=0;due=Number(route[0][2]);needsCheese=false;for each(var entry:Array in route)if(entry[1]=="cheese")needsCheese=true;if(point("F")!=null)needsCheese=true;phase="play";dt=0;}
   var wasGoal:Boolean=phase=="cheese" || phase=="hole" || phase=="recover";if(goals(k,now,dt))return;if(wasGoal)dt=0;
   if(phase=="finished"){input.release();show("fim da rota; aguardando confirmacao nativa ou proximo mapa | "+code);return;}
   if(phase=="play")play(now,dt,k);
  }
 }
}
