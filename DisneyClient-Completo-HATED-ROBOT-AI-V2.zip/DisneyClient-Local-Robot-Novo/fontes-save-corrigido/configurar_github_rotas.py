"""Run locally. Never ships or prints a GitHub credential."""
from getpass import getpass
from pathlib import Path
import os
import re
import shutil
import urllib.error
import urllib.request


def save_token(path, token):
    old = path.read_text(encoding='utf-8') if path.exists() else ''
    lines = [line for line in old.splitlines() if not re.match(r'^\s*(?:export\s+)?TFM_GITHUB_ROUTES_TOKEN\s*=',line)]
    lines.append('TFM_GITHUB_ROUTES_TOKEN=' + token)
    temporary = path.with_name(path.name + '.github.tmp')
    try:
        descriptor = os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(descriptor,'w',encoding='utf-8',newline='\n') as stream:
            stream.write('\n'.join(lines)+'\n')
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    root = Path(__file__).resolve().parent
    print('GitHub: hatedzin/repository / main / rotas-novas.json')
    print('Crie um fine-grained token em https://github.com/settings/personal-access-tokens/new')
    print('Selecione somente hatedzin/repository; Repository permissions > Contents: Read and write.')
    print('O token sera guardado somente em DisneyClient/.env deste computador.')
    token = getpass('Cole o token (nao aparece na tela): ').strip()
    if not re.fullmatch(r'[A-Za-z0-9_]{20,255}',token):
        raise ValueError('Token vazio ou formato invalido')
    request = urllib.request.Request('https://api.github.com/repos/hatedzin/repository/contents/rotas-novas.json?ref=main',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'DisneyClient-Routes-Setup'})
    try:
        with urllib.request.urlopen(request,timeout=20) as response:
            if response.status != 200:
                raise ValueError('Nao foi possivel acessar rotas-novas.json')
    except urllib.error.HTTPError as error:
        raise ValueError('GitHub recusou a configuracao (HTTP %s); confira token e repositorio' % error.code) from None
    except (urllib.error.URLError,TimeoutError):
        raise ValueError('Nao foi possivel conectar ao GitHub; tente novamente com internet') from None
    target = root / 'DisneyClient' / '.env'
    example = target.with_name('.env.example')
    if not target.exists() and example.exists():
        shutil.copyfile(example,target)
    save_token(target,token)
    print('Configuracao salva. Volte ao jogo e clique SAVE novamente; nao precisa reiniciar o servidor atualizado.')
    print('A leitura do arquivo foi verificada; o SAVE verificara a permissao de escrita.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError,OSError) as error:
        print('ERRO:',str(error))
        raise SystemExit(1)
