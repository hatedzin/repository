// ActionScript 3 / SlowFollowPath.as / Flash Player 10.3+ / replay live trajectory at eight ninths of source time
package disney {
 public class SlowFollowPath {
  public static const RATIO:Number=8/9;
  private var points:Array=[];private var clock:Number=0;private var previous:Number=-1;
  public function SlowFollowPath(){}
  public function reset():void{points=[];previous=-1;clock=0;}
  public function push(now:Number,x:Number,y:Number,vx:Number,vy:Number,left:Boolean,right:Boolean,jump:Boolean):Object{
   if(previous<0){clock=now;previous=now;}
   if(now<previous)throw new Error("Trajectory clock moved backwards",2301);
   var p:Object={t:now,x:x,y:y,vx:vx,vy:vy,left:left,right:right,jump:jump};
   if(points.length && points[points.length-1].t==now)points[points.length-1]=p;else points.push(p);
   clock+=(now-previous)*RATIO;previous=now;
   while(points.length>1 && points[1].t<=clock)points.shift();
   if(points.length>36000)throw new Error("Trajectory buffer full",2302);
   var a:Object=points[0];var b:Object=points.length>1 ? points[1] : a;
   var f:Number=b.t>a.t ? Math.max(0,Math.min(1,(clock-a.t)/(b.t-a.t))) : 0;
   return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,vx:(a.vx+(b.vx-a.vx)*f)*RATIO,vy:(a.vy+(b.vy-a.vy)*f)*RATIO,left:a.left,right:a.right,jump:a.jump};
  }
 }
}
