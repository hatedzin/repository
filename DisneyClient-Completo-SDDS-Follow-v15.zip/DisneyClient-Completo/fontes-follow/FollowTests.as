// ActionScript 3 / FollowTests.as / Ruffle AVM2 / slowed timeline and integrated Follow ratio checks
package disney {
 import flash.display.MovieClip;import flash.geom.Point;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var n:int=0;private static function check(ok:Boolean,label:String):void{if(!ok)throw new Error(label);n++;}
  private static function near(a:Number,b:Number):Boolean{return Math.abs(a-b)<0.00001;}
  public static function run(display:MovieClip):void{
   var result:String;
   try{
    var path:SlowFollowPath=new SlowFollowPath();var p:Object=path.push(0,0,0,9,-9,false,true,false);check(near(p.vx,8) && near(p.vy,-8),"nine velocity becomes eight");
    p=path.push(1000,9,-9,9,-9,true,false,true);check(near(p.x,8) && near(p.y,-8),"position replay also slowed");check(p.right && !p.jump,"discrete states retain slowed order");
    p=path.push(2000,18,-18,9,-9,false,true,false);check(near(p.x,16),"slowdown not cancelled by live position copying");check(p.left && p.jump,"delayed state transition applied");
    path.reset();p=path.push(5000,90,70,0,0,false,false,false);check(p.x==90 && p.y==70,"new session starts at current source position");p=path.push(5000,90,70,0,0,false,false,false);check(p.x==90,"same timestamp does not advance timeline");
    var rejected:Boolean=false;try{path.push(4000,0,0,0,0,false,false,false);}catch(e:Error){rejected=true;}check(rejected,"backward time rejected");
    path.reset();path.push(0,0,0,9,0,false,true,false);p=path.push(180,1.62,0,9,0,false,true,false);check(near(p.x,1.44),"irregular frame intervals preserve ratio");
    var r:MovieClip=new MovieClip();display.addChild(r);r.stage.focus=r.stage;var body:Object={velocity:{vx:0,vy:0},place:function(v:Point,a:Number):Boolean{return true;}};
    var local:Object={nick:"Self#0001",x:0,y:0,dead:false,cheese:false,body:body};var target:Object={nick:"Target#0000",x:0,y:0,dead:false,cheese:false,left:false,right:true,body:{velocity:{vx:9,vy:0}}};
    r["tfm"]={self:local,players:[target],chat:function(s:String):void{}};r["Keys"]={player:"self",player_list:"players",player_name:"nick",is_dead:"dead",player_cheese:"cheese",chat_message:"chat",player_physics:"body",bot_set_position:"place",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",player_moving_left:"left",player_moving_right:"right",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(s:String):Class{return Point;}}},packet_handler_class:{receive:function(v:Object):void{}},packet_handler:"receive"};
    var follow:FollowController=new FollowController(r);follow.command("/follow Target#0000");follow.update(0);target.x=9;follow.update(1000);check(near(local.x,8),"integrated controller consumes slowed coordinates");check(near(body.velocity.vx,8),"integrated velocity matches slowed trajectory");
    target.x=18;follow.update(2000);check(near(local.x,16),"integrated second sample preserves eight ninths");follow.command("/follow off");target.x=27;follow.update(3000);check(near(local.x,16),"stop still stops replay");
    result="PASS: "+n+" slowed trajectory checks";
   }catch(error:Error){result="FAIL: "+error.message+" #"+error.errorID;}
   ExternalInterface.call("recordTest",result);
  }
 }
}
