



#                https://safemarket.xyz | https://safemarket.xyz/discord
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#  | | ____     _     _____  _____      __  __     _     ____   _  __ _____  _____ | |  
#  | |/ ___|   / \   |  ___|| ____|    |  \/  |   / \   |  _ \ | |/ /| ____||_   _|| |  
#  | |\___ \  / _ \  | |_   |  _|      | |\/| |  / _ \  | |_) || ' / |  _|    | |  | |  
#  | | ___) |/ ___ \ |  _|  | |___     | |  | | / ___ \ |  _ < | . \ | |___   | |  | |  
#  | ||____//_/   \_\|_|    |_____|    |_|  |_|/_/   \_\|_| \_\|_|\_\|_____|  |_|  | |  
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#                               https://github.com/Jodis974                           



from aiohttp import web, ClientTimeout
import asyncio
from data import client
from utils import cryptjson

import infrastructure
import server

class GetKeys(web.View):
	def check_req(self):
		agent = self.request.headers.get("User-Agent")
		accept = self.request.headers.get("Accept")
		flash_version = self.request.headers.get("x-flash-version")

		host = self.request.headers.get("Host")
		trust_host = host.startswith("localhost") or host == "disneyclient-menu-c1628fe98d65.herokuapp.com"

		referer = self.request.headers.get("Referer")
		trust_ref = referer is None or any(referer.startswith(s) for s in ("http://localhost", "https://localhost", "http://disneyclient-menu-c1628fe98d65.herokuapp.com", "https://disneyclient-menu-c1628fe98d65.herokuapp.com"))

		if not agent or (agent != "Shockwave Flash" and ".NET" not in agent) \
			or not accept or (accept != "*/*" and "application/x-shockwave-flash" not in accept) \
			or not flash_version or "," not in flash_version or not trust_ref or not trust_host:
				return False
		return True

	async def get(self):
		response = { "success": False }
		status = 401

		key = None
		log = True

		addr = "127.0.0.1" if infrastructure.is_local else self.request.headers.get("X-Forwarded-For")
		agent = self.request.headers.get("User-Agent")
		access_token = self.request.query.get("access_token")
		flash_token = self.request.query.get("flash_token")
		access_token = server.check_conn(access_token, addr)

		if self.check_req():
			if access_token is None:
				status = 400

				response["error"] = "bad request"
			elif access_token:
				info = infrastructure.tokens[access_token]
				level = info["level"]

				passed = True
				if info["user"].flash_token is None:
					if flash_token:
						info["user"].flash_token = flash_token
						client.commit()
					else:
						passed = False
						status = 400

						response["error"] = "bad request"
				else:
					passed = info["user"].flash_token == flash_token
					if not passed:
						status = 200

						response["error"] = "your key was used by another device"

				if passed:
					key = info["key"]
					log = not info["user"].key_hidden

					if addr not in info["ips"]:
						if len(info["ips"]) < info["conn_limit"]:
							info["ips"].append(addr)
						else:
							passed = False
							status = 200

							response["error"] = "connection limit exceeded"

					if passed:
						response["success"] = True
						response["keys"] = {
							"maps_allowed": bool(
                                infrastructure.config["map_storage_fetch"]
                                and (
                                    client.find_map_by_key(key, True)
                                    or level in infrastructure.config.get("storage_allowed_levels", [])
                                )
                            ),
							"client_version": infrastructure.config["client_version"],
							"discord": infrastructure.discord.discord_names,
							"premium_level": level
						}

						parser_keys = None
						parser_error = "parser ainda não disponibilizou as chaves"
						for attempt in range(12):
							try:
								async with infrastructure.session.get(
									f"{infrastructure.parser_url}/api/tfm_keys",
									headers={"Authorization": f"Bearer {infrastructure.tfm_parser_token}"},
									timeout=ClientTimeout(total=8)
								) as parser_response:
									if parser_response.ok:
										candidate = await parser_response.json()
										if candidate:
											parser_keys = candidate
											break
										parser_error = "parser ainda não terminou de extrair as chaves"
									else:
										parser_error = f"parser respondeu HTTP {parser_response.status}"
										if parser_response.status in (400, 401, 403, 404):
											break
							except Exception as exc:
								parser_error = f"parser indisponível ({type(exc).__name__})"
							if attempt < 11:
								await asyncio.sleep(1)
						if parser_keys:
							response["keys"].update(parser_keys)
							response["keys"] = cryptjson.json_zip(response["keys"]).decode()
							status = 200
						else:
							response["success"] = False
							response["error"] = parser_error
							status = 503
			else:
				status = 200

				response["error"] = "expired/invalid token"
		else:
			status = 400

			response["error"] = "bad request"

		if log:
			infrastructure.loop.create_task(infrastructure.discord.log(
				"TFM", response, status, addr, key, access_token, agent))

		return web.json_response(response, status=status)




#                https://safemarket.xyz | https://safemarket.xyz/discord
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#  | | ____     _     _____  _____      __  __     _     ____   _  __ _____  _____ | |  
#  | |/ ___|   / \   |  ___|| ____|    |  \/  |   / \   |  _ \ | |/ /| ____||_   _|| |  
#  | |\___ \  / _ \  | |_   |  _|      | |\/| |  / _ \  | |_) || ' / |  _|    | |  | |  
#  | | ___) |/ ___ \ |  _|  | |___     | |  | | / ___ \ |  _ < | . \ | |___   | |  | |  
#  | ||____//_/   \_\|_|    |_____|    |_|  |_|/_/   \_\|_| \_\|_|\_\|_____|  |_|  | |  
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#                               https://github.com/Jodis974                           



