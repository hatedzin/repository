from __future__ import annotations

import asyncio
import datetime
import os
from pathlib import Path
from typing import Dict

import aiofiles
from aiohttp import web
from dotenv import load_dotenv
import ujson

BASE_DIR = Path(__file__).resolve().parent
os.chdir(BASE_DIR)
load_dotenv(BASE_DIR.parent / ".env")

import infrastructure
from data import client
from data.user import User
from utils import cryptjson, gentoken, records
import api
import resources


class LocalDiscord:
    """No-op logger used for a local install without a Discord bot."""
    def __init__(self, names=None):
        self.discord_names = names or []

    async def log(self, *args, **kwargs):
        return None

    async def log2(self, *args, **kwargs):
        return None


async def swf_downloader():
    while True:
        try:
            if not infrastructure.parser_url:
                await asyncio.sleep(8.0)
                continue
            async with infrastructure.session.get(
                f"{infrastructure.parser_url}/transformice?swf&d={datetime.datetime.now().timestamp()}"
            ) as response:
                if response.ok:
                    expected_len = response.content_length
                    payload = await response.read()
                    if payload:
                        async with aiofiles.open(BASE_DIR / "tfm.swf", "wb") as file:
                            await file.write(payload)
                        infrastructure.tfm_swf_expected_len = expected_len or len(payload)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"[SWF] Parser ainda não disponível: {exc}")
        await asyncio.sleep(8.0)


def check_conn(access_token: str, addr: str, **kwargs):
    if access_token is None:
        return None

    if addr in infrastructure.ips:
        access_token = infrastructure.ips[addr][1]

    if access_token in infrastructure.tokens:
        if (flash_token := kwargs.get("flash_token")) is not None:
            if infrastructure.tokens[access_token]["user"].flash_token != flash_token:
                return False
        if (session_token := kwargs.get("session_token")) is not None:
            if infrastructure.sessions.get(session_token) is None:
                return False
        return access_token
    return False


def store_access(key: str, addr: str, user: User, session_token: str) -> Dict:
    result = {}
    if not addr:
        return result

    now = datetime.datetime.now().timestamp()
    if addr not in infrastructure.ips:
        access_token = gentoken.gen_token()
        infrastructure.ips[addr] = (now, access_token)
        infrastructure.tokens[access_token] = {
            "key": key,
            "user": user,
            "level": user.level,
            "ips": [addr],
            "conn_limit": user.connection_limit,
        }
        if session_token:
            infrastructure.sessions[session_token] = (key, user, access_token)
        asyncio.create_task(del_token(addr, access_token))
    else:
        access_token = infrastructure.ips[addr][1]
        if session_token:
            infrastructure.sessions[session_token] = (key, user, access_token)
        result["contains"] = True

    result.update({
        "access_token": access_token,
        "level": user.level,
        "sleep": int((now - infrastructure.ips[addr][0]) // 60),
    })
    return result


async def del_token(ip: str, token: str):
    await asyncio.sleep(10800.0)
    if ip in infrastructure.ips and infrastructure.ips[ip][1] == token:
        del infrastructure.ips[ip]
    infrastructure.tokens.pop(token, None)
    for session_id, data in list(infrastructure.sessions.items()):
        if data[2] == token:
            infrastructure.sessions.pop(session_id, None)


async def unblock_addr(addr: str):
    await asyncio.sleep(240.0)
    infrastructure.auth_attempts.pop(addr, None)


async def main():
    await infrastructure.open_session()
    infrastructure.config = ujson.loads((BASE_DIR / "config.json").read_text(encoding="utf-8"))

    # The included record list is already compressed (base64 + zlib).
    try:
        packed_records = (BASE_DIR / "public" / "record_list.json").read_bytes()
        infrastructure.records_data = cryptjson.json_unzip(packed_records)
    except Exception as exc:
        print(f"[Records] Não foi possível ler record_list.json: {exc}")
        infrastructure.records_data = {}

    # Google Sheets is only needed for hosted deployments.
    if not infrastructure.is_local:
        try:
            sheet_id = os.getenv("RECORDS_SPREADSHEET_ID", "1xoPZXT5apgKm1Z5J-YEv-sXTQ6BjB0vnPgrWLxhRpaU")
            infrastructure.records_data = {
                "new": records.read_spreadsheet(sheet_id),
                "old": records.read_spreadsheet(sheet_id),
            }
        except Exception as exc:
            print(f"[Records] Google Sheets indisponível; usando cópia local: {exc}")

    infrastructure.discord = LocalDiscord(infrastructure.config.get("discord_names", []))
    discord_token = os.getenv("DISCORD_API_TOKEN", "").strip()
    if discord_token:
        try:
            from discordbot import Bot
            bot = Bot("!")
            infrastructure.discord = bot
            asyncio.create_task(bot.start(discord_token))
            print("[Discord] Bot iniciado.")
        except Exception as exc:
            print(f"[Discord] Bot desativado: {exc}")

    app = web.Application()
    app.router.add_get("/", resources.index)
    app.router.add_get("/auth", api.Auth)
    app.router.add_get("/dashboard", resources.dashboard)
    app.router.add_get("/get_keys", api.GetKeys)
    app.router.add_get("/tfmlogin", api.TfmLogin)
    app.router.add_get("/transformice", api.Transformice)
    app.router.add_routes([
        web.get("/data", api.Data),
        web.get("/data/soft", api.Soft),
        web.get("/mapstorage", api.MapStorage),
        web.post("/data", api.Data),
        web.post("/mapstorage", api.MapStorage),
    ])
    app.router.add_get("/api/discord", api.discord_handler)
    app.router.add_get("/api/auth", api.Auth)
    app.router.add_get("/api/fetch", api.Fetch)
    app.router.add_get("/api/update", api.Update)
    app.router.add_static("/images", str(BASE_DIR / "images"))
    app.router.add_static("/public", str(BASE_DIR / "public"))

    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", "8090"))
    host = os.getenv("HOST", "127.0.0.1" if infrastructure.is_local else "0.0.0.0")
    site = web.TCPSite(runner, host, port)
    await site.start()
    print(f"[DisneyClient] Online em http://localhost:{port}")
    print("[DisneyClient] Banco:", os.getenv("MARIADB_ENDPOINT") or os.getenv("DATABASE_URL") or "SQLite local")

    downloader = asyncio.create_task(swf_downloader())
    try:
        await asyncio.Event().wait()
    finally:
        downloader.cancel()
        await runner.cleanup()
        await infrastructure.close_session()
        client.close()


if __name__ == "__main__":
    asyncio.run(main())
