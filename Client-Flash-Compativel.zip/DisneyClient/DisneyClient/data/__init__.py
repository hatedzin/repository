from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from functools import wraps
from typing import Any, ByteString, Dict, List, Optional
import os

from dotenv import load_dotenv
load_dotenv()

import sqlalchemy
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.orm import load_only, sessionmaker
from sqlalchemy.sql import func

from utils import cryptjson

Base = declarative_base()
from data.config import Config
from data.map import Map
from data.mariadbutils import json_length
from data.soft import Soft
from data.user import User

MutableDict.associate_with(sqlalchemy.JSON)
date_format = "%Y-%m-%d %H:%M:%S"


class EventSystem:
    def __init__(self):
        self.subscribers = defaultdict(list)

    def subscribe(self, event_name, callback):
        self.subscribers[event_name].append(callback)

    def notify(self, event_name, data=None):
        for callback in tuple(self.subscribers[event_name]):
            callback(data)


class DBClient:
    def __init__(self, endpoint: Optional[str] = None):
        self.event_system = EventSystem()
        endpoint = endpoint or os.getenv("MARIADB_ENDPOINT") or os.getenv("DATABASE_URL")
        if not endpoint:
            endpoint = "sqlite:///./disneyclient-local.sqlite3"
            print("[DB] MARIADB_ENDPOINT not configured; using local SQLite database.")

        engine_options = {"pool_pre_ping": True}
        if endpoint.startswith("sqlite"):
            engine_options["connect_args"] = {"check_same_thread": False}
        else:
            engine_options["pool_recycle"] = 3600

        self.engine = sqlalchemy.create_engine(endpoint, **engine_options)
        self.Session = sessionmaker(bind=self.engine, expire_on_commit=False)
        self._session = self.Session()

        # Create missing tables without modifying or dropping existing tables.
        Base.metadata.create_all(self.engine)

        for name in dir(self):
            method = getattr(self, name)
            if callable(method) and (name.startswith("del_") or name.startswith("set_")):
                setattr(self, name, self._commit_after(method))

    def _commit_after(self, method):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                result = method(*args, **kwargs)
                self._session.commit()
                return result
            except Exception:
                self._session.rollback()
                raise
        return wrapper

    def execute_with_reconnection(self, operation, *args, **kwargs):
        last_error = None
        for _ in range(3):
            try:
                return operation(*args, **kwargs)
            except sqlalchemy.exc.OperationalError as exc:
                last_error = exc
                self._session.rollback()
                self._session.close()
                self._session = self.Session()
        raise last_error

    def get_date_diff(self, date):
        if isinstance(date, str):
            date = datetime.strptime(date, date_format)
        return datetime.now() - date

    def del_unmodified(self):
        for user in self._session.query(User).options(load_only(User.key, User.last_login)).all():
            if user.last_login and self.get_date_diff(user.last_login).days >= 60:
                stored_map = self.find_map_by_key(user.key, True)
                if stored_map is not None:
                    self.delete(stored_map)

    def add(self, obj: Any):
        self.event_system.notify("data_added", obj)
        self._session.add(obj)

    def commit(self):
        try:
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise

    def delete(self, obj: Any):
        self.event_system.notify("data_deleted", obj)
        self._session.delete(obj)

    def find_config_by_key(self, key: str):
        return self._session.get(Config, key)

    def find_map_by_key(self, key: str, check_exists: bool = False):
        if check_exists:
            return self._session.query(Map).options(load_only(Map.key)).filter_by(key=key).first()
        return self._session.get(Map, key)

    def find_soft_by_key(self, key: str, check_exists: bool = False):
        if check_exists:
            return self._session.query(Soft).options(load_only(Soft.key)).filter_by(key=key).first()
        return self._session.get(Soft, key)

    def find_user_by_key(self, key: str, check_exists: bool = False):
        if check_exists:
            return self._session.query(User).options(load_only(User.key)).filter_by(key=key).first()
        return self._session.get(User, key)

    def load_maps(self, only_keys: bool = False) -> List:
        query = self._session.query(Map)
        return query.options(load_only(Map.key)).all() if only_keys else query.all()

    def load_soft(self, more_than: Optional[int] = None, only_keys: bool = False) -> List:
        query = self._session.query(Soft)
        result = query.options(load_only(Soft.key)).all() if only_keys else query.all()
        if more_than is not None:
            return [item for item in result if item.data and len(item.data) > more_than]
        return result

    def load_users(self, only_keys: bool = False) -> List[User]:
        query = self._session.query(User)
        return query.options(load_only(User.key)).all() if only_keys else query.all()

    def del_user(self, key: str) -> bool:
        user = self.find_user_by_key(key)
        if user:
            self.delete(user)
            return True
        return False

    def set_config(self, key: str, tfm_menu: Dict):
        config = self.find_config_by_key(key)
        if config:
            config.tfm_menu = tfm_menu
        else:
            config = Config(key=key, tfm_menu=tfm_menu)
            self.add(config)
        return config

    def set_map(self, key: str, data: ByteString):
        record = self.find_map_by_key(key)
        if record:
            record.data = data
        else:
            record = Map(key=key, data=data)
            self.add(record)
        return record

    def set_soft(self, key: str, data: Optional[ByteString] = b""):
        soft = self.find_soft_by_key(key)
        if soft and soft.data:
            new_maps = cryptjson.json_unzip(data) if data else {}
            old_maps = cryptjson.json_unzip(soft.data)
            for code, info in new_maps.items():
                self.event_system.notify("data_set", key)
                if code.startswith("@") and bool(info):
                    old_maps[code] = info
                else:
                    old_maps.pop(code, None)
            soft.data = cryptjson.json_zip(old_maps)
        elif soft:
            soft.data = data
        else:
            soft = Soft(key=key, data=data)
            self.add(soft)
        return soft

    def set_user(self, key: str, level: str = "GOLD_II", browser_access: bool = True):
        level = level.upper()
        user = self.find_user_by_key(key)
        if user:
            user.level = level
            user.browser_access = browser_access
        else:
            user = User(key=key, level=level, browser_access=browser_access)
            self.add(user)
        return user

    def set_user_browser_token(self, key: str, token: Optional[str] = None):
        user = self.find_user_by_key(key)
        if user:
            user.browser_access = True
            user.browser_access_token = token
        return user

    def set_flash_token(self, key: str, token: Optional[str] = None):
        user = self.find_user_by_key(key)
        if user:
            user.flash_token = token
        return user

    def close(self):
        self._session.close()
        self.engine.dispose()


client = DBClient()
