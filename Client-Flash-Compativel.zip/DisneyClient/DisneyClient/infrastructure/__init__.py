from collections import defaultdict
from typing import ByteString, Dict, Optional
import asyncio
import os
from aiohttp import ClientSession
from dotenv import load_dotenv

# Load the client-local .env before other modules read settings.
load_dotenv()

is_local: bool = "DYNO" not in os.environ
parser_url: str = os.getenv("TFM_PARSER_ENDPOINT", "http://127.0.0.1:8091").rstrip("/")
tfm_parser_token: str = os.getenv("TFM_PARSER_API_TOKEN", "local-parser-token")

config: Dict = {}
discord = None
records_data: Optional[ByteString] = None

# aiohttp objects must be created inside the running event loop.
loop: Optional[asyncio.AbstractEventLoop] = None
session: Optional[ClientSession] = None

auth_attempts: defaultdict = defaultdict(int)
blacklisted_ips: Dict = {}
ips: Dict = {}
sessions: Dict = {}
tokens: Dict = {}

tfm_swf_expected_len: int = 0


async def open_session() -> ClientSession:
    global loop, session
    loop = asyncio.get_running_loop()
    if session is None or session.closed:
        session = ClientSession()
    return session


async def close_session() -> None:
    global session
    if session is not None and not session.closed:
        await session.close()
    session = None
