"""Read Transformice record spreadsheets, loading Google credentials lazily."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict
import os

cats = ("P3", "P5", "P6", "P7", "P9", "P13", "P17", "P18", "P19", "V", "WJ")


def read_spreadsheet(key: str) -> Dict:
    credential_path = Path(os.getenv(
        "GOOGLE_APPLICATION_CREDENTIALS", "service_account_credentials.json"
    ))
    if not credential_path.is_file():
        raise FileNotFoundError(
            f"Google Sheets credentials not found: {credential_path}. "
            "Set GOOGLE_APPLICATION_CREDENTIALS or place your own service-account JSON here."
        )

    try:
        import gspread
    except ImportError as exc:
        raise RuntimeError("Install gspread to read Google Sheets records.") from exc

    gc = gspread.service_account(filename=str(credential_path))
    result = {}
    spreadsheet = gc.open_by_key(key)

    with ThreadPoolExecutor() as executor:
        futures = [(
            executor.submit(
                spreadsheet.values_batch_get,
                [f"{cat}!B:B", f"{cat}!C:C", f"{cat}!D:D"]
            ),
            executor.submit(
                spreadsheet.values_batch_get,
                [f"{cat}!J:J", f"{cat}!K:K", f"{cat}!L:L"]
            ) if cat != "V" else None
        ) for cat in cats]

        for left_future, right_future in futures:
            left = left_future.result()
            maps, players, times = (
                left["valueRanges"][i]["values"] for i in range(3)
            )

            right = right_future.result() if right_future is not None else None
            if right is not None:
                rmaps, rplayers, rtimes = (
                    right["valueRanges"][i]["values"] for i in (2, 1, 0)
                )

            last_player_key = 2
            for last_map_key in range(1, len(maps), 8):
                map_row = maps[last_map_key]
                if map_row and map_row[0].startswith("@"):
                    map_code = map_row[0]
                    temp = result.setdefault(map_code, {})
                    if (last_player_key < len(players) and last_player_key < len(times)
                            and players[last_player_key] and times[last_player_key]):
                        temp["left"] = (
                            players[last_player_key][0], times[last_player_key][0]
                        )
                    if (right is not None and last_map_key < len(rmaps)
                            and last_player_key < len(rplayers)
                            and last_player_key < len(rtimes)
                            and rplayers[last_player_key] and rtimes[last_player_key]):
                        temp["right"] = (
                            rplayers[last_player_key][0], rtimes[last_player_key][0]
                        )
                last_player_key += 8
                if last_player_key >= len(players):
                    break

    return result
