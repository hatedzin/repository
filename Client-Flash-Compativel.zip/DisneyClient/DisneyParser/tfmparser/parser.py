



#                https://safemarket.xyz | https://safemarket.xyz/discord
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#  | | ____     _     _____  _____      __  __     _     ____   _  __ _____  _____ | |  
#  | |/ ___|   / \   |  ___|| ____|    |  \/  |   / \   |  _ \ | |/ /| ____||_   _|| |  
#  | |\___ \  / _ \  | |_   |  _|      | |\/| |  / _ \  | |_) || ' / |  _|    | |  | |  
#  | | ___) |/ ___ \ |  _|  | |___     | |  | | / ___ \ |  _ < | . \ | |___   | |  | |  
#  | ||____//_/   \_\|_|    |_____|    |_|  |_|/_/   \_\|_| \_\|_|\_\|_____|  |_|  | |  
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#                               https://github.com/Jodis974                           



from .bypasscode import BypassCode
from .chatcontainer import ChatContainer
from .chatclass import Chat
from .chatmessage import ChatMessage
from .checker import Checker
from .domainmanager import DomainManager
from .frameloop import FrameLoop
from .mapclass import Map
from .move import Move
from .player import Player
from .shaman import Shaman
from .socket import Socket
from .swf import Swf
from .timer import Timer
from .ui import UI

from typing import Dict, List

import aiohttp
import asyncio
import datetime
import subprocess
import sys
import os
from pathlib import Path

tfm_swf_url = "http://transformice.com/Transformice.swf"

class Parser:
	def __init__(self, is_local: bool = False):
		self._session = None

		self.dumpscript: List = []
		self.fetched: Dict = {}

		self.is_local: bool = is_local

		self.last_swf_len: int = 0

		self.downloaded_swf: str = "Transformice.swf"
		self.output_swf: str = "tfm.swf"

	async def run_console(self, target: str):
		self.dumpscript *= 0

		tools_dir = Path(__file__).resolve().parent.parent / "tools"
		executable = tools_dir / ("swfdump.exe" if os.name == "nt" else "swfdump")
		if not executable.is_file():
			raise FileNotFoundError(f"swfdump não encontrado: {executable}")
		console = subprocess.Popen(
			[str(executable), "-a", target],
			shell=False,
			stdin=subprocess.DEVNULL,
			stdout=subprocess.PIPE,
			stderr=subprocess.STDOUT,
		)
		output, _ = console.communicate(timeout=120)
		if console.returncode != 0:
			raise RuntimeError(
				f"swfdump terminou com código {console.returncode}: "
				f"{output.decode(errors='replace')[-1000:]}"
			)
		self.dumpscript = output.decode(errors="replace").splitlines()

	async def download_swf(self):
		if self._session is None:
			self._session = aiohttp.ClientSession()

		update = False

		try:
			url = f"{tfm_swf_url}?d={datetime.datetime.now().timestamp()}"

			async with self._session.head(url) as response:
				length = response.content_length
				if length != self.last_swf_len:
					async with self._session.get(url) as response:
						if response.ok:
							print("Downloading Transformice.swf")

							with open(self.downloaded_swf, "w+b") as f:
								f.write(await response.read())
								
							self.last_swf_len = length

							update = True
						else:
							self.last_swf_len = 0
		except Exception as e:
			print(f"Failed to download Transformice SWF: {e}")

		return update

	async def start(self):
		updated = await self.download_swf()
		# If the remote game SWF is unreachable on first startup, parse the copy
		# bundled with this legacy distribution rather than returning empty keys.
		if not updated and not self.fetched:
			bundled = Path(__file__).resolve().parent.parent / "Transformice.swf"
			if Path(self.downloaded_swf).is_file():
				updated = True
			elif bundled.is_file():
				self.downloaded_swf = str(bundled)
				updated = True
		if not updated:
			return
		try:
			await self.run_console(self.downloaded_swf)
			swf = Swf(self.downloaded_swf, self.output_swf)
			await swf.parse_content(self.dumpscript)
			await self.run_console(self.output_swf)
		except Exception as e:
			print(f"Failed to parse Transformice SWF: {e}")
		else:
			self.bypass = BypassCode()
			self.chat = Chat()
			self.chat_container = ChatContainer()
			self.chat_message = ChatMessage()
			self.checker = Checker()
			self.domain_manager = DomainManager()
			self.frame_loop = FrameLoop()
			self.map = Map()
			self.move = Move()
			self.player = Player()
			self.shaman = Shaman()
			self.socket = Socket()
			self.timer = Timer()
			self.ui = UI()

			names = (
				"chat", "chat_container", "chat_message", "checker", "domain_manager",
				"frame_loop", "map", "move", "player", "shaman", "socket", "timer", "ui",
				"bypass"
			)
			for result in await asyncio.gather(*[
				getattr(self, name).fetch(self.dumpscript) for name in names
			]):
				self.fetched.update(result)

			for key, value in self.fetched.items():
				self.fetched[key] = value.replace("\\", "")
			print("Parser data has been updated")



#                https://safemarket.xyz | https://safemarket.xyz/discord
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#  | | ____     _     _____  _____      __  __     _     ____   _  __ _____  _____ | |  
#  | |/ ___|   / \   |  ___|| ____|    |  \/  |   / \   |  _ \ | |/ /| ____||_   _|| |  
#  | |\___ \  / _ \  | |_   |  _|      | |\/| |  / _ \  | |_) || ' / |  _|    | |  | |  
#  | | ___) |/ ___ \ |  _|  | |___     | |  | | / ___ \ |  _ < | . \ | |___   | |  | |  
#  | ||____//_/   \_\|_|    |_____|    |_|  |_|/_/   \_\|_| \_\|_|\_\|_____|  |_|  | |  
#__| |_____________________________________________________________________________| |__
#__   _____________________________________________________________________________   __
#  | |                                                                             | |  
#                               https://github.com/Jodis974                           



