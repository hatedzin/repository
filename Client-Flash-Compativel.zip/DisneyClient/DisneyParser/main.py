from __future__ import annotations

from aiohttp import web
from dotenv import load_dotenv
from pathlib import Path
from typing import Optional
import asyncio
import json
import os
import sys

BASE_DIR = Path(__file__).resolve().parent
os.chdir(BASE_DIR)
load_dotenv(BASE_DIR.parent / ".env")

class API:
    def __init__(self):
        self.is_local = "DYNO" not in os.environ

    @staticmethod
    def authentication(auth: str) -> Optional[str]:
        credentials = auth.split()
        if len(credentials) == 2 and credentials[0] == "Bearer":
            return credentials[1]
        return None

    async def update(self):
        tokens_path = BASE_DIR / "tokens.json"
        tokens = []
        if tokens_path.exists():
            try:
                loaded = json.loads(tokens_path.read_text(encoding="utf-8"))
                tokens = loaded if isinstance(loaded, list) else []
            except Exception as exc:
                print(f"[Parser] tokens.json inválido: {exc}")
        if not tokens:
            token = os.getenv("TFM_PARSER_API_TOKEN", "local-parser-token").strip()
            if token:
                tokens = [token]
        import api
        api.tokens = tokens

    async def fetch(self):
        import api
        while True:
            try:
                await api.parser.start()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                print(f"[Parser] Falha ao atualizar as chaves: {exc}")
            await asyncio.sleep(8.0)


endpoint = API()
# Ensure `api` imports this exact module even when this file is executed as __main__.
if __name__ == "__main__":
    sys.modules.setdefault("main", sys.modules[__name__])

import api


async def main():
    await endpoint.update()
    app = web.Application()
    app.router.add_get("/api/tfm_keys", api.TfmKeys)
    app.router.add_get("/transformice", api.Transformice)

    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PARSER_PORT", "8091"))
    host = os.getenv("PARSER_HOST", "127.0.0.1" if endpoint.is_local else "0.0.0.0")
    site = web.TCPSite(runner, host, port)
    await site.start()
    print(f"[DisneyParser] Online em http://localhost:{port}")

    fetch_task = asyncio.create_task(endpoint.fetch())
    try:
        await asyncio.Event().wait()
    finally:
        fetch_task.cancel()
        await runner.cleanup()
        if api.parser._session is not None:
            await api.parser._session.close()


if __name__ == "__main__":
    asyncio.run(main())
