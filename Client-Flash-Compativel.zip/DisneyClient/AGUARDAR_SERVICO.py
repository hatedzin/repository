"""Wait for a local HTTP service before opening the client in a browser."""

from __future__ import annotations

import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import urlopen


def main() -> int:
    if len(sys.argv) != 4:
        print("Uso: AGUARDAR_SERVICO.py URL NOME TIMEOUT_SEGUNDOS")
        return 2

    url, name = sys.argv[1], sys.argv[2]
    try:
        timeout = max(1, int(sys.argv[3]))
    except ValueError:
        print("Timeout inválido.")
        return 2

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urlopen(url, timeout=2):
                pass
            print(f"{name} respondeu em {url}.")
            return 0
        except HTTPError as error:
            # 204 (No Content) is a valid response for the Parser health URL.
            if error.code == 204:
                print(f"{name} respondeu em {url}.")
                return 0
        except (URLError, OSError, TimeoutError):
            pass
        time.sleep(1)

    print(f"ERRO: {name} não respondeu em {timeout}s: {url}")
    print("Verifique a janela do serviço. A porta pode estar ocupada ou houve erro ao iniciar.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
