@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DisneyClient - Client + Parser
set "ROOT=%~dp0"
set "VENV_PY=%ROOT%.venv\Scripts\python.exe"
set "LOGDIR=%ROOT%logs"
set "MAINLOG=%LOGDIR%\inicializacao.log"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
>"%MAINLOG%" echo DisneyClient startup - %DATE% %TIME%

echo ==================================================
echo   DISNEYCLIENT - INICIAR CLIENT + PARSER
echo ==================================================
echo.

if not exist ".env" (
    if not exist ".env.example" (
        echo ERRO: .env.example nao encontrado.
        goto :fail
    )
    copy /y ".env.example" ".env" >>"%MAINLOG%" 2>&1
    if errorlevel 1 (
        echo ERRO: nao foi possivel criar o arquivo .env.
        goto :fail
    )
    echo Arquivo .env local criado.
)

rem Detecta Python 3.11, 3.12 ou 3.13 pelo Launcher ou pelo PATH.
set "PYRUN="
py -3.11 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,11) else 1)" >nul 2>&1
if not errorlevel 1 set "PYRUN=py -3.11"
if not defined PYRUN (
    py -3.12 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYRUN=py -3.12"
)
if not defined PYRUN (
    py -3.13 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYRUN=py -3.13"
)
if not defined PYRUN (
    python -c "import sys; sys.exit(0 if sys.version_info[:2] in ((3,11),(3,12),(3,13)) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYRUN=python"
)

if not defined PYRUN (
    echo ERRO: Python 3.11, 3.12 ou 3.13 nao foi encontrado.
    echo Instale Python x64 e marque 'Add Python to PATH'.
    goto :fail
)
echo Python detectado: %PYRUN%
echo Python detectado: %PYRUN%>>"%MAINLOG%"

if not exist "%VENV_PY%" (
    echo Criando ambiente virtual...
    %PYRUN% -m venv "%ROOT%.venv" >>"%MAINLOG%" 2>&1
    if errorlevel 1 (
        echo ERRO: nao foi possivel criar o ambiente virtual.
        goto :fail
    )
)

if not exist "%VENV_PY%" (
    echo ERRO: Python do ambiente virtual nao foi encontrado.
    goto :fail
)

if not exist "%ROOT%.venv\dependencias.ok" (
    echo Instalando dependencias do Client e do Parser. Isso ocorre na primeira execucao...
    "%VENV_PY%" -m pip install --disable-pip-version-check --retries 2 --timeout 25 -r "%ROOT%DisneyClient\requirements.txt" -r "%ROOT%DisneyParser\requirements.txt" >>"%MAINLOG%" 2>&1
    if errorlevel 1 (
        echo ERRO ao instalar dependencias. Consulte logs\inicializacao.log.
        goto :fail
    )
    >"%ROOT%.venv\dependencias.ok" echo OK
) else (
    echo Dependencias ja instaladas.
)

if not exist "%ROOT%DisneyParser\main.py" (
    echo ERRO: DisneyParser\main.py nao encontrado.
    goto :fail
)
if not exist "%ROOT%DisneyClient\server.py" (
    echo ERRO: DisneyClient\server.py nao encontrado.
    goto :fail
)

if not exist "%ROOT%AGUARDAR_SERVICO.py" (
    echo ERRO: AGUARDAR_SERVICO.py nao encontrado.
    goto :fail
)

rem Inicia o Parser e espera a porta responder antes de iniciar o Client.
echo Iniciando Parser em http://127.0.0.1:8091 ...
start "DisneyParser - Parser" /D "%ROOT%DisneyParser" "%ComSpec%" /k ""%VENV_PY%" -u main.py"
"%VENV_PY%" "%ROOT%AGUARDAR_SERVICO.py" http://127.0.0.1:8091/transformice "Parser" 60
if errorlevel 1 (
    echo ERRO: o Parser nao iniciou. Confira a janela DisneyParser e o log de instalacao.
    goto :fail
)

echo Iniciando Client em http://127.0.0.1:8090 ...
start "DisneyClient - Servidor" /D "%ROOT%DisneyClient" "%ComSpec%" /k ""%VENV_PY%" -u server.py"
"%VENV_PY%" "%ROOT%AGUARDAR_SERVICO.py" http://127.0.0.1:8090/ "Client" 60
if errorlevel 1 (
    echo ERRO: o Client nao iniciou. Confira a janela DisneyClient e o log de instalacao.
    goto :fail
)

echo.
echo Client e Parser respondendo. Abrindo http://localhost:8090.
echo Mantenha as janelas do Parser e do Client abertas.
echo Log de instalacao/inicializacao: %MAINLOG%
start "" "http://localhost:8090"
echo Inicializacao concluida. Esta janela pode ser fechada.
timeout /t 2 /nobreak >nul
exit /b 0

:fail
echo.
echo A inicializacao nao foi concluida.
echo Veja o log: %MAINLOG%
echo.
pause
exit /b 1
