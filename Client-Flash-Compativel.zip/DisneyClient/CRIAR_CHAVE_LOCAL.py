from __future__ import annotations

"""Create one local-only test account in the default SQLite database."""

import os
import secrets
import sys
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
CLIENT_DIR = ROOT / "DisneyClient"
load_dotenv(ROOT / ".env")

endpoint = (os.getenv("MARIADB_ENDPOINT") or os.getenv("DATABASE_URL") or "").strip()
if endpoint and not endpoint.startswith("sqlite"):
    print("Banco remoto detectado em .env.")
    print("Por seguranca, este utilitario nao cria usuarios em bancos remotos.")
    print("Cadastre sua conta pelo administrador do seu banco original.")
    raise SystemExit(2)

os.chdir(CLIENT_DIR)
sys.path.insert(0, str(CLIENT_DIR))

try:
    from data import client

    key = secrets.token_hex(8).upper()
    client.set_user(key, level="GOLD_II", browser_access=True)
    print("\nCHAVE LOCAL CRIADA COM SUCESSO")
    print("Copie esta chave e use-a na pagina http://localhost:8090:")
    print(f"\n{key}\n")
    print("Esta chave pertence somente ao banco local deste pacote.")
    print("Guarde-a: ela nao e uma licenca online do Transformice.")
finally:
    try:
        client.close()
    except Exception:
        pass
