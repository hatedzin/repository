from pathlib import Path
import base64
import importlib.util
import json
import sys
import zlib

ROOT = Path(__file__).resolve().parent
CLIENT = ROOT / "DisneyClient"
PARSER = ROOT / "DisneyParser"
errors = []
warnings = []

print("DisneyClient local diagnostic")
print("Python:", sys.version.split()[0])
if sys.version_info < (3, 11) or sys.version_info >= (3, 13):
    warnings.append("Python 3.11 ou 3.12 é recomendado para este projeto legado.")

for module in ("aiohttp", "aiofiles", "sqlalchemy", "ujson", "dotenv"):
    if importlib.util.find_spec(module) is None:
        errors.append(f"Dependência ausente: {module}")

for rel in ("config.json", "public/index/index.html", "public/ChargeurTransformice.swf",
            "public/maps.json", "public/record_list.json"):
    if not (CLIENT / rel).is_file():
        errors.append(f"Arquivo obrigatório ausente: DisneyClient/{rel}")

for rel in ("main.py", "Transformice.swf", "tools/swfdump.exe"):
    if not (PARSER / rel).is_file():
        warnings.append(f"Arquivo do parser ausente: DisneyParser/{rel}")

try:
    json.loads((CLIENT / "config.json").read_text(encoding="utf-8"))
except Exception as exc:
    errors.append(f"config.json inválido: {exc}")

for name in ("maps.json", "record_list.json", "protectedmaps.json"):
    path = CLIENT / "public" / name
    if path.exists():
        try:
            data = zlib.decompress(base64.b64decode(path.read_bytes()))
            if name != "maps.json":
                json.loads(data)
        except Exception as exc:
            errors.append(f"{name} compactado inválido: {exc}")

swf = CLIENT / "public" / "ChargeurTransformice.swf"
if swf.exists():
    magic = swf.read_bytes()[:3]
    if magic not in (b"FWS", b"CWS", b"ZWS"):
        errors.append("ChargeurTransformice.swf não parece ser um SWF válido.")

if not (ROOT / ".env").exists():
    warnings.append(".env ainda não existe; o inicializador cria uma configuração local.")

if not (CLIENT / "service_account_credentials.json").exists():
    print("Google Sheets: desativado (é opcional no modo local).")

for item in warnings:
    print("AVISO:", item)
for item in errors:
    print("ERRO:", item)

if errors:
    print(f"RESULTADO: FALHOU ({len(errors)} erro(s))")
    raise SystemExit(1)
print("RESULTADO: arquivos e dependências básicas OK.")
