// ActionScript 3 / ContactTests.as / Ruffle AVM2 / inspect actual embedded icons and contact layout
package disney {
 import flash.display.MovieClip;import flash.display.Sprite;import flash.display.DisplayObjectContainer;import flash.text.TextField;import flash.text.TextFormat;import flash.external.ExternalInterface;import flash.utils.setTimeout;
 public class RgbMouseTests {
  private static function text(value:String,x:Number,y:Number,size:int=12):TextField{var f:TextField=new TextField();f.defaultTextFormat=new TextFormat("_sans",size,0xD7DEEC);f.text=value;f.x=x;f.y=y;f.width=145;f.height=25;return f;}
  public static function run(display:MovieClip):void{
   var root:MovieClip=new MovieClip();display.addChild(root);var panel:Sprite=new Sprite();panel.graphics.beginFill(0x0E1420);panel.graphics.drawRoundRect(0,0,760,430,18);panel.graphics.endFill();panel.x=16;panel.y=16;root.addChild(panel);panel.addChild(text("DISNEY",36,14,20));panel.addChild(text("MODULOS",22,78,10));
   var labels:Array=["Jogador","Farm","Bot","Atalhos","Ajustes"];for(var i:int=0;i<labels.length;i++){var nav:Sprite=new Sprite();nav.x=16;nav.y=105+i*49;nav.graphics.beginFill(i==0 ? 0x292247 : 0x121A28);nav.graphics.drawRoundRect(0,0,142,40,6);nav.graphics.endFill();nav.addChild(text(labels[i],16,9));panel.addChild(nav);}panel.addChild(text("ROLE PARA VER MAIS",194,407,10));
   root["Interface"]={menu_ui:panel};var contacts:DiscordContacts=new DiscordContacts(root);contacts.update();var count:int=panel.numChildren;contacts.update();
   setTimeout(function():void{var result:String;try{if(panel.numChildren!=count)throw new Error("duplicate contacts");var names:Array=["shadowsmachine","arroz6710"];for each(var name:String in names){var row:Sprite=panel.getChildByName("sddsDiscord_"+name) as Sprite;if(!row)throw new Error("missing "+name);if(TextField(row.getChildByName("handle")).text!=name)throw new Error("wrong handle");if(DisplayObjectContainer(row.getChildAt(0)).numChildren!=1)throw new Error("embedded icon did not decode");if(row.x+row.width>173 || row.y<341 || row.y+row.height>398)throw new Error("contact outside sidebar space");}var next:Sprite=new Sprite();root.Interface.menu_ui=next;contacts.update();if(next.numChildren!=2)throw new Error("reopened menu missing contacts");result="PASS: two embedded Discord icons, exact handles, bounded layout, no duplicates, menu recreation";}catch(e:Error){result="FAIL: "+e.message;}ExternalInterface.call("recordTest",result);},250);
  }
 }
}
