@rem Batch / REMOVER_REGRA_RADMIN.bat / Windows 10+ / remove this package firewall rule
@echo off
netsh advfirewall firewall delete rule name="SDDS 207.180.3.127 8080"
pause
