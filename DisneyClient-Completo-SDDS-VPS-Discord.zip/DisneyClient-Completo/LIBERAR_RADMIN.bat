@rem Batch / LIBERAR_RADMIN.bat / Windows 10+ / allow requested Radmin host TCP8080
@echo off
netsh advfirewall firewall delete rule name="SDDS 207.180.3.127 8080" >nul 2>&1
netsh advfirewall firewall add rule name="SDDS 207.180.3.127 8080" dir=in action=allow protocol=TCP localip=207.180.3.127 localport=8080 remoteip=any profile=any
pause
