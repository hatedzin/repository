"""Serve the original Disney parser contract using the uploaded local SWF."""
import asyncio
import contextlib
import json
import os
from pathlib import Path
import signal
import sys
from aiohttp import web

# Support both `python main.py` and `python -m DisneyParser.main`.
if not __package__:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    __package__ = 'DisneyParser'
from .runtime import ParserRuntime
from .api import TfmKeys, Transformice

ROOT = Path(__file__).resolve().parent

async def extract_loop(app):
    while True:
        await app['parser'].refresh_local()
        await app['parser'].refresh_official()
        await asyncio.sleep(30)

async def lifecycle(app):
    task = asyncio.create_task(extract_loop(app))
    try:
        yield
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

def create_app(root=None):
    root = Path(root or ROOT)
    tokens_file = Path(os.getenv('DISNEY_PARSER_TOKENS_FILE', str(root/'tokens.json')))
    try:
        tokens = json.loads(tokens_file.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError) as exc:
        raise RuntimeError('Parser token file missing/invalid; use run_disney.py to configure it locally') from exc
    if not isinstance(tokens,list) or not tokens or not all(isinstance(t,str) and t for t in tokens):
        raise RuntimeError('Parser token file must be a nonempty list of token strings')
    app = web.Application()
    app.update(parser=ParserRuntime(root), tokens=tokens)
    app.cleanup_ctx.append(lifecycle)
    app.router.add_view('/api/tfm_keys',TfmKeys)
    app.router.add_view('/transformice',Transformice)
    async def health(request):
        return web.json_response(request.app['parser'].metadata())
    app.router.add_get('/health',health)
    return app

def main():
    if hasattr(signal,'SIGBREAK'):
        def stop(signum,frame):
            raise KeyboardInterrupt()
        signal.signal(signal.SIGBREAK,stop)
    web.run_app(create_app(),host='127.0.0.1',port=int(os.getenv('PARSER_PORT','8090')),access_log=None)

if __name__=='__main__':
    main()
