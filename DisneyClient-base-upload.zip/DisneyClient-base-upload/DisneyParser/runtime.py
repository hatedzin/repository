"""Extract existing symbols without changing the uploaded game or loader."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import aiohttp
from .tfmparser import parser as legacy
from DisneyClient.swf_assets import inspect_file

# These names are produced by the supplied extractors, not invented class values.
MINIMUM_KEYS = ('frame_loop_class_name', 'socket_class_name', 'ui_manager_class_name',
                'socket_name', 'read_data', 'main_socket_instance', 'bulle_socket_instance', 'event_socket_data')
EXTRACTORS = ('BypassCode', 'Chat', 'ChatContainer', 'ChatMessage', 'Checker',
              'DomainManager', 'FrameLoop', 'Map', 'Move', 'Player', 'Shaman',
              'Socket', 'Timer', 'UI')


class ParserRuntime:
    def __init__(self, root):
        self.root = Path(root)
        self.swf = self.root / 'tfm.swf'
        self.cache = self.root / '.cache' / 'symbols.json'
        self.fetched = {}
        self.error = None
        self.loaded_sha = None
        self.update_error = None
        self.official_sha = None

    def metadata(self):
        try:
            info = inspect_file(self.swf)
        except (OSError, ValueError):
            info = None
        ready = bool(info and self.loaded_sha == info['sha256'] and
                     all(self.fetched.get(k) for k in MINIMUM_KEYS))
        return {'status': 'ok', 'swf_ready': info is not None, 'symbols_ready': ready,
                'symbol_count': len(self.fetched), 'missing_symbols': [k for k in MINIMUM_KEYS if not self.fetched.get(k)],
                'extractor_error': self.error, 'swf': info,
                'automatic_official_update': True, 'update_error': self.update_error}

    async def refresh_local(self):
        """Read only the supplied decoded SWF; never download or patch it here."""
        try:
            info = inspect_file(self.swf)
            if info['sha256'] == self.loaded_sha and self.fetched:
                return
            if self.cache.is_file():
                try:
                    cached = json.loads(self.cache.read_text())
                    keys = cached.get('keys')
                    if (cached.get('swf_sha256') == info['sha256'] and isinstance(keys, dict)
                            and all(isinstance(keys.get(k), str) and keys[k] for k in MINIMUM_KEYS)):
                        self.fetched = keys
                        self.loaded_sha = info['sha256']
                        self.error = None
                        return
                except (ValueError, OSError):
                    # A bad cache does not stop extraction from the actual SWF.
                    self.error = 'cache_invalid'
            executable = os.getenv('PARSER_SWFDUMP')
            if not executable:
                executable = str(self.root/'tools'/'swfdump.exe') if os.name == 'nt' else shutil.which('swfdump')
            if not executable or not Path(executable).is_file():
                self.error = 'swfdump_missing'
                return
            process = await asyncio.create_subprocess_exec(executable, '-a', str(self.swf),
                        stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE, cwd=self.root)
            try:
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=60)
            except BaseException:
                if process.returncode is None:
                    process.kill()
                await process.communicate()
                raise
            if process.returncode:
                self.error = 'swfdump_failed'
                return
            lines = stdout.decode('utf-8', errors='replace').splitlines()
            if not any('getlex <q>' in line for line in lines):
                self.error = 'swfdump_format_unsupported'
                return
            results = await asyncio.gather(*(getattr(legacy, name)().fetch(lines) for name in EXTRACTORS), return_exceptions=True)
            candidate = {}
            for name, item in zip(EXTRACTORS, results):
                if isinstance(item, BaseException):
                    if isinstance(item, asyncio.CancelledError):
                        raise item
                    self.error = 'extractor_failed:' + name + ':' + type(item).__name__
                    return
                candidate.update(item)
            candidate = {k: v.replace('\\', '') for k,v in candidate.items() if isinstance(v,str)}
            if not all(candidate.get(k) for k in MINIMUM_KEYS):
                self.fetched = candidate
                self.loaded_sha = info['sha256']
                self.error = 'symbols_incomplete'
                return
            # Publish only a matching SWF/profile pair; retain previous valid cache on failures.
            self.cache.parent.mkdir(exist_ok=True)
            temp = self.cache.with_suffix('.tmp')
            temp.write_text(json.dumps({'swf_sha256': info['sha256'], 'keys': candidate}))
            temp.replace(self.cache)
            self.fetched = candidate
            self.loaded_sha = info['sha256']
            self.error = None
        except asyncio.CancelledError:
            raise
        except (OSError, ValueError, IndexError, AttributeError, TypeError, TimeoutError) as exc:
            self.error = 'extraction_' + type(exc).__name__

    async def refresh_official(self):
        """Keep the uploaded online pipeline, publish only a complete matching pair."""
        executable = os.getenv('PARSER_SWFDUMP') or (str(self.root/'tools'/'swfdump.exe') if os.name=='nt' else shutil.which('swfdump'))
        if not executable or not Path(executable).is_file():
            self.update_error = 'swfdump_missing'
            return
        url = 'http://transformice.com/Transformice.swf'
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as session:
                async with session.get(url) as response:
                    response.raise_for_status()
                    content = bytearray()
                    async for chunk in response.content.iter_chunked(65536):
                        content.extend(chunk)
                        if len(content)>64*1024*1024:
                            raise ValueError('size_limit')
            digest = hashlib.sha256(content).hexdigest()
            if digest==self.official_sha:
                return
            with tempfile.TemporaryDirectory(prefix='update-',dir=self.root) as folder:
                root = Path(folder)
                wrapper = root/'Transformice.swf'
                wrapper.write_bytes(content)
                inspect_file(wrapper)
                proc = await asyncio.create_subprocess_exec(executable,'-a',str(wrapper),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
                try:
                    stdout,_ = await asyncio.wait_for(proc.communicate(),60)
                except BaseException:
                    if proc.returncode is None: proc.kill()
                    await proc.communicate()
                    raise
                if proc.returncode: raise ValueError('disassembler_failed')
                candidate_path = root/'tfm.swf'
                await legacy.Swf(str(wrapper),str(candidate_path)).parse_content(stdout.decode('utf-8',errors='replace').splitlines())
                inspect_file(candidate_path)
                candidate = ParserRuntime(root)
                # Child reads the same real executable; it does not perform network requests.
                old = os.environ.get('PARSER_SWFDUMP')
                os.environ['PARSER_SWFDUMP'] = executable
                try:
                    await candidate.refresh_local()
                finally:
                    if old is None: os.environ.pop('PARSER_SWFDUMP',None)
                    else: os.environ['PARSER_SWFDUMP']=old
                if not candidate.metadata()['symbols_ready']:
                    self.update_error = 'official_symbols_incomplete'
                    return
                # No awaits while publishing this process's matching SWF/profile pair.
                candidate_path.replace(self.swf)
                self.fetched,self.loaded_sha = candidate.fetched,candidate.loaded_sha
                self.cache.parent.mkdir(exist_ok=True)
                candidate.cache.replace(self.cache)
                wrapper.replace(self.root/'Transformice.swf')
                self.official_sha=digest
                self.error=None
                self.update_error=None
        except asyncio.CancelledError:
            raise
        except (aiohttp.ClientError,TimeoutError,OSError,ValueError,IndexError,KeyError,AttributeError) as exc:
            self.update_error='official_update_'+type(exc).__name__
