"""Start the original Disney workflow, using existing local settings and assets."""
import argparse
import json
import os
from pathlib import Path
import secrets
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent


def parser_token(settings):
    path = ROOT/'DisneyParser'/'tokens.json'
    if path.exists():
        tokens = json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(tokens,list) or not all(isinstance(t,str) and t for t in tokens):
            raise ValueError('DisneyParser/tokens.json must contain a list of token strings')
    else:
        tokens = []
    token = settings.get('TFM_PARSER_API_TOKEN') or (tokens[0] if tokens else secrets.token_urlsafe(32))
    if token not in tokens:
        tokens.append(token)
        temporary = path.with_suffix('.tmp')
        temporary.write_text(json.dumps(tokens),encoding='utf-8')
        temporary.chmod(0o600)
        temporary.replace(path)
    return token


def stop(child):
    if child.poll() is not None:
        return
    try:
        child.send_signal(signal.CTRL_BREAK_EVENT if os.name=='nt' else signal.SIGINT)
        child.wait(timeout=10)
    except (OSError,ValueError,subprocess.TimeoutExpired):
        child.terminate()
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill();child.wait()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--no-browser',action='store_true')
    args=p.parse_args()
    settings_file=ROOT/'DisneyClient'/'.env'
    if not settings_file.is_file():
        print('Copy your existing DisneyClient .env here first, or configure .env.xampp.example. No settings were overwritten.')
        return 1
    children=[]
    try:
        settings=dotenv_values(settings_file)
        # Preserve existing injected values when present; never print credentials.
        settings={**settings,**{k:v for k,v in os.environ.items() if k in settings}}
        backend_port=int(settings.get('SERVER_PORT') or '8080')
        parser_port=int(settings.get('PARSER_PORT') or '8090')
        if backend_port==parser_port:
            raise ValueError('Backend and parser must use different ports')
        for port in (backend_port,parser_port):
            with socket.socket() as sock:
                try:sock.bind(('127.0.0.1',port))
                except OSError:raise ValueError(f'Port {port} is occupied; close the old server/parser terminal before starting')
        token=parser_token(settings)
        backend_env=dict(os.environ,TFM_PARSER_ENDPOINT=f'http://127.0.0.1:{parser_port}',
                         TFM_PARSER_API_TOKEN=token,SERVER_HOST='127.0.0.1',SERVER_PORT=str(backend_port))
        parser_env=dict(os.environ,PARSER_PORT=str(parser_port))
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0
        for folder,script,env in [('DisneyParser','main.py',parser_env),('DisneyClient','server.py',backend_env)]:
            children.append(subprocess.Popen([sys.executable,script],cwd=ROOT/folder,env=env,creationflags=creationflags))
        base=f'http://127.0.0.1:{backend_port}'
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            if any(child.poll() is not None for child in children):
                raise RuntimeError('A process stopped during startup; inspect the preceding terminal error')
            try:
                with urllib.request.urlopen(base+'/health',timeout=2) as response:
                    info=json.load(response)
                if info.get('database')=='ok':
                    break
            except (OSError,ValueError):
                pass
            time.sleep(0.2)
        else:
            raise RuntimeError('Backend readiness timed out; check the MySQL settings in .env')
        print('Original Disney login:',base,flush=True)
        print('Local diagnostics:',base+'/diagnostics',flush=True)
        print('Use the loader URL returned after key login. The NovoClient-base port 8082 is not part of this flow.',flush=True)
        if not args.no_browser:
            webbrowser.open(base)
        while True:
            if any(child.poll() is not None for child in children):
                raise RuntimeError('One service stopped; stopping the other process started by this launcher')
            time.sleep(0.5)
    except KeyboardInterrupt:
        return 0
    except (ValueError,OSError,RuntimeError) as exc:
        print(str(exc),file=sys.stderr)
        return 1
    finally:
        for child in reversed(children):
            stop(child)


if __name__=='__main__':
    raise SystemExit(main())
