# Base do upload de 27/10/2026

Preservados os cinco SWFs, o decoder e as regras de extracao do ZIP enviado.
Os hashes estao em PRESERVED_SWF_HASHES.json. Nenhum SWF antigo foi inserido.
O novo launcher reutiliza .env/banco existentes e configura o token local.
Imports circulares e ciclo de vida HTTP do parser foram corrigidos.
O backend continua buscando atualizacoes do parser automaticamente.
O parser busca o endereco oficial usado na source enviada, decodifica em pasta
temporaria e so publica o SWF/perfil quando os simbolos obrigatorios existem.
Uma falha de download ou extracao preserva os arquivos anteriores.

Validacao executada:
- 13 testes do backend passaram; 9 testes que exigem banco nao foram executados.
- 3 testes adicionais passaram: integridade dos SWFs, preservacao em falha de
  rede e deteccao da extracao incompleta real.
- O decoder original aplicado ao Transformice.swf do upload reproduziu o tfm.swf
  do mesmo upload byte a byte: SHA256 097eb831d9a4a719a3a0a96630660108f6bd3182946b0eeff0abbc6a38426f78.
- Extracao real: 109 simbolos, socket_name/read_data ausentes.
- Download do site oficial bloqueado neste ambiente: HTTP 403.

PENDENTE: adaptar as regras de socket/loader a versao oficial atual. O pacote
nao comprova conexao, login ou partida online; nao acrescenta Fly/Robot/salto.
A base foi reintegrada, mas a incompatibilidade de socket nao esta corrigida.
Para repetir os testes locais: python -m unittest -v tests_base.
O teste real de extracao requer PARSER_SWFDUMP apontando para swfdump.
