import asyncio
import hashlib
import json
import os
import sys
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import aiohttp
from DisneyParser.runtime import ParserRuntime

ROOT=Path(__file__).resolve().parent
DUMP=os.getenv('PARSER_SWFDUMP') or shutil.which('swfdump') or ''

class BaseTests(unittest.IsolatedAsyncioTestCase):
    def test_uploaded_swf_bytes_preserved(self):
        manifest=json.loads((ROOT/'PRESERVED_SWF_HASHES.json').read_text())
        for name,digest in manifest.items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)

    async def test_network_failure_keeps_upload(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder);shutil.copyfile(ROOT/'DisneyParser/tfm.swf',path/'tfm.swf')
            runtime=ParserRuntime(path)
            original=(path/'tfm.swf').read_bytes()
            with patch.dict(os.environ,{'PARSER_SWFDUMP':sys.executable}),patch('DisneyParser.runtime.aiohttp.ClientSession',side_effect=aiohttp.ClientConnectionError()):
                await runtime.refresh_official()
            self.assertEqual((path/'tfm.swf').read_bytes(),original)
            self.assertEqual(runtime.update_error,'official_update_ClientConnectionError')

    @unittest.skipUnless(DUMP and Path(DUMP).is_file(),'Set up native swfdump to validate real extraction')
    async def test_actual_upload_is_reported_incomplete(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder);shutil.copyfile(ROOT/'DisneyParser/tfm.swf',path/'tfm.swf')
            runtime=ParserRuntime(path)
            with patch.dict(os.environ,{'PARSER_SWFDUMP':DUMP}):
                await runtime.refresh_local()
            state=runtime.metadata()
            self.assertEqual(state['symbol_count'],109)
            self.assertEqual(set(state['missing_symbols']),{'socket_name','read_data'})
            self.assertFalse(state['symbols_ready'])
            self.assertTrue(state['automatic_official_update'])
            self.assertFalse(runtime.cache.exists())

if __name__=='__main__':unittest.main()
