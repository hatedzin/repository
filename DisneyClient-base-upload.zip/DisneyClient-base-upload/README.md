BASE DO ULTIMO ZIP ENVIADO — SEM TROCA POR SWF ANTIGO

1. Extraia em uma nova pasta. Nao sobrescreva sua copia funcional.
2. Copie seu DisneyClient/.env para DisneyClient/.env desta pasta.
3. Ligue o MySQL e feche os servidores anteriores.
4. Na raiz: python -m pip install -r requirements.txt
5. Execute: python run_disney.py

Loader, SWFs, extratores e decoder vieram deste ultimo upload.
A atualizacao automatica do site oficial esta ativa, como na base enviada.
O launcher cria o token local sem alterar seu .env.
Nao recrie o banco nem as keys.

LIMITACAO VERIFICADA: o SWF incluido produz 109 simbolos; faltam
socket_name e read_data. O parser agora informa essa falha, em vez de
entregar um perfil incompleto ao loader. Uma atualizacao so substitui
o par SWF/perfil se a extracao realmente estiver completa.
Neste ambiente o download oficial recebe HTTP 403. Nao foi possivel
validar o SWF oficial atual, login online, partida ou novos recursos.
Este pacote e a base reintegrada; NAO e uma correcao online comprovada.
Veja http://127.0.0.1:8080/diagnostics para o estado real.
