@echo off
cd /d "%~dp0"
if exist ".client-runtime\Scripts\python.exe" (
  ".client-runtime\Scripts\python.exe" configurar_github_rotas.py
) else (
  py -3 configurar_github_rotas.py
)
pause
