"""Run locally. Never ships or prints a GitHub credential."""
from getpass import getpass
import sys
from pathlib import Path
import os
import re
import shutil
import urllib.error
import urllib.request


def save_token(path, token):
    old = path.read_text(encoding='utf-8') if path.exists() else ''
    lines = [line for line in old.splitlines() if not re.match(r'^\s*(?:export\s+)?TFM_GITHUB_ROUTES_TOKEN\s*=',line)]
    lines.append('TFM_GITHUB_ROUTES_TOKEN=' + token)
    temporary = path.with_name(path.name + '.github.tmp')
    try:
        descriptor = os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(descriptor,'w',encoding='utf-8',newline='\n') as stream:
            stream.write('\n'.join(lines)+'\n')
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)



def normalize_token(value):
    value = value.strip().lstrip("\ufeff\u200b").strip()
    if value.startswith('TFM_GITHUB_ROUTES_TOKEN='):
        value = value.split('=',1)[1].strip()
    if value.lower().startswith('bearer '):
        value = value[7:].strip()
    if len(value)>=2 and value[0] in ('"', "'") and value[-1]==value[0]:
        value = value[1:-1].strip()
    value = ''.join(value.split())
    if not value or value == '\x16':
        raise ValueError('Nenhum token recebido. Clique em Colar na janela e depois em Continuar.')
    if not re.fullmatch(r'(?:github_pat_[A-Za-z0-9_]+|ghp_[A-Za-z0-9]+)',value) or not 20<=len(value)<=255:
        raise ValueError('Entrada invalida. Use o token GitHub, sem o conteudo de tokens.json.')
    return value


def gui_token():
    import tkinter as tk
    from tkinter import messagebox
    window=tk.Tk()
    window.title('Configurar GitHub - Rotas novas')
    window.resizable(False,False)
    value=tk.StringVar()
    result=[]
    tk.Label(window,text='Cole seu token GitHub para hatedzin/repository.',anchor='w').pack(padx=18,pady=(18,6),anchor='w')
    tk.Label(window,text='Permissao necessaria: Contents - Read and write.',anchor='w').pack(padx=18,anchor='w')
    entry=tk.Entry(window,textvariable=value,show='*',width=62)
    entry.pack(padx=18,pady=14)
    buttons=tk.Frame(window)
    buttons.pack(padx=18,pady=(0,10))
    def paste():
        try:
            value.set(window.clipboard_get())
            entry.focus_set()
        except tk.TclError:
            messagebox.showerror('Colar','Nao ha texto disponivel para colar.',parent=window)
    def confirm(event=None):
        try:
            result.append(normalize_token(value.get()))
        except ValueError as error:
            messagebox.showerror('Confira a entrada',str(error),parent=window)
            entry.focus_set()
            return
        window.destroy()
    tk.Button(buttons,text='Colar',width=14,command=paste).pack(side='left',padx=4)
    tk.Button(buttons,text='Continuar',width=14,command=confirm).pack(side='left',padx=4)
    tk.Button(buttons,text='Cancelar',width=14,command=window.destroy).pack(side='left',padx=4)
    tk.Label(window,text='O token fica oculto e sera salvo somente no .env local.').pack(padx=18,pady=(0,18))
    window.bind('<Return>',confirm)
    entry.focus_set()
    window.mainloop()
    if not result:
        raise ValueError('Configuracao cancelada. Nenhuma credencial foi alterada.')
    return result[0]


def read_token():
    if os.name == 'nt' and '--console' not in sys.argv:
        try:
            import tkinter
        except ImportError:
            print('Interface grafica indisponivel; usando console.')
        else:
            try:
                return gui_token()
            except tkinter.TclError:
                print('Nao foi possivel abrir a janela; usando console.')
    print('No console, cole com o botao direito do mouse. A entrada permanece oculta.')
    print('Nada aparecera enquanto voce cola; pressione Enter somente depois de colar.')
    for attempt in range(3):
        try:
            return normalize_token(getpass('Token GitHub: '))
        except ValueError as error:
            print(str(error))
    raise ValueError('Configuracao nao concluida. Execute novamente para tentar outra vez.')


def main():
    root = Path(__file__).resolve().parent
    print('CONFIGURADOR 2 - janela com botao Colar no Windows')
    print('GitHub: hatedzin/repository / main / rotas-novas.json')
    print('Crie um fine-grained token em https://github.com/settings/personal-access-tokens/new')
    print('Selecione somente hatedzin/repository; Repository permissions > Contents: Read and write.')
    print('O token sera guardado somente em DisneyClient/.env deste computador.')
    token = read_token()
    request = urllib.request.Request('https://api.github.com/repos/hatedzin/repository/contents/rotas-novas.json?ref=main',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'DisneyClient-Routes-Setup'})
    try:
        with urllib.request.urlopen(request,timeout=20) as response:
            if response.status != 200:
                raise ValueError('Nao foi possivel acessar rotas-novas.json')
    except urllib.error.HTTPError as error:
        if error.code==401:
            raise ValueError('GitHub recusou o token (HTTP401). Confira se foi revogado, expirou ou esta incompleto.') from None
        if error.code==403:
            raise ValueError('GitHub negou acesso (HTTP403). Confira repositorio, aprovacao e permissao Contents.') from None
        raise ValueError('GitHub recusou a configuracao (HTTP %s); confira token e repositorio' % error.code) from None
    except (urllib.error.URLError,TimeoutError):
        raise ValueError('Nao foi possivel conectar ao GitHub; tente novamente com internet') from None
    target = root / 'DisneyClient' / '.env'
    example = target.with_name('.env.example')
    if not target.exists() and example.exists():
        shutil.copyfile(example,target)
    save_token(target,token)
    print('Configuracao salva. Volte ao jogo e clique SAVE novamente; nao precisa reiniciar o servidor atualizado.')
    print('A leitura do arquivo foi verificada; o SAVE verificara a permissao de escrita.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError,OSError) as error:
        print('ERRO:',str(error))
        raise SystemExit(1)
