package disney {
 import flash.net.Socket;
 public class DiagnosticSocketRegistry {
  public var bulle:Socket;
  public function DiagnosticSocketRegistry(value:Socket){bulle=value;}
  public function get main():Object{throw new Error("Fixture unavailable main channel");}
 }
}
