// ActionScript 3 / DiagnosticsTests.as / actual native Socket event observation, no network connects
package disney {
 import flash.display.MovieClip;
 import flash.events.Event;
 import flash.events.IOErrorEvent;
 import flash.events.SecurityErrorEvent;
 import flash.external.ExternalInterface;
 import flash.net.Socket;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,name:String):void{if(!ok)throw new Error(name);count++;}
  public static function run(display:MovieClip):void{
   var result:String;
   try{
    var root:MovieClip=new MovieClip();display.addChild(root);
    var diagnostics:FollowDiagnostics=new FollowDiagnostics(root);
    check(!diagnostics.closed,"starts open");
    diagnostics.watch(0);check(!diagnostics.closed,"missing Keys is harmless");
    root["Keys"]={socket_class:{},main_socket_instance:"main",bulle_socket_instance:"bulle"};
    diagnostics.watch(1000);check(!diagnostics.closed,"missing native instances are harmless");
    var main:Socket=new Socket();var bulle:Socket=new Socket();var registry:Object={main:main,bulle:bulle};
    root.Keys.socket_class=registry;diagnostics.watch(2000);
    main.dispatchEvent(new Event(Event.CLOSE));check(diagnostics.closed,"current main close observed");
    main.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"current main connect resets close");
    main.dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"fixture",2031));check(diagnostics.closed,"current main IO error observed");
    main.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"connect resets IO failure");
    bulle.dispatchEvent(new SecurityErrorEvent(SecurityErrorEvent.SECURITY_ERROR,false,false,"fixture",2048));check(diagnostics.closed,"current bulle security error observed");
    bulle.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"bulle connect resets security failure");
    main.dispatchEvent(new Event(Event.CLOSE));
    var replacement:Socket=new Socket();registry.main=replacement;diagnostics.watch(3000);
    check(!diagnostics.closed,"discovered replacement resets channel failure");
    main.dispatchEvent(new Event(Event.CLOSE));check(!diagnostics.closed,"retired socket close does not halt current channel");
    replacement.dispatchEvent(new Event(Event.CLOSE));check(diagnostics.closed,"replacement socket close observed");
    main.dispatchEvent(new Event(Event.CONNECT));check(diagnostics.closed,"retired CONNECT cannot clear current failure");
    replacement.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"replacement CONNECT clears its own failure");
    var immediate:Socket=new Socket();registry.main=immediate;
    replacement.dispatchEvent(new Event(Event.CLOSE));check(!diagnostics.closed,"retired CLOSE resolves replacement before next watch");
    immediate.dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"fixture",2031));check(diagnostics.closed,"replacement discovered from event has listeners");
    immediate.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"immediate replacement CONNECT resets failure");
    immediate.dispatchEvent(new Event(Event.CLOSE));
    bulle.dispatchEvent(new Event(Event.CLOSE));
    bulle.dispatchEvent(new Event(Event.CONNECT));check(diagnostics.closed,"other channel CONNECT preserves failed main channel");
    immediate.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"both channels recover independently");
    var unobserved:Socket=new Socket();unobserved.dispatchEvent(new Event(Event.CLOSE));check(!diagnostics.closed,"unrelated sockets have no effect");
    diagnostics.watch(4000);
    var throttled:Socket=new Socket();registry.main=throttled;diagnostics.watch(4001);
    throttled.dispatchEvent(new Event(Event.CLOSE));check(!diagnostics.closed,"watch does not rescan before one second");
    diagnostics.watch(4999);throttled.dispatchEvent(new Event(Event.CLOSE));check(!diagnostics.closed,"watch throttle remains active at 999ms");
    diagnostics.watch(5000);throttled.dispatchEvent(new Event(Event.CLOSE));check(diagnostics.closed,"watch rescan at 1000ms observes new socket");
    throttled.dispatchEvent(new Event(Event.CONNECT));
    var wrapped:Socket=new Socket();var wrapper:DiagnosticSocketWrapper=new DiagnosticSocketWrapper(wrapped);registry.main=wrapper;
    diagnostics.watch(6000);check(wrapper.blockedReads>0,"reflection encounters throwing public accessor");
    wrapped.dispatchEvent(new Event(Event.CLOSE));check(diagnostics.closed,"throwing accessor does not hide later socket accessor");
    wrapped.dispatchEvent(new Event(Event.CONNECT));check(!diagnostics.closed,"reflected socket CONNECT resets failure");
    var wrappedReplacement:Socket=new Socket();wrapper.stream=wrappedReplacement;
    wrapped.dispatchEvent(new Event(Event.CLOSE));check(!diagnostics.closed,"replacement inside same native wrapper retires old socket");
    wrappedReplacement.dispatchEvent(new Event(Event.CLOSE));check(diagnostics.closed,"new reflected socket close is observed");
    wrappedReplacement.dispatchEvent(new Event(Event.CONNECT));
    var secondary:FollowDiagnostics=new FollowDiagnostics(root);var registryBulle:Socket=new Socket();root.Keys.socket_class=new DiagnosticSocketRegistry(registryBulle);
    secondary.watch(0);registryBulle.dispatchEvent(new Event(Event.CLOSE));check(secondary.closed,"main accessor failure does not prevent bulle observation");
    registryBulle.dispatchEvent(new Event(Event.CONNECT));check(!secondary.closed,"bulle recovers with unavailable main accessor");
    var shared:Socket=new Socket();root.Keys.socket_class={main:shared,bulle:shared};secondary.watch(1000);
    shared.dispatchEvent(new Event(Event.CLOSE));check(secondary.closed,"shared socket close reaches observed channels");
    shared.dispatchEvent(new Event(Event.CONNECT));check(!secondary.closed,"shared socket CONNECT clears both channel flags");
    delete root["Keys"];secondary.watch(2000);check(!secondary.closed,"keys disappearing is harmless");
    secondary.emit("sample",0,"active",{nickname:"PRIVATE",x:100,vy:-1000});check(!secondary.closed,"unconfigured diagnostics emit performs no network request");
    var absent:FollowDiagnostics=new FollowDiagnostics(null);absent.watch(0);absent.emit("ready");check(!absent.closed,"null root remains harmless");
    result="PASS: "+count+" passive diagnostics checks";
   }catch(error:Error){result="FAIL: "+error.message+" #"+error.errorID+" after "+count+" checks";}
   ExternalInterface.call("recordTest",result);
  }
 }
}
