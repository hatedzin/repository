// ActionScript 3 / FollowDiagnostics.as / passive, bounded local Follow diagnostics
package disney {
 import flash.display.MovieClip;
 import flash.events.Event;
 import flash.events.IOErrorEvent;
 import flash.events.SecurityErrorEvent;
 import flash.net.Socket;
 import flash.net.URLLoader;
 import flash.net.URLRequest;
 import flash.net.URLRequestMethod;
 import flash.net.URLVariables;
 import flash.utils.Dictionary;
 import flash.utils.describeType;
 import flash.utils.getTimer;
 import flash.utils.setTimeout;
 import flash.utils.clearTimeout;

 public class FollowDiagnostics {
  public var closed:Boolean=false;
  private var root:MovieClip;
  private var sockets:Dictionary=new Dictionary(true);
  private var current:Object={main:null,bulle:null};
  private var failed:Object={main:false,bulle:false};
  private var pending:Array=[];
  private var ordinary:Array=[];
  private var faults:Array=[];
  private var lastByLabel:Object={};
  private var lastClock:int=0;
  private var lastWatch:Number=-100000;
  private var lastCoverage:Number=-100000;
  private var coverage:int=-1;

  public function FollowDiagnostics(value:MovieClip){root=value;}

  private function allowed(value:String,list:String):Boolean {
   return ("|"+list+"|").indexOf("|"+value+"|")>=0 && value.indexOf("|")<0;
  }

  private function trim(times:Array,now:int):void {
   while(times.length && now-Number(times[0])>=60000)times.shift();
  }

  private function activeOptions():String {
   var result:Array=[];
   for each(var name:String in ["teleport","auto_play","recording","change_jump_delay","change_jump_height","change_jump_speed","change_movement_speed","mass_reduction","insta_death","insta_win","no_delay","no_bulle","soft_mode","macro"]){
    try{if(root[name])result.push(name);}catch(ignored:Error){}
   }
   return result.join(",");
  }

  private function copyNumbers(source:Object,destination:URLVariables,names:Array,minimum:Number,maximum:Number):void {
   if(!source)return;
   for each(var name:String in names){
    try{
     if(!source.hasOwnProperty(name))continue;
     var value:* =source[name];
     if(!(value is Number) && !(value is int) && !(value is uint))continue;
     var number:Number=Number(value);
     if(isFinite(number) && number>=minimum && number<=maximum)destination[name]=Math.round(number);
    }catch(ignored:Error){}
   }
  }

  private function copyFlags(source:Object,destination:URLVariables):void {
   if(!source)return;
   for each(var name:String in ["alive","symbol_available"]){
    try{
     if(!source.hasOwnProperty(name))continue;
     var value:* =source[name];
     if(value===true || value===1 || value==="1")destination[name]="1";
     else if(value===false || value===0 || value==="0")destination[name]="0";
    }catch(ignored:Error){}
   }
  }

  public function emit(reason:String,code:int=0,phase:String="observe",data:Object=null,channel:String="client"):void {
   try{
    if(!root || !allowed(reason,"ready|start|stop|initial_sync|sample|paused|error|watch|socket_close|io_error|security_error"))return;
    if(!allowed(phase,"idle|search|focus|input|local|target|body|round|map|sync|position|velocity|active|observe"))return;
    if(!allowed(channel,"client|main|bulle"))return;
    // The existing authenticated endpoint is local to the client launcher.
    // Missing launcher configuration makes diagnostics inert, including fixtures.
    var base:String=String(root["host_url"] || "");
    if(!/^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::[0-9]{1,5})?\/$/i.test(base))return;
    if(!root["access_token"] || !root["tfmdisney"] || !root["tfmdisney"].data || !root["tfmdisney"].data.flash_token)return;
    var now:int=getTimer();
    if(now<lastClock){ordinary=[];faults=[];lastByLabel={};}
    lastClock=now;trim(ordinary,now);trim(faults,now);
    var priority:Boolean=reason=="error" || reason=="socket_close" || reason=="io_error" || reason=="security_error";
    // Separate rolling budgets reserve a third of the server's 90/min limit
    // for faults even when samples and state transitions are busy.
    var times:Array=priority ? faults : ordinary;
    if(times.length>=(priority ? 30 : 60))return;
    var label:String=reason+":"+phase+":"+channel;
    var delay:int=reason=="sample" ? 2000 : 250;
    if(!priority && lastByLabel.hasOwnProperty(label) && now-Number(lastByLabel[label])<delay)return;
    // Ordinary requests leave an in-flight slot for a close/error report.
    if(!priority && pending.length>=3)return;
    if(priority && pending.length>=4){
     for each(var old:Object in pending.concat()){
      if(!old.priority){finish(old,true);break;}
     }
    }
    if(pending.length>=4)return;
    var values:URLVariables=new URLVariables();
    values.event="follow";values.build="sdds-follow-observe-v11";
    values.reason=reason;values.phase=phase;values.channel=channel;
    values.code=Math.max(-65535,Math.min(65535,code));values.elapsed=now;
    values.options=activeOptions();
    copyNumbers(data,values,["frame_count","sync_count","up_count","down_count"],0,1000000000);
    copyNumbers(data,values,["x","y","target_x","target_y","vx","vy"],-10000000,10000000);
    copyNumbers(data,values,["jump_state"],0,1);copyFlags(data,values);
    var request:URLRequest=new URLRequest(base+"client_diagnostics?access_token="+encodeURIComponent(String(root["access_token"]))+"&flash_token="+encodeURIComponent(String(root["tfmdisney"].data.flash_token)));
    request.method=URLRequestMethod.POST;request.data=values;
    var loader:URLLoader=new URLLoader();
    var record:Object={loader:loader,priority:priority,timer:0,done:false};
    record.listener=function(event:Event):void{finish(record,false);};
    pending.push(record);times.push(now);if(!priority)lastByLabel[label]=now;
    try{
     loader.addEventListener(Event.COMPLETE,record.listener);
     loader.addEventListener(IOErrorEvent.IO_ERROR,record.listener);
     loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,record.listener);
     record.timer=setTimeout(function():void{finish(record,true);},5000);
     loader.load(request);
    }catch(ignoredLoad:Error){finish(record,true);}
   }catch(ignored:Error){}
  }

  private function finish(record:Object,cancel:Boolean):void {
   if(!record || record.done)return;
   record.done=true;clearTimeout(uint(record.timer));
   var loader:URLLoader=record.loader as URLLoader;
   if(loader){
    loader.removeEventListener(Event.COMPLETE,record.listener);
    loader.removeEventListener(IOErrorEvent.IO_ERROR,record.listener);
    loader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,record.listener);
    if(cancel){try{loader.close();}catch(ignored:Error){}}
   }
   var at:int=pending.indexOf(record);if(at>=0)pending.splice(at,1);
   record.loader=null;record.listener=null;
  }

  private function connection(channel:String):Object {
   try{
    var keys:Object=root["Keys"];
    if(!keys || !keys.socket_class)return null;
    var name:* =channel=="main" ? keys.main_socket_instance : keys.bulle_socket_instance;
    if(!name)return null;
    return keys.socket_class[name];
   }catch(ignored:Error){}
   return null;
  }

  private function candidates(instance:Object):Array {
   var result:Array=[];
   if(!instance)return result;
   if(instance is Socket){result.push(instance);return result;}
   var description:XML;
   try{description=describeType(instance);}catch(ignoredDescription:Error){return result;}
   var checked:int=0;
   for each(var variable:XML in description.variable){
    if(++checked>128)break;
    if(String(variable.@uri)!="")continue;
    try{addCandidate(result,instance[String(variable.@name)]);}catch(ignoredVariable:Error){}
   }
   for each(var accessor:XML in description.accessor){
    if(++checked>128)break;
    if(String(accessor.@uri)!="" || String(accessor.@access)=="writeonly")continue;
    try{addCandidate(result,instance[String(accessor.@name)]);}catch(ignoredAccessor:Error){}
   }
   // Dynamic wrappers have no declared slots in describeType.
   try{
    for(var name:String in instance){
     if(++checked>128)break;
     try{addCandidate(result,instance[name]);}catch(ignoredDynamic:Error){}
    }
   }catch(ignoredEnumeration:Error){}
   return result;
  }

  private function addCandidate(result:Array,value:*):void {
   if(value is Socket && result.indexOf(value)<0)result.push(value);
  }

  private function refresh(channel:String):Array {
   var found:Array=candidates(connection(channel));
   var selected:Socket=null;
   var selectedConnected:Boolean=false;
   for each(var candidate:Socket in found){
    observe(candidate,channel);
    var connected:Boolean=false;
    try{
     connected=candidate.connected;
    }catch(ignored:Error){}
    if(!selected || (connected && !selectedConnected) || (candidate===current[channel] && (connected || !selectedConnected))){
     selected=candidate;selectedConnected=connected;
    }
   }
   if(selected && selected!==current[channel]){
    current[channel]=selected;failed[channel]=false;refreshClosed();
   }
   return found;
  }

  private function observe(socket:Socket,channel:String):void {
   var labels:Object=sockets[socket];
   if(labels){labels[channel]=true;return;}
   labels={};labels[channel]=true;sockets[socket]=labels;
   socket.addEventListener(Event.CLOSE,socketClose,false,0,true);
   socket.addEventListener(Event.CONNECT,socketConnect,false,0,true);
   socket.addEventListener(IOErrorEvent.IO_ERROR,socketIOError,false,0,true);
   socket.addEventListener(SecurityErrorEvent.SECURITY_ERROR,socketSecurityError,false,0,true);
  }

  private function refreshClosed():void {closed=Boolean(failed.main || failed.bulle);}

  private function socketEvent(event:Event,reason:String,code:int):void {
   var socket:Socket=event.currentTarget as Socket;
   var labels:Object=socket ? sockets[socket] : null;
   if(!labels)return;
   for each(var channel:String in ["main","bulle"]){
    if(!labels[channel])continue;
    // Resolve replacements before deciding whether this event affects Follow.
    // A retired native socket can dispatch CLOSE after its replacement exists.
    refresh(channel);
    if(current[channel]===socket){failed[channel]=true;refreshClosed();}
    emit(reason,code,"observe",null,channel);
   }
  }

  private function socketClose(event:Event):void {socketEvent(event,"socket_close",0);}
  private function socketIOError(event:IOErrorEvent):void {socketEvent(event,"io_error",event.errorID);}
  private function socketSecurityError(event:SecurityErrorEvent):void {socketEvent(event,"security_error",event.errorID);}

  private function socketConnect(event:Event):void {
   var socket:Socket=event.currentTarget as Socket;
   var labels:Object=socket ? sockets[socket] : null;
   if(!labels)return;
   for each(var channel:String in ["main","bulle"]){
    if(!labels[channel])continue;
    refresh(channel);
    if(current[channel]===socket)failed[channel]=false;
   }
   refreshClosed();
  }

  public function watch(now:int):void {
   if(now>=lastWatch && now-lastWatch<1000)return;
   lastWatch=now;
   try{
    var found:Dictionary=new Dictionary(true);var count:int=0;
    for each(var channel:String in ["main","bulle"]){
     for each(var socket:Socket in refresh(channel)){
      if(!found[socket]){found[socket]=true;count++;}
     }
    }
    // Coverage is the number of native Socket objects found, not frame/sync work.
    if(count!=coverage || now<lastCoverage || now-lastCoverage>=15000){
     coverage=count;lastCoverage=now;emit("watch",count,"observe");
    }
   }catch(ignored:Error){}
  }
 }
}
