package disney {
 import flash.net.Socket;
 public class DiagnosticSocketWrapper {
  private var nativeSocket:Socket;
  public var blockedReads:int=0;
  public function DiagnosticSocketWrapper(value:Socket){nativeSocket=value;}
  public function get blocked():Object{blockedReads++;throw new Error("Fixture inaccessible property");}
  public function get stream():Socket{return nativeSocket;}
  public function set stream(value:Socket):void{nativeSocket=value;}
 }
}
