@echo off
powershell -NoProfile -File "%~dp0Instalar-Xampp.ps1" %*
if errorlevel 1 pause
