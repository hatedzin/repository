<?php
// Apenas para testes com php -S. No XAMPP, use o Apache e .htaccess.
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
if (preg_match('~(?:^|/)private(?:/|$)~i', $path) || str_contains($path, '..') || str_contains($path, '\\')) {
    http_response_code(403); exit;
}
$file = __DIR__ . $path;
if ($path === '/mice.php') { require __DIR__ . '/mice.php'; return true; }
if (in_array($path, ['/pgiex.swf'], true) || str_starts_with($path, '/Client/files/images/') || str_starts_with($path, '/Client/files/musiques/')) {
    if (is_file($file)) return false;
}
$_SERVER['SCRIPT_NAME'] = '/index.php';
require __DIR__ . '/index.php';
