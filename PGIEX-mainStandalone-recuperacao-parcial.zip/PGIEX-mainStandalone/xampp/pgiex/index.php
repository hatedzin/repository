<?php
declare(strict_types=1);
header('Cache-Control: no-store');
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
    http_response_code(403); exit('Servidor disponivel apenas localmente.');
}
$config = require __DIR__ . '/config.php';
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$route = $base && str_starts_with($path, $base . '/') ? substr($path, strlen($base)) : $path;
function reply(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}
function readJson(string $path): array {
    if (!is_file($path)) reply(['error' => 'Contrato PGIEX ausente: ' . basename($path), 'ready' => false], 503);
    try { $data = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR); }
    catch (Throwable $error) { reply(['error' => 'JSON invalido: ' . basename($path)], 422); }
    if (!is_array($data)) reply(['error' => 'Esperado objeto JSON'], 422);
    return $data;
}
function metadata(array $config): array {
    $data = readJson($config['metadata']);
    foreach (['GameLenght', 'GameDomain'] as $key) {
        if (!isset($data[$key]) || !is_string($data[$key]) || $data[$key] === '') reply(['error' => 'Campo invalido: ' . $key], 422);
    }
    return $data;
}
function profile(array $config): array {
    $data = readJson($config['profile']);
    if (!is_string($data['type'] ?? null) || $data['type'] === '' ||
        !is_array($data['keys'][0] ?? null) || !$data['keys'][0] ||
        !is_array($data['permissions'][0] ?? null) ||
        !is_string($data['classList'] ?? null)) reply(['error' => 'Contrato type/keys/permissions/classList invalido'], 422);
    foreach ($data['keys'][0] as $value) {
        if (!is_string($value)) reply(['error' => 'Os simbolos keys[0] devem ser strings'], 422);
    }
    return $data;
}
function gameReady(string $path): bool {
    if (!is_file($path)) return false;
    $file = fopen($path, 'rb');
    if (!$file) return false;
    $signature = fread($file, 3); fclose($file);
    return in_array($signature, ['FWS', 'CWS', 'ZWS'], true);
}
if ($route === '/get_pgiex_keys') reply(metadata($config));
if ($route === '/checkAS.php') {
    $data = profile($config);
    $data['keys'][0] = (object) $data['keys'][0];
    $data['permissions'][0] = (object) $data['permissions'][0];
    header('Content-Type: text/plain; charset=us-ascii');
    echo base64_encode(json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); exit;
}
if ($route === '/transformice') {
    if (!gameReady($config['game'])) reply(['error' => 'SWF do jogo ausente ou invalida'], 503);
    header('Content-Type: application/x-shockwave-flash');
    header('Content-Length: ' . filesize($config['game']));
    readfile($config['game']); exit;
}
if ($route === '/Client/files/php/get.php' && ($_GET['type'] ?? '') === 'mps') {
    header('Content-Type: text/plain; charset=us-ascii');
    echo base64_encode(gzcompress(is_file($config['maps']) ? file_get_contents($config['maps']) : '')); exit;
}
if ($route === '/health') {
    $state = ['loader' => is_file(__DIR__ . '/pgiex.swf'), 'metadata' => is_file($config['metadata']),
        'profile' => is_file($config['profile']), 'game' => gameReady($config['game'])];
    reply(['components' => $state, 'files_present' => !in_array(false, $state, true),
        'game_functions_validated' => false]);
}
if ($route === '/info.txt') { header('Content-Type: text/plain'); exit('PGIEX standalone local'); }
if ($route === '/' || $route === '/index.php' || $route === '') {
    header('Content-Type: text/html; charset=utf-8');
    $escape = static fn(string $text): string => htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>PGIEX local</title><style>body{font:17px system-ui;background:#20242b;color:#eee;max-width:850px;margin:60px auto;padding:20px}a{color:#f0c040}li{margin:12px 0}</style><h1>PGIEX mainStandalone</h1>';
    echo '<p>Loader V6 reconstruído e compilado. A integração com o jogo ainda depende do contrato de símbolos do backend antigo.</p><ul>';
    foreach (['metadata', 'profile', 'game'] as $item) echo '<li>' . $escape($item) . ': ' . (is_file($config[$item]) ? 'arquivo presente (compatibilidade não validada)' : 'arquivo ausente') . '</li>';
    echo '</ul><p><a href="pgiex.swf">Baixar loader SWF</a> · <a href="health">Diagnóstico JSON</a></p><p>Abra a URL da SWF em um runtime Flash standalone compatível. Navegadores atuais não executam Flash.</p><p>O MySQL não é necessário para estes endpoints; nenhum esquema original de banco veio no PGIEX.</p></html>'; exit;
}
reply(['error' => 'Rota nao implementada', 'route' => $route], 404);
