<?php
declare(strict_types=1);
header('Cache-Control: no-store');
header('Content-Type: text/plain; charset=utf-8');
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) { http_response_code(403); exit; }
$hbid = $_GET['hbid'] ?? '';
$nickname = $_GET['nickname'] ?? '';
$outfit = $_GET['outfit'] ?? null;
$slot = $_GET['so'] ?? null;
foreach ([$hbid, $nickname] as $value) {
    if (!is_string($value) || strlen($value) > 100 || preg_match('/[|:\r\n]/', $value)) { http_response_code(400); exit('Identificador invalido'); }
}
if ($outfit !== null && (!is_string($outfit) || strlen($outfit) > 2048 || !preg_match('/^[0-9a-zA-Z_;,*+.-]+$/', $outfit))) {
    http_response_code(400); exit('Visual invalido');
}
if ($slot !== null && !in_array($slot, ['1', '2', '3'], true)) { http_response_code(400); exit('Perfil invalido'); }
if (($slot !== null || $outfit !== null) && ($hbid === '' || $nickname === '')) { http_response_code(400); exit('hbid/nickname obrigatorios'); }
$file = fopen(__DIR__ . '/private/dress.json', 'c+');
if (!$file || !flock($file, LOCK_EX)) { http_response_code(500); exit('Falha ao abrir armazenamento'); }
try {
    $raw = stream_get_contents($file);
    $data = $raw === '' ? [] : json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($data)) throw new RuntimeException('Armazenamento invalido');
    $owner = hash('sha256', $hbid . "\0" . $nickname);
    if ($outfit !== null) {
        $outfit = str_replace('*', '+', $outfit);
        if ($slot !== null) $data['profiles'][$owner][$slot] = $outfit;
        else $data['looks'][$nickname] = $outfit;
        $encoded = json_encode($data, JSON_THROW_ON_ERROR);
        rewind($file); ftruncate($file, 0);
        if (fwrite($file, $encoded) !== strlen($encoded) || !fflush($file)) throw new RuntimeException('Falha ao salvar');
    }
    if ($slot !== null) echo $data['profiles'][$owner][$slot] ?? '';
    elseif (($_GET['get'] ?? '') === 'all') {
        foreach (($data['looks'] ?? []) as $name => $look) echo $name . ':' . $look . '|';
    }
} catch (Throwable $error) {
    http_response_code(500); echo 'Falha no armazenamento de visuais';
} finally { flock($file, LOCK_UN); fclose($file); }
