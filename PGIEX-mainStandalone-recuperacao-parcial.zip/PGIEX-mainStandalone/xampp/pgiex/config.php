<?php
// Caminhos locais; o contrato PGIEX antigo nao vem nos arquivos recebidos.
return [
    'game' => __DIR__ . '/private/game.swf',
    'metadata' => __DIR__ . '/private/metadata.json',
    'profile' => __DIR__ . '/private/profile.json',
    'maps' => __DIR__ . '/private/maps.txt',
];
