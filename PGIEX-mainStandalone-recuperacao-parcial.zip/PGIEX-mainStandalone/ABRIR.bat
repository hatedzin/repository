@echo off
powershell -NoProfile -File "%~dp0Abrir.ps1" %*
if errorlevel 1 pause
