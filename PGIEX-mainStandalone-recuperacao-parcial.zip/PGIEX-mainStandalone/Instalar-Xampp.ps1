param([string]$XamppRoot = 'C:\xampp')
$ErrorActionPreference = 'Stop'
$htdocs = Join-Path $XamppRoot 'htdocs'
if (!(Test-Path $htdocs -PathType Container)) { throw "Pasta htdocs nao encontrada: $htdocs" }
$target = Join-Path $htdocs 'pgiex'
if (Test-Path $target) { throw "Ja existe $target. Preserve seus dados e escolha uma instalacao limpa antes de copiar este pacote." }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'xampp\pgiex') -Destination $target -Recurse
Write-Host "Copiado para $target. Ligue o Apache no XAMPP."
Start-Process 'http://localhost/pgiex/'
