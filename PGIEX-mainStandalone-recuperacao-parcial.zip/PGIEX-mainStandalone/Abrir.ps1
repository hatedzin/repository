param([string]$Backend = 'http://localhost/pgiex', [string]$Runtime = '')
$ErrorActionPreference = 'Stop'
$Backend = $Backend.TrimEnd('/')
if (!$Runtime) { $Runtime = Join-Path $PSScriptRoot 'runtime\flashplayer.exe' }
if (!(Test-Path $Runtime -PathType Leaf)) {
    Start-Process ($Backend + '/')
    throw 'Runtime Flash standalone nao encontrado. Use -Runtime com um executavel compativel. Consulte LEIA-ME.md.'
}
$url = $Backend + '/pgiex.swf?backend=' + [Uri]::EscapeDataString($Backend) + '&Language=EN&hbid=local'
Start-Process -FilePath $Runtime -ArgumentList @($url)
