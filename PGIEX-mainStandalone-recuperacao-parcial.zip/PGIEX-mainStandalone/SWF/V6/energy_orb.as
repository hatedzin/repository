package
{
   import flash.display.MovieClip;
   import flash.text.TextField;
   import flash.text.TextFormat;
   
   public dynamic class energy_orb extends MovieClip
   {
       
      
      public function energy_orb()
      {
         super();
         graphics.beginFill(0x3D5263); graphics.drawRoundRect(0,0,42,24,5,5); graphics.endFill();
         var label:TextField = new TextField();
         label.defaultTextFormat = new TextFormat("_sans",9,0xFFFFFF);
         label.text = "energy orb"; label.width = 42; label.height = 24;
         label.mouseEnabled = false; addChild(label); buttonMode = true; mouseChildren = false;
      }
   }
}
