package
{
   import flash.display.MovieClip;
   import flash.text.TextField;
   import flash.text.TextFormat;
   
   public dynamic class paper_airplane extends MovieClip
   {
       
      
      public function paper_airplane()
      {
         super();
         graphics.beginFill(0x3D5263); graphics.drawRoundRect(0,0,42,24,5,5); graphics.endFill();
         var label:TextField = new TextField();
         label.defaultTextFormat = new TextFormat("_sans",9,0xFFFFFF);
         label.text = "paper airplane"; label.width = 42; label.height = 24;
         label.mouseEnabled = false; addChild(label); buttonMode = true; mouseChildren = false;
      }
   }
}
