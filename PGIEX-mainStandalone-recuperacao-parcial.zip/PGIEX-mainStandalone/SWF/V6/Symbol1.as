package
{
   import flash.display.MovieClip;
   import flash.text.TextField;
   import flash.text.TextFormat;
   
   public dynamic class Symbol1 extends MovieClip
   {
       
      
      public function Symbol1()
      {
         super();
         graphics.beginFill(0x3D5263); graphics.drawRoundRect(0,0,42,24,5,5); graphics.endFill();
         var label:TextField = new TextField();
         label.defaultTextFormat = new TextFormat("_sans",9,0xFFFFFF);
         label.text = "Symbol1"; label.width = 42; label.height = 24;
         label.mouseEnabled = false; addChild(label); buttonMode = true; mouseChildren = false;
      }
   }
}
