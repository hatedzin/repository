package ChargeurTransformice_fla {
 import flash.display.*;
 import flash.events.*;
 import flash.text.*;
 [SWF(width="800", height="600", frameRate="30", backgroundColor="#20242B")]
 public class Standalone extends TransformiceChargeur {
   public function Standalone() {
     super();
     if(stage) start(); else addEventListener(Event.ADDED_TO_STAGE,start);
   }
   private function start(event:Event = null):void {
     removeEventListener(Event.ADDED_TO_STAGE,start);
     _C = new MovieClip(); _C._B = new MovieClip(); _C._K = new MovieClip();
     _C._B.graphics.beginFill(0xF0C040); _C._B.graphics.drawRect(0,0,200,8);
     _C.addChild(_C._B); _C.addChild(_C._K); addChild(_C);
     var status:TextField = new TextField();
     status.defaultTextFormat = new TextFormat("_sans",15,0xFFFFFF);
     status.width = 760; status.height = 160; status.x = 20; status.y = 35;
     status.multiline = true; status.wordWrap = true;
     status.text = "PGIEX V6 - iniciando backend local..."; _C.addChild(status);
     LocalBackend.onError = function(message:String):void {
       status.text = "PGIEX: " + message;
       if(!_C.parent) addChild(_C);
     };
     try { LocalBackend.configure(loaderInfo.parameters); frame1(); }
     catch(error:Error) { LocalBackend.onError(error.message); }
   }
 }
}
