package ChargeurTransformice_fla {
 import flash.display.Loader;
 import flash.events.*;
 import flash.net.*;
 import flash.utils.*;
 public final class LocalBackend {
   public static var baseURL:String = "http://localhost/pgiex";
   public static var onError:Function;
   public static function configure(parameters:Object):void {
     if(parameters && parameters.backend) {
       var value:String = String(parameters.backend).replace(/\/+$/, "");
       if(!/^https?:\/\/[a-z0-9.\-\[\]:]+(?:\/[a-z0-9_\-\/]+)?$/i.test(value))
         throw new ArgumentError("Endereco backend invalido");
       baseURL = value;
     }
   }
   public static function resolve(value:String):String {
     if(value == null) return "";
     return value.replace(/^https?:\/\/(?:transformice\.)?bolcorp\.icu(?=\/|$)/i,baseURL);
   }
   public static function request(value:String):URLRequest {
     return new URLRequest(resolve(value));
   }
   public static function text(request:URLRequest):URLLoader {
     var result:URLLoader = new URLLoader();
     var timeout:uint;
     var cleanup:Function = function(event:Event = null):void {
       clearTimeout(timeout);
       result.removeEventListener(Event.COMPLETE,cleanup);
       result.removeEventListener(IOErrorEvent.IO_ERROR,failed);
       result.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
     };
     var failed:Function = function(event:Event):void {
       cleanup();
       if(onError != null) onError("Falha no backend local: " + request.url.split("?")[0] +
         ". Consulte http://localhost/pgiex/ para o diagnostico.");
     };
     result.addEventListener(Event.COMPLETE,cleanup);
     result.addEventListener(IOErrorEvent.IO_ERROR,failed);
     result.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
     timeout = setTimeout(function():void {
       cleanup();
       try { result.close(); } catch(error:Error) {}
       if(onError != null) onError("O backend nao respondeu em 15 segundos.");
     },15000);
     try { result.load(request); } catch(error:Error) { failed(new Event("error")); }
     return result;
   }
   public static function loader():Loader {
     var result:Loader = new Loader();
     var failed:Function = function(event:Event):void {
       if(onError != null) onError("Falha ao carregar a SWF do jogo. Verifique a configuracao local.");
     };
     result.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,failed);
     result.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
     return result;
   }
 }
}
