package ChargeurTransformice_fla {
 public final class Randomize {
  public static function randomNumberGenerator(minimum:int,maximum:int):int {
   return minimum + int(Math.random() * (maximum - minimum + 1));
  }
  public static function GetRandomCha(length:int):String {
   var chars:String = "abcdefghijklmnopqrstuvwxyz";
   var value:String = "";
   for(var i:int=0; i<length; i++) value += chars.charAt(randomNumberGenerator(0,chars.length-1));
   return value;
  }
  public static function GetRandomCha2(length:int):String { return GetRandomCha(length); }
  public static function GetRandomRoomName():String { return "pgiex-"+GetRandomCha(8); }
  public static function GetRandomSPCha():String { return ""; }
 }
}
