package
{
   import flash.display.MovieClip;
   import flash.text.TextField;
   import flash.text.TextFormat;
   
   public dynamic class OpenHackMenu extends MovieClip
   {
       
      
      public function OpenHackMenu()
      {
         super();
         graphics.beginFill(0x3D5263); graphics.drawRoundRect(0,0,90,24,5,5); graphics.endFill();
         var label:TextField = new TextField();
         label.defaultTextFormat = new TextFormat("_sans",9,0xFFFFFF);
         label.text = "Menu [M]"; label.width = 90; label.height = 24;
         label.mouseEnabled = false; addChild(label); buttonMode = true; mouseChildren = false;
      }
   }
}
