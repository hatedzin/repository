"""Execute com o servidor de teste ativo e sem dados pessoais em private/."""
import base64, json, pathlib, urllib.error, urllib.parse, urllib.request, zlib
ROOT = pathlib.Path(__file__).resolve().parents[1] / 'xampp' / 'pgiex'
BASE = 'http://127.0.0.1:8765'
def call(route, expected=200):
    try:
        r = urllib.request.urlopen(BASE + route, timeout=5)
    except urllib.error.HTTPError as error:
        r = error
    assert r.code == expected, (route, r.code, r.read())
    return r.read()
checks = []
def ok(label): checks.append(label)
assert json.loads(call('/health'))['files_present'] is False; ok('health reports missing dependencies')
call('/get_pgiex_keys', 503); call('/checkAS.php', 503); call('/transformice', 503); ok('missing game/contract returns 503')
assert call('/pgiex.swf')[:3] in (b'CWS', b'FWS'); ok('compiled loader served')
assert zlib.decompress(base64.b64decode(call('/Client/files/php/get.php?type=mps'))) == b''; ok('empty map store roundtrip')
call('/private/metadata.json', 403); call('/unknown', 404); ok('private directory blocked; unknown route 404')
private = ROOT / 'private'
fixtures = [private / 'metadata.json', private / 'profile.json', private / 'game.swf', private / 'dress.json']
assert not any(p.exists() for p in fixtures), 'Use an empty disposable test install'
try:
    fixtures[0].write_text('{"GameLenght":"123","GameDomain":"456"}')
    assert json.loads(call('/get_pgiex_keys'))['GameDomain'] == '456'; ok('metadata contract delivered')
    fixtures[1].write_text('not json'); call('/checkAS.php',422); ok('invalid profile rejected')
    profile = {'type':'fixture','permissions':[{}],'keys':[{'fixture':'123'}],'classList':''}
    fixtures[1].write_text(json.dumps(profile))
    assert json.loads(base64.b64decode(call('/checkAS.php'))) == profile; ok('profile base64 roundtrip with compact JSON')
    fixtures[2].write_bytes(b'not a swf'); call('/transformice',503); ok('bad game signature rejected')
    def dress(**values): return '/mice.php?' + urllib.parse.urlencode(values)
    q = dict(hbid='test-local',nickname='Example230000',so='2')
    assert call(dress(**q,outfit='209;0,0,0')) == b'209;0,0,0'
    assert call(dress(**q)) == b'209;0,0,0'
    assert call(dress(**(q | {'hbid':'other'}))) == b''; ok('dress save/read and owner separation')
    call(dress(**(q | {'so':'9'})),400); ok('invalid dress slot rejected')
    call(dress(hbid='test-local',nickname='Example230000',outfit='209;1*2',get='all'))
    assert b'Example230000:209;1+2|' in call('/mice.php?get=all'); ok('live outfit encoding preserved')
finally:
    for path in fixtures: path.unlink(missing_ok=True)
print(json.dumps({'passed':len(checks),'checks':checks},indent=2))
