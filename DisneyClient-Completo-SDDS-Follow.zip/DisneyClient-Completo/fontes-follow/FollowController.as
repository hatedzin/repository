// ActionScript 3 / FollowController.as / Flash Player 10.3+ / room-local nickname following with native movement keys
package disney {
 import flash.display.MovieClip;import flash.events.Event;import flash.events.KeyboardEvent;import flash.text.TextField;import flash.text.TextFieldType;import flash.text.TextFormat;import flash.utils.Dictionary;import flash.utils.getTimer;
 public class FollowController {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var targetName:String="";private var owner:Object;private var left:Boolean=false;private var right:Boolean=false;private var jumping:Boolean=false;private var nextJump:int=0;private var releaseJump:int=0;private var hud:TextField;private var state:String="";
  public function FollowController(value:MovieClip){root=value;}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var follow:FollowController=new FollowController(value);instances[value]=follow;
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,follow.keyDown,true,2000);value.stage.addEventListener(KeyboardEvent.KEY_DOWN,follow.keyDown,false,2000);
   value.stage.addEventListener(Event.ENTER_FRAME,function(event:Event):void{follow.update();});
   value.stage.addEventListener(Event.DEACTIVATE,function(event:Event):void{follow.stop("Follow: pausado ao perder foco");});
  }
  public function keyDown(event:KeyboardEvent):void{
   var input:TextField=root.stage.focus as TextField;
   if(event.keyCode==13 && input && input.type==TextFieldType.INPUT && /^\s*\/follow(?:\s|$)/i.test(input.text)){
    command(input.text);input.text="";root.stage.focus=root.stage;event.preventDefault();event.stopImmediatePropagation();return;
   }
   if(event.keyCode==27 && targetName!="")stop("Follow: parado");
  }
  public function command(text:String):Boolean{
   if(!/^\s*\/follow(?:\s|$)/i.test(text))return false;
   var argument:String=text.replace(/^\s*\/follow\s*/i,"").replace(/\s+$/g,"");
   if(argument=="" || /^(?:off|stop|parar)$/i.test(argument)){stop("Follow: parado");return true;}
   if(!/^[^\s#]+#\d{4}$/.test(argument)){notice("Uso: /follow Nome#0000 | /follow off");return true;}
   var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
   if(local && String(local[k.player_name]).toLowerCase()==argument.toLowerCase()){stop("Follow: escolha outro jogador");return true;}
   release();targetName=argument.toLowerCase();owner=null;root["auto_play"]=false;nextJump=0;notice("Follow: procurando "+argument+" nesta sala");return true;
  }
  public function stop(message:String="Follow: parado"):void{release();targetName="";owner=null;notice(message);}
  private function notice(message:String):void{
   state=message;if(!root.stage)return;if(!hud){hud=new TextField();hud.name="sddsFollowStatus";hud.defaultTextFormat=new TextFormat("_sans",12,0xD7F5FF);hud.width=540;hud.height=22;hud.background=true;hud.backgroundColor=0x141B2A;hud.selectable=false;hud.mouseEnabled=false;root.stage.addChild(hud);}hud.x=8;hud.y=Math.max(60,root.stage.stageHeight-48);hud.text=message;
  }
  private function key(code:uint,down:Boolean):void{if(root.stage)root.stage.dispatchEvent(new KeyboardEvent(down ? KeyboardEvent.KEY_DOWN : KeyboardEvent.KEY_UP,true,false,0,code));}
  private function movement(l:Boolean,r:Boolean,j:Boolean):void{
   if(left!=l){key(37,l);left=l;}if(right!=r){key(39,r);right=r;}if(jumping!=j){key(38,j);jumping=j;}
  }
  private function release():void{movement(false,false,false);}
  public function update(now:int=-1):void{
   if(targetName=="")return;if(now<0)now=getTimer();
   try{
    var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
    if(local!==owner){release();owner=local;}
    if(!local || (k.is_dead && local[k.is_dead])){release();notice("Follow: aguardando renascer");return;}
    if(root.stage.focus is TextField && TextField(root.stage.focus).type==TextFieldType.INPUT){release();notice("Follow: pausado enquanto digita");return;}
    var found:Object=null;var list:Object=game[k.player_list];if(list)for each(var player:Object in list){if(player && String(player[k.player_name]).toLowerCase()==targetName){found=player;break;}}
    if(!found || found===local || (k.is_dead && found[k.is_dead]) || (found.hasOwnProperty("parent") && !found.parent)){release();notice("Follow: aguardando "+targetName+" nesta sala");return;}
    var dx:Number=Number(found.x)-Number(local.x);var dy:Number=Number(found.y)-Number(local.y);
    if(!isFinite(dx) || !isFinite(dy))throw new Error("Coordenadas indisponiveis");
    var jump:Boolean=jumping && now<releaseJump;
    if(dy < -22 && now>=nextJump){jump=true;releaseJump=now+110;nextJump=now+650;}
    movement(dx < -18,dx > 18,jump);notice("Follow: "+targetName+" | "+(Math.abs(dx)<=18 ? "perto" : "seguindo"));
   }catch(error:Error){stop("Follow: interrompido #"+error.errorID);}
  }
 }
}
