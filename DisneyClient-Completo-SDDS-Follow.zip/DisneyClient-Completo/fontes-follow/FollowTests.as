// ActionScript 3 / FollowTests.as / Ruffle AVM2 / command parsing, identity tracking and native key transitions
package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.text.TextField;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var checks:int=0;
  private static function check(value:Boolean,name:String):void{if(!value)throw new Error(name);checks++;}
  public static function run(display:MovieClip):void{
   var result:String;
   try{
    var root:MovieClip=new MovieClip();display.addChild(root);var pressed:Object={};var downs:int=0;
    root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{pressed[e.keyCode]=true;downs++;});
    root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{pressed[e.keyCode]=false;});
    var local:Object={nick:"Self#0001",x:100,y:100,dead:false};var target:Object={nick:"Example#0000",x:200,y:100,dead:false};var wrong:Object={nick:"Example#0002",x:0,y:100,dead:false};
    root["Keys"]={player:"self",player_list:"players",player_name:"nick",is_dead:"dead"};root["tfm"]={self:local,players:[wrong,target]};root["auto_play"]=true;
    var follow:FollowController=new FollowController(root);root.stage.focus=root.stage;
    check(!follow.command("/room abc"),"other commands unaffected");
    follow.command("/follow example#0000");follow.update(0);check(pressed[39] && !pressed[37],"full discriminator and case insensitive match");check(!root.auto_play,"route autoplay stopped");
    var previous:int=downs;follow.update(20);check(downs==previous,"held direction not repeatedly pressed");target.x=20;follow.update(30);check(pressed[37] && !pressed[39],"moving target changes direction");
    target.x=110;follow.update(40);check(!pressed[37] && !pressed[39],"distance deadzone stops horizontal movement");target.y=30;follow.update(100);check(pressed[38],"higher target triggers jump");follow.update(230);check(!pressed[38],"jump key released");previous=downs;follow.update(300);check(downs==previous,"jump cooldown");
    target.x=300;target.y=100;follow.update(800);root.tfm.players=[];follow.update(900);check(!pressed[39],"missing target releases keys");root.tfm.players=[target];follow.update(1000);check(pressed[39],"target return reacquired");
    local.dead=true;follow.update(1100);check(!pressed[39],"death releases keys");local.dead=false;follow.update(1200);check(pressed[39],"respawn resumes");
    var input:TextField=new TextField();input.type="input";root.addChild(input);root.stage.focus=input;follow.update(1300);check(!pressed[39],"chat entry pauses movement");input.text="/follow off";var enter:KeyboardEvent=new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,true,0,13);follow.keyDown(enter);follow.update(1400);check(input.text=="" && !pressed[39] && enter.isDefaultPrevented(),"stop command intercepted and cleared");
    input.text="/follow Example#0000";root.stage.focus=input;follow.keyDown(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,true,0,13));follow.update(1500);check(pressed[39] && root.stage.focus===root.stage,"chat start returns focus to game");
    follow.keyDown(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,27));follow.update(1600);check(!pressed[39],"escape stops follow");
    follow.command("/follow Self#0001");follow.update(1700);check(!pressed[39],"self target rejected");follow.command("/follow Example");follow.update(1800);check(!pressed[39],"nickname without discriminator rejected");
    follow.command("/follow Example#0000");follow.update(1900);target.dead=true;follow.update(2000);check(!pressed[39],"target death pauses");
    result="PASS: "+checks+" follow checks";
   }catch(error:Error){result="FAIL: "+error.message+" #"+error.errorID;}
   ExternalInterface.call("recordTest",result);
  }
 }
}
