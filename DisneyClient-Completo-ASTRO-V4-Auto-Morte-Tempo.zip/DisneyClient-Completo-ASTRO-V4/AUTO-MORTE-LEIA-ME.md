# ASTRO V4 — Auto morte com tempo proprio

Base: projeto completo DisneyClient-Completo-ASTRO-V4-Morte-Na-Toca-Corrigida.zip enviado pelo usuario.
Extraia o ZIP em uma pasta nova e execute INICIAR_TUDO.bat.

Em Farm, abaixo de Auto Win (queijo > toca), existe Auto morte e um campo de segundos.
O padrao e 5 segundos; aceita de 0.1 a 600 segundos (use ponto para decimais).
Marque o circulo para ativar. O tempo conta a partir do nascimento ou da ativacao.
Mudar o valor reinicia a contagem. Cada vida recebe apenas uma solicitacao de morte.
Ao renascer ou receber um novo mapa, o tempo reinicia. Desativar cancela a contagem.
Durante Robot ou gravacao, a contagem fica pausada e recomeca ao terminar.

Este controle tem tempo proprio; Farm Time continua pertencendo ao Auto Win.
Auto Win (queijo > toca) e este Auto morte se desativam mutuamente para evitar conflito.
O comando enviado e o mort nativo pelo socket do projeto; nao chama a rotina antiga vazia.
A opcao antiga Auto mort [CTRL F11] permanece no menu.

Testes: 23 verificacoes AS3 de menu/tempo, 50 de regressao de Rato leve e Auto Win,
1971 metodos com limites de pilha/escopo verificados. Transporte de rede simulado nos testes.
Nao foi possivel testar uma sala online no Flash Player do Windows.
Site, contas, keys, parser, skins e demais metodos do loader foram preservados.
