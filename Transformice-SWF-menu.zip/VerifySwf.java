// Java / VerifySwf.java / Java 21 + FFDec / Verify limited bytecode changes and menu stack bounds.
import com.jpexs.decompiler.flash.*;
import com.jpexs.decompiler.flash.tags.*;
import com.jpexs.decompiler.flash.abc.*;
import com.jpexs.decompiler.flash.abc.types.*;
import java.io.*;
import java.util.*;
class VerifySwf {
 static ABC abc(SWF s){for(Tag t:s.getTags())if(t instanceof DoABC2Tag)return ((DoABC2Tag)t).getABC();throw new RuntimeException("No ABC");}
 public static void main(String[] args)throws Exception{
  ABC before=abc(new SWF(new FileInputStream(args[0]),false)),after=abc(new SWF(new FileInputStream(args[1]),false));
  if(after.instance_info.size()!=before.instance_info.size()+1)throw new RuntimeException("Class count mismatch");
  Set<Integer> changed=new TreeSet<>();
  for(MethodBody b:before.bodies){MethodBody a=after.findBody(b.method_info);if(a==null)throw new RuntimeException("Original method missing");if(!Arrays.equals(b.getCodeBytes(),a.getCodeBytes()))changed.add(b.method_info);}
  Set<Integer> expected=new TreeSet<>();expected.add(before.instance_info.get(307).iinit_index);expected.add(before.instance_info.get(732).iinit_index);
  if(!changed.equals(expected))throw new RuntimeException("Unexpected original methods changed: "+changed);
  int checked=0;
  for(MethodBody b:after.bodies)if(b.method_info>=before.method_info.size()||changed.contains(b.method_info)){
   var stats=b.getCode().getStats(after,b,b.init_scope_depth,false);
   if(stats==null||stats.maxstack>b.max_stack||stats.maxscope>b.max_scope_depth)throw new RuntimeException("Declared stack/scope bound invalid at "+b.method_info);
   checked++;
  }
  System.out.println("PASS: original methods changed="+changed+"; checked new/hooked methods="+checked+"; menu class="+after.findClassByName("zyon.ZyonMenu"));
 }
}
