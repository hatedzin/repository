// Java / PatchSwf.java / Java 21 + FFDec 26.4 / Add internal menu and login hooks to supplied SWF.
import com.jpexs.decompiler.flash.SWF;
import com.jpexs.decompiler.flash.tags.*;
import com.jpexs.decompiler.flash.abc.*;
import com.jpexs.decompiler.flash.abc.types.*;
import com.jpexs.decompiler.flash.abc.avm2.*;
import com.jpexs.decompiler.flash.abc.avm2.instructions.*;
import com.jpexs.decompiler.flash.abc.avm2.parser.script.*;
import java.io.*;
import java.nio.file.*;
class PatchSwf {
 public static void main(String[] args)throws Exception {
  SWF swf=new SWF(new FileInputStream(args[0]),false);
  DoABC2Tag tag=null;for(Tag t:swf.getTags())if(t instanceof DoABC2Tag)tag=(DoABC2Tag)t;
  if(tag==null)throw new IllegalStateException("No ABC tag");
  ABC abc=tag.getABC();int oldClasses=abc.instance_info.size();int oldScripts=abc.script_info.size();
  var index=swf.getAbcIndex();index.selectAbc(abc);
  ActionScript3Parser parser=new ActionScript3Parser(index);
  parser.addScript(Files.readString(Path.of(args[1])),"ZyonMenu.as",oldClasses,oldScripts,swf.getDocumentClass(),abc);
  int menuClass=abc.findClassByName("zyon.ZyonMenu");if(menuClass<0)throw new IllegalStateException("Menu class missing");
  int menuName=abc.instance_info.get(menuClass).name_index;
  int attachName=abc.constants.getQnameId("attach",0x16,"",true);
  String[] names={"\u0008\u0002\u0003\u0003\u0002\u0008\u0006\u0002\u0006\u0004\u0007\u0007\u0005","\u0002\u0006\u0004\u0005\u0005\u0006\u0005\u0004\u0002\u0008\u0004\u0002\u0001"};
  for(String name:names){
   int ci=abc.findClassByName(name);if(ci<0)throw new IllegalStateException("Login class missing");
   MethodBody body=abc.findBody(abc.instance_info.get(ci).iinit_index);AVM2Code code=body.getCode();int hooks=0;
   for(int i=code.code.size()-1;i>=0;i--)if(code.code.get(i).definition.instructionCode==0x47){
    code.insertInstruction(i,new AVM2Instruction(0,0x60,new int[]{menuName}),body);
    code.insertInstruction(i+1,new AVM2Instruction(0,0xD0,new int[]{}),body);
    code.insertInstruction(i+2,new AVM2Instruction(0,0x4F,new int[]{attachName,1}),body);hooks++;
   }
   if(hooks==0)throw new IllegalStateException("No constructor return to hook");
   body.max_stack=Math.max(body.max_stack,2);body.setModified();System.out.println("Hooked class="+ci+" returns="+hooks);
  }
  tag.setModified(true);swf.setModified(true);try(OutputStream out=new FileOutputStream(args[2])){swf.saveTo(out);}
  System.out.println("Original classes="+oldClasses+" final="+abc.instance_info.size()+" scripts="+abc.script_info.size());
 }
}
