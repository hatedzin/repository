# Transformice - menu dentro da SWF

## Arquivo principal

158-descriptografada-menu.swf e a SWF interna recuperada de 158.swf, modificada e salva em formato FWS sem compressao. O menu e sua logica estao no bytecode da propria SWF; nao dependem do painel externo Windows criado anteriormente.

O 158.swf recebido era um carregador com 12 segmentos de uma SWF CWS. A ordem recuperada dos IDs de DefineBinaryData foi: 11, 7, 9, 12, 10, 1, 5, 2, 3, 6, 4, 8. A descompressao zlib, seu checksum e o tamanho declarado foram validados.

158-0.zip era o assembly do carregador. ChargeurTransformice.zip contem um cliente antigo, usado como referencia de organizacao do menu e acesso ao personagem; suas dependencias remotas e nomes antigos nao foram copiados.

## Menu e controles

O menu e instalado pelos construtores das duas classes de login identificadas, aguardando ADDED_TO_STAGE quando necessario. Nao utiliza um temporizador para adivinhar o login. O mesmo menu permanece no jogo depois da autenticacao.

- Insert mostra/esconde. O botao - oculta. Arraste pelo titulo.
- Fly: WASD ou setas, velocidade horizontal/vertical de 9 unidades de fisica.
- Velocidade: WASD/setas horizontais a 9 unidades de fisica.
- Elevador: velocidade vertical de -6, incompativel simultaneamente com Fly.
- Rato invisivel: alpha local do personagem.
- Rosa/verde: ColorTransform local, mutuamente exclusivos.
- Desativar tudo: encerra os controles e restaura alpha/cor capturados.

Os efeitos visuais sao locais. Fly/velocidade/elevador modificam o vetor de velocidade do corpo fisico local; nao ha garantia de aceitacao pelo servidor. O menu nao le o texto de usuario/senha e nao envia dados de autenticacao. Controles de movimento nao sao aplicados enquanto um TextField de entrada esta em foco.

Os demais patches nativos da lista de AoBs anterior NAO foram portados para ActionScript. Este pacote nao afirma incluir imortalidade, queijo instantaneo, noclip ou outros efeitos nao listados acima.

## Verificacao feita

- A SWF modificada foi recompilada e reaberta no FFDec 26.4.0.
- Apenas o tag DoABC foi alterado; os demais tags originais permanecem byte a byte identicos.
- Foram preservados todos os metodos originais, exceto os dois construtores de login que receberam a chamada ZyonMenu.attach.
- Adicionada uma classe: zyon.ZyonMenu. Limites de pilha/escopo dos 22 metodos novos ou modificados foram conferidos por analise estatica.
- Nomes dos campos utilizados foram conferidos contra as classes descompiladas desta SWF.
- NAO houve teste em runtime Flash/AIR nem conexao aos servidores. A verificacao estatica nao substitui a verificacao do AVM2 em execucao.

## Empacotamento e reproducao

A SWF principal nao foi recriptografada. Use sua ferramenta de empacotamento sobre ela conforme o formato que seu carregador espera. Nao foi testada compatibilidade com Rabscam.

Fontes: ZyonMenu.as, PatchSwf.java, VerifySwf.java e bindings.json. Os scripts Java utilizam os jars do FFDec 26.4.0, distribuidos pelo projeto oficial https://github.com/jindrapetrik/jpexs-decompiler. O programa Java recebe: SWF interna original, ZyonMenu.as, caminho de saida. VerifySwf recebe SWF interna original e SWF modificada.

SHA-256 de 158-descriptografada-menu.swf:
49b7b2e5604f2a1573e4be9c34ffd6c41ca284a0998d33d7954d4a0593c6a5e3
