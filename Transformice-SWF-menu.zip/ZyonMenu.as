// ActionScript 3 / ZyonMenu.as / Flash Player 11.1+ / Menu embedded in supplied Transformice SWF.
package zyon {
 import flash.display.DisplayObject;
 import flash.display.Sprite;
 import flash.events.Event;
 import flash.events.KeyboardEvent;
 import flash.events.MouseEvent;
 import flash.geom.ColorTransform;
 import flash.geom.Rectangle;
 import flash.text.TextField;
 import flash.text.TextFieldType;
 import flash.text.TextFormat;
 import flash.utils.getDefinitionByName;
 public class ZyonMenu extends Sprite {
  private static var instance:ZyonMenu;
  private var characterClass:Object;
  private var keys:Object = {};
  private var buttons:Array = [];
  private var status:TextField;
  private var player:Object;
  private var fly:Boolean=false;
  private var speed:Boolean=false;
  private var elevator:Boolean=false;
  private var invisible:Boolean=false;
  private var tint:uint=0;
  private var oldAlpha:Number=1;
  private var oldColor:ColorTransform;
  private var alphaApplied:Boolean=false;
  private var colorApplied:Boolean=false;
  private const LOCAL:String="\u0005\u0001\u0004\u0001\u0005\u0007\u0003\u0005\u0002\u0007\u0003\u0003\u0007";
  private const BODY:String="\u0006\u0001\u0004\u0006\u0002\u0008\u0002\u0004\u0002\u0005\u0006\u0008\u0005";
  private const VELOCITY:String="\u0006\u0008\u0005\u0001\u0007\u0002\u0007\u0001\u0007\u0003\u0004\u0006";
  private const VX:String="\u0006\u0002\u0002\u0003\u0001\u0001\u0004\u0005\u0002\u0006\u0001\u0003\u0004";
  private const VY:String="\u0007\u0001\u0004\u0001\u0005\u0008\u0008\u0006\u0002\u0005";
  private const WAKE:String="\u0003\u0008\u0002\u0006\u0005\u0006\u0005\u0004\u0008\u0006\u0008\u0003";
  public static function attach(login:DisplayObject):void {
   if(!login)return;
   if(!login.stage){login.addEventListener(Event.ADDED_TO_STAGE,onLoginStage,false,0,true);return;}
   try {
    if(instance&&instance.stage==login.stage){instance.visible=true;return;}
    instance=new ZyonMenu();
    login.stage.addChild(instance);
    instance.initialize();
   }catch(error:Error){trace("ZyonMenu: "+error.message);}
  }
  private static function onLoginStage(event:Event):void {
   var login:DisplayObject=event.currentTarget as DisplayObject;
   login.removeEventListener(Event.ADDED_TO_STAGE,onLoginStage);
   attach(login);
  }
  public function ZyonMenu(){
   super();
   name="ZyonMenu";
   characterClass=getDefinitionByName("\u0006\u0008\u0002\u0004\u0008\u0007\u0004\u0005\u0005\u0007\u0003");
   graphics.lineStyle(1,0x466178);graphics.beginFill(0x17212C,0.96);graphics.drawRoundRect(0,0,294,344,10);graphics.endFill();
   var title:Sprite=new Sprite();title.graphics.beginFill(0x294052);title.graphics.drawRoundRect(0,0,294,33,10);title.graphics.endFill();
   title.addChild(label("ZYON | TRANSFORMICE",12,8,245,20,0x7CE1D0));title.addEventListener(MouseEvent.MOUSE_DOWN,dragMenu);addChild(title);
   addButton("close","-",260,4,27,24);
   addButton("fly","Fly - WASD / setas",12,45,270,29);
   addButton("speed","Velocidade",12,79,270,29);
   addButton("elevator","Elevador",12,113,270,29);
   addButton("invisible","Rato invisivel",12,147,270,29);
   addButton("pink","Rosa",12,181,130,29);addButton("green","Verde",152,181,130,29);
   addButton("reset","Desativar tudo",12,218,270,29);
   addChild(label("Insert: menu | Arraste pelo titulo",12,257,270,20,0xBAC9D8));
   status=label("Login: configuracoes prontas",12,283,270,45,0xF0DA99);status.multiline=true;status.wordWrap=true;addChild(status);
   x=15;y=45;redraw();
  }
  private function initialize():void {
   stage.addEventListener(KeyboardEvent.KEY_DOWN,onKeyDown,false,50,true);
   stage.addEventListener(KeyboardEvent.KEY_UP,onKeyUp,false,50,true);
   stage.addEventListener(MouseEvent.MOUSE_UP,endDrag,false,0,true);
   stage.addEventListener(Event.DEACTIVATE,onDeactivate,false,0,true);
   stage.addEventListener(Event.RESIZE,onResize,false,0,true);
   addEventListener(Event.ENTER_FRAME,onFrame,false,0,true);
   addEventListener(MouseEvent.MOUSE_DOWN,blockMouse,false,0,true);
   addEventListener(MouseEvent.CLICK,blockMouse,false,0,true);
   onResize(null);
  }
  private function label(text:String,px:Number,py:Number,w:Number,h:Number,color:uint):TextField {
   var field:TextField=new TextField();field.defaultTextFormat=new TextFormat("_sans",12,color);field.text=text;field.x=px;field.y=py;field.width=w;field.height=h;field.selectable=false;field.mouseEnabled=false;return field;
  }
  private function addButton(id:String,text:String,px:Number,py:Number,w:Number,h:Number):void {
   var button:Sprite=new Sprite();button.name=id;button.x=px;button.y=py;button.buttonMode=true;button.mouseChildren=false;
   button.graphics.beginFill(0x334B60);button.graphics.drawRoundRect(0,0,w,h,5);button.graphics.endFill();button.addChild(label(text,8,5,w-12,h-4,0xFFFFFF));
   button.addEventListener(MouseEvent.CLICK,onButton);buttons.push(button);addChild(button);
  }
  private function onButton(event:MouseEvent):void {
   event.stopPropagation();var id:String=event.currentTarget.name;
   if(id=="close"){visible=false;return;}
   if(id=="fly"){fly=!fly;if(fly)elevator=false;}
   if(id=="speed")speed=!speed;
   if(id=="elevator"){elevator=!elevator;if(elevator)fly=false;}
   if(id=="invisible")invisible=!invisible;
   if(id=="pink")tint=tint==0xFF70BC?0:0xFF70BC;
   if(id=="green")tint=tint==0x60EA80?0:0x60EA80;
   if(id=="reset"){fly=false;speed=false;elevator=false;invisible=false;tint=0;restoreVisual();}
   redraw();
  }
  private function redraw():void {
   for each(var button:Sprite in buttons){
    var id:String=button.name;
    var active:Boolean=(id=="fly"&&fly)||(id=="speed"&&speed)||(id=="elevator"&&elevator)||(id=="invisible"&&invisible)||(id=="pink"&&tint==0xFF70BC)||(id=="green"&&tint==0x60EA80);
    var w:Number=id=="close"?27:(id=="pink"||id=="green"?130:270);var h:Number=id=="close"?24:29;
    button.graphics.clear();button.graphics.beginFill(active?0x167E6D:0x334B60);button.graphics.drawRoundRect(0,0,w,h,5);button.graphics.endFill();
   }
  }
  private function typing():Boolean {return stage&&stage.focus is TextField&&TextField(stage.focus).type==TextFieldType.INPUT;}
  private function onKeyDown(event:KeyboardEvent):void {
   if(event.keyCode==45){if(!keys[45])visible=!visible;keys[45]=true;event.stopImmediatePropagation();return;}
   if(!typing())keys[event.keyCode]=true;
  }
  private function onKeyUp(event:KeyboardEvent):void {delete keys[event.keyCode];}
  private function onDeactivate(event:Event):void {keys={};stopDrag();}
  private function blockMouse(event:MouseEvent):void {event.stopPropagation();}
  private function dragMenu(event:MouseEvent):void {event.stopPropagation();startDrag(false,new Rectangle(0,0,Math.max(0,stage.stageWidth-294),Math.max(0,stage.stageHeight-344)));}
  private function endDrag(event:MouseEvent):void {stopDrag();}
  private function onResize(event:Event):void {if(stage){x=Math.max(0,Math.min(x,stage.stageWidth-294));y=Math.max(0,Math.min(y,stage.stageHeight-344));}}
  private function restoreVisual():void {
   if(player){if(alphaApplied)player.alpha=oldAlpha;if(colorApplied&&oldColor)player.transform.colorTransform=oldColor;}
   alphaApplied=false;colorApplied=false;oldColor=null;
  }
  private function onFrame(event:Event):void {
   if(!stage)return;
   if(visible&&parent==stage&&stage.getChildIndex(this)!=stage.numChildren-1)stage.setChildIndex(this,stage.numChildren-1);
   try {
    var current:Object=characterClass[LOCAL];
    if(current!=player){restoreVisual();player=current;}
    if(!player||!DisplayObject(player).stage){status.text="Entre em uma sala para aplicar.";return;}
    if(invisible){if(!alphaApplied){oldAlpha=player.alpha;alphaApplied=true;}player.alpha=0;}
    else if(alphaApplied){player.alpha=oldAlpha;alphaApplied=false;}
    if(tint){if(!colorApplied){oldColor=player.transform.colorTransform;colorApplied=true;}var color:ColorTransform=new ColorTransform();color.color=tint;player.transform.colorTransform=color;}
    else if(colorApplied){player.transform.colorTransform=oldColor;colorApplied=false;oldColor=null;}
    var body:Object=player[BODY];
    if(!body){status.text="Personagem sem corpo fisico ativo.";return;}
    var velocity:Object=body[VELOCITY];
    var dx:int=(keys[68]||keys[39]?1:0)-(keys[65]||keys[37]?1:0);
    var dy:int=(keys[83]||keys[40]?1:0)-(keys[87]||keys[38]?1:0);
    if(!typing()){
     if(fly){body[WAKE]();velocity[VX]=dx*9;velocity[VY]=dy*9;}
     else {if(speed&&dx){body[WAKE]();velocity[VX]=dx*9;}if(elevator){body[WAKE]();velocity[VY]=-6;}}
    }
    status.text="Menu interno ativo. Insert para ocultar.";
   }catch(error:Error){
    fly=false;speed=false;elevator=false;invisible=false;tint=0;restoreVisual();redraw();status.text="Falha de compatibilidade: "+error.message;
   }
  }
 }
}
