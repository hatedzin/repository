@rem Batch / INICIAR_CLIENT.bat / Windows 10-11 / DisneyClient launcher
@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 iniciar_client.py
    goto result
)
where python >nul 2>nul
if not errorlevel 1 (
    python iniciar_client.py
    goto result
)
echo Instale Python 3.11 ou superior: https://www.python.org/downloads/windows/
pause
exit /b 1
:result
if errorlevel 1 (
    echo.
    echo O client nao iniciou. Leia a mensagem acima.
    pause
    exit /b 1
)
exit /b 0
