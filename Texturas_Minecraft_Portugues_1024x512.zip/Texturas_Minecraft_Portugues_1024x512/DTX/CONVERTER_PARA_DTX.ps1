﻿param([Parameter(Mandatory=$true)][string]$Conversor)
$ErrorActionPreference = 'Stop'
$ferramenta = (Resolve-Path -LiteralPath $Conversor).Path
$pacote = Split-Path -Parent $PSScriptRoot
$origem = Join-Path $pacote 'TGA'
$destino = Join-Path $PSScriptRoot 'CONVERTIDAS'
New-Item -ItemType Directory -Force -Path $destino | Out-Null
$falhas = @()
$total = 0
foreach ($arquivo in (Get-ChildItem -LiteralPath $origem -Filter '*.tga' -File)) {
    $saida = Join-Path $destino ($arquivo.BaseName + '.dtx')
    $temporario = $saida + '.pendente.dtx'
    if ((Test-Path -LiteralPath $saida) -or (Test-Path -LiteralPath $temporario)) {
        throw "Arquivo de destino ou conversao pendente ja existe: $saida"
    }
    try {
        & $ferramenta '-tga2dtx' $arquivo.FullName $temporario
        if ($LASTEXITCODE -ne 0) { throw "Conversor retornou $LASTEXITCODE" }
        if (!(Test-Path -LiteralPath $temporario)) { throw 'DTX nao foi criado' }
        if ((Get-Item -LiteralPath $temporario).Length -le 164) { throw 'Arquivo DTX pequeno demais' }
        Move-Item -LiteralPath $temporario -Destination $saida
        $total++
    } catch {
        $falhas += "$($arquivo.Name): $($_.Exception.Message)"
        if (Test-Path -LiteralPath $temporario) { Remove-Item -LiteralPath $temporario }
    }
}
Write-Host "$total arquivos convertidos em $destino"
if ($falhas.Count -gt 0) {
    $falhas | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'ERROS.txt') -Encoding UTF8
    throw "$($falhas.Count) conversoes falharam. Consulte ERROS.txt."
}
Write-Host 'Confira resolucao, cores, alpha e mipmaps no seu DEdit/DtxView.'
