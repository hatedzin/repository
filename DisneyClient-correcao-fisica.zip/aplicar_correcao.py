# Python / aplicar_correcao.py / Python 3.11 on Windows / apply a verified six-file update with backup and rollback
from pathlib import Path
import argparse,hashlib,json,os,shutil,socket,subprocess,sys,tempfile,time

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def install(root,bundle):
 manifest=json.loads((bundle/'correcao-manifesto.json').read_text(encoding='utf-8'))
 payload=bundle/'correcao-fisica';entries=manifest['files']
 # Validate every input and destination before modifying anything.
 already=True
 for name,entry in entries.items():
  relative=Path(name)
  if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Caminho invalido no manifesto.')
  if digest(payload/relative)!=entry['after']:raise RuntimeError('Arquivo da correcao corrompido: '+name)
  current=digest(root/relative)
  if current not in {entry['before'],entry['after']}:raise RuntimeError('A versao deste arquivo e diferente da base enviada: '+name+'. Nenhuma alteracao foi feita.')
  already=already and current==entry['after']
 if already:return None
 backup=root/('backup-fisica-'+time.strftime('%Y%m%d-%H%M%S')+'-'+str(os.getpid()));backup.mkdir()
 original={};modified=[]
 for name in entries:
  target=root/name;original[name]=target.is_file()
  if original[name]:dst=backup/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,dst)
 (backup/'restaurar-arquivos.json').write_text(json.dumps(original,indent=2),encoding='utf-8')
 try:
  for name in entries:
   target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
   fd,temp=tempfile.mkstemp(prefix='.correcao-',dir=target.parent);os.close(fd)
   try:
    shutil.copy2(payload/name,temp);os.replace(temp,target);modified.append(name)
   finally:
    Path(temp).unlink(missing_ok=True)
  if any(digest(root/name)!=entry['after'] for name,entry in entries.items()):raise RuntimeError('A verificacao apos a copia falhou.')
 except BaseException:
  for name in reversed(modified):
   target=root/name
   if original[name]:shutil.copy2(backup/name,target)
   else:target.unlink(missing_ok=True)
  raise
 return backup

def find_project(here,argument=None):
 if argument:
  candidate=Path(argument).resolve();candidate=candidate.parent if candidate.is_file() else candidate
  if (candidate/'DisneyClient/public/ChargeurTransformice.swf').is_file():return candidate
  raise RuntimeError('O caminho indicado nao contem este projeto.')
 for candidate in [here,here.parent,here/'DisneyClient-Completo',here.parent/'DisneyClient-Completo']:
  if (candidate/'DisneyClient/public/ChargeurTransformice.swf').is_file() and (candidate/'INICIAR_CLIENT.bat').is_file():return candidate
 raise RuntimeError('Extraia o conteudo deste ZIP na pasta do projeto, ao lado de INICIAR_CLIENT.bat. Ou arraste INICIAR_CLIENT.bat sobre APLICAR_CORRECAO.bat.')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('project',nargs='?');parser.add_argument('--no-start',action='store_true');args=parser.parse_args()
 here=Path(__file__).resolve().parent
 try:
  root=find_project(here,args.project)
  with socket.socket() as check:
   check.settimeout(0.3)
   if check.connect_ex(('127.0.0.1',8080))==0:raise RuntimeError('Feche a janela INICIAR_CLIENT antiga antes de aplicar esta correcao.')
  backup=install(root,here)
  print('Correcao aplicada e verificada.' if backup else 'Esta correcao ja esta aplicada.')
  if backup:print('Backup dos arquivos anteriores: '+str(backup))
  print('Configuracao, keys, banco, tokens e menu foram preservados.')
  if not args.no_start and os.name=='nt':subprocess.Popen(['cmd','/c',str(root/'INICIAR_CLIENT.bat')],cwd=root,creationflags=subprocess.CREATE_NEW_CONSOLE)
  return 0
 except Exception as error:print('ERRO: '+str(error));return 1
if __name__=='__main__':raise SystemExit(main())
