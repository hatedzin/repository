# Python / test_symbols.py / Python 3.11 / repair the supplied game's missing movement fields and validate native contracts
import asyncio,sys,json,unittest
from pathlib import Path
sys.path.insert(0,'/workspace/work/disney-user-fix/input/DisneyClient-Completo/DisneyParser')
from tfmparser.physics_symbols import extract_physics_symbols
from tfmparser.parser import collect_symbols
class Tests(unittest.TestCase):
 def test_uploaded_and_two_reference_builds(self):
  for name in ['user-game','new-158','original-game']:
   with self.subTest(name=name):
    if name=='user-game':
     path=Path('/workspace/work/disney-user-fix/user-game.dump');norm=json.loads(Path('/workspace/work/disney-user-fix/user-keys.json').read_text());raw={k:''.join('\\'+x for x in v) if v.isdigit() else v for k,v in norm.items()}
     self.assertNotIn('player_moving_right',raw);self.assertNotIn('player_moving_left',raw)
    else:
     path=Path('/workspace/work/disney-fix/'+name+'.dump');raw=json.loads(Path('/workspace/work/disney-fix/'+name+'.dump.keys.json').read_text())
    result=extract_physics_symbols(path.read_text().splitlines(),raw)
    self.assertEqual(len(result),12);self.assertNotEqual(result['player_moving_left'],result['player_moving_right'])
 def test_invalid_build_does_not_guess(self):
  with self.assertRaises((ValueError,KeyError)):extract_physics_symbols([],{'player_physics':'unknown'})
if __name__=='__main__':unittest.main()
