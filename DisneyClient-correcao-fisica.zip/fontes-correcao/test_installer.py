# Python / test_installer.py / Python 3.11 / verified update is idempotent and leaves unrelated files untouched
import importlib.util,sys,unittest,tempfile,hashlib,json
from pathlib import Path
from unittest.mock import patch
p=Path('/workspace/work/disney-user-fix/release/aplicar_correcao.py');spec=importlib.util.spec_from_file_location('installer',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class Tests(unittest.TestCase):
 def prepare(self,folder):
  root=Path(folder)/'project';bundle=Path(folder)/'update';root.mkdir();(bundle/'correcao-fisica/DisneyClient').mkdir(parents=True)
  (root/'DisneyClient').mkdir();(root/'DisneyClient/a').write_bytes(b'old');(root/'.env').write_bytes(b'PRIVATE');(root/'tokens.json').write_bytes(b'PRIVATE');(bundle/'correcao-fisica/DisneyClient/a').write_bytes(b'new');(bundle/'correcao-fisica/DisneyClient/b').write_bytes(b'added')
  h=lambda b:hashlib.sha256(b).hexdigest();(bundle/'correcao-manifesto.json').write_text(json.dumps({'files':{'DisneyClient/a':{'before':h(b'old'),'after':h(b'new')},'DisneyClient/b':{'before':None,'after':h(b'added')}}}));return root,bundle
 def test_backup_and_idempotence_preserve_private_files(self):
  with tempfile.TemporaryDirectory() as d:
   root,bundle=self.prepare(d);backup=mod.install(root,bundle)
   self.assertEqual((backup/'DisneyClient/a').read_bytes(),b'old');self.assertEqual((root/'DisneyClient/a').read_bytes(),b'new');self.assertEqual((root/'.env').read_bytes(),b'PRIVATE');self.assertEqual((root/'tokens.json').read_bytes(),b'PRIVATE');self.assertIsNone(mod.install(root,bundle))
 def test_wrong_base_no_changes(self):
  with tempfile.TemporaryDirectory() as d:
   root,bundle=self.prepare(d);(root/'DisneyClient/a').write_bytes(b'other')
   with self.assertRaises(RuntimeError):mod.install(root,bundle)
   self.assertEqual((root/'DisneyClient/a').read_bytes(),b'other');self.assertFalse((root/'DisneyClient/b').exists());self.assertFalse(list(root.glob('backup-*')))
 def test_payload_damage_no_changes(self):
  with tempfile.TemporaryDirectory() as d:
   root,bundle=self.prepare(d);(bundle/'correcao-fisica/DisneyClient/b').write_bytes(b'damaged')
   with self.assertRaises(RuntimeError):mod.install(root,bundle)
   self.assertEqual((root/'DisneyClient/a').read_bytes(),b'old')
 def test_copy_failure_rolls_back(self):
  with tempfile.TemporaryDirectory() as d:
   root,bundle=self.prepare(d);actual=mod.os.replace
   def fail_second(source,target):
    if Path(target).name=='b':raise OSError('simulated failure')
    return actual(source,target)
   with patch.object(mod.os,'replace',side_effect=fail_second):
    with self.assertRaises(OSError):mod.install(root,bundle)
   self.assertEqual((root/'DisneyClient/a').read_bytes(),b'old');self.assertFalse((root/'DisneyClient/b').exists())
if __name__=='__main__':unittest.main()
