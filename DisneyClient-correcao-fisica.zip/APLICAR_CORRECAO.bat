@rem Batch / APLICAR_CORRECAO.bat / Windows 10-11 / verified update and normal client startup
@echo off
setlocal
cd /d "%~dp0"
if exist ".client-runtime\Scripts\python.exe" (
    ".client-runtime\Scripts\python.exe" aplicar_correcao.py %*
    goto result
)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 aplicar_correcao.py %*
    goto result
)
where python >nul 2>nul
if not errorlevel 1 (
    python aplicar_correcao.py %*
    goto result
)
echo ERRO: Python 3 nao encontrado. Abra o iniciador normal para preparar o ambiente.
pause
exit /b 1
:result
if errorlevel 1 (
    pause
    exit /b 1
)
exit /b 0
