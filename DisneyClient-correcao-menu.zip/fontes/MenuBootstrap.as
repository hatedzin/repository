// ActionScript 3 / MenuBootstrap.as / Flash Player 11+ / DisneyClient loader menu initialization
package disney {
    import flash.display.DisplayObject;
    import flash.display.MovieClip;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.getDefinitionByName;
    public class MenuBootstrap {
        public static function attach(root:MovieClip):void {
            if (!root || !root.stage || root.stage.getChildByName("disneyMenuButton")) return;
            var button:Sprite = new Sprite();
            button.name = "disneyMenuButton";
            button.graphics.beginFill(0x25344B, 0.96);
            button.graphics.drawRoundRect(0, 0, 100, 28, 8, 8);
            button.graphics.endFill();
            button.x = 8; button.y = 8; button.buttonMode = true;
            var label:TextField = new TextField();
            label.defaultTextFormat = new TextFormat("_sans", 13, 0xFFFFFF, true);
            label.text = "Abrir menu"; label.width = 100; label.height = 25;
            label.mouseEnabled = false; label.selectable = false;
            label.x = 8; label.y = 3; button.addChild(label);
            var status:TextField = new TextField();
            status.name = "disneyMenuStatus";
            status.defaultTextFormat = new TextFormat("_sans", 12, 0xFFFFFF);
            status.background = true; status.backgroundColor = 0x25344B;
            status.width = 620; status.height = 38; status.x = 8; status.y = 39;
            status.visible = false; status.selectable = true;
            root.stage.addChild(status); root.stage.addChild(button);
            button.addEventListener(MouseEvent.CLICK, function(event:MouseEvent):void {
                event.stopImmediatePropagation();
                showMenu(root, status, button, true);
            });
            showMenu(root, status, button, false);
        }
        private static function showMenu(root:MovieClip, status:TextField, button:Sprite, toggle:Boolean):void {
            try {
                var keys:Object = root["Keys"];
                var required:Array = ["ui_element_class", "prep_ui_class", "set_prep_ui", "add_ui_element", "prep_ui1_instance", "prep_ui4_instance", "ui_items_list_class", "select_item"];
                var missing:Array = [];
                for each (var name:String in required) if (!keys[name]) missing.push(name);
                if (missing.length) {
                    status.text = "Menu indisponivel: simbolos ausentes: " + missing.join(", ");
                    status.visible = true;
                    return;
                }
                var instance:Object = root["Interface"];
                if (instance && toggle && instance["menu_ui"] && instance["menu_ui"].parent) {
                    instance["menu_ui"].parent.removeChild(instance["menu_ui"]);
                    return;
                }
                if (!instance) {
                    var MenuClass:Class = getDefinitionByName("ChargeurTransformice_fla.Interface") as Class;
                    instance = new MenuClass();
                    root["Interface"] = instance;
                }
                var menu:DisplayObject = instance["menu_ui"] as DisplayObject;
                if (!menu) throw new Error("Missing menu display object");
                root.stage.addChild(menu);
                menu.x = 20; menu.y = 80; menu.visible = true;
                instance["menu_x"] = menu.x; instance["menu_y"] = menu.y;
                instance["change_menu_tab"](instance["last_tab"]);
                status.visible = false;
                root.stage.addChild(button);
            } catch (error:Error) {
                status.text = "Falha ao construir o menu. Codigo Flash: " + error.errorID;
                status.visible = true;
            }
        }
    }
}
