@rem Batch / CORRIGIR_MENU.bat / Windows 10-11 / apply DisneyClient menu correction
@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 corrigir_menu.py
    goto result
)
where python >nul 2>nul
if not errorlevel 1 (
    python corrigir_menu.py
    goto result
)
echo Instale Python 3.11 ou superior.
pause
exit /b 1
:result
if errorlevel 1 (
    echo A correcao nao foi aplicada. Leia a mensagem acima.
    pause
    exit /b 1
)
echo.
echo Feche esta janela e abra INICIAR_CLIENT.bat na pasta do projeto.
pause
exit /b 0
