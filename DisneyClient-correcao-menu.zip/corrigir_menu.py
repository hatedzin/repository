# Python / corrigir_menu.py / Python 3.11+ / install DisneyClient menu correction with backups
import sys
import _menu_install_core as core

if __name__ == '__main__':
    try:
        print('Feche a janela INICIAR_CLIENT anterior antes de aplicar esta correcao.',flush=True)
        core.configure_project(sys.argv[1] if len(sys.argv)>1 else None)
        core.apply_update()
        print('\nCorrecao aplicada em: '+str(core.ROOT),flush=True)
        print('Abra novamente INICIAR_CLIENT.bat nessa pasta. O loader tentara abrir o menu ao carregar o jogo.')
        print('Tambem aparecera o botao Abrir menu. Se houver erro, anote o codigo mostrado dentro do jogo.')
    except (OSError,ValueError,RuntimeError) as error:
        if isinstance(error,RuntimeError):print('ERRO: '+str(error))
        else:print('ERRO ao aplicar correcao: '+type(error).__name__)
        sys.exit(1)
