// ActionScript 3 / RoutePlayerTests.as / AVM2 via Ruffle / saved-route integration tests with a mock native physics API
package disney {
    import flash.display.MovieClip;
    import flash.display.Sprite;
    import flash.text.TextField;
    import flash.geom.Point;
    import flash.external.ExternalInterface;
    import flash.utils.setTimeout;
    import flash.events.Event;
    import flash.events.MouseEvent;
    import flash.events.IOErrorEvent;
    import flash.net.URLLoader;
    import flash.net.URLRequest;
    public class RoutePlayerTests {
        private static var count:int=0;
        private static function check(ok:Boolean,name:String):void {if(!ok)throw new Error("FAIL: "+name);count++;}
        private static function walk(x:Number,delay:Number):Array {return [{x:x,y:1000,vx:200,vy:-100,mr:true,ml:false,jump:false,frame:0},"walk",delay];}
        private static function fixture():Object {
            var r:MovieClip=new MovieClip();var calls:Array=[];
            var body:Object={velocity:{vx:0,vy:0}};
            body.setPosition=function(p:Point,angle:Number):Boolean {calls.push({x:p.x,y:p.y});return true;};
            var player:Object={x:100,y:200,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true};
            player.jump=function(value:Boolean,frame:int=0):void {};
            player.run=function(side:Boolean):void {};
            player.idle=function(side:Boolean):void {};
            player.crouch=function(side:Boolean):void {};
            player.stand=function(side:Boolean):void {};
            var map:Object={codeObject:{number:123},container:{mirror:false}};
            var keys:Object={bot_map_code_object:"codeObject",bot_map_code_value:"number",bot_reverse:"mirror",bot_map_width:"width",player_physics:"body",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",map_class:{instance:map,width:800},map_instance:"instance",player:"mouse",player_clip:"clip",is_dead:"dead",obj_container:"container",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked",player_moving_left:"left",player_moving_right:"right",jump:"jump",animation_course:"run",static_animation:"idle",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",text_field:"field",maps:{},app_domain:{applicationDomain:{getDefinition:function(name:String):Class{return Point;}}}};
            var delay:TextField=new TextField();delay.text="10";
            r["Keys"]=keys;r["tfm"]={mouse:player};r["auto_play"]=true;r["auto_play_disable_on_move"]=true;
            r["Interface"]={status_field:new TextField(),bot_delay_input:{field:delay}};
            keys.maps["@123"]=com.adobe.serialization.json.JSON.encode([walk(1000,999),walk(2000,1000),[0,"hole",1000]]);
            return {root:r,keys:keys,body:body,player:player,map:map,calls:calls,robot:new RoutePlayer(r)};
        }
        public static function run(display:MovieClip):void {
            var result:String;
            try {
                var f:Object=fixture();f.robot.advance(0);check(f.calls.length==0,"settle before start");f.robot.advance(300);
                check(f.calls.length==1 && f.calls[0].x==10,"first step immediate and scaled");
                check(f.body.velocity.vx==2 && f.body.velocity.vy==-1,"recorded velocity scaled");
                f.robot.advance(1289);check(f.calls.length==1,"honor recorded delay");f.robot.advance(1290);check(f.calls.length==2 && f.player.x==600,"delay reduction and native display position");
                f.robot.advance(2290);f.robot.advance(9000);check(f.calls.length==2 && f.robot.message.indexOf("finalizada")>=0,"completed route does not loop");
                f=fixture();f.map.container.mirror=true;f.robot.advance(0);f.robot.advance(300);check(Math.abs(f.calls[0].x-(800/30-10))<0.001 && f.body.velocity.vx==-2 && f.player.left,"mirrored position velocity and controls");
                f=fixture();f.robot.advance(0);f.robot.advance(300);f.root.auto_play=false;f.robot.advance(400);f.robot.advance(5000);check(f.calls.length==1 && !f.player.right,"disable cancels pending steps");
                f.root.auto_play=true;f.robot.advance(5100);f.robot.advance(5400);check(f.calls.length==2,"enable restarts route");
                f=fixture();f.robot.advance(0);f.robot.advance(300);f.robot.pause();f.robot.advance(3000);check(f.calls.length==1 && f.robot.message.indexOf("pausado")>=0,"manual pause stays paused");
                f=fixture();delete f.keys.maps["@123"];f.robot.advance(0);f.robot.advance(300);check(f.calls.length==0 && f.robot.message.indexOf("sem rota")>=0,"missing map explicit status");
                f.keys.maps["@123"]=com.adobe.serialization.json.JSON.encode([walk(1000,0)]);f.robot.advance(500);check(f.calls.length==1,"late-loaded route becomes available");
                f=fixture();f.robot.advance(0);f.robot.advance(300);f.player.dead=true;f.robot.advance(400);f.player.dead=false;f.robot.advance(500);f.robot.advance(800);check(f.calls.length==2,"respawn replays same map and body");
                f=fixture();f.robot.advance(0);f.robot.advance(300);f.keys.map_class.instance={codeObject:{number:123},container:{mirror:false}};f.robot.advance(400);f.robot.advance(700);check(f.calls.length==2,"new round with same code restarts");
                f=fixture();f.keys.timer_class.locked=true;f.robot.advance(0);f.robot.advance(300);check(f.calls.length==0,"native countdown preserved");f.keys.timer_class.locked=false;f.robot.advance(500);check(f.calls.length==1,"start after native countdown");
                f=fixture();f.keys.maps["@123"]="[[{},\"walk\",0]]";f.robot.advance(0);f.robot.advance(300);f.robot.advance(1000);check(f.calls.length==0 && f.robot.message.indexOf("erro #2004")>=0,"invalid route stays failed without moving");
                f=fixture();var many:Array=[];for(var i:int=0;i<40;i++)many.push(walk(1000+i,1000));
                f.keys.maps["@123"]=com.adobe.serialization.json.JSON.encode(many);f.robot.advance(0);f.robot.advance(300);f.robot.advance(100000);
                check(f.calls.length==13 && f.robot.message.indexOf("atrasada")>=0,"stalled window bounded and stopped");
                f.robot.advance(200000);check(f.calls.length==13,"stalled route stays stopped");
                f=fixture();delete f.keys.bot_reverse;f.robot.advance(0);f.robot.advance(300);check(f.calls.length==0 && f.robot.message.indexOf("simbolo ausente")>=0,"unsupported build stays idle");
                f=fixture();var negative:Array=walk(4294967196,0);negative[0].vx=65535;negative[0].vy=65436;
                f.keys.maps["@123"]=com.adobe.serialization.json.JSON.encode([negative,["cheese",37],["hole",410]]);
                f.robot.advance(0);f.robot.advance(300);
                check(f.calls[0].x==-1 && f.body.velocity.vx==-0.01 && f.body.velocity.vy==-1,"unsigned storage decoded as signed native integers");
                f.robot.advance(327);f.robot.advance(727);check(f.robot.message.indexOf("finalizada")>=0,"legacy two-element markers normalized");
                var welcomeCalls:Array=[];f=fixture();f.keys.chat_class2={show:function(text:String):void{welcomeCalls.push(text);}};f.keys.chat_message2="show";
                f.keys.ui_element_class=MockUI;f.keys.ui_check_button_class=MockCheck;f.keys.ui_text_field_class=MockText;
                f.keys.set_prep_ui="prep";f.keys.prep_ui_class={normal:{}};f.keys.prep_ui1_instance="normal";f.keys.add_ui_element="add";
                f.keys.text_field2="caption";f.keys.is_selected="selected";f.keys.check_button_exec="exec";
                var general:MockUI=new MockUI();f.root.Interface.general_ui=general;
                var controls:NativeControls=new NativeControls(f.root);controls.tick(0);controls.tick(1000);
                check(welcomeCalls.length==1 && welcomeCalls[0]=="<BL>BEM VINDO AO SDDS CHEATS</BL>","welcome appears once in local chat");
                check(general.numChildren==2 && general.getChildAt(0).name=="sddsWjFlyRow","native WJ Fly row added without duplicates");
                check(MockCheck(MockUI(general.getChildAt(0)).getChildAt(0)).caption.text=="WJ Fly","WJ Fly uses native checkbox and plain label");
                f=fixture();f.player.dead=true;delete f.keys.maps["@123"];f.robot.advance(0);f.robot.advance(300);
                check(f.robot.message.indexOf("sem rota")>=0,"missing route reported before respawn state");
                f=fixture();f.robot.advance(0);f.robot.advance(300);f.robot.disconnect();f.robot.advance(2000);
                check(f.calls.length==1 && f.robot.message.indexOf("conexao encerrada")>=0,"disconnect stops pending playback and stale respawn status");
                f.keys.map_class.instance={codeObject:{number:123},container:{mirror:false}};f.robot.advance(2100);f.robot.advance(2400);
                check(f.calls.length==2,"new map after reconnect rearms playback");
                f=fixture();f.root.auto_play=false;f.robot.advance(0);f.robot.toggleRecording(300);
                f.player.x=330;f.player.y=150;f.body.velocity.vx=2;f.body.velocity.vy=-1;f.robot.setJumpState(true);f.robot.advance(400);f.robot.toggleRecording(500);
                var recorded:Array=RoutePlayer.decodeRoute(f.robot.recordedRoute());
                check(recorded.length>=3 && recorded[1][0].x==1100 && recorded[1][0].vx==200 && recorded[1][0].jump,"REC captures local position velocity and jump");
                check(recorded[1][2]==100 && recorded[2][2]==100,"REC preserves elapsed movement timing");
                var recordedFixture:Object=f;
                f=fixture();f.root.change_movement_speed=true;var movement:TextField=new TextField();movement.text="3.45";f.root.Interface.movement_input={field:movement};
                f.keys.get_linear_velocity="getVelocity";var speedBody:Object=f.body;f.body.getVelocity=function():Object{return speedBody.velocity;};f.player.right=true;f.body.velocity.vx=1;
                SddsMenu.applySpeed(f.root);check(Math.abs(f.body.velocity.vx-1.1)<0.0001,"speed uses native velocity getter");
                f.keys.physics_state_vx="missing";SddsMenu.applySpeed(f.root);check(!f.root.change_movement_speed,"speed invalid fields stop without throwing 1069");
                f=fixture();var weightFixture:Object=f;f.root.mass_reduction=false;f.body.mass=10;f.body.inertia=4;f.body.sweep={center:{vx:1,vy:2}};
                f.body.setMass=function(data:MockMassData):void{weightFixture.body.mass=data.mass;weightFixture.body.inertia=data.inertia;weightFixture.body.sweep.center={vx:data.center.x,vy:data.center.y};};
                f.keys.mass_data_class=MockMassData;f.keys.mass_set="setMass";f.keys.mass_body_mass="mass";f.keys.mass_body_inertia="inertia";
                f.keys.mass_data_mass="mass";f.keys.mass_data_inertia="inertia";f.keys.mass_data_center="center";f.keys.mass_body_sweep="sweep";f.keys.mass_sweep_center="center";f.keys.pos_x="vx";f.keys.pos_y="vy";
                var massText:TextField=new TextField();massText.text="2";f.root.Interface.mass_input={field:massText};f.root.Interface.keys={};
                var weight:WeightController=new WeightController(f.root);weight.update();check(massText.text=="100","weight migrates old reduction field to original 100 percent");
                massText.text="50";f.root.mass_reduction=true;weight.update();check(f.body.mass==5 && f.body.inertia==2,"weight scales native mass and inertia: "+weight.message+" mass="+f.body.mass+" inertia="+f.body.inertia);
                massText.text="200";weight.update();check(f.body.mass==20 && f.body.inertia==8,"weight changes relative to original without compounding");
                f.root.mass_reduction=false;weight.update();check(f.body.mass==10 && f.body.inertia==4 && f.body.sweep.center.vx==1,"weight restores mass inertia and center");
                massText.text="0";f.root.mass_reduction=true;weight.update();check(!f.root.mass_reduction && f.body.mass==10,"invalid weight rejected and original retained");
                var menuRoot:MovieClip=new MovieClip();menuRoot["Keys"]={};menuRoot["tfm"]={};menuRoot["Interface"]=null;display.addChild(menuRoot);SddsMenu.attach(menuRoot);
                check(!display.stage.getChildByName("disneyMenuStatus").visible,"login does not show premature menu construction error");
                var options:Sprite=new Sprite();var generalPanel:Sprite=new Sprite();var contentLabel:TextField=new TextField();contentLabel.text="Jogador | Peso do rato (%)";contentLabel.width=400;generalPanel.addChild(contentLabel);
                var menuUi:Object={options_ui:options,general_ui:generalPanel,keys_ui:new Sprite(),settings_ui:new Sprite(),bot_ui:new Sprite(),last_tab:"general"};
                menuUi.change_menu_tab=function(id:String):void {while(options.numChildren)options.removeChildAt(0);options.addChild(id=="bot" ? menuUi.bot_ui : generalPanel);};
                menuRoot["Interface"]=menuUi;menuRoot["Keys"]={player:"mouse",ui_element_class:MockUI,prep_ui_class:{},set_prep_ui:"prep",add_ui_element:"add",prep_ui1_instance:"normal",prep_ui4_instance:"normal",ui_items_list_class:MockUI,select_item:"select"};menuRoot["tfm"]={mouse:{}};
                display.stage.getChildByName("disneyMenuButton").dispatchEvent(new MouseEvent(MouseEvent.CLICK));
                check(menuUi.menu_ui && menuUi.menu_ui.parent && TextField(menuUi.menu_ui.getChildAt(0)).text=="Sdds MENU","ready game opens renamed menu");
                check(menuUi.menu_ui.getChildByName("sddsRgbBorder")!=null,"RGB border integrated into menu");
                result="PASS: "+count+" AVM2 route playback assertions";
            } catch(error:Error) {result=error.message+" #"+error.errorID;}
            if (result.indexOf("PASS:")!=0) {report(display,result);return;}
            try {
                var routes:Array=ExternalInterface.call("getRoutes") as Array;
                for each(var saved:String in routes)RoutePlayer.decodeRoute(saved);
                var saveFixture:Object=recordedFixture;
                saveFixture.keys.map_class.instance={codeObject:{number:456},container:{mirror:false}};saveFixture.robot.advance(800);
                saveFixture.root.host_url=ExternalInterface.call("testOrigin")+"/";saveFixture.root.access_token="fixture";saveFixture.root.tfmdisney={data:{flash_token:"fixture"}};
                saveFixture.robot.saveRecording();
                var attempts:int=0;
                var poll:Function=function():void {
                    attempts++;
                    if(saveFixture.robot.message.indexOf("rota @123 salva")>=0) {
                        check(saveFixture.keys.maps["@123"]==saveFixture.robot.recordedRoute() && !saveFixture.keys.maps["@456"],"SAVE uses recorded map even after round changes");
                        report(display,result+"; SAVE persisted correct map; "+routes.length+" actual saved routes decoded");
                    }else if(attempts<100)setTimeout(poll,100);
                    else report(display,"FAIL: SAVE timeout: "+saveFixture.robot.message);
                };
                setTimeout(poll,100);
            }catch(error:Error){report(display,"FAIL: actual saved routes: "+error.message+" #"+error.errorID);}

        }
        private static function report(display:MovieClip,result:String):void {
            var field:TextField=new TextField();field.width=780;field.height=400;field.text=result;display.addChild(field);
            trace(result);if(ExternalInterface.available)ExternalInterface.call("recordTest",result);
        }
    }
}
