// ActionScript 3 / MockCheck.as / AVM2 / native menu fixture
package disney {
import flash.display.Sprite;import flash.text.TextField;
    public class MockCheck extends Sprite {
        public var selected:Boolean=false;
        public var caption:TextField=new TextField();
        private var callback:Function;
        public function MockCheck(fn:Function) {callback=fn;addChild(caption);}
        public function exec(event:flash.events.MouseEvent):void {selected=!selected;callback(selected);}
    }

}
