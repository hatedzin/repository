// ActionScript 3 / MockText.as / AVM2 / native menu fixture
package disney {
import flash.display.Sprite;import flash.text.TextField;
    public class MockText extends TextField {
        public function MockText(value:String="") {text=value;}
    }

}
