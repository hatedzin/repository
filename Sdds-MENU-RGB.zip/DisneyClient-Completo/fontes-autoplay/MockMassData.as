// ActionScript 3 / MockMassData.as / AVM2 / native mass fixture
package disney {import flash.geom.Point;public class MockMassData {public var mass:Number;public var inertia:Number;public var center:Point;public function MockMassData(){super();mass=0;inertia=0;center=new Point();}}}
