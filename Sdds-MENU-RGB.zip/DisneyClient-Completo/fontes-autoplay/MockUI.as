// ActionScript 3 / MockUI.as / AVM2 / native menu fixture
package disney {
import flash.display.Sprite;import flash.text.TextField;
    public class MockUI extends Sprite {
        public function MockUI(w:Number=525,h:Number=24) {graphics.beginFill(0);graphics.drawRect(0,0,w,h);graphics.endFill();}
        public function prep(value:Object):void {}
        public function add(value:Object):void {addChild(value as flash.display.DisplayObject);}
    }

}
