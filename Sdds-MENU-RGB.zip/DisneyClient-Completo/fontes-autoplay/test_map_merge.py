# Python / test_map_merge.py / Python 3.11 / saved routes override shared maps without discarding the shared database
import sys,types,importlib,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"DisneyClient"))
pkg=types.ModuleType('api');pkg.__path__=[str(Path(__file__).resolve().parents[1]/"DisneyClient/api")];sys.modules['api']=pkg
mod=importlib.import_module('api.map_storage');from utils import cryptjson
class Tests(unittest.TestCase):
 def test_personal_routes_preserve_shared_and_override_matching(self):
  shared=cryptjson.text_encode(b'@1:[["hole",0]]#@2:[["cheese",0]]');personal=cryptjson.text_encode(b'@2:[["hole",10]]#@3:[["hole",20]]')
  result=cryptjson.text_decode(mod.merge_routes(shared,personal));self.assertEqual(result,b'@1:[["hole",0]]#@2:[["hole",10]]#@3:[["hole",20]]')
 def test_codes_canonicalized_for_override(self):
  result=cryptjson.text_decode(mod.merge_routes(cryptjson.text_encode(b'@1:A'),cryptjson.text_encode(b'1:B')))
  self.assertEqual(result,b'@1:B')
 def test_empty_personal_keeps_all_shared(self):
  self.assertEqual(cryptjson.text_decode(mod.merge_routes(cryptjson.text_encode(b'@1:A#@2:B'),None)),b'@1:A#@2:B')
if __name__=='__main__':unittest.main()
