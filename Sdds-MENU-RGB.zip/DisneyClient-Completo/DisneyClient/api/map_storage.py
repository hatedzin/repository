import re
from aiohttp import web
from utils import cryptjson
from .common import authorize

def merge_routes(shared,personal):
    routes={}
    for encoded in [shared,personal]:
        if not encoded:continue
        for chunk in cryptjson.text_decode(encoded).split(b'#'):
            if not chunk:continue
            code,payload=chunk.split(b':',1)
            code=b'@'+code.lstrip(b'@')
            routes[code]=payload
    return cryptjson.text_encode(b'#'.join(code+b':'+payload for code,payload in routes.items()))

class MapStorage(web.View):
    async def get(self):
        user = await authorize(self.request, allow_cookie=True)
        data = await self.request.app['db'].get_data(user['user_id'])
        config = self.request.app['config']
        if user['level'] not in config.get('storage_allowed_levels', []):
            raise web.HTTPForbidden()
        shared=(self.request.app['root']/'public/maps.json').read_bytes()
        personal=data.get('map_data') if config.get('map_storage_fetch') else None
        return web.Response(body=merge_routes(shared,personal) if personal else shared)

    async def post(self):
        user = await authorize(self.request, allow_cookie=True)
        if user['level'] not in self.request.app['config'].get('storage_allowed_levels', []):
            raise web.HTTPForbidden()
        form = await self.request.post()
        code, info = form.get('code'), form.get('info')
        method = self.request.query.get('method')
        if not code or not re.fullmatch(r'@?[0-9]+', code) or method not in {'save','del'}:
            raise web.HTTPBadRequest()
        code='@'+code.lstrip('@')
        # Row lock prevents concurrent read/modify/write losing a map update.
        async with self.request.app['db'].transaction() as cur:
            await cur.execute('INSERT INTO user_data(user_id) VALUES(%s) ON DUPLICATE KEY UPDATE user_id=user_id', (user['user_id'],))
            await cur.execute('SELECT map_data FROM user_data WHERE user_id=%s FOR UPDATE', (user['user_id'],))
            previous = (await cur.fetchone())['map_data']
            raw = cryptjson.text_decode(previous) if previous else b''
            chunks = [p for p in raw.split(b'#') if p and not p.startswith(code.encode() + b':')]
            if method == 'save':
                if not info:
                    raise web.HTTPBadRequest()
                chunks.append(code.encode() + b':' + cryptjson.text_decode(info))
            await cur.execute('UPDATE user_data SET map_data=%s WHERE user_id=%s', (cryptjson.text_encode(b'#'.join(chunks)), user['user_id']))
        return web.Response(status=204)
