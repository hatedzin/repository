// ActionScript 3 / WeightController.as / Flash Player 10.3+ / physical body mass percentage with native mass-data restoration
package disney {
    import flash.display.MovieClip;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.utils.Dictionary;
    public class WeightController {
        private static var active:Dictionary=new Dictionary(true);
        private var root:MovieClip;
        private var ui:Object;
        private var original:Object;
        public var message:String="Peso: 100% = original";
        public function WeightController(target:MovieClip){root=target;}
        public static function tick(target:MovieClip):void {
            var controller:WeightController=active[target] as WeightController;
            if(!controller){controller=new WeightController(target);active[target]=controller;}
            controller.update();
        }
        private function restore(k:Object):void {
            if(!original)return;
            var body:Object=original.body;
            try {
                var current:Number=Number(body[k.mass_body_mass]);
                if(Math.abs(current-original.mass*original.ratio)<0.00001) {
                    writeMass(body,k,original.mass,original.inertia,original.x,original.y);
                    if(Math.abs(Number(body[k.mass_body_mass])-original.mass)>0.00001)return;
                }
            }catch(ignored:Error){}
            original=null;
        }
        private function writeMass(body:Object,k:Object,mass:Number,inertia:Number,x:Number,y:Number):void {
            var Data:Class=k.mass_data_class as Class;
            var VectorType:Class=k.app_domain.applicationDomain.getDefinition(String(k.b2vec2)) as Class;
            var data:Object=new Data();data[k.mass_data_mass]=mass;data[k.mass_data_inertia]=inertia;
            data[k.mass_data_center]=new VectorType(x,y);body[k.mass_set](data);
        }
        public function update():void {
            var k:Object=root["Keys"];
            try {
                var nextUi:Object=root["Interface"];
                if(nextUi && nextUi!==ui && nextUi["mass_input"] && k) {
                    ui=nextUi;
                    ui["mass_input"][k.text_field].text="100";
                    for each(var entry:Object in ui["keys"])if(entry.ui_input===ui["mass_input"] && entry.ui)entry.ui[k.text_field2].text="Peso do rato (%)";
                }
                if(!root["mass_reduction"]){restore(k);message=original ? "Peso: aguardando restauracao" : "Peso: original restaurado";return;}
                for each(var key:String in ["mass_data_class","mass_set","mass_body_mass","mass_body_inertia","mass_data_mass","mass_data_inertia","mass_data_center","mass_body_sweep","mass_sweep_center"])if(!k || !k[key])throw new Error("Mass symbols unavailable",2013);
                var p:Object=root["tfm"] ? root["tfm"][k.player] : null;
                if(!p || !p[k.player_clip] || p[k.is_dead]){restore(k);return;}
                var body:Object=p[k.player_physics];if(!body)return;
                if(original && original.body!==body)restore(k);
                if(!original) {
                    var center:Object=body[k.mass_body_sweep][k.mass_sweep_center];
                    original={body:body,mass:Number(body[k.mass_body_mass]),inertia:Number(body[k.mass_body_inertia]),x:Number(center[k.pos_x]),y:Number(center[k.pos_y]),ratio:1};
                    if(!isFinite(original.mass)||original.mass<=0||!isFinite(original.inertia)||!isFinite(original.x)||!isFinite(original.y))throw new Error("Invalid mass body",2013);
                }
                if(!ui || !ui["mass_input"])return;
                var percent:Number=Number(String(ui["mass_input"][k.text_field].text).replace(",","."));
                if(!isFinite(percent)||percent<1||percent>500)throw new Error("Mass percentage must be 1 to 500",2014);
                var ratio:Number=percent/100;
                if(Math.abs(original.ratio-ratio)>0.000001) {
                    writeMass(body,k,original.mass*ratio,original.inertia*ratio,original.x,original.y);
                    if(Math.abs(Number(body[k.mass_body_mass])-original.mass*ratio)<0.00001)original.ratio=ratio;
                }
                message="Peso: "+percent+"% | massa "+Number(body[k.mass_body_mass]).toFixed(2);
            }catch(error:Error) {
                root["mass_reduction"]=false;restore(k);
                message=error.errorID==2014 ? "Peso: informe 1 a 500%" : "Peso: campos nativos indisponiveis #"+error.errorID;
                try {for each(var entry:Object in ui["keys"])if(entry.ui_input===ui["mass_input"] && entry.ui && entry.ui[k.is_selected])entry.ui[k.check_button_exec](new MouseEvent("mouseDown"));}catch(ignored:Error){}
                var line:TextField=root.stage ? root.stage.getChildByName("sddsConnectionStatus") as TextField : null;if(line)line.text=message;
            }
        }
    }
}
