@echo off
setlocal
call "%~dp0INICIAR_CLIENT.bat" --site %*
exit /b %errorlevel%
