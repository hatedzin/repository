@echo off
setlocal
call "%~dp0INICIAR_CLIENT.bat" %*
exit /b %errorlevel%
