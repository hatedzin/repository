# ASTRO V4 — Auto morte em milissegundos

Extraia em uma pasta nova. Feche o Flash Player e encerre o inicializador antigo com Ctrl+C antes de executar INICIAR_TUDO.bat da nova pasta.
Build: astro-v4-auto-morte-ms-abaixo-status-v1.

Em Farm, role ate a mensagem Opcoes desligadas. O novo Auto morte fica ABAIXO dessa mensagem.
Marque o circulo e informe Tempo (ms). O padrao e 5000 ms = 5 segundos.
A faixa e de 500 a 600000 ms, igual a faixa do Farm Time existente.
O tempo reinicia ao ativar, editar o campo, renascer ou trocar de mapa.
Ha uma solicitacao nativa de morte por vida. Desativar cancela o temporizador.
Robot ou gravacao pausam a contagem e ela recomeca ao terminar.

Auto Win (queijo > toca), seu Farm Time e sua sequencia foram mantidos.
O novo controle tem tempo proprio e nao desliga o Auto Win. Ativar o Auto Win tambem nao desliga o novo temporizador.

Validacao: 21 verificacoes de menu/temporizador ms e 50 verificacoes de regressao de Rato leve e Auto Win, executadas no Ruffle com transporte simulado. Conferencia visual do controle sob a mensagem no menu moderno.
A resposta de uma sala online no Flash Player do Windows ainda precisa ser validada.
