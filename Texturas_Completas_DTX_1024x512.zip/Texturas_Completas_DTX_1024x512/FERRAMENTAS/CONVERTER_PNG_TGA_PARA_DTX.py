"""Native encoder for LithTech Jupiter DTX v-5 / BPP_32, with standard 4 mipmaps.

File layout follows the public tools/shared/engine/dtxmgr.h and dtxmgr.cpp.
The implementation is original; no engine implementation is copied here.
"""
from pathlib import Path
import struct
import numpy as np
from PIL import Image

HEADER=struct.Struct('<IiHHHHii12s128s')
assert HEADER.size==164

def mip_chain(rgba,count=4):
    if rgba.dtype!=np.uint8 or rgba.ndim!=3 or rgba.shape[2]!=4:
        raise ValueError('RGBA uint8 expected')
    levels=[np.ascontiguousarray(rgba)]
    for _ in range(1,count):
        previous=levels[-1].astype(np.uint16)
        h,w=previous.shape[:2]
        if h<2 or w<2 or h%2 or w%2:raise ValueError('Invalid mip dimensions')
        # Exact integer 2x2 box average used by the original DTX tools.
        level=((previous[0::2,0::2]+previous[0::2,1::2]+
                previous[1::2,0::2]+previous[1::2,1::2])>>2).astype(np.uint8)
        levels.append(level)
    return levels

def write_dtx(source,destination):
    with Image.open(source) as image:
        if image.size!=(1024,512):raise ValueError(f'Expected 1024x512, got {image.size}')
        rgba=np.array(image.convert('RGBA'))
    levels=mip_chain(rgba,4)
    extra=bytearray(12)
    extra[1]=4 # Runtime mip count, explicit.
    extra[2]=3 # BPP_32, uncompressed BGRA8888.
    # Resource type 0, v-5, dimensions, 4 mipmaps, no sections,
    # DTX_SECTIONSFIXED=8, no surface flags, no special command string.
    header=HEADER.pack(0,-5,1024,512,4,0,8,0,bytes(extra),b'\0'*128)
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix('.pending')
    with temporary.open('wb') as out:
        out.write(header)
        for level in levels:out.write(level[:,:,[2,1,0,3]].tobytes())
    expected=164+sum(level.size for level in levels)
    if temporary.stat().st_size!=expected:raise ValueError('Invalid serialized size')
    temporary.replace(destination)
    return {'width':1024,'height':512,'mipmaps':4,'bytes':expected,
            'base_alpha_min':int(rgba[:,:,3].min()),'base_alpha_max':int(rgba[:,:,3].max()),
            'alpha_pixels':int((rgba[:,:,3]<255).sum())}

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description='PNG/TGA -> DTX Jupiter v-5 BGRA8888 (1024x512)')
    parser.add_argument('source');parser.add_argument('destination')
    args=parser.parse_args();print(write_dtx(args.source,args.destination))
