"""Strict independent field-by-field reader for the delivered DTX profile.
No dependency on the encoder, its header struct, or its mip generator.
"""
from pathlib import Path
import struct
from PIL import Image

def read_dtx(path):
    data=Path(path).read_bytes()
    if len(data)<164:raise ValueError('Truncated header')
    def u16(offset):return int.from_bytes(data[offset:offset+2],'little',signed=False)
    def u32(offset):return int.from_bytes(data[offset:offset+4],'little',signed=False)
    if u32(0)!=0 or int.from_bytes(data[4:8],'little',signed=True)!=-5:raise ValueError('Wrong DTX resource/version')
    width,height=u16(8),u16(10)
    count,sections=u16(12),u16(14)
    if (width,height)!=(1024,512):raise ValueError('Wrong base dimensions')
    if count!=4 or sections!=0:raise ValueError('Unexpected mip/section count')
    if u32(16)!=8 or u32(20)!=0:raise ValueError('Unexpected flags')
    if data[25]!=4 or data[26]!=3 or data[28]!=0:raise ValueError('Wrong runtime mip count, pixel format or UI offset')
    if any(data[36:164]):raise ValueError('Unexpected command string')
    offset=164;images=[]
    for i in range(count):
        w,h=width>>i,height>>i
        size=w*h*4
        if offset+size>len(data):raise ValueError('Truncated pixel payload')
        images.append(Image.frombytes('RGBA',(w,h),data[offset:offset+size],'raw','BGRA'))
        offset+=size
    if offset!=len(data):raise ValueError('Unexpected trailing bytes')
    return images

if __name__=='__main__':
    import argparse,json
    parser=argparse.ArgumentParser(description='Validate the DTX v-5 BGRA8888 1024x512 profile delivered in this pack')
    parser.add_argument('file')
    args=parser.parse_args();images=read_dtx(args.file)
    print(json.dumps({'valid':True,'base_size':list(images[0].size),'mipmaps':[list(im.size) for im in images]}))
