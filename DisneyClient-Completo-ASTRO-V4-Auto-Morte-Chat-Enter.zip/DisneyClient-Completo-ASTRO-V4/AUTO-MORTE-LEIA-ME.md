# ASTRO V4 — Auto morte usando o campo de chat e Enter nativo

Feche o Flash Player e encerre o inicializador anterior com Ctrl+C. Extraia em uma pasta nova e execute INICIAR_TUDO.bat.
Build: astro-v4-auto-morte-chat-enter-v1.

Em Farm, abaixo de Opcoes desligadas, ative Auto morte e informe Tempo (ms).
5000 = 5 segundos. A faixa permanece 500 a 600000 ms.
Esta versao coloca /mort no campo de chat do jogo e chama o tratamento nativo do Enter com foco nesse campo. Depois restaura o texto, selecao e foco que estavam no chat. Nao envia o pacote mort diretamente e nao depende do novo simbolo chat_command_handler das versoes anteriores.

Existe uma mensagem propria logo abaixo do campo de tempo: faltam N ms, pausado por Robot ou gravacao, aguardando personagem vivo, /mort enviado pelo chat ou erro. Enviado indica que o metodo nativo foi chamado, e nao confirma sozinho a morte no servidor.
Auto Win e Farm Time preservados. O tempo de Auto morte e separado.

Testes em Ruffle com transporte simulado: 23 verificacoes de tempo e interacao com chat, incluindo texto /mort, Enter, foco correto e restauracao de rascunho/selecao/foco; 50 de regressao de Rato leve e Auto Win.
O metodo de chat do jogo fornecido foi inspecionado. A execucao numa sala online no Flash Player Windows permanece pendente.
