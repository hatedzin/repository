﻿package com.bit101.components
{
    import flash.display.*;
    import flash.events.*;
    import flash.geom.*;

    public class ComboBox extends Component
    {
        protected var _defaultLabel:String = "";
        protected var _dropDownButton:PushButton;
        protected var _items:Array;
        protected var _labelButton:PushButton;
        protected var _list:List;
        protected var _numVisibleItems:int = 6;
        protected var _open:Boolean = false;
        protected var _openPosition:String = "bottom";
        protected var _stage:Stage;
        public static const TOP:String = "top";
        public static const BOTTOM:String = "bottom";

        public function ComboBox(param1:DisplayObjectContainer = null, param2:Number = 0, param3:Number = 0, param4:String = "", param5:Array = null)
        {
            this._defaultLabel = param4;
            this._items = param5;
            addEventListener(Event.ADDED_TO_STAGE, this.onAddedToStage);
            addEventListener(Event.REMOVED_FROM_STAGE, this.onRemovedFromStage);
            super(param1, param2, param3);
            return;
        }// end function

        override protected function init() : void
        {
            super.init();
            setSize(100, 20);
            this.setLabelButtonLabel();
            return;
        }// end function

        override protected function addChildren() : void
        {
            super.addChildren();
            this._list = new List(null, 0, 0, this._items);
            this._list.autoHideScrollBar = true;
            this._list.addEventListener(Event.SELECT, this.onSelect);
            this._labelButton = new PushButton(this, 0, 0, "", this.onDropDown);
            this._dropDownButton = new PushButton(this, 0, 0, "v", this.onDropDown);
            return;
        }// end function

        protected function setLabelButtonLabel() : void
        {
            if (this.selectedItem == null)
            {
                this._labelButton.label = this._defaultLabel;
            }
            else if (this.selectedItem is String)
            {
                this._labelButton.label = this.selectedItem as String;
            }
            else if (this.selectedItem.hasOwnProperty("label") && this.selectedItem.label is String)
            {
                this._labelButton.label = this.selectedItem.label;
            }
            else
            {
                this._labelButton.label = this.selectedItem.toString();
            }
            return;
        }// end function

        protected function removeList() : void
        {
            if (this._stage.contains(this._list))
            {
                this._stage.removeChild(this._list);
            }
            this._stage.removeEventListener(MouseEvent.CLICK, this.onStageClick);
            this._dropDownButton.label = "v";
            return;
        }// end function

        override public function draw() : void
        {
            super.draw();
            this._labelButton.setSize(_width - _height + 1, _height);
            this._labelButton.draw();
            this._dropDownButton.setSize(_height, _height);
            this._dropDownButton.draw();
            this._dropDownButton.x = _width - height;
            this._list.setSize(_width, this._numVisibleItems * this._list.listItemHeight);
            return;
        }// end function

        public function addItem(param1:Object) : void
        {
            this._list.addItem(param1);
            return;
        }// end function

        public function addItemAt(param1:Object, param2:int) : void
        {
            this._list.addItemAt(param1, param2);
            return;
        }// end function

        public function removeItem(param1:Object) : void
        {
            this._list.removeItem(param1);
            return;
        }// end function

        public function removeItemAt(param1:int) : void
        {
            this._list.removeItemAt(param1);
            return;
        }// end function

        public function removeAll() : void
        {
            this._list.removeAll();
            return;
        }// end function

        protected function onDropDown(event:MouseEvent) : void
        {
            var _loc_2:Point = null;
            this._open = !this._open;
            if (this._open)
            {
                _loc_2 = new Point();
                if (this._openPosition == BOTTOM)
                {
                    _loc_2.y = _height;
                }
                else
                {
                    _loc_2.y = (-this._numVisibleItems) * this._list.listItemHeight;
                }
                _loc_2 = this.localToGlobal(_loc_2);
                this._list.move(_loc_2.x, _loc_2.y);
                this._stage.addChild(this._list);
                this._stage.addEventListener(MouseEvent.CLICK, this.onStageClick);
                this._dropDownButton.label = "^";
            }
            else
            {
                this.removeList();
            }
            return;
        }// end function

        protected function onStageClick(event:MouseEvent) : void
        {
            if (event.target == this._dropDownButton || event.target == this._labelButton)
            {
                return;
            }
            if (new Rectangle(this._list.x, this._list.y, this._list.width, this._list.height).contains(event.stageX, event.stageY))
            {
                return;
            }
            this._open = false;
            this.removeList();
            return;
        }// end function

        protected function onSelect(event:Event) : void
        {
            this._open = false;
            this._dropDownButton.label = "v";
            if (stage != null && stage.contains(this._list))
            {
                stage.removeChild(this._list);
            }
            this.setLabelButtonLabel();
            dispatchEvent(event);
            return;
        }// end function

        protected function onAddedToStage(event:Event) : void
        {
            this._stage = stage;
            return;
        }// end function

        protected function onRemovedFromStage(event:Event) : void
        {
            this.removeList();
            return;
        }// end function

        public function set selectedIndex(param1:int) : void
        {
            this._list.selectedIndex = param1;
            this.setLabelButtonLabel();
            return;
        }// end function

        public function get selectedIndex() : int
        {
            return this._list.selectedIndex;
        }// end function

        public function set selectedItem(param1:Object) : void
        {
            this._list.selectedItem = param1;
            this.setLabelButtonLabel();
            return;
        }// end function

        public function get selectedItem() : Object
        {
            return this._list.selectedItem;
        }// end function

        public function set defaultColor(param1:uint) : void
        {
            this._list.defaultColor = param1;
            return;
        }// end function

        public function get defaultColor() : uint
        {
            return this._list.defaultColor;
        }// end function

        public function set selectedColor(param1:uint) : void
        {
            this._list.selectedColor = param1;
            return;
        }// end function

        public function get selectedColor() : uint
        {
            return this._list.selectedColor;
        }// end function

        public function set rolloverColor(param1:uint) : void
        {
            this._list.rolloverColor = param1;
            return;
        }// end function

        public function get rolloverColor() : uint
        {
            return this._list.rolloverColor;
        }// end function

        public function set listItemHeight(param1:Number) : void
        {
            this._list.listItemHeight = param1;
            invalidate();
            return;
        }// end function

        public function get listItemHeight() : Number
        {
            return this._list.listItemHeight;
        }// end function

        public function set openPosition(param1:String) : void
        {
            this._openPosition = param1;
            return;
        }// end function

        public function get openPosition() : String
        {
            return this._openPosition;
        }// end function

        public function set defaultLabel(param1:String) : void
        {
            this._defaultLabel = param1;
            this.setLabelButtonLabel();
            return;
        }// end function

        public function get defaultLabel() : String
        {
            return this._defaultLabel;
        }// end function

        public function set numVisibleItems(param1:int) : void
        {
            this._numVisibleItems = Math.max(1, param1);
            invalidate();
            return;
        }// end function

        public function get numVisibleItems() : int
        {
            return this._numVisibleItems;
        }// end function

        public function set items(param1:Array) : void
        {
            this._list.items = param1;
            return;
        }// end function

        public function get items() : Array
        {
            return this._list.items;
        }// end function

        public function set listItemClass(param1:Class) : void
        {
            this._list.listItemClass = param1;
            return;
        }// end function

        public function get listItemClass() : Class
        {
            return this._list.listItemClass;
        }// end function

        public function set alternateColor(param1:uint) : void
        {
            this._list.alternateColor = param1;
            return;
        }// end function

        public function get alternateColor() : uint
        {
            return this._list.alternateColor;
        }// end function

        public function set alternateRows(param1:Boolean) : void
        {
            this._list.alternateRows = param1;
            return;
        }// end function

        public function get alternateRows() : Boolean
        {
            return this._list.alternateRows;
        }// end function

        public function set autoHideScrollBar(param1:Boolean) : void
        {
            this._list.autoHideScrollBar = param1;
            invalidate();
            return;
        }// end function

        public function get autoHideScrollBar() : Boolean
        {
            return this._list.autoHideScrollBar;
        }// end function

        public function get isOpen() : Boolean
        {
            return this._open;
        }// end function

    }
}
