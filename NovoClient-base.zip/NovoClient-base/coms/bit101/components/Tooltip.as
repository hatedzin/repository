﻿package coms.bit101.components
{
    import flash.display.*;
    import flash.events.*;
    import flash.utils.*;
    import flash.text.engine.SpaceJustifier;
	import ChargeurTransformice_fla.*
	
    public class Tooltip extends Panel
    {

		public var _label:Label
		public var _label2:Label
		public var xSprite:Sprite = new Sprite();
		public var _color_:int = 0;
		
        public function Tooltip(param1:DisplayObjectContainer = null,param2:String = "pgiex",param3:int = 1,param4:int = 0)
        {
			var Obje1 = param1;
			for(var i:int = 0; i<param3; i++)
			{
				Obje1 = Obje1.parent
			}
			super(Obje1, 5, 2);
			if(param2.indexOf("remium") != -1)
			{
				_color_ = 0x16dbff
			}
			else if(param2.indexOf("ERROR") != -1)
			{
				_color_ = 0xff0000
			}
			else
			{
				_color_ = 12238127
			}
				
				
				_label = new Label(xSprite,5,2,param2,-1,_color_)
				super.addChild(xSprite)
				if(param4 == 3)
				{
					_label2 = new Label(xSprite,_label.width + _label.x + 0,2,"[Pro]",-1,0x3edbf0)
				}
				else if(param4 == 1)
				{
					_label2 = new Label(xSprite,_label.width + _label.x + 0,2,"[Free]",-1,0xffffff)
				}
				else if(param4 == 2)
				{
					_label2 = new Label(xSprite,_label.width + _label.x + 0,2,"[Plus]",-1,0xffc93c)
				}
				//_label
				super.width = xSprite.width + 8
				super.height = xSprite.height + 4
				super.afficherFond = true
				super.visible = false;
			
				param1.addEventListener(MouseEvent.MOUSE_MOVE,function()
										{
											if(TransformiceChargeur.instance.stage.mouseX + xSprite.width + 14 > TransformiceChargeur.instance.stage.stageWidth)
											{
												x = TransformiceChargeur.instance.stage.stageWidth - xSprite.width - 8;
											}
											else
											{
												x = TransformiceChargeur.instance.stage.mouseX;
											}
										
											if(TransformiceChargeur.instance.stage.mouseY + xSprite.height + 10 > TransformiceChargeur.instance.stage.stageHeight)
											{
												y = TransformiceChargeur.instance.stage.stageHeight - xSprite.height -4;
											}
											else
											{
												y = TransformiceChargeur.instance.stage.mouseY + 25;
											}
											
											
											TransformiceChargeur.instance.stage.addChild(xSprite.parent.parent)
											visible = true;
										})
				param1.addEventListener(MouseEvent.MOUSE_OUT,function()
										{
											if(!focusedToPanel)
											{
												visible = false;
											}
											
											//IMAGE_1.visible = false;
										})
			xSprite.parent.parent.addEventListener(MouseEvent.MOUSE_MOVE,function()
										{
											focusedToPanel=true
											visible = true;
											//IMAGE_1.visible = false;
										})
			xSprite.parent.parent.addEventListener(MouseEvent.MOUSE_OUT,function()
										{
											if(focusedToPanel)
											{
												focusedToPanel=!true
											visible = !true;
											}
											
											//IMAGE_1.visible = false;
										})
			
			return;
        }// end function
		public var focusedToPanel:Boolean = false;
		public function set text(param1:String)
		{
			xSprite.removeChildAt(0)
			_label = new Label(xSprite,5,2,param1,-1,12238127)
			super.width = xSprite.width + 10
			super.height = xSprite.height + 4
		}
    }
}
