﻿package coms.bit101.components
{
    import flash.display.*;
    import flash.events.*;
    import flash.filters.*;
	import ChargeurTransformice_fla.*;
    public class CheckBox extends Component
    {
        protected var _back:Sprite;
        protected var _button:Sprite;
        protected var _label:Label;
        protected var _labelText:String = "";
        protected var _selected:Boolean = false;
        private static var filtreCheckBox:Array = new Array(new BevelFilter(1, 45, 0, 1, 6325657, 1, 1, 1, 1, 3));
		public var tik1:Sprite;
		public var tik2:Sprite;
		public var tik3:Sprite;
		public var newCheckbox:Boolean;
		public var colorC:int = -1;
		
        public function CheckBox(param1:DisplayObjectContainer = null, param2:Number = 0, param3:Number = 0, param4:String = "", param5:Function = null, param6:Boolean = true, param7:Boolean = false)
        {
            this._labelText = param4;
			if(param6)
			{
				newCheckbox = param6
				Style.effetLumiere(this,true,true)
			}
			if(param7)
			{
				colorC = 0x16dbff
			}
            super(param1, param2, param3);
            if (param5 != null)
            {
                addEventListener(MouseEvent.CLICK, param5);
            }
			
            return;
        }// end function

        override protected function init() : void
        {
            super.init();
            buttonMode = true;
            useHandCursor = true;
            mouseChildren = false;
            return;
        }// end function

        override protected function addChildren() : void
        {
            this._back = new Sprite();
            this._back.graphics.beginFill(2306616);
			if(newCheckbox)
			{
				this._back.graphics.drawRect(1, 1, 14, 14);
			}
			else
			{
				this._back.graphics.drawCircle(6, 6, 6);
			}
            this._back.graphics.endFill();
            this._back.filters = filtreCheckBox;
            addChild(this._back);
			
			////////
			if(newCheckbox)
			{
				this.tik1 = new Sprite();
				this.tik1.graphics.beginFill(11059144);
				this.tik1.graphics.drawRoundRect(1, 1, 6, 2, 3);
				this.tik1.rotation = 45
				this.tik1.graphics.endFill();
				
				this.tik2 = new Sprite();
				this.tik2.graphics.beginFill(11059144);
				this.tik2.graphics.drawRoundRect(0, 0, 12, 2, 4);
				this.tik2.rotation = 125
	
				_button = new Sprite();
				_button.addChild(tik1)
				_button.addChild(tik2)
				tik2.x += 10
				tik2.y -= 2
				
				_button.x += 4
				_button.y += 6
				_button.width -= 1
				_button.height -= 1
			}
			else
			{
				this._button = new Sprite();
            	this._button.graphics.beginFill(11059144);
            	this._button.graphics.drawCircle(6, 6, 3);
			}
			
			////////
			
            
            this._button.visible = false;
            addChild(this._button);
            this._label = new Label(this, 20, 10, this._labelText,-1,colorC);
            this.draw();
            addEventListener(MouseEvent.CLICK, this.onClick);
            return;
        }// end function

        override public function draw() : void
        {
            super.draw();
            this._label.text = this._labelText;
            this._label.draw();
			if(newCheckbox)
			{
				this._label.x = 18;
            	this._label.y = -1//(12 - this._label.height) / 2;
			}
			else
			{
				this._label.x = 13;
            	this._label.y = (12 - this._label.height) / 2;
			}
            
            _width = this._label.width + 12;
            _height = 10;
            return;
        }// end function

        protected function onClick(event:MouseEvent) : void
        {
            this._selected = !this._selected;
            this._button.visible = this._selected;
            return;
        }// end function

        public function set label(param1:String) : void
        {
            this._labelText = param1;
            invalidate();
            return;
        }// end function

        public function get label() : String
        {
            return this._labelText;
        }// end function

        public function set selected(param1:Boolean) : void
        {
            this._selected = param1;
            this._button.visible = this._selected;
            return;
        }// end function

        public function get selected() : Boolean
        {
            return this._selected;
        }// end function

        override public function set enabled(param1:Boolean) : void
        {
            super.enabled = param1;
            mouseChildren = false;
            return;
        }// end function

    }
}
