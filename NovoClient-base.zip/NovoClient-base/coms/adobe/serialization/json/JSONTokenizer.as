﻿package coms.adobe.serialization.json
{
	import ChargeurTransformice_fla.*
   public class JSONTokenizer
   {
       
      
      private var strict:Boolean;
      
      private var obj:Object;
      
      private var jsonString:String;
      
      private var loc:int;
      
      private var ch:String;
      
      private const controlCharsRegExp:RegExp = /[\x00-\x1F]/;
      
      public function JSONTokenizer(param1:String, param2:Boolean)
      {
         super();
         jsonString = param1;
         strict = param2;
         loc = 0;
         nextChar();
      }
      
      public function getNextToken() : JSONToken
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc1_:JSONToken = null;
         skipIgnored();
         switch(ch)
         {
            case "{":
               _loc1_ = JSONToken.create(JSONTokenType.LEFT_BRACE,ch);
               nextChar();
               break;
            case "}":
               _loc1_ = JSONToken.create(JSONTokenType.RIGHT_BRACE,ch);
               nextChar();
               break;
            case "[":
               _loc1_ = JSONToken.create(JSONTokenType.LEFT_BRACKET,ch);
               nextChar();
               break;
            case "]":
               _loc1_ = JSONToken.create(JSONTokenType.RIGHT_BRACKET,ch);
               nextChar();
               break;
            case ",":
               _loc1_ = JSONToken.create(JSONTokenType.COMMA,ch);
               nextChar();
               break;
            case ":":
               _loc1_ = JSONToken.create(JSONTokenType.COLON,ch);
               nextChar();
               break;
            case "t":
               _loc2_ = "t" + nextChar() + nextChar() + nextChar();
               if(_loc2_ == "true")
               {
                  _loc1_ = JSONToken.create(JSONTokenType.TRUE,true);
                  nextChar();
               }
               else
               {
                  parseError("Expecting \'true\' but found " + _loc2_);
               }
               break;
            case "f":
               _loc3_ = "f" + nextChar() + nextChar() + nextChar() + nextChar();
               if(_loc3_ == "false")
               {
                  _loc1_ = JSONToken.create(JSONTokenType.FALSE,false);
                  nextChar();
               }
               else
               {
                  parseError("Expecting \'false\' but found " + _loc3_);
               }
               break;
            case "n":
               if((_loc4_ = "n" + nextChar() + nextChar() + nextChar()) == "null")
               {
                  _loc1_ = JSONToken.create(JSONTokenType.NULL,null);
                  nextChar();
               }
               else
               {
                  parseError("Expecting \'null\' but found " + _loc4_);
               }
               break;
            case "N":
               if((_loc5_ = "N" + nextChar() + nextChar()) == "NaN")
               {
                  _loc1_ = JSONToken.create(JSONTokenType.NAN,NaN);
                  nextChar();
               }
               else
               {
                  parseError("Expecting \'NaN\' but found " + _loc5_);
               }
               break;
            case "\"":
               _loc1_ = readString();
               break;
            default:
               if(isDigit(ch) || ch == "-")
               {
                  _loc1_ = readNumber();
               }
               else if(ch == "")
               {
                  _loc1_ = null;
               }
               else
               {
                  parseError("Unexpected " + ch + " encountered");
               }
         }
         return _loc1_;
      }
      
      private final function readString() : JSONToken
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc1_:int = loc;
         while(true)
         {
            _loc1_ = jsonString.indexOf("\"",_loc1_);
            if(_loc1_ >= 0)
            {
               _loc3_ = 0;
               _loc4_ = _loc1_ - 1;
               while(jsonString.charAt(_loc4_) == "\\")
               {
                  _loc3_++;
                  _loc4_--;
               }
               if((_loc3_ & 1) == 0)
               {
                  break;
               }
               _loc1_++;
            }
            else
            {
               parseError("Unterminated string literal");
            }
         }
         var _loc2_:JSONToken = JSONToken.create(JSONTokenType.STRING,unescapeString(jsonString.substr(loc,_loc1_ - loc)));
         loc = _loc1_ + 1;
         nextChar();
         return _loc2_;
      }
      
      public function unescapeString(param1:String) : String
      {
         var _loc4_:int = 0;
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:String = null;
         if(strict && controlCharsRegExp.test(param1))
         {
            parseError("String contains unescaped control character (0x00-0x1F)");
         }
         var _loc2_:* = "";
         var _loc3_:int = 0;
         _loc4_ = 0;
         var _loc5_:int = param1.length;
         do
         {
            _loc3_ = param1.indexOf("\\",_loc4_);
            if(_loc3_ < 0)
            {
               _loc2_ += param1.substr(_loc4_);
               break;
            }
            _loc2_ += param1.substr(_loc4_,_loc3_ - _loc4_);
            _loc4_ = _loc3_ + 2;
            _loc6_ = param1.charAt(_loc3_ + 1);
            switch(_loc6_)
            {
               case "\"":
                  _loc2_ += _loc6_;
                  break;
               case "\\":
                  _loc2_ += _loc6_;
                  break;
               case "n":
                  _loc2_ += "\n";
                  break;
               case "r":
                  _loc2_ += "\r";
                  break;
               case "t":
                  _loc2_ += "\t";
                  break;
               case "u":
                  _loc7_ = "";
                  if((_loc8_ = _loc4_ + 4) > _loc5_)
                  {
                     parseError("Unexpected end of input.  Expecting 4 hex digits after \\u.");
                  }
                  _loc9_ = _loc4_;
                  while(_loc9_ < _loc8_)
                  {
                     _loc10_ = param1.charAt(_loc9_);
                     if(!isHexDigit(_loc10_))
                     {
                        parseError("Excepted a hex digit, but found: " + _loc10_);
                     }
                     _loc7_ += _loc10_;
                     _loc9_++;
                  }
                  _loc2_ += String.fromCharCode(parseInt(_loc7_,16));
                  _loc4_ = _loc8_;
                  break;
               case "f":
                  _loc2_ += "\f";
                  break;
               case "/":
                  _loc2_ += "/";
                  break;
               case "b":
                  _loc2_ += "\b";
                  break;
               default:
                  _loc2_ += "\\" + _loc6_;
                  break;
            }
         }
         while(_loc4_ < _loc5_);
         
         return _loc2_;
      }
      
      private final function readNumber() : JSONToken
      {
         var _loc1_:* = "";
         if(ch == "-")
         {
            _loc1_ += "-";
            nextChar();
         }
         if(!isDigit(ch))
         {
            parseError("Expecting a digit");
         }
         if(ch == "0")
         {
            _loc1_ += ch;
            nextChar();
            if(isDigit(ch))
            {
               parseError("A digit cannot immediately follow 0");
            }
            else if(!strict && ch == "x")
            {
               _loc1_ += ch;
               nextChar();
               if(isHexDigit(ch))
               {
                  _loc1_ += ch;
                  nextChar();
               }
               else
               {
                  parseError("Number in hex format require at least one hex digit after \"0x\"");
               }
               while(isHexDigit(ch))
               {
                  _loc1_ += ch;
                  nextChar();
               }
            }
         }
         else
         {
            while(isDigit(ch))
            {
               _loc1_ += ch;
               nextChar();
            }
         }
         if(ch == ".")
         {
            _loc1_ += ".";
            nextChar();
            if(!isDigit(ch))
            {
               parseError("Expecting a digit");
            }
            while(isDigit(ch))
            {
               _loc1_ += ch;
               nextChar();
            }
         }
         if(ch == "e" || ch == "E")
         {
            _loc1_ += "e";
            nextChar();
            if(ch == "+" || ch == "-")
            {
               _loc1_ += ch;
               nextChar();
            }
            if(!isDigit(ch))
            {
               parseError("Scientific notation number needs exponent value");
            }
            while(isDigit(ch))
            {
               _loc1_ += ch;
               nextChar();
            }
         }
         var _loc2_:Number = Number(_loc1_);
         if(isFinite(_loc2_) && !isNaN(_loc2_))
         {
            return JSONToken.create(JSONTokenType.NUMBER,_loc2_);
         }
         parseError("Number " + _loc2_ + " is not valid!");
         return null;
      }
      
      private final function nextChar() : String
      {
         return ch = jsonString.charAt(loc++);
      }
      
      private final function skipIgnored() : void
      {
         var _loc1_:int = 0;
         do
         {
            _loc1_ = loc;
            skipWhite();
            skipComments();
         }
         while(_loc1_ != loc);
         
      }
      
      private function skipComments() : void
      {
         if(ch == "/")
         {
            nextChar();
            switch(ch)
            {
               case "/":
                  do
                  {
                     nextChar();
                  }
                  while(ch != "\n" && ch != "");
                  
                  nextChar();
                  break;
               case "*":
                  nextChar();
                  while(true)
                  {
                     if(ch == "*")
                     {
                        nextChar();
                        if(ch == "/")
                        {
                           break;
                        }
                     }
                     else
                     {
                        nextChar();
                     }
                     if(ch == "")
                     {
                        parseError("Multi-line comment not closed");
                     }
                  }
                  nextChar();
                  break;
               default:
                  parseError("Unexpected " + ch + " encountered (expecting \'/\' or \'*\' )");
            }
         }
      }
      
      private final function skipWhite() : void
      {
         while(isWhiteSpace(ch))
         {
            nextChar();
         }
      }
      
      private final function isWhiteSpace(param1:String) : Boolean
      {
         if(param1 == " " || param1 == "\t" || param1 == "\n" || param1 == "\r")
         {
            return true;
         }
         if(!strict && param1.charCodeAt(0) == 160)
         {
            return true;
         }
         return false;
      }
      
      private final function isDigit(param1:String) : Boolean
      {
         return param1 >= "0" && param1 <= "9";
      }
      
      private final function isHexDigit(param1:String) : Boolean
      {
         return isDigit(param1) || param1 >= "A" && param1 <= "F" || param1 >= "a" && param1 <= "f";
      }
      
      public final function parseError(param1:String) : void
      {
         throw new JSONParseError(param1,loc,jsonString);
      }
   }
}
