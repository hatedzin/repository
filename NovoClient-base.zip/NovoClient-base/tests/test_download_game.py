"""Standard-library tests with a local HTTP server, never a live game service."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import struct
import sys
import tempfile
import threading
import unittest
import urllib.error
import zlib
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from download_game import download, validate_swf

# These bytes are a structural SWF fixture, not a playable game.
BODY = b'local-test-body'
FWS = b'FWS' + bytes([10]) + struct.pack('<I', len(BODY)+8) + BODY
CWS = b'CWS' + bytes([10]) + struct.pack('<I', len(BODY)+8) + zlib.compress(BODY)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def do_GET(self):
        if self.path == '/denied':
            self.send_error(403)
            return
        if self.path == '/redirect':
            self.send_response(302);self.send_header('Location','/game');self.end_headers()
            return
        body = b'<html>not a SWF</html>' if self.path == '/html' else CWS
        self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers()
        self.wfile.write(body)

class DownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever);cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.server.server_port}'
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join()
    def test_fws_and_cws(self):
        for data in (FWS,CWS):
            self.assertEqual(validate_swf(data)['swf_format'],10)
    def test_invalid_payloads(self):
        for data in (b'{}',CWS[:-3],FWS[:-1],CWS+b'junk'):
            with self.assertRaises(ValueError):validate_swf(data)
    def test_download_redirect_and_no_blind_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            dest=Path(folder)/'game.swf'
            download(self.url+'/redirect',dest)
            self.assertEqual(dest.read_bytes(),CWS)
            with self.assertRaises(FileExistsError):download(self.url+'/game',dest)
    def test_invalid_html_preserves_existing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            dest=Path(folder)/'game.swf';dest.write_bytes(FWS)
            with self.assertRaises(ValueError):download(self.url+'/html',dest,replace=True)
            self.assertEqual(dest.read_bytes(),FWS)
            self.assertEqual(list(Path(folder).glob('*.tmp')),[])
    def test_http_denial_does_not_publish_file(self):
        with tempfile.TemporaryDirectory() as folder:
            dest=Path(folder)/'game.swf'
            with self.assertRaises(urllib.error.HTTPError):download(self.url+'/denied',dest)
            self.assertFalse(dest.exists())

if __name__=='__main__':unittest.main()
