package {
    import flash.display.Sprite;
    import flash.text.TextField;
    import flash.text.TextFormat;
    [SWF(width="800",height="400",backgroundColor="#23324A")]
    public class SmokeGame extends Sprite {
        public function SmokeGame() {
            var field:TextField = new TextField();
            field.defaultTextFormat = new TextFormat("_sans",22,0xFFFFFF);
            field.width=760;field.height=100;field.x=20;field.y=30;
            field.text="FIXTURE DE TESTE — não é o Transformice";
            addChild(field);
            trace("SMOKE_GAME_READY");
        }
    }
}
