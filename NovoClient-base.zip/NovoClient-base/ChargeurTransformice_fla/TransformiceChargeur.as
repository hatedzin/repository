package ChargeurTransformice_fla
{
    import flash.display.*;
    import flash.events.*;
    import flash.net.*;
    import flash.system.*;
	import coms.bit101.components.*;
	import ChargeurTransformice_fla.Forms.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
	import flash.external.*;
	
	import coms.adobe.serialization.json.*;
	

    dynamic public class TransformiceChargeur extends MovieClip
    {
		public static var instance:TransformiceChargeur;
        public var hackedAppDomain:LoaderInfo;
        public var _C:MovieClip;
        public var Charge:Number;
        public var Chargeur:Loader;
        public var P:Number;
        public var date:Date;
		
        public var tfm:Object;
        public var tfm2:Object;
		public var maps = new Array();
		
		public var _Dict:Dictionary = new Dictionary();
		public var last_bulle_socket_instance:Object;
        public var last_main_socket_instance:Object;
        
        public var isAIR:Boolean = false;
        
		public var Packets:FPacket;
		public var send_bulle;
		public var mainMenu:Main_menu;
		
		
		public function TransformiceChargeur()
        {
			
			instance = this;
            if (_C == null) {
                _C = new MovieClip();
                _C._B = new MovieClip();
                _C._B.graphics.beginFill(0x4DC9FF);
                _C._B.graphics.drawRect(0, 0, 200, 8);
                _C._B.graphics.endFill();
                _C._K = new MovieClip();
                _C.addChild(_C._B);
                _C.addChild(_C._K);
                _C.x = 300; _C.y = 200;
                addChild(_C);
            }
            addFrameScript(0, frame1);
			
            return;
        }// end function
		
		
	public function getmaprecords()
	{
		if (!clientConfig.maps_url) { return; }
        var _mapLoader:URLLoader = new URLLoader();
        _mapLoader.addEventListener(IOErrorEvent.IO_ERROR, resourceFailed);
        _mapLoader.addEventListener(SecurityErrorEvent.SECURITY_ERROR, resourceFailed);
		_mapLoader.addEventListener(Event.COMPLETE,function(e)
			{
				var _local4:Object = decode_data(e.target.data);
				if (_local4.arr){
					maps = _local4.arr;
					_Dict.maps_len = _local4.len;
				};
			})
		_mapLoader.addEventListener(ProgressEvent.PROGRESS,function(e:ProgressEvent)
		{
			var _progressValue = int(e.bytesLoaded / e.bytesTotal * 100)
			_Dict.AutoPlay.label = "Auto Play (%1%)".replace("%1",_progressValue)
			if(_progressValue == 100)
			{
				_Dict.AutoPlay.enabled = true;
				_Dict.AutoPlay.label = "Auto Play"
			}
			
		})
        _mapLoader.load(new URLRequest(String(clientConfig.maps_url)));
	}// end function
		
		public function decode_data(_arg1:String):Object{
		var _local2:Array;
		var _local4:Array;
		var _local5:Array;
		var _local3:uint;
		if (((!((_arg1.indexOf("@") == -1))) && (!((_arg1.indexOf(":") == -1))))){
			_local2 = new Array();
			_local4 = _arg1.split("#");
			while (_local3 < _local4.length) {
				_local5 = (_local4[_local3] as String).match(/(.*?):(.*)/);
				if (_local5 != null){
					_local2[_local5[1]] = _local5[2];
				};
				_local3++;
			};
		};
		return ({
			"arr":_local2,
			"len":_local3
		});
    }
	
       public function Chargement_Ok(event:Event) : void
        {
            Chargeur.contentLoaderInfo.removeEventListener("complete", Chargement_Ok);
            Chargeur.contentLoaderInfo.removeEventListener("progress", Chargement_EnCours);
            Charge = 0;
            if (contains(_C)) removeChild(_C);
            return;
        }// end function
	
		
		public function onReceive(_arg1:ByteArray, _arg2:String) : void {
		
		_local3 = new ByteArray();
        _local3.writeObject(_arg1);
        _local3.position = 0;
        var packet:ByteArray = _local3.readObject();
		
	    var C:uint = packet.readUnsignedByte();
        var CC:uint = packet.readUnsignedByte();
		var _send:* = true;
		//trace(C + "," + CC)
	    try
		{
			if ((C == 5) && (CC == 2)){
			_Dict.standardForm.disable_auto_play();
			_Dict.map_code_int = 0;
			_Dict.map_code_int = packet.readInt();
            _Dict.map_code = ("@" + _Dict.map_code_int);
			_Dict.miceCount = packet.readShort();
			_Dict.round_code = packet.readByte();
			_local20 = packet.readInt();
            _local21 = "";
			if(_Dict.sendRoomInformation)
			{
				sendChatMessage("<R>Map code: <J>%1</J>, mice: <J>%2".replace("%1",_Dict.map_code).replace("%2",_Dict.miceCount))
			}
			
            if (_local20){
                _local3 = new ByteArray()
                packet.readBytes(_local3, 0, _local20);
                _local3.uncompress("zlib");
                _local3.position = 0;
                _local21 = _local3.readUTFBytes(_local3.length);
            };
			_Dict.current_map_xml = _local21;
			_local24 = packet.readUTF();
            _local25 = packet.readByte();
            _Dict.reverse_map = packet.readBoolean();
			
            _local26 = packet.readBoolean();
            _local27 = packet.readBoolean();
            _local28 = packet.readInt();
            _local29 = packet.readBoolean();
			
			
	    };
		
		
		
		if ((C == 26) && (CC == 2)){
			_local14 = new ByteArray();
			_Dict.playerID = packet.readInt()
			_Dict.playerName = packet.readUTF()
			_local14.writeInt(_Dict.playerID);
			_local14.writeUTF(_Dict.hackClass.mouse_Info("name"));
			_local14.writeInt(packet.readInt());
			_local14.writeByte(packet.readByte());
			_Dict.playerCode = packet.readInt()
			
		};
		
		if(Boolean(_Dict.BlockInventory.selected))
		{
			if ((C == 8) && (CC == 44)){
				_send = false;
			}
			else if ((C == 100) && (CC == 67)){
				_send = false;
			}
		}
	
		
		
		
		
		
		if (C == 144)
		{
			if(CC == 1 && true)//!Boolean(_Dict.isCreated)
			{
				if(_Dict.AutoPlay.selected)
				{
					_Dict.standardForm.stage.addEventListener("enterFrame", _Dict.standardForm.PlayRecord);
				}
				
			}
			if(CC == 2)
			{
				if(_Dict.AutoPlay.selected)
				{
					_Dict.standardForm.stage.addEventListener("enterFrame", _Dict.standardForm.PlayRecord);
				}
			}
			
		}
		if ((C == 8) && (CC == 11)){
			_Dict.shamanList=""
				_Dict.canCreateLoyalty=true
		}
		if ((C == 28) && (CC == 50)){
			_send = false;
		};	
		}
		catch(E:Error)
		{
			trace(E.toString())
		}
		packet.position = 0;
		if (_send) {
			_Dict.Key_.ClassReciv[_Dict.Key_.Recive](packet);
		};
		if(_Dict.canCreateLoyalty && _Dict.ShamanLoyalty.selected)
		{
			_Dict.canCreateLoyalty = false
			for each(var miceList in tfm[_Dict.Key_.ListeJoueur])
					{
						if(miceList[_Dict.Key_.Guide])
						{
							if(_Dict.shamanList == "")
							{
								_Dict.shamanList = miceList[_Dict.Key_.GameName]
							}
							else
							{
								_Dict.shamanList += "," + miceList[_Dict.Key_.GameName]
							}
						}
					}
				if(_Dict.shamanList.indexOf(_Dict.ShamanName.text) == -1)
				{
					_Dict.hackClass.InstantDeath()
				}
				else
				{
					_Dict.LoyaltyWin = true
				}
	}
	}// end function
	
	

		public function PressKey(speed:int=0, key:uint=87):void
        {
            var _local3:uint;
            if (speed > 0)
            {
                _local3 = 0;
                while (_local3 <= speed)
                {
                    this.stage.dispatchEvent(new KeyboardEvent(KeyboardEvent.KEY_DOWN, true, false, 0, key));
                    _local3++;
                };
            };
        }

	
	public var isIn:Boolean = false
	public var isLoaded:Boolean = false
	public function loop_game(_arg1:Event) : void
	{
		if(!mainMenu && !isLoaded)
		{
			isLoaded= true
			setTimeout(PressKey,1000,1,96546541)
		}
	

		
		try
		{
			
			var main_class:* = _Dict.Key_.MoteurReseau[_Dict.Key_["main_socket"]];
			var bulle_class:* = _Dict.Key_.MoteurReseau[_Dict.Key_.Satellite];
			if (((main_class) || (bulle_class))){
			if (((main_class) && (!((main_class == last_main_socket_instance))))){
				main_class[_Dict.Key_.serveur].removeEventListener("socketData", main_class[_Dict.Key_.event_socket_data]);
				main_class[_Dict.Key_.serveur].addEventListener("socketData", Packets.main_socket_data);
				main_class[_Dict.Key_.serveur].addEventListener("close", Packets.close_main_socket);
				last_main_socket_instance = main_class;
			};
			if (((bulle_class) && (!((bulle_class == last_bulle_socket_instance))))){
				bulle_class[_Dict.Key_.serveur].removeEventListener("socketData", bulle_class[_Dict.Key_.event_socket_data]);
				bulle_class[_Dict.Key_.serveur].addEventListener("socketData", Packets.bulle_socket_data);
				bulle_class[_Dict.Key_.serveur].addEventListener("close", Packets.close_bulle_socket);
				last_bulle_socket_instance = bulle_class;
			};
			}; 
			if(!isIn && _Dict.hackClass.myMouse)
			{
				isIn = true
				this.sendChatMessage("<J>Hello <R>%1</R>, welcome to <font color='#00E6FF'>Pgiex Client</font color='#00E6FF'>!".replace("%1",_Dict.hackClass.mouse_Info("name")))
			}
			
			if(_Dict.FarmLoop)
			{
				_Dict.FarmLoop()
			}
			
			if(_Dict.ImmortalMouse.selected)
			{
				tfm[_Dict.Key_.tempsPartieZero] = int.MAX_VALUE;
			}
        
		
		
		}
		catch(E:Error)
		{
		}	
		
	    
		
		
		
	}//end function
	
        public function Chargement_EnCours(event:ProgressEvent) : void
        {
            if (event.bytesLoaded > Charge)
            {
                Charge = event.bytesLoaded;
            }
            P = event.bytesTotal > 0 ? Charge / event.bytesTotal : 0;
            _C._B.width = P * (10 * 20);
			
            return;
        }// end function
	
			
		public function keyboard(event:KeyboardEvent)
		{
			
			var _key:uint = event.keyCode;
			if(!mainMenu)
			{
				mainMenu = new Main_menu("")
				getmaprecords()
				_Dict.hackClass = new Hack_Class(this)
			}
			var _local2:* = _Dict.Key_.chat_class[_Dict.Key_.chat_instance]
            var _local3:*;
			var ui:* = undefined;
			var bot_button:* = undefined;
			if(tfm[_Dict.Key_.ClipJoueur] && _key == Keyboard.ENTER)
			{
				if (_Dict.Key_.chat_class && _local2 && _local2[_Dict.Key_.chat_container]){
                        ParseCommands(_local2[_Dict.Key_.chat_container][_Dict.Key_.chat_text_field].text);
					};
			}
			
			if(tfm[_Dict.Key_.ClipJoueur] && stage.focus == _local2[_Dict.Key_.chat_container][_Dict.Key_.chat_text_field])
			{return}
		
			if(_Dict.standardKeyboard)
			{
				_Dict.standardKeyboard(event)
			}
		
		
			
		}
		
	
		public function ParseCommands(_arg1)
		{
			args = _arg1.split(" ");
			if(args[0] == "/test")
			{
				trace("test1")
			}
		}
		
		
		
			
		public function getToken(param1) 
		{
			var _1:String = param1
			_1 = strReplace(_1,"1","\x01")
			_1 = strReplace(_1,"2","\x02")
			_1 = strReplace(_1,"3","\x03")
			_1 = strReplace(_1,"4","\x04")
			_1 = strReplace(_1,"5","\x05")
			_1 = strReplace(_1,"6","\x06")
			_1 = strReplace(_1,"7","\x07")
			_1 = strReplace(_1,"8","\x08")
			_1 = strReplace(_1,"9","\x09")
			return _1
		}
		
		public function strReplace(str:String, search:String, replace:String):String 
		{
			return str.split(search).join(replace);
		}
		
		public function Plugin_ok(event:Event) : void
        {
			tfm = event.target.content;
			hackedAppDomain = LoaderInfo(event.target);
			if (_Dict.Key_ == null) {
                trace("Game SWF loaded without a symbol profile; legacy features are not enabled.");
                showStatus("SWF carregada. Recursos legados desativados: perfil de símbolos não configurado.");
                statusText.y = 450;
                return;
            }
            try { getClass(); }
            catch (profileError:Error) {
                showStatus("Perfil incompatível com esta SWF: " + profileError.message);
                return;
            }
            // No overrides of third-party length/integrity checks.
			
			Packets = new FPacket(_Dict)
			stage.addEventListener(KeyboardEvent.KEY_DOWN,keyboard)
			
			stage.addEventListener("enterFrame", loop_game);
			
            return;
        }// end function

		public function ApplyMovePlayer(param1:int, param2:int, param3:Boolean, param4:int, param5:int, param6:Boolean) : void
        {
            var _loc_7:* = new ByteArray();
            _loc_7.writeShort(param1);
            _loc_7.writeShort(param2);
            _loc_7.writeBoolean(param3);
            _loc_7.writeShort(param4);
            _loc_7.writeShort(param5);
            _loc_7.writeBoolean(param6);
            Packets.ParsePacket(8, 3, _loc_7);
            return;
        }// end function

        

        
		
	
	
	
	public function getMouseLOC(param1:Boolean = false) :int
	{
		return param1 ? (_Dict.hackClass.myMouse.parent.mouseX) : (_Dict.hackClass.myMouse.parent.mouseY)
	}
	
		public function sendChatMessage(param1)
		{
			var _loc_7:* = new ByteArray();
			_loc_7.writeUTF(param1);
			Packets.ParsePacket(6, 9, _loc_7);
		}
		
        public function parseClass(param1) : Class
        {
			try
			{
				return Class(hackedAppDomain.applicationDomain.getDefinition(param1)) as Class;
			}
			catch(E:Error)
			{
				trace(E.message);
			}
            return null;
        }// end function
		
		

        public var JSONx:Object;
        public var clientConfig:Object = {};
        private var statusText:TextField;

        public function showStatus(message:String):void {
            trace(message);
            if (statusText == null) {
                statusText = new TextField();
                statusText.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFFFF);
                statusText.width = 760; statusText.height = 140;
                statusText.x = 20; statusText.y = 250;
                statusText.multiline = true; statusText.wordWrap = true;
                addChild(statusText);
            }
            statusText.text = message;
        }

        public function resourceFailed(event:Event):void {
            showStatus("Falha ao carregar recurso. Confira client-config.json, arquivos e serviços locais. " + event.type);
        }

        public function loadConfiguration():void {
            showStatus("Carregando configuração local...");
            var configLoader:URLLoader = new URLLoader();
            configLoader.addEventListener(IOErrorEvent.IO_ERROR, resourceFailed);
            configLoader.addEventListener(SecurityErrorEvent.SECURITY_ERROR, resourceFailed);
            configLoader.addEventListener(Event.COMPLETE, function(event:Event):void {
                try {
                    clientConfig = JSON.parse(String(event.target.data));
                    if (!clientConfig.game_url) { throw new Error("game_url é obrigatório"); }
                    if (clientConfig.keylist_url) { getKeylist(); }
                    else {
                        showStatus("Abrindo SWF sem perfil de símbolos. Os recursos legados não estão ativados.");
                        getNewGame(stage, String(clientConfig.game_url));
                    }
                } catch (error:Error) { showStatus("Configuração inválida: " + error.message); }
            });
            configLoader.load(new URLRequest("client-config.json"));
        }

        public function getKeylist(param1:Object = null):void {
            var keyLoader:URLLoader = new URLLoader();
            keyLoader.addEventListener(IOErrorEvent.IO_ERROR, resourceFailed);
            keyLoader.addEventListener(SecurityErrorEvent.SECURITY_ERROR, resourceFailed);
            keyLoader.addEventListener(Event.COMPLETE, function(event:Event):void {
                try {
                    JSONx = JSON.parse(String(event.target.data));
                    if (!(JSONx.keys is Array) || JSONx.keys.length == 0 || JSONx.keys[0] == null) {
                        throw new Error("Perfil deve conter keys: [objeto de símbolos reais]");
                    }
                    _Dict.Key_ = JSONx.keys[0];
                    _Dict.classList = "prep_ui_class,ui_manager_class,ui_sprite2_class,ui_text_field_class,main_ui_class,ui_element_class,chat_class,packet_out_class,CheeHoleC,MoteurReseau,AFKc,ClassPackt,ClassReciv,Puloc,CreationClass,Leve_C,LeveC,MapName,GetContagemSeg,GetFreeMove,CSync,DistanceInvocClass,class_Incorrect,setWing,ChatTribulle,ProxyTribulle,class_admin";
                    for (var keyname:String in _Dict.Key_) { setKeys(keyname); }
                    getNewGame(stage, String(clientConfig.game_url));
                } catch (error:Error) { showStatus("Perfil de símbolos inválido: " + error.message); }
            });
            keyLoader.load(new URLRequest(String(clientConfig.keylist_url)));
        }

		public function setKeys(param1:String)
		{
			try
			{
				_Dict.Key_[param1] = getToken(_Dict.Key_[param1])
			}
			catch(E:Error)
			{
				trace(E.toString())
			}
		}
		
		public function setClass(param1:String)
		{
			try
			{
				_Dict.Key_[param1] = parseClass(_Dict.Key_[param1]);
			}
			catch(E:Error)
			{
				trace(E.toString())
			}
		}
		
		public function getClass()
		{
			var classList:Array = _Dict.classList.split(",")
			for each(var class_key in classList)
			{
				if (!(_Dict.Key_[class_key] is String) || !_Dict.Key_[class_key]) {
                    throw new Error("Classe não informada: " + class_key);
                }
                setClass(class_key);
                if (_Dict.Key_[class_key] == null) {
                    throw new Error("Classe não encontrada: " + class_key);
                }
			}
		}
		public function getNewGame(param1,gameUrl:String = "")
		{
			Chargeur = new Loader();
            Chargeur.mouseEnabled = true;
            Chargeur.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, resourceFailed);
            Chargeur.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR, resourceFailed);
			Chargeur.contentLoaderInfo.addEventListener("complete", Chargement_Ok);
			Chargeur.contentLoaderInfo.addEventListener("complete", Plugin_ok);
            Chargeur.contentLoaderInfo.addEventListener("progress", Chargement_EnCours);
            param1.addChild(Chargeur);
			if(isAIR)
			{
				Chargeur.load(new URLRequest("transformice.swf"));
			}
			else
			{
				Chargeur.load(new URLRequest(gameUrl));
			}
			
		
		}
		
        function frame1()
        {
			isAIR = this.loaderInfo.url.indexOf("app:") != -1
			if(!isAIR)
			{
				Security.allowDomain("*")
			}
			
			date = new Date();
			Charge = 0;
            P = 0;
            _C._B.width = 1;
            _C.mouseEnabled = false;
            _C.mouseChildren = false;
			_C._K.cacheAsBitmap = true
			
			loadConfiguration()
			return;
        }// end function
}
}