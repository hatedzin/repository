﻿package ChargeurTransformice_fla
{
     import flash.display.*;
	import ChargeurTransformice_fla.*
	import flash.events.*;
    import flash.net.*;
    import flash.system.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
    dynamic public class TFM_Menu extends MovieClip
    {
        public var menu_ui;
		
		public function get _Dict() : Dictionary
		{
			return TransformiceChargeur.instance._Dict
		}
	
        public function TFM_Menu(sizeX,sizeY,locX,locY,canDrag = false,title = "Pgiex TFM",closeFunction= null,typeX=11)
        {
			menu_ui = createMenu(sizeX,sizeY,locX,locY,canDrag,title,closeFunction,typeX)
			TransformiceChargeur.instance.stage.addChild(menu_ui)
            return;
        }// end function
		
		public function createMenu(sizeX,sizeY,locX,locY,canDrag = false,title = "Pgiex TFM",closeFunction= null,typeX=11)
		{
			try
			{
				var menu_xx = new _Dict.Key_.ui_element_class(sizeX, sizeY);
				
				menu_xx[_Dict.Key_.set_prep_ui](_Dict.Key_.prep_ui_class[_Dict.Key_.prep_ui1_instance], 0);
				menu_xx.x = locX;
				menu_xx.y = locY;
				
				menu_xx[_Dict.Key_.set_box](title,closeFunction,typeX);
				if(canDrag)
				{
					menu_xx[_Dict.Key_.set_draggable]();
				}
			}
			catch(E:Error)
			{
				
			}
			
					
			return menu_xx
		}
	
		public function addScroll(param1:int,param2:int)
		{
			var ui2 = new Key_.ui_element_class(param1, param2);
					ui[Key_.set_prep_ui](Key_.prep_ui_class[Key_.prep_ui4_instance], 15);
					ui[Key_.set_scrollable](true);
			
					menu_ui[Key_.add_ui_element](ui);
			return ui
		}
		
		public function set_shape(targetX,param1:int, param2:int, param3:Boolean, param4:int, param5:int = 0, param6:int = 0) : Shape
        {
            if (!param5 && !param6)
            {
                param5 = 3500917;
                param6 = 858652;
            }
            var _loc_7:* = new Shape();
            _loc_7.graphics.lineStyle(1, param5);
            if (param3)
            {
                _loc_7.graphics.lineTo(param4, 0);
                _loc_7.graphics.moveTo((0), (1));
                _loc_7.graphics.lineStyle((1), param6);
                _loc_7.graphics.lineTo(param4, 1);
            }
            else
            {
                _loc_7.graphics.lineTo((0), param4);
                _loc_7.graphics.moveTo((1), (0));
                _loc_7.graphics.lineStyle((1), param6);
                _loc_7.graphics.lineTo((1), param4);
            }
            _loc_7.x = param1;
            _loc_7.y = param2;
            targetX.addChild(_loc_7);
            return _loc_7;
        }// end function
	
	
    }
}