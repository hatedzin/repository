﻿package ChargeurTransformice_fla
{
    import flash.display.*;
    import flash.events.*;
    import flash.net.*;
    import flash.system.*;
	import com.bit101.components.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
    dynamic public class Hack_Class extends MovieClip
    {
        public var instance:Hack_Class = this;
		public var Key_:Object;
		public var tfm;
		public var main_:TransformiceChargeur;
        public function Hack_Class(param1)
        {
			main_ = TransformiceChargeur.instance
			Key_ = TransformiceChargeur.instance._Dict.Key_;
			tfm = param1.tfm
			
            return;
        }// end function
		
		public function get cheeseX()
		{
			return Key_.CheeHoleC[Key_.CheeHole1][Key_.ClipFromage]
		}
		
		public function get holeList()
		{
			return Key_.CheeHoleC[Key_.CheeHole1][Key_.Hole2][Key_.LsTS]
		}
		
		public function get myMouse()
		{
			return tfm[Key_.ClipJoueur]
		}
		
		public function mouse_Info(param1 = null)
		{
			if(param1 == "name")
			{
				return tfm[Key_.ClipJoueur][Key_.GameName]
			}
			else if(param1 == "mort")
			{
				return tfm[Key_.ClipJoueur][Key_.Mort]
			}
			else if(param1 == "grosse")
			{
				return tfm[Key_.ClipJoueur][Key_.Grosse]
			}
			else if(param1 == "MovingRight")
			{
				return tfm[Key_.ClipJoueur][Key_.MovingRight]
			}
			
			return tfm[Key_.ClipJoueur]
		}
		
		public function SetPlayerPosition(param1:Number, param2:Number) : void
        {
            main_.ApplyMovePlayer(param1, param2, false, 0, 0, false);
            return;
        }// end function
		
		public function SetPlayerFakePosition(param1:Number, param2:Number) : void
        {
            tfm[Key_.ClipJoueur].x = param1;
            tfm[Key_.ClipJoueur].y = param2;
            return;
        }// end function
		
		
		public function Conjuration() : void
        {
            main_.Packets.ParseOldPacket(4,14,mouseX/10,mouseY/10)
			setTimeout(Destroy_Conjuration,5000,mouseX/10,mouseY/10)
            return;
        }// end function
		
		public function Destroy_Conjuration(param1,param2) : void
        {
            main_.Packets.ParseOldPacket(4,15,param1,param2)
            return;
        }// end function
		
		
		public function Object_creation(param1:int, param2:int, param3:int, param4:int = 0, param5:Number = 0, param6:Number = 0, param7:Boolean = true)
        {
            CSynchroniseur();
			tfm[Key_.ClipJoueur][Key_.Guide] = true
			tfm[Key_.Guide] = true
            return Key_.CreationClass[Key_.Creation_Object](param1, param2, param3, param4, param5, param6, param7);
        }// end function
		
		
		public function CSynchroniseur() : void
        {
            try
            {
                Key_.CSync[Key_.Synchroniseur] = true;
            }
            catch (E:Error)
            {
            }
            return;
        }// end function
		
		
		public function setGrosse(param1:Boolean = false, param2:Boolean = false) : void
        {
			if(param1)
			{
				tfm[Key_.ClipJoueur][Key_.Grosse] = param2
			}
			else
			{
				tfm[Key_.ClipJoueur][Key_.Grosse] = !tfm[Key_.ClipJoueur][Key_.Grosse];
			}
            
            return;
        }// end function
		
		public function setMoveRight(param1:Boolean = false, param2:Boolean = false) : void
        {
			if(param1)
			{
				tfm[Key_.ClipJoueur][Key_.MovingRight] = param2
			}
			else
			{
				tfm[Key_.ClipJoueur][Key_.MovingRight] = true
			}
            
            return;
        }// end function
		
		public function get isDead()
        {
            return tfm[Key_.ClipJoueur] == null ? false : tfm[Key_.ClipJoueur][Key_.Mort];
        }// end function
		
		
		public function chatCommand(param1:String = null)
        {
            tfm[Key_["chatCommand"]](param1);
            return;
        }// end function

		public function sendChatMessage(param1:String = null)
        {
			Key_.class_admin[Key_.set_admin] = true;
			Key_.ChatTribulle[Key_.ProxyInstance][Key_.validationMessage](param1);
			
            return;
        }// end function

		public function sendPrivMessage(user:String = null,content:String = null)
        {
			Key_.class_admin[Key_.set_admin] = true;
			Key_.ProxyTribulle[Key_.ProxyInstance][Key_.envoieMsgPrive](user,content);
            return;
        }// end function

		public function TeleWin()
		{
			if (!isDead)
            {
				SetPlayerPosition(cheeseX.x + 1,cheeseX.y + 1)
				setTimeout(SetPlayerPosition,150,holeList[1],holeList[2])
			}
			return;
		}
		
        public function set jumpulo(param1:Number)
        {
            Key_.Puloc[Key_.Pulo1][Key_.Pulo2] = param1;
            return;
        }// end function

        public function set leve(param1:Number)
        {
            Key_.Leve_C[Key_.Leve_1] = false;
            Key_.LeveC[Key_.Leve1](tfm[Key_.ClipJoueur], param1);
            return;
        }// end function

        public function set MouseSize(param1:Number)
        {
            tfm[Key_.ClipJoueur][Key_.set_mouseSize](param1);
			/*var aws = new ByteArray()
				aws.writeInt(main_.playerCode)
				aws.writeShort(500)
				aws.writeBoolean(false)
				main_.ParsePacket(5,31,aws)*/
            return;
        }// end function

		public function set cheeseSize(param1:Number)
        {
            if (param1 < 10)
            {
                if (cheeseX.width >= 30)
                {
                    this.ShamanSkillPacket(257, 50);
                }
            }
            else if (param1 > 10 && param1 < 20)
            {
                if (cheeseX.width <= 30)
                {
                    this.ShamanSkillPacket(257, 200);
                }
                if (cheeseX.width >= 90)
                {
                    this.ShamanSkillPacket(257, 50);
                }
            }
            else if (param1 > 20)
            {
                if (cheeseX.width <= 90)
                {
                    this.ShamanSkillPacket(257, 200);
                }
            }
            return;
        }// end function

		public function ShamanSkillPacket(param1:int, param2:int) : void
        {
            var _loc_3:* = new ByteArray();
            _loc_3.writeByte(param1);
            _loc_3.writeByte(param2);
            main_.Packets.ParsePacket(8, 10, _loc_3);
            return;
        }// end function
		
        public function MovePlayer(param1:int, param2:int, param3:Boolean = false) : void
        {
            main_.ApplyMovePlayer(0, 0, false, param1, param2, param3);
            return;
        }// end function
		
		public function send_crouch_packet(_arg1:int=0):void{
        var packet:* = new ByteArray()
        packet.writeByte(_arg1);
		main_.Packets.SendPacket(4,9,packet)
      }
      
      public function removeStartPeriod() : void
      {
         var packet:* = new ByteArray()
         packet.writeBoolean(false);
		 main_.Packets.ParsePacket(5,10,packet)
      }
	  
	   public function InstantDeath() : void
      {
         var packet:* = new ByteArray()
         packet.writeInt(main_._Dict.round_code)//tfm[Key_.CodeEnPart]);//round_code
		 packet.writeByte(0);
		 main_.Packets.SendPacket(4,5,packet)
      }
	  
	   public function InstantWin() : void
      {
		 send_cheese_packet()
		 send_hole_packet()
      }
	  
      public function send_cheese_packet() : void
      {
         var packet:* = new ByteArray()
         packet.writeInt(main_._Dict.round_code)//tfm[Key_.CodeEnPart]);//round_code
         packet.writeShort(cheeseX.x);
         packet.writeShort(cheeseX.y);
         packet.writeByte(0);
         packet.writeShort(15);
		 main_.Packets.SendPacket(5,19,packet)
      }
      
      public function send_hole_packet() : void
      {
         var packet:* = new ByteArray()
         packet.writeByte(holeList[0]);
         packet.writeInt(main_._Dict.round_code)//tfm[Key_.CodeEnPart]);//round_code
         packet.writeInt(main_._Dict.map_code_int)//tfm[Key_.CodeEnPartHole]);//map_code_int);
         packet.writeShort(15);
         packet.writeShort(holeList[1]);
         packet.writeShort(holeList[2]);
		 main_.Packets.SendPacket(5,18,packet)
      }

    }
}