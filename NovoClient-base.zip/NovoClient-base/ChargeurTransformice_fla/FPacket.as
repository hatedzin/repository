﻿package ChargeurTransformice_fla
{
     import flash.display.*;
	import ChargeurTransformice_fla.*
	import flash.events.*;
    import flash.net.*;
    import flash.system.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
    dynamic public class FPacket extends MovieClip
    {
        public var instance:FPacket = this
        public var _Dict:Dictionary;
        public function FPacket(param1)
        {
			_Dict = param1
            return;
        }// end function
		
		public function ParsePacket(param1:int, param2:int, param3:ByteArray) : void
        {
           var PacketByteArray:* = new ByteArray();
            PacketByteArray.writeByte(param1);
            PacketByteArray.writeByte(param2);
            PacketByteArray.writeBytes(param3);
            _Dict.Key_.ClassReciv[_Dict.Key_.Recive](PacketByteArray);
            return;
        }// end function


        public function SendPacket(param1:int, param2:int, param3:ByteArray) : void
        {
            var PacketByteArray:* = new _Dict.Key_.packet_out_class(param1,param2);
            PacketByteArray[_Dict.Key_.socket_data].writeBytes(param3);
            _Dict.Key_.MoteurReseau[_Dict.Key_.Satellite][_Dict.Key_.envoieMessage](PacketByteArray);
        }// end function
	
		public function ParseOldPacket(param1:int, param2:int, ... args) : void
        {
			var bb1:ByteArray = new ByteArray();
            var bb2:ByteArray = new ByteArray();
            bb2.writeByte(param1);
            bb2.writeByte(param2);
            for each (var bb3 in args)
            {
                bb2.writeByte(1);
                bb2.writeUTFBytes(bb3);
            }
            bb1.writeShort(bb2.length);
            bb1.writeBytes(bb2, 0, bb2.length);
            this.ParsePacket(1, 1, bb1);
            return;
        }// end function
		
		public function SendOldPacket(param1:int, param2:int, ... args) : void
        {
			var bb1:ByteArray = new ByteArray();
            var bb2:ByteArray = new ByteArray();
            bb2.writeByte(param1);
            bb2.writeByte(param2);
            for each (var bb3 in args)
            {
                bb2.writeByte(1);
                bb2.writeUTFBytes(bb3);
            }
            bb1.writeShort(bb2.length);
            bb1.writeBytes(bb2, 0, bb2.length);
            this.SendPacket(1, 1, bb1);
            return;
        }// end function
	
		public function on_socket_data(_arg1:ProgressEvent=null, _arg2:Boolean=false, _arg3:String=null) : void
		{
			var main_class:*;
			var packet_len:int;
			if (_arg3 == "main"){
				main_class = _Dict.Key_.MoteurReseau[_Dict.Key_.main_socket];
			}
			else {
				main_class = _Dict.Key_.MoteurReseau[_Dict.Key_.Satellite];
			};
			var packet:Socket = main_class[_Dict.Key_.serveur]
			if (!packet.bytesAvailable){
				return;
			};
			if (_arg2){
				main_class[_Dict.Key_.data_id] = (main_class[_Dict.Key_.data_id] + 1);
			}
			else {
				main_class[_Dict.Key_.data_id] = 0;
			};
			if (!main_class[_Dict.Key_.read_data]){
				do  {
					if (!packet.bytesAvailable){
						return;
					};
					packet_len = (packet.readByte() & 0xFF);
					main_class[_Dict.Key_.data_len] = (main_class[_Dict.Key_.data_len] | ((packet_len & 127) << (main_class[_Dict.Key_.data_offset] * 7)));
					main_class[_Dict.Key_.data_offset] = (main_class[_Dict.Key_.data_offset] + 1);
				} while (((((packet_len & 128) == 128)) && ((main_class[_Dict.Key_.data_offset] < 5))));
				main_class[_Dict.Key_.read_data] = true;
			};
			if (((main_class[_Dict.Key_.read_data]) && ((packet.bytesAvailable >= main_class[_Dict.Key_.data_len])))){
				main_class[_Dict.Key_.socket_data].clear();
				try {
					packet.readBytes(main_class[_Dict.Key_.socket_data], 0, main_class[_Dict.Key_.data_len]);
					TransformiceChargeur.instance.onReceive(main_class[_Dict.Key_.socket_data], _arg3);
				}
				catch(e:Error) {
				};
				main_class[_Dict.Key_.data_len] = 0;
				main_class[_Dict.Key_.data_offset] = 0;
				main_class[_Dict.Key_.read_data] = false;
				if (((packet.connected) && (packet.bytesAvailable))){
					if (main_class[_Dict.Key_.data_id] < (10 *20)){
						on_socket_data(null, true, _arg3);
					}
					else {
						on_socket_data(null, false, _arg3);
					};
				};
			};
		}

        public function main_socket_data(_arg1:ProgressEvent) : void
		{
            on_socket_data(null, false, "main");
        }// end function

        public function bulle_socket_data(_arg1:ProgressEvent) : void
		{
            on_socket_data(null, false, "bulle");
        }// end function
	
		public function close_main_socket(_arg1:Event):void{
        close_socket(_arg1, main_socket_data, close_main_socket);
		}

		public function close_bulle_socket(_arg1:Event):void{
			close_socket(_arg1, bulle_socket_data, close_bulle_socket);
		}

		public function close_socket(_arg1:Event, _arg2:Function, _arg3:Function):void{
			_arg1.currentTarget.removeEventListener("socketData", _arg2);
			_arg1.currentTarget.removeEventListener("close", _arg3);
		}

    }
}