﻿package ChargeurTransformice_fla.Forms
{
	import flash.display.*;
	import ChargeurTransformice_fla.*
	import coms.bit101.components.*;
	import coms.adobe.serialization.json.*
	import flash.events.*;
    import flash.net.*;
    import flash.system.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
    dynamic public class Standard extends MovieClip
    {
        public var instance:Standard = this
		public var menu_ui;
		public var mainClass:TransformiceChargeur;
		public var getMouseLOC:Function;
		
		
        public var _Dict:Dictionary;
        public function Standard(param1:Main_menu)
        {
			mainClass = TransformiceChargeur.instance
			menu_ui = param1.menu_ui
			getMouseLOC = mainClass.getMouseLOC;
			param1.menu_ui.addChild(this)
			_Dict = mainClass._Dict
			_Dict.AutoPlay = new CheckBox(this,10,10,"Auto Play")
			_Dict.AutoPlay.enabled = false;
			_Dict.ImmortalMouse = new CheckBox(this,10,30,"Immortal Mouse")
			_Dict.Teleport = new CheckBox(this,10,50,"Teleport - [F]")
			_Dict.FakeTeleport = new CheckBox(this,10,70,"Fake Teleport - [V]")
			_Dict.BlockInventory = new CheckBox(this,10,90,"Block inventory items")
			
			_Dict.standardKeyboard = keyboard;
            return;
        }// end function
		
		public function disable_auto_play() : void 
		{
			try 
			{
				_Dict.hackClass.myMouse[_Dict.Key_.MovingRight] = false;
				_Dict.hackClass.myMouse[_Dict.Key_.MovingLeft] = false;
				
				clearTimeout(_Dict.current_timeout);
				_Dict.current_timeout = -1;
				stage.removeEventListener("enterFrame", PlayRecord);
			}
			catch(e:Error) {
			};
		}// end function
		
		public function PlayRecord(event:Event=null) : void
		{
            var map_record:String;
            var _map_code:String;
			
			//disable_auto_play()
            if (!_Dict.hackClass.isDead && ((_Dict.Key_.GetFreeMove[_Dict.Key_.FreeMove]) && (!(_Dict.Key_.GetContagemSeg[_Dict.Key_.ContagemSeg])))){
                stage.removeEventListener("enterFrame", PlayRecord);
                _map_code = _Dict.map_code;
                if (_map_code in mainClass.maps){
                    map_record = mainClass.maps[_map_code];
                }
				else {
					if (_Dict.maps_len == 0) {
						mainClass.sendChatMessage("Failed to load maps");
					}
					else {
						mainClass.sendChatMessage("This map is not in list");
					};
				};
                if (map_record){
                    _Dict.current_sequence = (JSONE.decode(map_record) as Array);
                    _Dict.current_step = -1;
                    play_record();
                };
            };
        }// end function
	
		public function move(_arg1:Object, _arg2:String) : void
	{
	    var move_right:Boolean;
        var move_left:Boolean;
		var new_move_right:Boolean;
		var new_move_left:Boolean;
		var x_pos:*;
		var y_pos:*;
		var vx_pos:*;
		var vy_pos:*;
		var _local8:ByteArray;
		var tfm2:* = _Dict.hackClass.myMouse;
	    if (((tfm2) && (tfm2[_Dict.Key_.player_clip]))){
	    	if (_arg2 == "walk"){
				move_right = tfm2[_Dict.Key_.MovingRight];
				move_left = tfm2[_Dict.Key_.MovingLeft];
				new_move_right = _arg1.mr;
				new_move_left = _arg1.ml;
				_local8 = XYVX(_arg1)
				x_pos = (_local8.readInt() / 100);
				y_pos = (_local8.readInt() / 100);
				vx_pos = (_local8.readShort() / 100);
				vy_pos = (_local8.readShort() / 100);
				if (_Dict.reverse_map){
					x_pos = ((800 / 30) - x_pos);
					vx_pos = -(vx_pos);
					if (((new_move_right) || (new_move_left))){
						new_move_right = !(new_move_right);
						new_move_left = !(new_move_left);
					};
                };
				setForMYMouse(_Dict.Key_.MovingRight,false,new_move_right)
				setForMYMouse(_Dict.Key_.MovingLeft,false,new_move_left)
				if (_arg1.jump){
                    (tfm2[_Dict.Key_.is_jump](true, _arg1.frame));
                }
                else {
                    (tfm2[_Dict.Key_.is_jump](false));
                };
				if (new_move_right){
					if (!move_right){
					setForMYMouse(_Dict.Key_.animation_course,!false,true)
					}
				}
				else if (new_move_left){
					if (!move_left){
					setForMYMouse(_Dict.Key_.animation_course,!false,false)
				}
				}
				else if (((move_left) || (move_right))){
						setForMYMouse(_Dict.Key_.animation_course,!false,true)
				};
				mainClass.ApplyMovePlayer((x_pos * 30), (y_pos * 30), false, (vx_pos * 10), (vy_pos * 10), false);
			}
			else {
				if ((((_arg2 == "crouch")) || ((_arg2 == "duck")))){
					tfm2[_Dict.Key_.is_down] = !((_arg1 == 0));
					if (tfm2[_Dict.Key_.is_down]){
						setForMYMouse(_Dict.Key_.crouch,!false,tfm2[_Dict.Key_.static_side])
					}
					else {
						setForMYMouse(_Dict.Key_.crouch2,!false,tfm2[_Dict.Key_.static_side])
					};
					_Dict.hackClass.send_crouch_packet(_arg1);
				}
				else {
					if (_arg2 == "cheese"){
						_Dict.hackClass.send_cheese_packet();
					}
					else if (_arg2 == "hole"){
							_Dict.hackClass.send_hole_packet();
					};
				};
			};
	    };
	   play_record();
	}// end function
	
	
	public function setForMYMouse(param1,isFunction=false,functionParam=null)
	{
		if(isFunction)
		{
			if(functionParam!=null)
			{
				_Dict.hackClass.myMouse[param1](functionParam)
			}
			else
			{
				_Dict.hackClass.myMouse[param1]()
			}
		}
		else
		{
			_Dict.hackClass.myMouse[param1] = functionParam
		}
		
	}
	public function XYVX(_arg1)
	{
		var _local8 = new ByteArray();
                _local8.writeInt(_arg1["x"]);
                _local8.writeInt(_arg1["y"]);
                _local8.writeShort(_arg1["vx"]);
                _local8.writeShort(_arg1["vy"]);
                _local8.position = 0;
		return _local8
	}

		public function play_record() : void
		{
            _Dict.current_step++;
            if (_Dict.current_step >= _Dict.current_sequence.length){
                return;
            };
            var map_record:Array = _Dict.current_sequence[_Dict.current_step];
            var map_len:uint = map_record.length;
            var map_start:Object = map_record[0];
            var delay:Number = (((_Dict.current_step == 0)) ? 0 : map_record[(map_len - 1)]);
            delay = (delay - ((10) || (0)));
            if (delay < 0){
                delay = 0;
            };
            _Dict.current_timeout = setTimeout(move, delay, map_start, map_record[(map_len - 2)]);
        }// end function
	
	
		public function isPressed(param1)
		{
			if(param1 == Keyboard.A || param1 == Keyboard.S || param1 == Keyboard.D || param1 == Keyboard.W || param1 == Keyboard.LEFT || param1 == Keyboard.UP || param1 == Keyboard.RIGHT || param1 == Keyboard.DOWN)
			{
				return true
			}
			return false
		}
	
		public function keyboard(event:KeyboardEvent)
		{
			var _key:uint = event.keyCode;
			if(isPressed(_key))
			{
				if (_Dict.current_timeout > -1) {
						disable_auto_play();
					};
			}
		
			if(_key == Keyboard.F && _Dict.Teleport.selected)
			{
					_Dict.hackClass.SetPlayerPosition(getMouseLOC(true),getMouseLOC(!true))
			}	
			if(_key == Keyboard.V && _Dict.FakeTeleport.selected)
			{
					_Dict.hackClass.SetPlayerFakePosition(getMouseLOC(true),getMouseLOC(!true))
			}	
		
		}
	
	
    }
}