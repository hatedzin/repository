package ChargeurTransformice_fla.Forms
{
	import flash.display.*;
	import ChargeurTransformice_fla.*
	import coms.bit101.components.*;
	import flash.events.*;
    import flash.net.*;
    import flash.system.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
    dynamic public class Farm extends MovieClip
    {
        public var instance:Farm = this
		public var menu_ui;
		public var getMouseLOC:Function;
		public var timerFarm:int = 0;
        public var _Dict:Dictionary;
        public function Farm(param1:Main_menu)
        {
			menu_ui = param1.menu_ui
			getMouseLOC = TransformiceChargeur.instance.getMouseLOC;
			param1.menu_ui.addChild(this)
			_Dict = TransformiceChargeur.instance._Dict
			_Dict.CollectGiftBox = new CheckBox(this,10,10,"Collect box")
			_Dict.Tooltip1 = new Tooltip(_Dict.BlockInventory,"Incoming inventory items wont appear\non the right of the screen")
			_Dict.AutoWin = new CheckBox(this,10,30,"Auto win",function()
			{
				setSelected(_Dict.AutoWin)
				
			})
			_Dict.AutoDie = new CheckBox(this,10,50,"Auto die",function()
			{
				setSelected(_Dict.AutoDie)
			})
			_Dict.ShamanLoyalty = new CheckBox(this,10,70,"Shaman Loyalty",function()
			{
				setSelected(_Dict.ShamanLoyalty)
			})
			_Dict.ShamanName = new InputText(this,30,90,"Shaman#0000")
			_Dict.farmLabel1 = new Label(this,10,110,"Farm Time:")
			_Dict.FarmTime = new InputText(this,90,110,"5000")
			_Dict.ShamanName.width = 130
			_Dict.FarmTime.width = 70
			
			
			_Dict.FarmLoop = FarmLoop;
            return;
        }// end function
		
		public function setSelected(param1:CheckBox)
		{
			if(param1.selected)
			{
				_Dict.AutoWin.selected = false;
				_Dict.AutoDie.selected = false;
				_Dict.ShamanLoyalty.selected = false;
				param1.selected = true
			}
			
		}
		
		public function collectBox(param1:DisplayObjectContainer)
        {
            var xnumChildren= param1.numChildren;
            var counterx= 0;
            var objectx;
			try
			{
				while (counterx < xnumChildren)
				{
					objectx = param1.getChildAt(counterx);
					if(objectx.width == 37 && objectx.height == 39)
					{
						if(objectx.x < 10 || objectx.y < 10 )
						{
							return
						}
					//trace(objectx.x + ",:" + objectx.y)
						_Dict.hackClass.SetPlayerFakePosition(objectx.x,objectx.y) 
					}
					
					if (objectx is DisplayObjectContainer && objectx.numChildren > 0)
					{
						try
						{
							collectBox(objectx);
						}
						catch(E:Error)
						{
							
						}
						
					}
					counterx = counterx + 1;
				}
			}
			catch(E:Error)
			{
				
			}
            
            return;
        }// end function
	
		public function FarmLoop()
		{
			
			var farmTime = int(_Dict.FarmTime.text)
			if(_Dict.ShamanLoyalty.selected && _Dict.hackClass.myMouse[_Dict.Key_.Guide] )
			{
				farmTime = int(_Dict.FarmTime.text) + 1150
			}
			if(!_Dict.hackClass.mouse_Info("mort") && (_Dict.AutoWin.selected || _Dict.AutoDie.selected || _Dict.ShamanLoyalty.selected))
			{
					if((getTimer() - timerFarm >=  farmTime - 1000) )
						{
							_Dict.hackClass.setMoveRight(false,false)
							
								TransformiceChargeur.instance.PressKey(50, Keyboard.W);
							
							
						}
					
					if((getTimer() - timerFarm >= farmTime - 500) && _Dict.CollectGiftBox.selected)
						{
							collectBox(TransformiceChargeur.instance.tfm)
						}
					if((getTimer() - timerFarm >= farmTime) )
						{
							timerFarm = getTimer()
							if(_Dict.AutoWin.selected || (_Dict.ShamanLoyalty.selected && Boolean(_Dict.LoyaltyWin)))
							{
								_Dict.hackClass.TeleWin()
							}
							else
							{
								_Dict.hackClass.InstantDeath()
							}
						}
					
			}
			else
			{
				timerFarm = getTimer()
			}
		}
	
    }
}