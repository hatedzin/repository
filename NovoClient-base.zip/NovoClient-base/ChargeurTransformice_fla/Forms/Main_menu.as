package ChargeurTransformice_fla.Forms
{
	import flash.display.*;
	import ChargeurTransformice_fla.*
	import flash.events.*;
    import flash.net.*;
    import flash.system.*;
    import flash.utils.*;
	import flash.ui.*
	import flash.text.*;
	import coms.bit101.components.*;

    dynamic public class Main_menu extends MovieClip
    {
        public var instance:Main_menu = this
		public var BadgeCount:int = 0;
		public var menu_ui;
		public var menuHeight:int = 180;
		public var menuList:Array = new Array()
        public var _Dict:Dictionary;
        public var Key_;
        public var imageLOC = ""
        public function Main_menu(param1)
        {
			_Dict = TransformiceChargeur.instance._Dict
			Key_ = _Dict.Key_
			create_Main_Menu()
			
            return;
        }// end function
		
		public function create_Main_Menu()
        {
			var menu_uiClass = new TFM_Menu(165, menuHeight,605,60,true,"Pgiex TFM")
			menu_ui = menu_uiClass.menu_ui
			menu_uiClass.set_shape(menu_ui,-4, menuHeight - 47, true, 174)
			TransformiceChargeur.instance.stage.addChild(this.menu_ui)
			
			_Dict.standardForm = new Standard(this);
			_Dict.farmForm = new Farm(this);
			
			addMenuBadge(imageLOC + "Standard.png","Standard",_Dict.standardForm,true)
			addMenuBadge(imageLOC + "Farm.png","Farm",_Dict.farmForm)
            return;
        }// end function
	
	

        public function addMenuBadge(imageURL:String, description:String = "Standard", menuSprite:Sprite = null, _visible:Boolean = false):void {
            menuSprite.visible = _visible;
            menuList.push(menuSprite);
            var button:PushButton = new PushButton(menu_ui, BadgeCount, menuHeight - 40, description, function(event:MouseEvent):void {
                for each (var page:Sprite in menuList) { page.visible = false; }
                menuSprite.visible = true;
            });
            button.width = 80;
            BadgeCount += 84;
        }

    }
}