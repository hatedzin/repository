"""Serve the client on loopback, optionally using an explicit local game SWF."""
import argparse
import json
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import shutil
from urllib.parse import urlsplit


def handler_for(root, game=None):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(root), **kwargs)

        def end_headers(self):
            self.send_header('Cache-Control', 'no-cache')
            super().end_headers()

        def do_GET(self):
            path = urlsplit(self.path).path
            if game is not None and path == '/client-config.json':
                try:
                    config = json.loads((root / 'client-config.json').read_text(encoding='utf-8-sig'))
                    if not isinstance(config, dict):
                        raise ValueError('Expected an object')
                except (ValueError, OSError):
                    self.send_error(500, 'Invalid client-config.json')
                    return
                config['game_url'] = 'local-game.swf'
                body = json.dumps(config).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif game is not None and path == '/local-game.swf':
                try:
                    stream = game.open('rb')
                except OSError:
                    self.send_error(404, 'Local game SWF is unavailable')
                    return
                with stream:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/x-shockwave-flash')
                    self.send_header('Content-Length', str(game.stat().st_size))
                    self.end_headers()
                    shutil.copyfileobj(stream, self.wfile)
            else:
                super().do_GET()
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8082)
    parser.add_argument('--swf', type=Path, help='Serve this local game SWF instead of the backend game URL')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent / 'dist'
    if not (root / 'NovoClient.swf').is_file():
        parser.error('Compile the client first: dist/NovoClient.swf is absent')
    game = args.swf.resolve() if args.swf is not None else None
    if game is not None:
        try:
            with game.open('rb') as stream:
                header = stream.read(8)
            if len(header) != 8 or header[:3] not in (b'FWS', b'CWS', b'ZWS'):
                raise ValueError('Not a recognized SWF file')
        except (ValueError, OSError):
            parser.error('The --swf path must point to a readable SWF game file')
    with ThreadingHTTPServer(('127.0.0.1', args.port), handler_for(root, game)) as server:
        print(f'Client file: http://127.0.0.1:{server.server_port}/NovoClient.swf')
        print('Open this address in a compatible SWF projector, not a modern browser.')
        if game is not None:
            print('Local game mode: /local-game.swf (no backend game download; config file unchanged).')
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
