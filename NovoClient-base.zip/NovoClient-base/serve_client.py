"""Serve only the compiled client directory on loopback."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8082)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent/'dist'
    if not (root/'NovoClient.swf').is_file():
        parser.error('Compile the client first: dist/NovoClient.swf is absent')
    handler=partial(SimpleHTTPRequestHandler,directory=str(root))
    with ThreadingHTTPServer(('127.0.0.1',args.port),handler) as server:
        print(f'Client file: http://127.0.0.1:{args.port}/NovoClient.swf')
        print('Open this address in a compatible SWF projector, not a modern browser.')
        try: server.serve_forever()
        except KeyboardInterrupt: pass

if __name__=='__main__':main()
