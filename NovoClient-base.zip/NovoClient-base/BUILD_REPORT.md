# Atualização — diagnóstico de recursos e SWF local

A mensagem genérica de ioError não distinguia configuração, símbolos, mapas e
arquivo do jogo. Agora cada requisição tem nome, status HTTP quando disponível,
texto de erro e uma orientação contextual. Valores de token/key/access_token em
querystrings de erro são ocultados antes de exibir a mensagem.

Validação atual da compilação SWF 10 em Chromium/Ruffle:
1. Configuração válida e fixture carregada: PASS.
2. Arquivo SWF ausente: PASS; mensagem identifica SWF do jogo e HTTP 404.
3. Configuração ausente: PASS; mensagem identifica client-config.json e HTTP 404.

serve_client.py agora aceita --swf CAMINHO. Um teste HTTP real confirmou que a
configuração aponta local-game.swf somente na resposta, o conteúdo retornado é
idêntico ao arquivo escolhido e o config original permanece inalterado. O servidor
continua restrito a 127.0.0.1. Nenhuma partida ou recurso do jogo foi validado.

A SWF tfm.swf recebida do usuário tem formato 14 (referência Flash 11.1). O loader
SWF 10 não adapta bytecode/APIs do jogo para Flash 10. É necessário um runtime
adequado à SWF do jogo. Não foram modificadas checagens de proteção ou autenticação.

---

# Atualização — leitura de configuração no Flash Player 10

O erro #1065 mostrado pelo usuário ocorre durante a configuração. A base anterior
referenciava JSON.parse, indisponível no Flash 10. Os dois usos foram substituídos
por JSONE.decode, biblioteca já incluída no projeto. Os scripts agora usam
playerglobal 10.0, target-player=10.0 e swf-version=10.

Validação atual:
- Compilação concluída: zero erros, 110 avisos legados preservados no log.
- Cabeçalho SWF 10, comprimento válido e bloco ABC legível.
- A string de referência à classe global JSON não está mais no bytecode.
- JSONE está incluído no SWF final.
- Chromium + Ruffle executaram a base nova, leram o config e executaram a fixture
  compilada também para SWF 10. Marcadores de execução e COMPLETE confirmados.
- Evidências em tests/evidence foram atualizadas para essa execução.

Não foi possível executar o projector nativo do usuário neste ambiente. A SWF do
jogo pode exigir APIs mais recentes. Não foram acrescentados Fly/salto alto nem
validados Robot, perfis de símbolos ou partida online.

Abaixo, o registro da montagem inicial, que usava formato SWF 14/Flash 11.1.
Ele é histórico; os arquivos compilados da entrega atual usam formato SWF 10.

---

# Resultado da montagem

- Apache Flex SDK 4.16.1 baixado do arquivo oficial Apache; assinatura GPG validada
  usando a chave 44998F3E242727E94C4BADEB6B0A7EC905061FC8 publicada no KEYS Apache.
- Biblioteca playerglobal 11.1 obtida do repositório nexussays/playerglobal,
  revisão fef560243029214656d83fc673be0267a1ea0816; a origem Adobe é documentada
  no README da biblioteca. O download direto Adobe não estava acessível neste ambiente.
- build.sh executado com OpenJDK 21, strict=false para classes dinâmicas legadas,
  target-player 11.1 e swf-version 14. Resultado: zero erros e 110 avisos preservados
  em tests/evidence/compile.log. Traces de diagnóstico foram mantidos na compilação.
- FLA reparado: apenas tamanho do diretório ZIP central corrigido; 124 entradas
  verificadas por CRC. O original foi preservado. Abertura no Animate não testada.
- NovoClient.swf: cabeçalho, comprimento, bloco ABC e ausência de URLs do host antigo
  verificados. Detalhes em tests/evidence/swf-inspection.json.
- Runtime: Chromium headless + Ruffle 0.7.1 executaram o SWF novo, leram o config
  e carregaram a SWF de teste SmokeGame. Dois marcadores confirmaram execução do
  conteúdo e o evento COMPLETE do loader. Captura e logs estão em tests/evidence.
  A fixture está explicitamente identificada e NÃO é o jogo Transformice.
- O primeiro harness não capturava traces porque o SDK os removia por padrão.
  Após manter traces e registrar o observador no momento correto, as verificações
  de execução passaram. A evidência final é do SWF compilado com formato 14.

## Alterações no código

Criada entrada Client.as, barra de loading por código, build.cmd/build.sh e config
local. Removidos imports não usados que exigiam componentes Adobe/AIR extras.
Navegação por imagens remotas foi substituída por botões locais. Falhas de rede e
configuração são exibidas. Os endpoints antigos não são usados na compilação nova.
Perfis vazios/incompatíveis não ativam hooks. Não há sobrescrita dos campos antigos
GameLenght/GameDomain para falsificar domínio ou tamanho do jogo. O diretório dist
não contém credenciais, binário do jogo ou runtime Flash de terceiros.

## O que não está pronto

Isto é uma base compilada de carregamento, não um cliente completo com os recursos
pedidos. Fly e salto alto não foram implementados. O Auto Play legado foi preservado
na source, mas não foi executado/validado com um jogo. Falta um perfil de símbolos
real e compatível com a SWF, além dos mapas de gravação. O serviço antigo de símbolos
não ficou acessível nas verificações feitas; não foram inventados substitutos.
O contrato de símbolos do DisneyParser difere do contrato desta source. Nenhuma
conversão foi declarada pronta. A licença MySQL do DisneyClient não foi integrada
nesta base nova. Não foi executada partida no jogo nem testado Windows/projector.

Para compilar não é necessário Adobe Animate. Para executar SWF ainda é necessário
um runtime compatível; o teste Ruffle não prova suporte ao protocolo ou sockets do
Transformice atual. Sem essas integrações, não é correto chamar os recursos de
funcionais ou a base de cliente final pronto para jogar.
