#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
: "${FLEX_HOME:?Set FLEX_HOME to Apache Flex SDK 4.16.1}"
export PLAYERGLOBAL_HOME="$FLEX_HOME/frameworks/libs/player"
mkdir -p dist
"$FLEX_HOME/bin/mxmlc" -strict=false -compiler.omit-trace-statements=false -target-player=11.1 -swf-version=14 -source-path=. -static-link-runtime-shared-libraries=true -output=dist/NovoClient.swf Client.as
cp client-config.json dist/client-config.json
