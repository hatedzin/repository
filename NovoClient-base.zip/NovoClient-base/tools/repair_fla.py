"""Repair only the central-directory size in the supplied malformed FLA ZIP."""
import argparse
import io
from pathlib import Path
import struct
import zipfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('input',type=Path)
p.add_argument('output',type=Path)
a=p.parse_args()
if a.input.resolve()==a.output.resolve() or a.output.exists():
    p.error('Use a new output file; input and existing files are never overwritten.')
b=bytearray(a.input.read_bytes())
end=b.rfind(b'PK\x05\x06')
if end<0:raise ValueError('ZIP end record not found')
offset=struct.unpack_from('<I',b,end+16)[0]
if not 0<=offset<end or b[offset:offset+4]!=b'PK\x01\x02':
    raise ValueError('Unexpected central directory; no automatic repair attempted')
struct.pack_into('<I',b,end+12,end-offset)
with zipfile.ZipFile(io.BytesIO(b)) as z:
    if z.testzip() is not None:raise ValueError('CRC verification failed')
    count=len(z.infolist())
a.output.write_bytes(b)
print(f'Created repaired FLA; {count} entries verified by CRC.')
