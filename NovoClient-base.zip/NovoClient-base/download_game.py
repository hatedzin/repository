"""Download a SWF through Python, validate it, then publish it atomically."""
import argparse
import hashlib
import os
from pathlib import Path
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zlib

DEFAULT_URL = 'https://transformice.com/Transformice.swf'
MAX_BYTES = 64 * 1024 * 1024


def validate_swf(data):
    if len(data) < 8 or data[:3] not in (b'FWS', b'CWS'):
        raise ValueError('The response is not a supported SWF (FWS/CWS); it may be an HTML or JSON error page')
    expected = int.from_bytes(data[4:8], 'little')
    if not 8 <= expected <= MAX_BYTES or data[3] == 0:
        raise ValueError('Invalid SWF header or excessive uncompressed size')
    if data[:3] == b'FWS':
        if len(data) != expected:
            raise ValueError('The SWF download is truncated or has an invalid length')
    else:
        decoder = zlib.decompressobj()
        try:
            body = decoder.decompress(data[8:], expected - 8 + 1)
        except zlib.error as exc:
            raise ValueError('The SWF compressed data is invalid') from exc
        if not decoder.eof or decoder.unused_data or len(body) + 8 != expected:
            raise ValueError('The compressed SWF is truncated or has an invalid length')
    return {'swf_format': data[3], 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def download(url, output, *, replace=False):
    output = Path(output)
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ('https', 'http') or not parts.hostname or parts.username or parts.password:
        raise ValueError('Use an HTTP(S) URL without embedded credentials')
    if output.exists() and not replace:
        raise FileExistsError('Output already exists; use --replace to refresh it explicitly')
    request = urllib.request.Request(url, headers={'User-Agent': 'NovoClient-SWF-Downloader/1.0', 'Accept': 'application/x-shockwave-flash,application/octet-stream;q=0.9,*/*;q=0.5'})
    # urllib keeps standard certificate and hostname verification enabled for HTTPS.
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(MAX_BYTES + 1)
        if len(data) > MAX_BYTES:
            raise ValueError('The response exceeded the maximum download size')
    info = validate_swf(data)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=output.name+'.', suffix='.tmp', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        os.replace(temporary, output)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default=DEFAULT_URL)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'dist'/'game-official.swf')
    parser.add_argument('--replace', action='store_true', help='Replace an existing output only after a new download validates')
    args = parser.parse_args()
    try:
        info = download(args.url, args.output, replace=args.replace)
    except urllib.error.HTTPError as exc:
        print(f'Download failed: HTTP {exc.code}. No SWF was published; the site or a network intermediary rejected the request.')
        return 1
    except urllib.error.URLError as exc:
        print('Download failed: connection, DNS or TLS error: ' + str(exc.reason) + '. No SWF was published.')
        return 1
    except (ValueError, OSError) as exc:
        print('Download failed: ' + str(exc))
        return 1
    print('SWF downloaded and structurally validated:', args.output)
    print('SWF format:', info['swf_format'], '| bytes:', info['bytes'])
    print('SHA256:', info['sha256'])
    print('This checks the file, not gameplay or compatibility with a particular Flash runtime.')
    print('Start locally: python serve_client.py --swf "' + str(args.output) + '"')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
