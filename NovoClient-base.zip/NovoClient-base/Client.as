package {
    import ChargeurTransformice_fla.TransformiceChargeur;
    [SWF(width="800", height="600", frameRate="30", backgroundColor="#161B26")]
    public class Client extends TransformiceChargeur {
        public function Client() { super(); }
    }
}
