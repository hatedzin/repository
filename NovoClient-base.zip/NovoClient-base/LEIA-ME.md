# NovoClient — base compilável do ChargeurTransformice

Esta é uma base derivada da source enviada. Não é uma entrega de Fly, salto alto
ou Robot funcionando no Transformice atual. O Auto Play legado foi conservado,
mas depende de perfil de símbolos e gravações compatíveis ainda não disponíveis.

## Abrir

A base foi recompilada para as APIs do Flash 10.0 e formato SWF 10. O erro #1065
na leitura da configuração foi tratado substituindo JSON nativo pela biblioteca
JSONE incluída na source. A SWF do jogo pode exigir um runtime mais novo do que o
loader; essa mudança não garante compatibilidade de qualquer jogo com Flash 10.

O arquivo compilado fica em `dist/NovoClient.swf`. Abra-o em um runtime/projector
Flash compatível com Flash 10.0 ou superior, mantendo `client-config.json` ao lado.
Um navegador moderno comum não executa SWF. Não é necessário Adobe Animate para
usar o SWF ou compilá-lo com Apache Flex; ainda é necessário um runtime para SWF.
Não incluí executável Flash nem um instalador de terceiros no pacote.

Se o projector bloquear arquivos/configuração locais, execute `python serve_client.py`
e abra `http://127.0.0.1:8082/NovoClient.swf` pelo menu Arquivo > Abrir do projector.
Esse helper só publica a pasta dist na interface local, sem expor fontes ou .env.

### Baixar o jogo pelo Python em vez do Flash

Se o Flash mostra #2035 ao acessar o site, execute na pasta da base:

```console
python download_game.py
python serve_client.py --swf "dist\game-official.swf"
```

Execute o segundo comando somente se o primeiro confirmar que salvou uma SWF.
Abra depois http://127.0.0.1:8082/NovoClient.swf no projector compatível.
O downloader usa HTTPS com verificação de certificado e hostname padrão, segue
redirecionamentos, verifica assinatura/tamanho e a descompressão da SWF e só então
publica o arquivo. HTML/JSON de erro não são tratados como jogo. Para atualizar
um arquivo existente explicitamente, use `python download_game.py --replace`.
O SHA256 exibido identifica o conteúdo baixado; não é comparação com um hash
oficial conhecido nem prova de que a partida funciona.

O domínio oficial ficou inacessível pelo proxy deste ambiente; o download real
precisa ser verificado na máquina do usuário. Os testes do downloader usam apenas
um servidor HTTP local e fixtures identificadas, sem simular uma partida.
Se houver falha HTTP/TLS, o script mostra o motivo e não publica um arquivo novo.
Isso não transforma uma SWF recente em um jogo compatível com Flash Player 10.

### Jogo em arquivo local (sem o endpoint de jogo da porta 8080)

Se o backend retorna erro/JSON no lugar da SWF, execute na pasta da base:

```console
python serve_client.py --swf "C:\caminho\DisneyParser\tfm.swf"
```

Escolha o arquivo do jogo, não NovoClient.swf nem ChargeurTransformice.swf.
O helper publica apenas o arquivo explicitamente escolhido em /local-game.swf e
altera game_url somente na resposta HTTP de configuração; não modifica o JSON
salvo, não copia a SWF e não requer o backend para esse download. Perfil de
símbolos/mapas, se configurados, continuam necessários para os recursos legados.
O tfm.swf recebido usa formato SWF 14; para ele, o runtime de referência é Flash
11.1+. A compatibilidade do loader com Flash 10 não muda a exigência do jogo.

O config padrão aponta a SWF do backend local DisneyClient:

```json
{
  "game_url": "http://127.0.0.1:8080/transformice?swf",
  "keylist_url": "",
  "maps_url": ""
}
```

Mantenha o servidor Python e seu parser disponíveis e fornecendo uma SWF válida.
Para outra SWF autorizada, altere `game_url` no config ao lado do SWF compilado.
Sem `keylist_url`, o loader carrega a SWF sem instalar os hooks ou menus legados.
Isso permite diagnosticar o carregamento sem executar perfis inventados.

## Recursos legados

`keylist_url` aceita o formato original `{ "keys": [ { ... } ] }`. Os nomes e os
valores devem corresponder ao jogo real. O resultado atual do DisneyParser NÃO é
automaticamente compatível: os contratos e nomes dos símbolos são diferentes.
Não existe conversão validada incluída nesta entrega. `maps_url` aponta para as
gravações do Auto Play no formato antigo; não habilite sem dados compatíveis.
Nenhum perfil vazio é apresentado como recurso funcional. Não há AOBs ou patches
nativos aplicados; tampouco alteração de checagens de domínio/tamanho do jogo.

## Compilar sem Adobe Animate

Use Apache Flex SDK 4.16.1 e a biblioteca playerglobal 10.0. Configure `FLEX_HOME`
para a pasta do SDK, que deve conter `frameworks/libs/player/10.0/playerglobal.swc`.
No Windows, execute `build.cmd`. No Linux, execute `bash build.sh`.
A flag strict=false é necessária porque a source legada usa classes dinâmicas.
O compilador ainda reporta erros; a flag não ignora falhas de compilação.

## Projeto do Animate

`originals/ChargeurTransformice-original.fla` é o original preservado. Ele tinha um tamanho incorreto
no índice ZIP interno. `ChargeurTransformice-reparado.fla` corrige esse metadado;
os 124 arquivos internos passaram na verificação CRC, sem alterar seus conteúdos.
A abertura no Animate não foi testada. Os assets de loading do `.fla` não são
necessários para a compilação Flex: a barra é criada em ActionScript.

## Limitações de validação

O relatório BUILD_REPORT.md registra os comandos executados. Não há teste visual
Flash neste ambiente e não foi confirmada a execução de partida online. Sucesso
na compilação e integridade da SWF não comprovam compatibilidade com o servidor.
