# NovoClient — base compilável do ChargeurTransformice

Esta é uma base derivada da source enviada. Não é uma entrega de Fly, salto alto
ou Robot funcionando no Transformice atual. O Auto Play legado foi conservado,
mas depende de perfil de símbolos e gravações compatíveis ainda não disponíveis.

## Abrir

O arquivo compilado fica em `dist/NovoClient.swf`. Abra-o em um runtime/projector
Flash compatível com Flash 11.1 ou superior, mantendo `client-config.json` ao lado.
Um navegador moderno comum não executa SWF. Não é necessário Adobe Animate para
usar o SWF ou compilá-lo com Apache Flex; ainda é necessário um runtime para SWF.
Não incluí executável Flash nem um instalador de terceiros no pacote.

Se o projector bloquear arquivos/configuração locais, execute `python serve_client.py`
e abra `http://127.0.0.1:8082/NovoClient.swf` pelo menu Arquivo > Abrir do projector.
Esse helper só publica a pasta dist na interface local, sem expor fontes ou .env.

O config padrão aponta a SWF do backend local DisneyClient:

```json
{
  "game_url": "http://127.0.0.1:8080/transformice?swf",
  "keylist_url": "",
  "maps_url": ""
}
```

Mantenha o servidor Python e seu parser disponíveis e fornecendo uma SWF válida.
Para outra SWF autorizada, altere `game_url` no config ao lado do SWF compilado.
Sem `keylist_url`, o loader carrega a SWF sem instalar os hooks ou menus legados.
Isso permite diagnosticar o carregamento sem executar perfis inventados.

## Recursos legados

`keylist_url` aceita o formato original `{ "keys": [ { ... } ] }`. Os nomes e os
valores devem corresponder ao jogo real. O resultado atual do DisneyParser NÃO é
automaticamente compatível: os contratos e nomes dos símbolos são diferentes.
Não existe conversão validada incluída nesta entrega. `maps_url` aponta para as
gravações do Auto Play no formato antigo; não habilite sem dados compatíveis.
Nenhum perfil vazio é apresentado como recurso funcional. Não há AOBs ou patches
nativos aplicados; tampouco alteração de checagens de domínio/tamanho do jogo.

## Compilar sem Adobe Animate

Use Apache Flex SDK 4.16.1 e a biblioteca playerglobal 11.1. Configure `FLEX_HOME`
para a pasta do SDK, que deve conter `frameworks/libs/player/11.1/playerglobal.swc`.
No Windows, execute `build.cmd`. No Linux, execute `bash build.sh`.
A flag strict=false é necessária porque a source legada usa classes dinâmicas.
O compilador ainda reporta erros; a flag não ignora falhas de compilação.

## Projeto do Animate

`originals/ChargeurTransformice-original.fla` é o original preservado. Ele tinha um tamanho incorreto
no índice ZIP interno. `ChargeurTransformice-reparado.fla` corrige esse metadado;
os 124 arquivos internos passaram na verificação CRC, sem alterar seus conteúdos.
A abertura no Animate não foi testada. Os assets de loading do `.fla` não são
necessários para a compilação Flex: a barra é criada em ActionScript.

## Limitações de validação

O relatório BUILD_REPORT.md registra os comandos executados. Não há teste visual
Flash neste ambiente e não foi confirmada a execução de partida online. Sucesso
na compilação e integridade da SWF não comprovam compatibilidade com o servidor.
