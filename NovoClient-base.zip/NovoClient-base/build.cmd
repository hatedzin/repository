@echo off
setlocal
cd /d "%~dp0"
if "%FLEX_HOME%"=="" (
 echo Defina FLEX_HOME com a pasta do Apache Flex SDK 4.16.1.
 exit /b 1
)
set "PLAYERGLOBAL_HOME=%FLEX_HOME%\frameworks\libs\player"
if not exist dist mkdir dist
call "%FLEX_HOME%\bin\mxmlc.bat" -strict=false -compiler.omit-trace-statements=false -target-player=11.1 -swf-version=14 -source-path=. -static-link-runtime-shared-libraries=true -output=dist\NovoClient.swf Client.as
if errorlevel 1 exit /b 1
copy /y client-config.json dist\client-config.json >nul
