// ActionScript 3 / FollowTests.as / Ruffle AVM2 / normal movement without continuous physics writes or repeated teleports
package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.text.TextField;import flash.external.ExternalInterface;import flash.utils.ByteArray;
 public class RgbMouseTests {
  private static var count:int=0;private static function check(ok:Boolean,name:String):void{if(!ok)throw new Error(name);count++;}
  private static function signed(b:ByteArray):int{var v:int=0;var shift:int=0;var part:int;do{part=b.readUnsignedByte();v|=(part&127)<<shift;shift+=7;}while(part&128);if(shift<32 && (part&64))v|=(-1)<<shift;return v;}
  public static function run(display:MovieClip):void{
   var result:String;
   try{
    var r:MovieClip=new MovieClip();display.addChild(r);r.stage.focus=r.stage;var pressed:Object={};r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{pressed[e.keyCode]=true;});r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{pressed[e.keyCode]=false;});
    var body:Object={velocity:{vx:7,vy:9},place:function(p:Object,a:Number):void{throw new Error("Unexpected physics write");}};
    var local:Object={nick:"Self#0001",x:10,y:20,dead:false,clip:true,body:body};var target:Object={nick:"Target#0000",x:300,y:150,dead:false,clip:true,body:{velocity:{vx:2,vy:-8}}};var teleports:int=0;
    r["Keys"]={player:"self",player_list:"players",player_name:"nick",is_dead:"dead",player_clip:"clip",player_physics:"body",bot_set_position:"place",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",packet_handler_class:{receive:function(b:ByteArray):void{b.readUnsignedByte();b.readUnsignedByte();local.x=signed(b);local.y=signed(b);teleports++;}},packet_handler:"receive",map_class:{current:{number:{code:1}}},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"code"};
    r["tfm"]={self:local,players:[target]};var f:FollowController=new FollowController(r);f.command("/follow Target#0000");f.update(0);check(teleports==1 && local.x==300 && local.y==150,"single native initial teleport");check(!pressed[38],"rising velocity never triggers jump");
    target.x=400;target.y=50;f.update(20);check(local.x==300 && local.y==150,"target position not copied continuously");check(body.velocity.vx==7 && body.velocity.vy==9,"local velocity untouched");check(pressed[39] && !pressed[38] && teleports==1,"normal right movement without flight or repeated teleport");
    target.x=200;f.update(40);check(pressed[37] && !pressed[39],"normal left movement");target.x=310;f.update(60);check(!pressed[37] && !pressed[39],"distance deadzone");
    r.Keys.is_jumping="jumpActive";target.jumpActive=true;f.update(80);check(pressed[38],"known real jump state copied");target.jumpActive=false;f.update(100);check(!pressed[38],"known jump release copied");
    var input:TextField=new TextField();input.type="input";r.addChild(input);r.stage.focus=input;f.update(120);r.stage.focus=r.stage;f.update(140);check(teleports==1,"typing does not rearm teleport");
    target.x=600;f.update(160);target.clip=false;f.update(180);check(!pressed[39] && teleports==1 && local.x==300,"target entering hole pauses without copying invalid coordinates");target.clip=true;f.update(200);check(pressed[39] && teleports==1,"target returns without repeated teleport");
    r.tfm.players=[];f.update(220);r.tfm.players=[target];f.update(240);check(teleports==1,"temporary target loss does not rearm teleport");
    local.dead=true;f.update(260);local.dead=false;f.update(280);check(teleports==2 && local.x==600,"respawn receives one synchronization");
    r.Keys.map_class.current={number:{code:2}};target.x=700;f.update(300);f.update(320);check(teleports==3 && local.x==700,"round change gets one synchronization");
    f.command("/follow off");target.x=900;f.update(340);check(teleports==3 && !pressed[39],"off releases controls");
    f.command("/follow Target#0000");target.clip=false;f.update(360);check(teleports==3,"command cannot teleport to player already in hole");target.clip=true;f.update(380);check(teleports==4,"pending first synchronization waits for live target");
    f.keyDown(new KeyboardEvent(KeyboardEvent.KEY_DOWN,true,false,0,27));f.update(400);check(!pressed[37] && !pressed[39] && !pressed[38],"escape stops controls");
    result="PASS: "+count+" normal-physics follow checks";
   }catch(e:Error){result="FAIL: "+e.message+" #"+e.errorID;}
   ExternalInterface.call("recordTest",result);
  }
 }
}
