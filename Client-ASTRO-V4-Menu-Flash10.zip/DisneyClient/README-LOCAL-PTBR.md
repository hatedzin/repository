# DisneyClient — pacote local corrigido

Esta cópia parte do `DisneyClient-main.zip` enviado. O README original do repositório informa que o DisneyClient foi arquivado e não recebe manutenção. Esta atualização corrige bloqueios do modo local; não transforma os serviços antigos em serviços oficialmente suportados.

## Iniciar no Windows

1. Instale **Python 3.11, 3.12 ou 3.13 x64** (3.11/3.12 são preferidos para este projeto legado).
2. Extraia a pasta inteira.
3. Execute o único inicializador `INICIAR.bat`.
4. O inicializador procura Python 3.11/3.12/3.13 tanto por `py` quanto por `python`, cria `.venv`, instala as dependências na primeira execução e abre o Parser e o Client em duas janelas separadas. Não é necessário executar outro BAT.
5. A página abre em `http://localhost:8090`. Se uma janela de serviço encerrar, ela permanece aberta mostrando o erro. Os detalhes da instalação ficam em `logs\inicializacao.log`. Se ocorrer erro durante a execução, mantenha aberta a janela do serviço e copie a mensagem exibida.

Mantenha as duas janelas abertas. Não abra o arquivo SWF diretamente; o client precisa do servidor local.

### Criar uma chave de teste local

O SQLite começa sem usuários. Depois de executar o inicializador uma vez, rode `".venv\Scripts\python.exe" CRIAR_CHAVE_LOCAL.py` em um Prompt de Comando aberto na pasta do client. Ele cria uma chave aleatória de nível GOLD_II no SQLite local e mostra a chave no terminal. Use-a na página local para testar o menu e o acesso às rotas. Essa chave é apenas para esta instalação local, não é uma licença online do Transformice. O script se recusa a criar usuários se detectar um banco remoto configurado.

## Rotas que já vêm no pacote

O arquivo `DisneyClient/public/maps.json` foi preservado. Ele contém **2.357 códigos de mapas/rotas** no formato comprimido usado pelo client. Também corrigi o sinalizador `maps_allowed` para considerar os níveis autorizados no catálogo, mesmo quando a conta ainda não tem uma tabela pessoal de rotas.

O servidor agora:
- entrega o catálogo embutido quando a conta não tem armazenamento pessoal;
- usa os dados pessoais quando existem;
- cria o registro pessoal na primeira gravação SAVE, em vez de rejeitar o primeiro salvamento.

## Banco e chave de acesso

Por padrão, o client usa SQLite local em `DisneyClient/disneyclient-local.sqlite3`. As tabelas são criadas automaticamente, sem apagar tabelas existentes.

**O banco começa vazio.** A página e o servidor podem iniciar, mas o login só aceita uma chave cadastrada na tabela `users`. Para recuperar suas contas e rotas pessoais antigas, configure `MARIADB_ENDPOINT` em `.env` para o banco original, por exemplo:

`mysql+pymysql://usuario:senha@host:3306/banco`

Este ZIP não contém backup do banco nem credenciais do seu servidor, então dados remotos não podem ser recuperados automaticamente. O catálogo público de 2.357 rotas já está incluído e não depende desse banco.

Não compartilhe seu `.env` ou credenciais do banco.

## Menu ASTRO / Parser / SWF do jogo

O `ChargeurTransformice.swf` agora é o carregador ASTRO V4 do outro client enviado, que inclui a interface ASTRO MENU. Também foram incluídas as imagens CJ, Big Smoke, Minecraft e Gragas usadas pelo Skin Changer.

**Tentativa de compatibilidade com Flash Player 10:** o cabeçalho do carregador ASTRO V4 e do SWF servido pelo client é anunciado como versão 10. A inspeção estática encontrou apenas tags SWF disponíveis até essa versão. Isso não converte APIs ActionScript novas; recursos não existentes no Player 10 ainda podem impedir a abertura do jogo ou do menu. Depois do login, copie o link gerado e abra-o no Flash Player standalone. O site não incorpora o player nem inicia um executável local automaticamente.

O Parser usa `DisneyParser/tools/swfdump.exe` no Windows e tenta baixar o SWF atual do jogo. Se o download falhar no primeiro início, tenta analisar o `Transformice.swf` incluído no pacote. A cópia incluída pode estar desatualizada; a atualização depende de o endpoint do jogo continuar acessível e de o formato permanecer compatível com este parser antigo.

O token local de comunicação está em `.env` (`TFM_PARSER_API_TOKEN`). Client e Parser leem o mesmo valor. O Client espera o Parser disponibilizar as chaves antes de responder ao loader.

## Integrações opcionais

- Discord: deixe `DISCORD_API_TOKEN` vazio para executar sem bot. Para ativar, preencha o token e instale as dependências opcionais com `".venv\Scripts\python.exe" -m pip install -r DisneyClient\requirements-optional.txt`.
- Google Sheets: só é necessário para o modo hospedado. Coloque sua própria chave de serviço como `DisneyClient/service_account_credentials.json` e instale as integrações opcionais. O modo local usa `public/record_list.json`.

O ZIP original continha uma chave privada de service account e um token de parser. Ambos foram removidos desta cópia. Caso ainda estejam ativos, revogue/rotacione a credencial do Google Cloud e gere um token novo para o parser.

## Testes realizados nesta cópia

- Importação do servidor e do parser.
- Criação de tabelas SQLite e gravação/leitura de usuários, configurações, mapas e soft maps.
- Página principal (`/`), API de atualização (`/api/update`) e API do Discord (`/api/discord`).
- Autenticação local com um usuário de teste.
- Leitura do catálogo por `/mapstorage` (resposta de 3.215.680 bytes, descompactando para 16.650.071 bytes).
- Primeiro SAVE de rota em conta sem registro pessoal (HTTP 204) e recuperação do dado gravado.
- `maps_allowed` para nível permitido, consultando um endpoint Parser de teste.

Esses testes validam o backend e o armazenamento; não substituem um teste no Windows com `swfdump.exe`, Flash runtime e uma conta/banco reais.

## Limitações conhecidas

Este ZIP contém o backend, as páginas e os arquivos SWF, mas não inclui um executável desktop/Flash player completo nem seu banco de contas. Navegadores modernos não executam SWF por conta própria. O jogo legado ainda depende de um runtime Flash compatível, do Parser conseguir extrair as chaves e de uma conta válida cadastrada no banco.
