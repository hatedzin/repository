#include "bloco/history.hpp"
#include "bloco/project_store.hpp"
#include <iostream>
int main(int argc,char** argv) {
    try {
        bloco::Document doc("Arena de exemplo");
        bloco::Layer floor;floor.name="Estrutura";doc.add_layer(floor);
        bloco::Material grass;grass.name="Grama";grass.texture="textures/grama.dtx";grass.color={.35,.65,.25,1};doc.add_material(grass);
        bloco::Material stone;stone.name="Pedra";stone.texture="textures/pedra.dtx";doc.add_material(stone);
        bloco::History history(doc);
        std::vector<bloco::BlockEdit> edits;
        for(int x=-8;x<8;++x)for(int z=-8;z<8;++z) {
            edits.push_back({floor.id,{x,0,z},bloco::Block::uniform(grass.id)});
            if(x==-8||x==7||z==-8||z==7)for(int y=1;y<=3;++y)edits.push_back({floor.id,{x,y,z},bloco::Block::uniform(stone.id)});
        }
        history.execute("Construir arena",std::move(edits));
        bloco::Entity base;base.layer=floor.id;base.name="Base azul (referencia)";base.class_name="editor.marker";
        base.transform.position={-320,64,0};base.properties["team"]=std::string("blue");
        base.properties["gameEntityValidated"]=false;doc.add_entity(base);
        const std::filesystem::path path=argc>1?argv[1]:"arena-exemplo";
        bloco::ProjectStore::save(doc,path);
        auto reopened=bloco::ProjectStore::load(path);
        std::cout<<"Projeto salvo e reaberto: "<<path<<"\n"<<reopened.block_count()<<" blocos / "<<reopened.chunks().size()<<" chunks / "<<reopened.entities().size()<<" entidade de referencia\n";
        std::cout<<"Este modulo nao exporta LTA nem cria pontos de nascimento funcionais.\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
