#pragma once
#include "document.hpp"
#include <cstddef>
namespace bloco {
struct BlockEdit { Id layer; Cell cell; std::optional<Block> value; };
// Single-threaded. One batch is one undo step; all edits succeed or none do.
// Direct Document edits invalidate this history until clear() is called.
class History {
public:
    explicit History(Document& document,std::size_t max_steps=256);
    bool execute(std::string label,std::vector<BlockEdit> edits);
    bool undo();
    bool redo();
    void clear();
    bool can_undo() const noexcept { return cursor_>0; }
    bool can_redo() const noexcept { return cursor_<entries_.size(); }
    std::size_t size() const noexcept { return entries_.size(); }
private:
    struct Entry { std::string label;std::vector<BlockEdit> before,after; };
    Document& document_;
    Id document_id_;
    std::uint64_t expected_;
    std::size_t limit_,cursor_{};
    std::vector<Entry> entries_;
    void check_revision() const;
    void apply(const std::vector<BlockEdit>& edits);
};
}
