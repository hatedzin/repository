#pragma once
#include <array>
#include <compare>
#include <cstdint>
#include <map>
#include <optional>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>

namespace bloco {
class Error : public std::runtime_error { public: using std::runtime_error::runtime_error; };
class Id {
public:
    Id(); // UUID v4; persistent identity, never a pointer or array index.
    explicit Id(std::string canonical_uuid);
    const std::string& str() const noexcept { return value_; }
    auto operator<=>(const Id&) const = default;
private:
    std::string value_;
};
struct Cell {
    std::int32_t x{}, y{}, z{};
    auto operator<=>(const Cell&) const = default;
};
inline constexpr int chunk_size = 16;
struct Address { Cell chunk; std::uint16_t index; };
Address address_of(Cell cell) noexcept;
Cell cell_of(Cell chunk, std::uint16_t index);
struct Vec3 {
    double x{}, y{}, z{};
    bool operator==(const Vec3&) const = default;
};
struct Transform {
    Vec3 position{};
    Vec3 rotation_degrees{}; // Euler XYZ; adapter must explicitly convert to target conventions.
    Vec3 scale{1,1,1};
    bool operator==(const Transform&) const = default;
};
struct EntityRef { Id id; bool operator==(const EntityRef&) const = default; };
using Property = std::variant<bool,std::int64_t,double,std::string,Vec3,EntityRef>;
struct Material {
    Id id;
    std::string name;
    std::string texture; // Relative project path; UTF-8. Empty means untextured.
    std::array<double,4> color{1,1,1,1};
    bool operator==(const Material&) const = default;
};
struct Layer {
    Id id;
    std::string name;
    bool visible{true};
    bool locked{false};
    bool operator==(const Layer&) const = default;
};
// Face order: +X, -X, +Y, -Y, +Z, -Z. Air is absence of a Block.
struct Block {
    std::array<Id,6> materials;
    static Block uniform(const Id& material);
    bool operator==(const Block&) const = default;
};
struct Entity {
    Id id;
    Id layer;
    std::string name;
    std::string class_name; // Game-specific name; existence checked by future LithTech adapter.
    Transform transform;
    std::optional<Id> parent;
    std::map<std::string,Property> properties;
    bool operator==(const Entity&) const = default;
};
struct ChunkKey {
    Id layer;
    Cell position;
    auto operator<=>(const ChunkKey&) const = default;
};
using Chunk = std::map<std::uint16_t,Block>;
class ProjectStore;
class Document {
public:
    explicit Document(std::string name="Novo mapa");
    const Id& id() const noexcept { return id_; }
    const std::string& name() const noexcept { return name_; }
    double units_per_block() const noexcept { return units_; }
    std::uint64_t revision() const noexcept { return revision_; }
    const auto& materials() const noexcept { return materials_; }
    const auto& layers() const noexcept { return layers_; }
    const auto& entities() const noexcept { return entities_; }
    const auto& chunks() const noexcept { return chunks_; }
    void set_name(std::string name);
    void set_units_per_block(double units);
    void add_material(Material material);
    void add_layer(Layer layer);
    void update_layer(Layer layer);
    void add_entity(Entity entity);
    void update_entity(Entity entity);
    void remove_entity(const Id& id); // Refuses dangling parent/property references.
    std::optional<Block> block(const Id& layer, Cell cell) const;
    void set_block(const Id& layer, Cell cell, std::optional<Block> block);
    std::size_t block_count() const noexcept;
    // Global invariants, including entity references and hierarchy cycles.
    void validate() const;
private:
    friend class ProjectStore;
    Id id_;
    std::string name_;
    double units_{64};
    std::uint64_t revision_{};
    std::map<Id,Material> materials_;
    std::map<Id,Layer> layers_;
    std::map<Id,Entity> entities_;
    std::map<ChunkKey,Chunk> chunks_;
    bool id_used(const Id& id) const;
    void require_editable(const Id& layer) const;
    void validate_entity(const Entity& entity,bool check_hierarchy=true) const;
};
}
