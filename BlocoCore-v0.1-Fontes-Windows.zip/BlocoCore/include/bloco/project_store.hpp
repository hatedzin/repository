#pragma once
#include "document.hpp"
#include <filesystem>
namespace bloco {
struct LoadLimits {
    std::uintmax_t max_file_bytes{32*1024*1024};
    std::uintmax_t max_total_bytes{256*1024*1024};
    std::size_t max_chunks{65536};
    std::size_t max_blocks{1000000};
    std::size_t max_entities{100000};
};
class ProjectStore {
public:
    static constexpr int format_version=1;
    // Directory store; a complete generation is written before project.json is replaced.
    // Concurrent save calls are rejected by a directory lock. Call on the owning thread
    // or supply an independent Document snapshot to a worker.
    static void save(const Document& document,const std::filesystem::path& directory);
    static Document load(const std::filesystem::path& directory,LoadLimits limits={});
};
}
