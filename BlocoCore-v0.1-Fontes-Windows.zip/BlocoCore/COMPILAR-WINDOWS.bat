@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul
if errorlevel 1 (
  echo Instale CMake 3.20+ e Visual Studio 2022 com C++ Desktop.
  exit /b 1
)
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
if errorlevel 1 exit /b 1
cmake --build build --config Release
if errorlevel 1 exit /b 1
ctest --test-dir build -C Release --output-on-failure
if errorlevel 1 exit /b 1
build\Release\bloco_demo.exe arena-exemplo
if errorlevel 1 exit /b 1
echo Modulo compilado e testes aprovados. Exemplo em arena-exemplo.
