# Decisões do primeiro módulo

## Separação de responsabilidades

O domínio em `document.hpp` usa somente a biblioteca padrão C++20.
`project_store.cpp` é o único módulo que conhece nlohmann/json e as operações de disco.
`History` pertence à camada de aplicação e aplica lotes sobre `Document`.
A UI futura referencia `Bloco::Core`, sem exigir que o domínio conheça Qt ou Direct3D.

## Invariantes

1. IDs canônicos e globalmente únicos entre projeto, materiais, camadas e entidades.
2. Todas as faces de um bloco referenciam materiais existentes.
3. Todos os blocos e entidades pertencem a camadas existentes.
4. Camadas bloqueadas não podem ter blocos ou entidades editados pelas APIs de edição.
5. A árvore de parentesco é acíclica; referências de propriedades são válidas.
6. Transformações e propriedades numéricas são finitas; textos são UTF-8 válido.
7. Blocos são indexados por chunk e camada; cada posição local ocorre uma vez.

As coleções são expostas por referência const. Alterações passam por métodos validados.
`ProjectStore` tem acesso de reconstrução para carregar camadas bloqueadas e resolver
referências futuras; o documento só é devolvido depois da validação global.
A checagem global da hierarquia visita os caminhos uma vez, com mapas de estado,
em vez de percorrer todos os ancestrais de todas as entidades repetidamente.

## Histórico

Uma execução agrupa várias alterações de células em uma etapa. Repetir a mesma
célula no lote é erro; um lote sem mudanças não cria etapa. As validações são
aplicadas mesmo para operações que não mudam um bloco em camada bloqueada.
Um erro no meio do lote mantém o documento e o histórico anteriores.
Após undo, uma edição nova descarta o ramo de redo.
O limite padrão é 256 etapas, configurável. Não há orçamento em bytes nesta versão.
Cada etapa retém o estado anterior/posterior das células afetadas.
A execução usa uma cópia transitória do documento para assegurar rollback.
Esse custo precisa de medição antes da evolução para mapas grandes; a substituição
natural é staging e compartilhamento de chunks, mantendo o contrato de comandos.

## Evolução imediata

- Teste de compilação e persistência em Windows x64 real, inclusive pastas Unicode.
- Contrato exato de orientação, rotação e escala entre editor e DEdit.
- Adaptador LTA com um mapa mínimo de referência validado pelo DEdit alvo.
- Comandos de entidades, materiais e camadas; atualização/remoção de materiais
  precisa verificar uso antes de permitir referências pendentes.
- Remoção de camadas e recursos com política explícita para seu conteúdo.
- Geometria de brushes fechados e separação da malha de visualização.
- UI e renderização somente depois dos contratos de coordenadas e persistência.

Nenhum componente LithTech é carregado ou executado por este módulo.
