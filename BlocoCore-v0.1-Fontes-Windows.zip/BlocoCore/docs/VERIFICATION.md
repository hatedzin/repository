# Verificação realizada

- Compilador: GCC 14.2.0, Linux x86-64.
- CMake: 3.31.6, configurações Debug com sanitizadores e Release.
- Biblioteca e demonstração de console compiladas com C++20.
- Opções de aviso: -Wall -Wextra -Wpedantic -Wconversion -Wshadow.
- Sanitizadores: AddressSanitizer e UndefinedBehaviorSanitizer.
- 28 casos no executável de testes, registrados como uma suíte CTest.
- 28 passaram; zero falhas em ambas as configurações.
- Demonstração: 436 blocos, quatro chunks, uma entidade de referência;
  projeto gravado e reaberto pelo próprio código C++.

O LeakSanitizer não funciona sob o mecanismo de execução desta sessão
(erro de ptrace); os testes de ASan/UBSan foram executados com
`ASAN_OPTIONS=detect_leaks=0`. Não foi verificada a ausência de vazamentos.
Não foram executados testes em Windows, testes de interface gráfica,
importação no DEdit ou compilação de mapas LithTech.

Comandos usados após a configuração:

```sh
cmake --build build -j 2
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build --output-on-failure
ASAN_OPTIONS=detect_leaks=0 ./build/bloco_demo arena-exemplo
```

A bateria cobre UUIDs, chunks negativos e extremos de int32, índices locais,
camadas, materiais por face, referências, transformações, UTF-8, ciclos,
rollback de lotes, undo/redo e ramificação, limites de histórico, roundtrip
completo, limites de leitura, corrupção de dados, versões/campos desconhecidos,
chaves JSON duplicadas, inteiros fora do intervalo, referências futuras,
locks e falhas de salvamento antes da troca do manifesto.
