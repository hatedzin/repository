# Contrato do formato nativo v1

Este é o formato de edição Bloco Arena, independente de LithTech.
Não é um mapa compilado nem um arquivo LTA.

## Estrutura

```text
Projeto/
  project.json
  generations/
    <uuid-da-geracao>/
      materials.json
      scene.json
      chunks/
        <uuid-camada>_<cx>_<cy>_<cz>.json
```

`project.json` é o ponto de entrada. Contém os campos obrigatórios:

| Campo | Tipo e significado |
|---|---|
| format | `"bloco-arena"` |
| version | inteiro `1` |
| id | UUID persistente do documento |
| name | nome UTF-8 |
| unitsPerBlock | número finito > 0 e <= 1.000.000 |
| upAxis | `"Y"` |
| handedness | `"right"` |
| chunkSize | inteiro `16` |
| generation | UUID do snapshot efetivamente publicado |

A geração usa UUID novo a cada save. Identificadores de projeto, camadas,
materiais e entidades permanecem estáveis. A revisão de memória e o histórico
não são salvos; uma carga começa na revisão zero.

## Materiais

`materials.json` contém `{ "materials": [...] }`.
Cada item exige `id`, `name`, `texture` e `color`.
`texture` é um caminho relativo com `/`, sem segmentos `.` ou `..`; pode ser vazio.
`color` tem quatro componentes RGBA entre 0 e 1. A biblioteca não abre a textura
nem presume que o arquivo existe ou que o DEdit aceite sua extensão.

## Cena

`scene.json` contém `layers`, `entities` e `chunks`, todos arrays.
Uma camada exige `id`, `name`, `visible` e `locked`.
A visibilidade é metadado para a futura UI; não remove conteúdo do arquivo.

Uma entidade exige:

- `id`, `layer`, `name` e `class`;
- `parent`: UUID de outra entidade, ou `null`;
- `transform`: `position`, `rotationDegrees` e `scale`, cada um com três números;
- `properties`: objeto cujas entradas têm `type` e `value`.

A rotação é declarada como Euler XYZ em graus. A ordem de aplicação e a conversão
para a engine devem ser fixadas e testadas pelo adaptador antes de exportar.
A escala da entidade é estritamente positiva; todos os componentes são finitos.
As posições de entidade estão em unidades de mundo, não em células.
Tipos de propriedade suportados: `bool`, `int64`, `real`, `string`, `vec3`, `entity_ref`.
Referências a entidades posteriores no arquivo são permitidas; referências ausentes
ou ciclos de parentesco causam erro. Referências entre propriedades podem ser cíclicas:
elas representam ligações, não a árvore de parentesco.

## Chunks e índices

Cada entrada de `chunks` tem apenas `layer` e `position` (coordenada inteira do chunk).
O leitor deriva o nome do arquivo, sem aceitar um caminho arbitrário no JSON.
Cada arquivo de chunk contém `{ "cells": [...] }`; cada célula exige:

- `index`: inteiro entre 0 e 4095;
- `materials`: seis UUIDs de materiais, na ordem +X, -X, +Y, -Y, +Z, -Z.

Não se grava ar: uma célula ausente é vazia. Chunks vazios não são gravados.
As coordenadas locais usam:

```text
index = localX + 16 * (localY + 16 * localZ)
chunkAxis = floor(cellAxis / 16)
localAxis = cellAxis - 16 * chunkAxis
```

A célula X=-1 pertence ao chunk X=-1, com localX=15.
O endereço global de qualquer célula deve caber em int32 com sinal.
Blocos na mesma posição, mas em camadas distintas, são conteúdos diferentes;
a resolução de sobreposições na exportação será responsabilidade do adaptador.

## Salvamento e falhas

1. Validar invariantes do documento.
2. Obter `.save-lock` no diretório do projeto.
3. Criar uma geração nova e gravar seus chunks e metadados.
4. Fechar e sincronizar os arquivos.
5. Gravar manifesto temporário no mesmo diretório do manifesto final.
6. Substituir `project.json` atomicamente e sincronizar o diretório quando suportado.
7. Liberar o lock.

Uma geração incompleta não referenciada é ignorada. Não há limpeza automática.
As gerações antigas não constituem ainda um histórico de versões restaurável pela UI:
os metadados gerais do documento estão no manifesto atual.
A escrita assume um sistema de arquivos local com suporte à substituição atômica.
Não há checksum de conteúdo nesta versão.

## Validação e evolução

Campos extras, chaves JSON duplicadas, tipos desconhecidos, convenções divergentes e
versões diferentes de 1 são recusados. Não há migração implementada nesta versão.
Isso evita a perda silenciosa de dados ao abrir um formato mais novo.
O formato não contém ainda perfil de jogo, brushes ou extensões opacas LithTech.

Limites padrão de leitura: 32 MiB por arquivo, 256 MiB totais, 65.536 chunks,
1.000.000 blocos e 100.000 entidades. Profundidade JSON máxima: 64.
Os limites de volume são configuráveis por `LoadLimits`; profundidade é fixa.
Não há conversão automática de números fracionários para coordenadas inteiras.
O leitor não altera um documento existente: retorna um novo documento apenas se
sua carga e validação forem concluídas.
