#include "bloco/document.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <random>
#include <set>
#include <utility>
#include <type_traits>

namespace bloco {
namespace {
void require(bool condition,const std::string& message) { if(!condition) throw Error(message); }
bool utf8(const std::string& s) {
    std::size_t i=0;
    while(i<s.size()) {
        const auto first=static_cast<unsigned char>(s[i++]);
        if(first<128)continue;
        int extra=0;std::uint32_t value=0,minimum=0;
        if(first>=0xc2&&first<=0xdf){extra=1;value=first&31u;minimum=0x80;}
        else if(first>=0xe0&&first<=0xef){extra=2;value=first&15u;minimum=0x800;}
        else if(first>=0xf0&&first<=0xf4){extra=3;value=first&7u;minimum=0x10000;}
        else return false;
        while(extra--){if(i>=s.size())return false;const auto next=static_cast<unsigned char>(s[i++]);if((next&0xc0u)!=0x80u)return false;value=(value<<6)|(next&63u);}
        if(value<minimum||value>0x10ffff||(value>=0xd800&&value<=0xdfff))return false;
    }
    return true;
}
void text(const std::string& s,const char* field) {
    require(!s.empty() && s.size()<=4096 && utf8(s) && s.find('\0')==std::string::npos,std::string(field)+": texto vazio, grande demais ou com NUL");
}
bool finite(Vec3 v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z); }
void check_material(const Material& m) {
    text(m.name,"material.name");
    for(double c:m.color) require(std::isfinite(c)&&c>=0&&c<=1,"Cor deve estar entre 0 e 1");
    require(m.texture.size()<=4096 && utf8(m.texture) && m.texture.find('\0')==std::string::npos,"Textura invalida");
    if(!m.texture.empty()) {
        require(m.texture.front()!='/' && m.texture.front()!='\\' && m.texture.find(':')==std::string::npos && m.texture.find('\\')==std::string::npos,"Use caminho relativo com / para textura");
        std::size_t begin=0;
        do {
            auto end=m.texture.find('/',begin);
            auto part=m.texture.substr(begin,end==std::string::npos?end:end-begin);
            require(!part.empty()&&part!="."&&part!="..","Caminho de textura invalido");
            if(end==std::string::npos) break;
            begin=end+1;
        } while(true);
    }
}
}
Id::Id() {
    std::random_device random;
    constexpr char hex[]="0123456789abcdef";
    for(int i=0;i<16;++i) {
        auto b=static_cast<unsigned>(random())&255u;
        if(i==6)b=(b&15u)|64u;
        if(i==8)b=(b&63u)|128u;
        if(i==4||i==6||i==8||i==10)value_+='-';
        value_+=hex[b>>4];value_+=hex[b&15u];
    }
}
Id::Id(std::string uuid):value_(std::move(uuid)) {
    require(value_.size()==36,"UUID deve ter 36 caracteres");
    for(std::size_t i=0;i<value_.size();++i) {
        const bool dash=i==8||i==13||i==18||i==23;
        const auto ch=value_[i];
        require(dash?ch=='-':((ch>='0'&&ch<='9')||(ch>='a'&&ch<='f')),"UUID deve ser canonico em minusculas");
    }
    require(value_!="00000000-0000-0000-0000-000000000000","UUID nulo nao permitido");
}
Address address_of(Cell cell) noexcept {
    const auto split=[](std::int32_t v) { return std::pair{static_cast<std::int32_t>(v/16-(v%16<0?1:0)),v%16<0?v%16+16:v%16}; };
    auto [cx,x]=split(cell.x);auto [cy,y]=split(cell.y);auto [cz,z]=split(cell.z);
    return {{cx,cy,cz},static_cast<std::uint16_t>(x+16*(y+16*z))};
}
Cell cell_of(Cell chunk,std::uint16_t index) {
    require(index<4096,"Indice local fora do chunk");
    const auto join=[](std::int32_t c,int local) {
        const auto v=static_cast<std::int64_t>(c)*16+local;
        require(v>=std::numeric_limits<std::int32_t>::min()&&v<=std::numeric_limits<std::int32_t>::max(),"Coordenada excede int32");
        return static_cast<std::int32_t>(v);
    };
    return {join(chunk.x,index%16),join(chunk.y,(index/16)%16),join(chunk.z,index/256)};
}
Block Block::uniform(const Id& material) { return {{material,material,material,material,material,material}}; }
Document::Document(std::string name):name_(std::move(name)) { text(name_,"project.name"); }
bool Document::id_used(const Id& id) const { return id==id_||materials_.contains(id)||layers_.contains(id)||entities_.contains(id); }
void Document::set_name(std::string name) { text(name,"project.name");if(name_!=name){name_=std::move(name);++revision_;} }
void Document::set_units_per_block(double units) {
    require(std::isfinite(units)&&units>0&&units<=1000000,"Escala invalida");
    if(units_!=units){units_=units;++revision_;}
}
void Document::add_material(Material m) {
    check_material(m);require(!id_used(m.id),"UUID duplicado");auto id=m.id;
    materials_.emplace(std::move(id),std::move(m));++revision_;
}
void Document::add_layer(Layer layer) {
    text(layer.name,"layer.name");require(!id_used(layer.id),"UUID duplicado");auto id=layer.id;
    layers_.emplace(std::move(id),std::move(layer));++revision_;
}
void Document::update_layer(Layer layer) {
    text(layer.name,"layer.name");auto it=layers_.find(layer.id);require(it!=layers_.end(),"Camada inexistente");
    if(it->second!=layer){it->second=std::move(layer);++revision_;}
}
void Document::require_editable(const Id& layer) const {
    auto it=layers_.find(layer);require(it!=layers_.end(),"Camada inexistente");require(!it->second.locked,"Camada bloqueada");
}
std::optional<Block> Document::block(const Id& layer,Cell cell) const {
    require(layers_.contains(layer),"Camada inexistente");const auto a=address_of(cell);
    auto chunk=chunks_.find({layer,a.chunk});if(chunk==chunks_.end())return {};
    auto b=chunk->second.find(a.index);if(b==chunk->second.end())return {};return b->second;
}
void Document::set_block(const Id& layer,Cell cell,std::optional<Block> value) {
    require_editable(layer);
    if(value)for(const auto& m:value->materials)require(materials_.contains(m),"Material inexistente");
    if(block(layer,cell)==value)return;
    const auto a=address_of(cell);ChunkKey key{layer,a.chunk};
    if(value){
        auto found=chunks_.find(key);
        if(found==chunks_.end()){Chunk chunk;chunk.emplace(a.index,*value);chunks_.emplace(key,std::move(chunk));}
        else {
            auto existing=found->second.find(a.index);
            if(existing==found->second.end())found->second.emplace(a.index,*value);
            else { Block replacement=*value;std::swap(existing->second,replacement); }
        }
    } else {
        auto found=chunks_.find(key);
        if(found!=chunks_.end()){found->second.erase(a.index);if(found->second.empty())chunks_.erase(found);}
    }
    ++revision_;
}
std::size_t Document::block_count() const noexcept { std::size_t n=0;for(const auto& [key,chunk]:chunks_){(void)key;n+=chunk.size();}return n; }
void Document::validate_entity(const Entity& e,bool check_hierarchy) const {
    require(layers_.contains(e.layer),"Entidade em camada inexistente");text(e.name,"entity.name");text(e.class_name,"entity.class");
    require(finite(e.transform.position)&&finite(e.transform.rotation_degrees)&&finite(e.transform.scale),"Transformacao nao finita");
    auto s=e.transform.scale;require(s.x>0&&s.y>0&&s.z>0,"Escala da entidade deve ser positiva");
    if(e.parent)require(*e.parent!=e.id && entities_.contains(*e.parent),"Pai inexistente ou autorreferencia");
    for(const auto& [name,value]:e.properties) {
        text(name,"property.name");
        std::visit([this](const auto& v){
            using T=std::decay_t<decltype(v)>;
            if constexpr(std::is_same_v<T,double>)require(std::isfinite(v),"Propriedade nao finita");
            else if constexpr(std::is_same_v<T,Vec3>)require(finite(v),"Vetor nao finito");
            else if constexpr(std::is_same_v<T,EntityRef>)require(entities_.contains(v.id),"Referencia de entidade inexistente");
            else if constexpr(std::is_same_v<T,std::string>)require(v.size()<=1048576 && utf8(v) && v.find('\0')==std::string::npos,"Texto de propriedade invalido");
        },value);
    }
    if(!check_hierarchy)return;
    std::set<Id> seen{e.id};auto parent=e.parent;
    while(parent){require(seen.insert(*parent).second,"Ciclo na hierarquia");auto it=entities_.find(*parent);require(it!=entities_.end(),"Pai inexistente");parent=it->second.parent;}
}
void Document::add_entity(Entity entity) {
    require_editable(entity.layer);require(!id_used(entity.id),"UUID duplicado");validate_entity(entity);auto id=entity.id;
    entities_.emplace(std::move(id),std::move(entity));++revision_;
}
void Document::update_entity(Entity entity) {
    auto it=entities_.find(entity.id);require(it!=entities_.end(),"Entidade inexistente");
    require_editable(it->second.layer);require_editable(entity.layer);validate_entity(entity);
    if(it->second!=entity){it->second=std::move(entity);++revision_;}
}
void Document::remove_entity(const Id& id) {
    auto it=entities_.find(id);require(it!=entities_.end(),"Entidade inexistente");require_editable(it->second.layer);
    for(const auto& [key,e]:entities_) {
        if(key==id)continue;
        require(e.parent!=id,"Entidade ainda tem filhos");
        for(const auto& [name,value]:e.properties){(void)name;auto ref=std::get_if<EntityRef>(&value);require(!ref||ref->id!=id,"Entidade ainda e referenciada");}
    }
    entities_.erase(it);++revision_;
}
void Document::validate() const {
    text(name_,"project.name");require(std::isfinite(units_)&&units_>0&&units_<=1000000,"Escala invalida");std::set<Id> ids{id_};
    for(const auto& [id,m]:materials_){require(id==m.id&&ids.insert(id).second,"UUID duplicado");check_material(m);}
    for(const auto& [id,l]:layers_){require(id==l.id&&ids.insert(id).second,"UUID duplicado");text(l.name,"layer.name");}
    for(const auto& [id,e]:entities_){require(id==e.id&&ids.insert(id).second,"UUID duplicado");validate_entity(e,false);}
    // Check the entire hierarchy once; avoid walking every ancestor for every entity.
    std::map<Id,int> state;
    for(const auto& [id,e]:entities_) {
        (void)e;if(state[id]==2)continue;
        std::vector<Id> path;std::optional<Id> current=id;
        while(current&&state[*current]!=2) {
            require(state[*current]!=1,"Ciclo na hierarquia");state[*current]=1;
            path.push_back(*current);current=entities_.at(*current).parent;
        }
        for(const auto& visited:path)state[visited]=2;
    }
    for(const auto& [key,chunk]:chunks_){
        require(layers_.contains(key.layer)&&!chunk.empty(),"Chunk sem camada ou vazio");
        for(const auto& [index,b]:chunk){(void)cell_of(key.position,index);for(const auto& m:b.materials)require(materials_.contains(m),"Material inexistente");}
    }
}
}
