#include "bloco/project_store.hpp"
#include <nlohmann/json.hpp>
#include <cmath>
#include <fstream>
#include <limits>
#include <set>
#include <system_error>
#include <type_traits>
#ifdef _WIN32
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <fcntl.h>
#include <unistd.h>
#endif

namespace bloco {
namespace {
using Json=nlohmann::json;
namespace fs=std::filesystem;
void require(bool condition,const std::string& message){if(!condition)throw Error(message);}
void fields(const Json& j,std::initializer_list<const char*> names) {
    require(j.is_object(),"Esperado objeto JSON");std::set<std::string> expected;
    for(auto name:names){expected.insert(name);require(j.contains(name),std::string("Campo ausente: ")+name);}
    for(auto it=j.begin();it!=j.end();++it)require(expected.contains(it.key()),"Campo desconhecido: "+it.key());
}
std::string string(const Json& j){require(j.is_string(),"Esperado texto");return j.get<std::string>();}
bool boolean(const Json& j){require(j.is_boolean(),"Esperado booleano");return j.get<bool>();}
std::int64_t integer(const Json& j) {
    require(j.is_number_integer(),"Esperado inteiro");
    if(j.is_number_unsigned())require(j.get<std::uint64_t>()<=static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()),"Inteiro excede int64");
    return j.get<std::int64_t>();
}
std::int32_t int32(const Json& j){auto n=integer(j);require(n>=INT32_MIN&&n<=INT32_MAX,"Coordenada excede int32");return static_cast<std::int32_t>(n);}
double number(const Json& j){require(j.is_number(),"Esperado numero");auto n=j.get<double>();require(std::isfinite(n),"Numero nao finito");return n;}
void array(const Json& j,std::size_t size){require(j.is_array()&&j.size()==size,"Tamanho de array invalido");}
Json encode(Cell c){return Json::array({c.x,c.y,c.z});}
Cell cell(const Json& j){array(j,3);return {int32(j[0]),int32(j[1]),int32(j[2])};}
Json encode(Vec3 v){return Json::array({v.x,v.y,v.z});}
Vec3 vec3(const Json& j){array(j,3);return {number(j[0]),number(j[1]),number(j[2])};}
Json encode(const Property& value) {
    return std::visit([](const auto& v)->Json {
        using T=std::decay_t<decltype(v)>;
        if constexpr(std::is_same_v<T,bool>)return { {"type","bool"},{"value",v} };
        else if constexpr(std::is_same_v<T,std::int64_t>)return {{"type","int64"},{"value",v}};
        else if constexpr(std::is_same_v<T,double>)return {{"type","real"},{"value",v}};
        else if constexpr(std::is_same_v<T,std::string>)return {{"type","string"},{"value",v}};
        else if constexpr(std::is_same_v<T,Vec3>)return {{"type","vec3"},{"value",encode(v)}};
        else return {{"type","entity_ref"},{"value",v.id.str()}};
    },value);
}
Property property(const Json& j) {
    fields(j,{"type","value"});auto type=string(j.at("type"));const auto& v=j.at("value");
    if(type=="bool")return boolean(v);
    if(type=="int64")return integer(v);
    if(type=="real")return number(v);
    if(type=="string")return string(v);
    if(type=="vec3")return vec3(v);
    if(type=="entity_ref")return EntityRef{Id(string(v))};
    throw Error("Tipo de propriedade desconhecido: "+type);
}
std::string chunk_name(const ChunkKey& key) {
    const auto c=key.position;
    return key.layer.str()+"_"+std::to_string(c.x)+"_"+std::to_string(c.y)+"_"+std::to_string(c.z)+".json";
}
void no_symlink(const fs::path& path){require(!fs::is_symlink(fs::symlink_status(path)),"Link simbolico nao permitido no projeto");}
void flush_file(const fs::path& path) {
#ifdef _WIN32
    auto handle=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    require(handle!=INVALID_HANDLE_VALUE,"Falha ao abrir arquivo para flush");
    const auto ok=FlushFileBuffers(handle);CloseHandle(handle);require(ok!=0,"Falha ao sincronizar arquivo");
#else
    const int fd=::open(path.c_str(),O_RDONLY);require(fd>=0,"Falha ao abrir arquivo para fsync");
    const int result=::fsync(fd);::close(fd);require(result==0,"Falha ao sincronizar arquivo");
#endif
}
void flush_directory(const fs::path& path) {
#ifndef _WIN32
    const int fd=::open(path.c_str(),O_RDONLY|O_DIRECTORY);require(fd>=0,"Falha ao abrir diretorio para fsync");
    const int result=::fsync(fd);::close(fd);require(result==0,"Falha ao sincronizar diretorio");
#else
    (void)path; // Directory metadata durability depends on the Windows filesystem.
#endif
}
void write_json(const fs::path& path,const Json& data) {
    const auto bytes=data.dump(2,' ',false,Json::error_handler_t::strict)+"\n";
    std::ofstream out(path,std::ios::binary|std::ios::trunc);require(bool(out),"Falha ao criar arquivo JSON");
    out.write(bytes.data(),static_cast<std::streamsize>(bytes.size()));out.flush();require(bool(out),"Falha ao gravar arquivo JSON");
    out.close();require(!out.fail(),"Falha ao fechar arquivo JSON");flush_file(path);
}
void replace_manifest(const fs::path& source,const fs::path& target) {
#ifdef _WIN32
    require(MoveFileExW(source.c_str(),target.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0,"Falha ao substituir manifesto");
#else
    fs::rename(source,target);
#endif
}
class Lock {
    fs::path path_;
public:
    explicit Lock(fs::path path):path_(std::move(path)){require(fs::create_directory(path_),"Projeto em uso ou lock de salvamento pendente");}
    ~Lock(){std::error_code error;fs::remove(path_,error);}
    Lock(const Lock&)=delete;Lock& operator=(const Lock&)=delete;
};
struct Reader {
    LoadLimits limits;std::uintmax_t total{};
    Json read(const fs::path& path) {
        no_symlink(path);require(fs::is_regular_file(path),"Arquivo do projeto ausente");
        const auto size=fs::file_size(path);
        require(size<=limits.max_file_bytes&&total<=limits.max_total_bytes&&size<=limits.max_total_bytes-total,"Limite de leitura excedido");total+=size;
        std::ifstream in(path,std::ios::binary);require(bool(in),"Falha ao abrir JSON");
        // Bounded allocation even if a file grows while it is read.
        std::string bytes(static_cast<std::size_t>(size),'\0');in.read(bytes.data(),static_cast<std::streamsize>(size));
        require(in.gcount()==static_cast<std::streamsize>(size)&&in.peek()==std::char_traits<char>::eof(),"Arquivo mudou durante a leitura");
        std::vector<std::set<std::string>> keys;
        return Json::parse(bytes,[&keys](int depth,Json::parse_event_t event,Json& parsed){
            require(depth<=64,"JSON excede profundidade maxima");
            if(event==Json::parse_event_t::object_start)keys.emplace_back();
            else if(event==Json::parse_event_t::key)require(keys.back().insert(parsed.get<std::string>()).second,"Chave JSON duplicada");
            else if(event==Json::parse_event_t::object_end)keys.pop_back();
            return true;
        });
    }
};
}
void ProjectStore::save(const Document& doc,const fs::path& directory) {
    try {
        doc.validate();
        no_symlink(directory);fs::create_directories(directory);Lock lock(directory/".save-lock");
        auto generations=directory/"generations";no_symlink(generations);fs::create_directories(generations);
        const Id snapshot;auto base=generations/snapshot.str();require(fs::create_directory(base),"Geracao ja existente");fs::create_directory(base/"chunks");
        Json materials=Json::array(),layers=Json::array(),entities=Json::array(),chunks=Json::array();
        for(const auto& [id,m]:doc.materials_)materials.push_back({{"id",id.str()},{"name",m.name},{"texture",m.texture},{"color",m.color}});
        for(const auto& [id,l]:doc.layers_)layers.push_back({{"id",id.str()},{"name",l.name},{"visible",l.visible},{"locked",l.locked}});
        for(const auto& [id,e]:doc.entities_) {
            Json properties=Json::object();for(const auto& [name,value]:e.properties)properties[name]=encode(value);
            entities.push_back({{"id",id.str()},{"layer",e.layer.str()},{"name",e.name},{"class",e.class_name},
                {"parent",e.parent?Json(e.parent->str()):Json(nullptr)},
                {"transform",{{"position",encode(e.transform.position)},{"rotationDegrees",encode(e.transform.rotation_degrees)},{"scale",encode(e.transform.scale)}}},
                {"properties",std::move(properties)}});
        }
        for(const auto& [key,chunk]:doc.chunks_) {
            Json cells=Json::array();for(const auto& [index,block]:chunk){Json faces=Json::array();for(const auto& id:block.materials)faces.push_back(id.str());cells.push_back({{"index",index},{"materials",std::move(faces)}});}
            chunks.push_back({{"layer",key.layer.str()},{"position",encode(key.position)}});
            write_json(base/"chunks"/chunk_name(key),{{"cells",std::move(cells)}});
        }
        write_json(base/"materials.json",{{"materials",std::move(materials)}});
        write_json(base/"scene.json",{{"layers",std::move(layers)},{"entities",std::move(entities)},{"chunks",std::move(chunks)}});
        flush_directory(base/"chunks");flush_directory(base);flush_directory(generations);
        Json manifest={{"format","bloco-arena"},{"version",format_version},{"id",doc.id_.str()},{"name",doc.name_},
            {"unitsPerBlock",doc.units_},{"upAxis","Y"},{"handedness","right"},{"chunkSize",chunk_size},{"generation",snapshot.str()}};
        auto temporary=directory/(".project-"+snapshot.str()+".tmp");write_json(temporary,manifest);
        replace_manifest(temporary,directory/"project.json");flush_directory(directory);
    }catch(const Error&){throw;}catch(const std::exception& e){throw Error(std::string("Falha ao salvar projeto: ")+e.what());}
}
Document ProjectStore::load(const fs::path& directory,LoadLimits limits) {
    try {
        no_symlink(directory);Reader reader{limits};auto manifest=reader.read(directory/"project.json");
        fields(manifest,{"format","version","id","name","unitsPerBlock","upAxis","handedness","chunkSize","generation"});
        require(string(manifest.at("format"))=="bloco-arena","Formato de projeto desconhecido");
        require(integer(manifest.at("version"))==format_version,"Versao de projeto nao suportada; migracao necessaria");
        require(string(manifest.at("upAxis"))=="Y"&&string(manifest.at("handedness"))=="right"&&integer(manifest.at("chunkSize"))==chunk_size,"Convencao de coordenadas nao suportada");
        Document doc(string(manifest.at("name")));doc.id_=Id(string(manifest.at("id")));doc.set_units_per_block(number(manifest.at("unitsPerBlock")));
        auto generation=Id(string(manifest.at("generation")));auto generations=directory/"generations";no_symlink(generations);
        auto base=generations/generation.str();no_symlink(base);no_symlink(base/"chunks");
        auto material_data=reader.read(base/"materials.json");fields(material_data,{"materials"});
        require(material_data.at("materials").is_array(),"materials deve ser array");
        for(const auto& j:material_data.at("materials")) {
            fields(j,{"id","name","texture","color"});array(j.at("color"),4);
            Material m{Id(string(j.at("id"))),string(j.at("name")),string(j.at("texture")),{}};
            for(std::size_t i=0;i<4;++i) m.color[i]=number(j.at("color")[i]);
            doc.add_material(std::move(m));
        }
        auto scene=reader.read(base/"scene.json");fields(scene,{"layers","entities","chunks"});
        for(auto key:{"layers","entities","chunks"})require(scene.at(key).is_array(),std::string(key)+" deve ser array");
        require(scene.at("entities").size()<=limits.max_entities&&scene.at("chunks").size()<=limits.max_chunks,"Limite de entidades/chunks excedido");
        for(const auto& j:scene.at("layers")) {
            fields(j,{"id","name","visible","locked"});doc.add_layer({Id(string(j.at("id"))),string(j.at("name")),boolean(j.at("visible")),boolean(j.at("locked"))});
        }
        // Two-phase entity loading: forward references are legal, validation happens after all insertions.
        for(const auto& j:scene.at("entities")) {
            fields(j,{"id","layer","name","class","parent","transform","properties"});
            Entity e;e.id=Id(string(j.at("id")));e.layer=Id(string(j.at("layer")));e.name=string(j.at("name"));e.class_name=string(j.at("class"));
            if(!j.at("parent").is_null())e.parent=Id(string(j.at("parent")));
            const auto& t=j.at("transform");fields(t,{"position","rotationDegrees","scale"});
            e.transform={vec3(t.at("position")),vec3(t.at("rotationDegrees")),vec3(t.at("scale"))};
            require(j.at("properties").is_object(),"properties deve ser objeto");
            for(auto it=j.at("properties").begin();it!=j.at("properties").end();++it)e.properties.emplace(it.key(),property(it.value()));
            require(!doc.id_used(e.id),"UUID duplicado");auto id=e.id;doc.entities_.emplace(std::move(id),std::move(e));
        }
        std::size_t count=0;
        for(const auto& j:scene.at("chunks")) {
            fields(j,{"layer","position"});ChunkKey key{Id(string(j.at("layer"))),cell(j.at("position"))};
            (void)cell_of(key.position,0);require(!doc.chunks_.contains(key),"Chunk duplicado");
            auto data=reader.read(base/"chunks"/chunk_name(key));fields(data,{"cells"});
            const auto& cells=data.at("cells");require(cells.is_array()&&!cells.empty()&&cells.size()<=4096,"Chunk vazio ou tamanho invalido");
            require(count<=limits.max_blocks&&cells.size()<=limits.max_blocks-count,"Limite de blocos excedido");count+=cells.size();
            Chunk chunk;
            for(const auto& item:cells) {
                fields(item,{"index","materials"});auto n=integer(item.at("index"));require(n>=0&&n<4096,"Indice de bloco invalido");
                array(item.at("materials"),6);const auto& faces=item.at("materials");
                Block block{{Id(string(faces[0])),Id(string(faces[1])),Id(string(faces[2])),Id(string(faces[3])),Id(string(faces[4])),Id(string(faces[5]))}};
                require(chunk.emplace(static_cast<std::uint16_t>(n),std::move(block)).second,"Celula duplicada");
            }
            doc.chunks_.emplace(std::move(key),std::move(chunk));
        }
        doc.validate();doc.revision_=0;return doc;
    }catch(const Error&){throw;}catch(const std::exception& e){throw Error(std::string("Falha ao abrir projeto: ")+e.what());}
}
}
