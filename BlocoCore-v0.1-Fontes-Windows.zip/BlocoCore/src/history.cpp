#include "bloco/history.hpp"
#include <set>
#include <tuple>
#include <utility>
#include <type_traits>
static_assert(std::is_nothrow_move_assignable_v<bloco::Document>);
namespace bloco {
History::History(Document& document,std::size_t max_steps):document_(document),document_id_(document.id()),expected_(document.revision()),limit_(max_steps) {
    if(!limit_)throw Error("Historico deve permitir pelo menos uma operacao");
}
void History::check_revision() const {
    if(document_.id()!=document_id_||document_.revision()!=expected_)throw Error("Documento mudou fora do historico; chame clear()");
}
void History::clear() { entries_.clear();cursor_=0;expected_=document_.revision();document_id_=document_.id(); }
bool History::execute(std::string label,std::vector<BlockEdit> edits) {
    check_revision();if(label.empty())throw Error("Comando sem descricao");
    std::set<std::tuple<Id,Cell>> visited;
    Entry entry{std::move(label),{}, {}};
    Document staged=document_;
    for(const auto& edit:edits) {
        if(!visited.emplace(edit.layer,edit.cell).second)throw Error("Celula duplicada no mesmo comando");
        auto previous=document_.block(edit.layer,edit.cell);
        // Also validate locks/material references for no-op edits.
        staged.set_block(edit.layer,edit.cell,edit.value);
        if(previous!=edit.value){entry.before.push_back({edit.layer,edit.cell,previous});entry.after.push_back(edit);}
    }
    if(entry.after.empty())return false;
    entries_.reserve(entries_.size()+1); // Allocate before changing live state or redo history.
    entries_.erase(entries_.begin()+static_cast<std::ptrdiff_t>(cursor_),entries_.end());
    entries_.push_back(std::move(entry));
    if(entries_.size()>limit_)entries_.erase(entries_.begin());
    document_=std::move(staged);cursor_=entries_.size();expected_=document_.revision();return true;
}
void History::apply(const std::vector<BlockEdit>& edits) {
    Document staged=document_;
    for(const auto& e:edits)staged.set_block(e.layer,e.cell,e.value);
    document_=std::move(staged);expected_=document_.revision();
}
bool History::undo() {check_revision();if(!can_undo())return false;apply(entries_[cursor_-1].before);--cursor_;return true;}
bool History::redo() {check_revision();if(!can_redo())return false;apply(entries_[cursor_].after);++cursor_;return true;}
}
