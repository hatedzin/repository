#include "bloco/document.hpp"
#include "bloco/history.hpp"
#include "bloco/project_store.hpp"
#include <nlohmann/json.hpp>
#include <cmath>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>

using namespace bloco;
using Json=nlohmann::json;
namespace fs=std::filesystem;
#define CHECK(...) do { if(!(__VA_ARGS__))throw std::runtime_error(std::string(__FILE__)+":"+std::to_string(__LINE__)+": " #__VA_ARGS__); } while(false)
void rejects(const std::function<void()>& f){bool caught=false;try{f();}catch(const Error&){caught=true;}CHECK(caught);}
struct Temp {
    fs::path path=fs::temp_directory_path()/("bloco-test-"+Id{}.str());
    Temp(){fs::create_directory(path);}
    ~Temp(){std::error_code error;fs::remove_all(path,error);}
};
struct Fixture {
    Document doc{"Teste"};Layer layer;Material material;
    Fixture(){layer.name="Estrutura";material.name="Pedra";doc.add_layer(layer);doc.add_material(material);}
    Block block() const {return Block::uniform(material.id);}
};
Json read(const fs::path& path){std::ifstream in(path);Json j;in>>j;return j;}
void write(const fs::path& path,const Json& j){std::ofstream out(path);out<<j.dump(2);}
std::string bytes(const fs::path& path){std::ifstream in(path,std::ios::binary);std::ostringstream s;s<<in.rdbuf();return s.str();}
fs::path generation(const fs::path& path){return path/"generations"/read(path/"project.json").at("generation").get<std::string>();}

int main() {
    int passed=0,failed=0;
    auto test=[&](const char* name,const std::function<void()>& f){try{f();++passed;std::cout<<"PASS "<<name<<'\n';}catch(const std::exception& e){++failed;std::cerr<<"FAIL "<<name<<": "<<e.what()<<'\n';}};
    test("UUID validacao e unicidade",[]{
        std::set<Id> ids;for(int i=0;i<300;++i){Id id;CHECK(Id(id.str())==id);CHECK(id.str()[14]=='4');CHECK(std::string("89ab").find(id.str()[19])!=std::string::npos);CHECK(ids.insert(id).second);}
        rejects([]{Id bad("../fora");});rejects([]{Id bad("00000000-0000-0000-0000-000000000000");});
    });
    test("Chunks negativos e extremos int32",[]{
        for(auto v:{INT32_MIN,-33,-17,-16,-15,-1,0,1,15,16,17,INT32_MAX}) {
            Cell c{v,v,v};auto a=address_of(c);CHECK(cell_of(a.chunk,a.index)==c);
        }
        CHECK(address_of({-1,0,0}).chunk.x==-1);CHECK(address_of({-1,0,0}).index==15);
        rejects([]{(void)cell_of({INT32_MAX,0,0},0);});rejects([]{(void)cell_of({},4096);});
    });
    test("Indice local cobre 4096 celulas",[]{
        std::set<std::uint16_t> indices;
        for(int x=0;x<16;++x)for(int y=0;y<16;++y)for(int z=0;z<16;++z){auto a=address_of({x,y,z});CHECK(indices.insert(a.index).second);CHECK(cell_of(a.chunk,a.index)==Cell{x,y,z});}
    });
    test("Blocos separados por camada e limpeza de chunk",[]{
        Fixture f;Layer l;l.name="Detalhes";f.doc.add_layer(l);
        f.doc.set_block(f.layer.id,{-1,0,0},f.block());f.doc.set_block(l.id,{-1,0,0},f.block());CHECK(f.doc.chunks().size()==2);
        f.doc.set_block(f.layer.id,{-1,0,0},{});CHECK(f.doc.chunks().size()==1);CHECK(f.doc.block(l.id,{-1,0,0}).has_value());f.doc.validate();
    });
    test("Referencias de material e IDs globais",[]{
        Fixture f;auto bad=Block::uniform(Id{});auto revision=f.doc.revision();
        rejects([&]{f.doc.set_block(f.layer.id,{},bad);});CHECK(f.doc.block_count()==0&&f.doc.revision()==revision);
        auto m=f.material;m.id=f.layer.id;rejects([&]{f.doc.add_material(m);});m.id=f.doc.id();rejects([&]{f.doc.add_material(m);});
    });
    test("Camada bloqueada e sem alteracao em no-op",[]{
        Fixture f;f.doc.set_block(f.layer.id,{},f.block());auto n=f.doc.revision();f.doc.set_block(f.layer.id,{},f.block());CHECK(f.doc.revision()==n);
        f.layer.locked=true;f.doc.update_layer(f.layer);rejects([&]{f.doc.set_block(f.layer.id,{},{});});CHECK(f.doc.block_count()==1);
    });
    test("Validacao de caminhos cores e escala",[]{
        Fixture f;
        for(auto path:{"../fora.dtx","/fora.dtx","C:/fora.dtx","a/../b.dtx","a\\b.dtx","a//b.dtx","a/"}){Material m;m.name="Erro";m.texture=path;rejects([&]{f.doc.add_material(m);});}
        Material bad;bad.name="Erro";bad.color[0]=std::numeric_limits<double>::quiet_NaN();rejects([&]{f.doc.add_material(bad);});
        rejects([&]{f.doc.set_units_per_block(0);});rejects([&]{f.doc.set_units_per_block(std::numeric_limits<double>::infinity());});
    });
    test("Entidades referencias e ciclos",[]{
        Fixture f;Entity a;a.layer=f.layer.id;a.name="A";a.class_name="marker";f.doc.add_entity(a);
        Entity b;b.layer=f.layer.id;b.name="B";b.class_name="marker";b.parent=a.id;b.properties["target"]=EntityRef{a.id};f.doc.add_entity(b);
        auto changed=a;changed.parent=b.id;rejects([&]{f.doc.update_entity(changed);});rejects([&]{f.doc.remove_entity(a.id);});
        f.doc.remove_entity(b.id);f.doc.remove_entity(a.id);CHECK(f.doc.entities().empty());
    });
    test("Entidade invalida nao altera documento",[]{
        Fixture f;Entity a;a.layer=f.layer.id;a.name="A";a.class_name="marker";a.properties["ref"]=EntityRef{Id{}};
        rejects([&]{f.doc.add_entity(a);});a.properties.clear();a.transform.scale.y=0;rejects([&]{f.doc.add_entity(a);});CHECK(f.doc.entities().empty());
    });
    test("Historico agrupado undo redo e ramificacao",[]{
        Fixture f;History h(f.doc);
        CHECK(h.execute("Piso",{{f.layer.id,{0,0,0},f.block()},{f.layer.id,{1,0,0},f.block()}}));CHECK(f.doc.block_count()==2&&h.size()==1);
        CHECK(h.undo());CHECK(f.doc.block_count()==0);CHECK(h.redo());CHECK(f.doc.block_count()==2);CHECK(h.undo());
        h.execute("Outra rota",{{f.layer.id,{5,0,0},f.block()}});CHECK(!h.can_redo()&&f.doc.block_count()==1);
        CHECK(!h.execute("Sem mudanca",{{f.layer.id,{5,0,0},f.block()}}));CHECK(h.size()==1);
    });
    test("Historico transacional rejeita lote parcial",[]{
        Fixture f;History h(f.doc);auto rev=f.doc.revision();
        rejects([&]{h.execute("Erro",{{f.layer.id,{},f.block()},{Id{},{1,0,0},f.block()}});});
        CHECK(f.doc.block_count()==0&&f.doc.revision()==rev&&h.size()==0);
        rejects([&]{h.execute("Duplicado",{{f.layer.id,{},f.block()},{f.layer.id,{},f.block()}});});CHECK(f.doc.block_count()==0);
    });
    test("Historico limitado e alteracao externa",[]{
        Fixture f;History h(f.doc,2);for(int x=0;x<3;++x)h.execute("Bloco",{{f.layer.id,{x,0,0},f.block()}});
        CHECK(h.size()==2);CHECK(h.undo());CHECK(h.undo());CHECK(!h.undo());CHECK(f.doc.block_count()==1);
        f.doc.set_name("Mudou");rejects([&]{h.redo();});h.clear();CHECK(!h.can_redo());
    });
    test("Roundtrip completo todos os tipos e materiais por face",[]{
        Fixture f;Temp temp;Material other;other.name="Grama";other.texture="texturas/grama.dtx";f.doc.add_material(other);
        auto b=f.block();b.materials[2]=other.id;
        for(auto c:{Cell{-17,-1,16},Cell{0,0,0},Cell{INT32_MAX,INT32_MIN,0}})f.doc.set_block(f.layer.id,c,b);
        Entity a;a.layer=f.layer.id;a.name="Alvo";a.class_name="editor.marker";f.doc.add_entity(a);
        Entity e;e.layer=f.layer.id;e.name="Entidade";e.class_name="editor.marker";e.parent=a.id;e.transform.position={1,2,3};e.transform.rotation_degrees={0,90,0};
        e.properties={{"boolean",true},{"min",std::int64_t(INT64_MIN)},{"max",std::int64_t(INT64_MAX)},{"real",2.5},{"string",std::string("área azul")},{"vector",Vec3{4,5,6}},{"ref",EntityRef{a.id}}};f.doc.add_entity(e);
        f.layer.locked=true;f.doc.update_layer(f.layer);
        ProjectStore::save(f.doc,temp.path);auto loaded=ProjectStore::load(temp.path);
        CHECK(loaded.id()==f.doc.id()&&loaded.name()==f.doc.name());CHECK(loaded.materials()==f.doc.materials());CHECK(loaded.layers()==f.doc.layers());CHECK(loaded.chunks()==f.doc.chunks());CHECK(loaded.entities()==f.doc.entities());CHECK(loaded.revision()==0);
    });
    test("Projeto vazio e alteracao de unidades",[]{
        Document d("Vazio");d.set_units_per_block(32);Temp temp;ProjectStore::save(d,temp.path);auto loaded=ProjectStore::load(temp.path);CHECK(loaded.block_count()==0&&loaded.units_per_block()==32);
    });
    test("Versao futura recusada",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);auto j=read(t.path/"project.json");j["version"]=99;write(t.path/"project.json",j);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Campo desconhecido nao e perdido silenciosamente",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);auto j=read(t.path/"project.json");j["futureField"]=true;write(t.path/"project.json",j);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Chave JSON duplicada recusada",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);auto s=bytes(t.path/"project.json");s.insert(1,"\"format\":\"bloco-arena\",");std::ofstream(t.path/"project.json")<<s;
        rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Limites de leitura e numero de blocos",[]{
        Fixture f;Temp t;f.doc.set_block(f.layer.id,{},f.block());ProjectStore::save(f.doc,t.path);
        LoadLimits l;l.max_file_bytes=10;rejects([&]{(void)ProjectStore::load(t.path,l);});
        l={};l.max_total_bytes=10;rejects([&]{(void)ProjectStore::load(t.path,l);});
        l={};l.max_blocks=0;rejects([&]{(void)ProjectStore::load(t.path,l);});
    });
    test("Chunk ausente e celula duplicada",[]{
        Fixture f;Temp t;f.doc.set_block(f.layer.id,{},f.block());ProjectStore::save(f.doc,t.path);
        const auto p=fs::directory_iterator(generation(t.path)/"chunks")->path();const auto original=read(p);auto j=original;j["cells"].push_back(j["cells"][0]);write(p,j);
        rejects([&]{(void)ProjectStore::load(t.path);});fs::remove(p);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Referencias invalidas ao carregar",[]{
        Fixture f;Temp t;f.doc.set_block(f.layer.id,{},f.block());ProjectStore::save(f.doc,t.path);
        auto p=fs::directory_iterator(generation(t.path)/"chunks")->path();auto j=read(p);j["cells"][0]["materials"][0]=Id{}.str();write(p,j);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Coordenadas fracionarias e convencao de eixo recusadas",[]{
        Fixture f;Temp t;f.doc.set_block(f.layer.id,{},f.block());ProjectStore::save(f.doc,t.path);
        auto p=generation(t.path)/"scene.json";auto j=read(p);j["chunks"][0]["position"][0]=0.5;write(p,j);rejects([&]{(void)ProjectStore::load(t.path);});
        auto manifest=read(t.path/"project.json");manifest["upAxis"]="Z";write(t.path/"project.json",manifest);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Manifesto anterior preservado em falha de salvamento",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);auto original=bytes(t.path/"project.json");
        // Force an I/O error while preparing the new generation, before commit.
        fs::rename(t.path/"generations",t.path/"generations-old");std::ofstream(t.path/"generations")<<"not a directory";
        f.doc.set_name("Nao deve substituir");rejects([&]{ProjectStore::save(f.doc,t.path);});CHECK(bytes(t.path/"project.json")==original);CHECK(!fs::exists(t.path/".save-lock"));
        fs::remove(t.path/"generations");fs::rename(t.path/"generations-old",t.path/"generations");CHECK(ProjectStore::load(t.path).name()=="Teste");
    });
    test("Lock de escrita nao e removido por outro escritor",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);auto old=bytes(t.path/"project.json");fs::create_directory(t.path/".save-lock");
        rejects([&]{ProjectStore::save(f.doc,t.path);});CHECK(fs::exists(t.path/".save-lock"));CHECK(bytes(t.path/"project.json")==old);
    });
    test("Geracao incompleta ignorada e geracao nova consistente",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);auto previous=generation(t.path);fs::create_directory(t.path/"generations"/Id{}.str());
        CHECK(ProjectStore::load(t.path).name()=="Teste");f.doc.set_name("Atualizado");f.doc.set_block(f.layer.id,{4,5,6},f.block());ProjectStore::save(f.doc,t.path);
        CHECK(generation(t.path)!=previous);CHECK(fs::exists(previous));auto d=ProjectStore::load(t.path);CHECK(d.name()=="Atualizado"&&d.block_count()==1);
    });
    test("UTF8 invalido recusado no modelo",[]{
        rejects([]{Document bad(std::string("invalido")+char(0xff));});
        Fixture f;Entity e;e.layer=f.layer.id;e.name="Teste";e.class_name="marker";e.properties["texto"]=std::string("\xc0\xaf");
        rejects([&]{f.doc.add_entity(e);});Document unicode("Arena — ação 🎮");unicode.validate();
    });
    test("Ciclo em arquivo e referencia futura",[]{
        Fixture f;Temp t;Entity a;a.layer=f.layer.id;a.name="A";a.class_name="marker";f.doc.add_entity(a);
        Entity b;b.layer=f.layer.id;b.name="B";b.class_name="marker";b.parent=a.id;f.doc.add_entity(b);ProjectStore::save(f.doc,t.path);
        const auto p=generation(t.path)/"scene.json";auto j=read(p);
        // Force a forward parent reference irrespective of UUID ordering.
        if(j["entities"][0]["name"]=="A")std::swap(j["entities"][0],j["entities"][1]);
        write(p,j);CHECK(ProjectStore::load(t.path).entities()==f.doc.entities());
        for(auto& entity:j["entities"])if(entity["name"]=="A")entity["parent"]=b.id.str();
        write(p,j);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Tipo futuro e excesso int64 recusados",[]{
        Fixture f;Temp t;Entity a;a.layer=f.layer.id;a.name="A";a.class_name="marker";a.properties["n"]=std::int64_t(5);f.doc.add_entity(a);ProjectStore::save(f.doc,t.path);
        auto p=generation(t.path)/"scene.json";auto original=read(p);auto j=original;
        j["entities"][0]["properties"]["n"]["type"]="future";write(p,j);rejects([&]{(void)ProjectStore::load(t.path);});
        j=original;j["entities"][0]["properties"]["n"]["value"]=std::numeric_limits<std::uint64_t>::max();write(p,j);rejects([&]{(void)ProjectStore::load(t.path);});
    });
    test("Limite de profundidade do parser",[]{
        Fixture f;Temp t;ProjectStore::save(f.doc,t.path);
        std::string deep;for(int i=0;i<70;++i)deep+="[";deep+="0";for(int i=0;i<70;++i)deep+="]";
        std::ofstream(t.path/"project.json")<<deep;rejects([&]{(void)ProjectStore::load(t.path);});
    });
    std::cout<<passed<<" testes passaram; "<<failed<<" falharam\n";return failed?1:0;
}
