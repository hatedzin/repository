# Bloco Core 0.1

Primeiro módulo do novo editor Windows: documento, comandos de blocos e persistência.
Implementado em C++20, sem Qt, MFC ou dependência dos binários antigos.
Este pacote contém código-fonte; não é o editor gráfico nem um EXE Windows pronto.

## Conteúdo

- `include/bloco/document.hpp`: documento, UUIDs, materiais, camadas, blocos e entidades.
- `include/bloco/history.hpp`: comandos agrupados de blocos com undo/redo.
- `include/bloco/project_store.hpp`: salvar e carregar projetos versionados.
- `examples/main.cpp`: cria uma arena, salva e reabre o resultado.
- `tests/core_tests.cpp`: testes de invariantes, persistência e falhas.
- `docs/FORMAT.md`: contrato do formato nativo v1.
- `docs/ARCHITECTURE.md`: decisões e limites deste primeiro módulo.
- `examples/arena-exemplo`: projeto nativo gerado e validado pelo exemplo.

## Compilar no Windows

Instale Visual Studio 2022 com **Desktop development with C++**, Windows SDK e CMake
3.20 ou superior. Use um terminal de desenvolvimento do Visual Studio.

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
build\Release\bloco_demo.exe minha-arena
```

`COMPILAR-WINDOWS.bat` executa esses passos. Interrompe em caso de erro.
Para Visual Studio de outra versão, adapte o nome do gerador CMake.
A dependência JSON já acompanha o código; não há download durante a compilação.
O programa `bloco_demo.exe` é uma demonstração de console, não uma interface gráfica.

## Compilar em Linux para desenvolvimento/testes

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DBLOCO_SANITIZERS=ON
cmake --build build -j 2
ctest --test-dir build --output-on-failure
./build/bloco_demo minha-arena
```

## Uso da biblioteca

```cpp
#include <bloco/document.hpp>
#include <bloco/history.hpp>
#include <bloco/project_store.hpp>

bloco::Document doc("Minha arena");
bloco::Layer layer;
layer.name = "Estrutura";
doc.add_layer(layer);

bloco::Material material;
material.name = "Pedra";
material.texture = "textures/pedra.dtx";
doc.add_material(material);

bloco::History history(doc);
history.execute("Colocar bloco", {
    {layer.id, {0, 0, 0}, bloco::Block::uniform(material.id)}
});
history.undo();
history.redo();

bloco::ProjectStore::save(doc, "minha-arena");
auto reopened = bloco::ProjectStore::load("minha-arena");
```

Os IDs são UUIDs persistentes. As coordenadas de células são inteiros com sinal de
32 bits. Y aponta para cima. A unidade padrão é 64 unidades por bloco.
Uma camada não equivale a uma altura Y: é um agrupamento independente de conteúdo.
Os seis materiais de um bloco correspondem a +X, -X, +Y, -Y, +Z, -Z.

A biblioteca rejeita referências inválidas, IDs repetidos, ciclos de parentesco,
valores não finitos e edição em camadas bloqueadas. O leitor rejeita campos e
versões desconhecidos, em vez de descartá-los silenciosamente.
Falhas são reportadas como `bloco::Error`; a UI futura poderá traduzi-las em diagnósticos.

## Limites e estado atual

- Sem interface gráfica, renderização, brushes arbitrários ou CSG neste módulo.
- Sem exportação LTA/LTC, compilação LithTech ou pontos de nascimento funcionais.
- Entidades guardam nomes de classe e propriedades; a existência da classe no jogo
  será verificada pelo adaptador LithTech. `editor.marker` é apenas uma referência.
- O histórico cobre comandos de blocos. Alterações diretas no documento invalidam
  o histórico até `clear()`. Comandos de entidades e materiais ficam para a próxima etapa.
- Operações transacionais do histórico usam uma cópia temporária do documento;
  os registros retidos guardam diferenças de células. Isso prioriza correção no MVP;
  cópia por chunk/compartilhamento será a evolução para mapas maiores.
- Cada save grava uma geração completa, não um incremental. Gerações anteriores
  ficam no disco; ainda não existe limpeza automática ou UI de recuperação.
- Não é thread-safe: use o documento no thread proprietário. Um worker de save deve
  receber uma cópia independente criada sem edição concorrente.
- O lock `.save-lock` impede dois saves simultâneos pela API. Se o processo morrer,
  ele pode permanecer: confirme que nenhum save está ativo antes de removê-lo.
- Save usa flush de arquivos e troca atômica do manifesto. A durabilidade contra
  queda de energia depende do sistema de arquivos; não é uma garantia para qualquer
  unidade de rede. Uma falha no flush final pode ser reportada após o commit.
- A compilação/testes foram executados em Linux. O caminho Windows de flush e troca
  de manifesto está implementado, mas não foi executado nesta sessão.

## Dependência

`nlohmann/json` 3.11.3, distribuído com sua licença MIT em `third_party/nlohmann`.
URLs e SHA-256 dos arquivos obtidos estão em `third_party/DEPENDENCIES.json`.
Nenhum fonte ou binário dos anexos LithTech foi copiado para esta biblioteca.
