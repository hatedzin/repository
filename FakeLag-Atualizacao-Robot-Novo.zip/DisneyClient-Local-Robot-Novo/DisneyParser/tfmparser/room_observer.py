"""Add a read-only observer to the native dispatch path; preserve native sockets."""
import struct,zlib
SLOT='astroRoomObserverV1'
def u(n):
 out=bytearray()
 while n>127:out.append((n&127)|128);n>>=7
 out.append(n);return bytes(out)
class Reader:
 def __init__(self,b):self.b=b;self.p=0
 def byte(self):n=self.b[self.p];self.p+=1;return n
 def var(self):
  n=0
  for i in range(5):
   v=self.byte();n|=(v&127)<<(7*i)
   if not v&128 or i==4:return n&0xffffffff
  raise ValueError('Invalid ABC integer')
 def skip(self,n):self.p+=n
 def traits(self):
  start=self.p;count=self.var();items=[]
  for _ in range(count):
   a=self.p;name=self.var();kind=self.byte();data=[]
   if kind&15 in (0,6):
    data=[self.var(),self.var(),self.var()]
    if data[2]:self.byte()
   elif kind&15 in (1,2,3,4,5):data=[self.var(),self.var()]
   else:raise ValueError('Unsupported trait')
   if kind&64:
    for _ in range(self.var()):self.var()
   items.append((name,kind,data,a,self.p))
  return start,self.p,count,items

def patch_abc(b,class_name):
 r=Reader(b);r.skip(4);edits=[]
 for _ in range(2):
  for _ in range(max(0,r.var()-1)):r.var()
 r.skip(max(0,r.var()-1)*8)
 sp=r.p;sn=r.var();ss=r.p;strings=['']
 for _ in range(sn-1):n=r.var();strings.append(b[r.p:r.p+n].decode());r.skip(n)
 se=r.p
 np=r.p;nn=r.var();nsstart=r.p;namespaces=[None]
 for _ in range(nn-1):namespaces.append((r.byte(),r.var()))
 ns_end=r.p
 for _ in range(max(0,r.var()-1)):
  for _ in range(r.var()):r.var()
 mp=r.p;mn=r.var();ms=r.p;multis=[None]
 for _ in range(mn-1):
  kind=r.byte()
  if kind in (7,13):data=[r.var(),r.var()]
  elif kind in (15,16):data=[r.var()]
  elif kind in (17,18):data=[]
  elif kind in (9,14):data=[r.var(),r.var()]
  elif kind in (27,28):data=[r.var()]
  elif kind==29:data=[r.var()]+[r.var() for _ in range(r.var())]
  else:raise ValueError('Unsupported multiname')
  multis.append((kind,data))
 me=r.p
 def name(i):
  if i==0:return '*'
  kind,d=multis[i]
  if kind not in (7,13):return ''
  ns=namespaces[d[0]];prefix=strings[ns[1]]
  return (prefix+'.' if prefix else '')+strings[d[1]]
 methods=[]
 for _ in range(r.var()):
  count=r.var();ret=r.var();params=[r.var() for _ in range(count)];r.var();flags=r.byte()
  if flags&8:
   for _ in range(r.var()):r.var();r.byte()
  if flags&128:
   for _ in range(count):r.var()
  methods.append((ret,params))
 for _ in range(r.var()):
  r.var();count=r.var()
  for _ in range(count*2):r.var()
 count=r.var();classes=[]
 for _ in range(count):
  cname=r.var();r.var();flags=r.byte()
  if flags&8:r.var()
  for _ in range(r.var()):r.var()
  r.var();r.traits();classes.append(cname)
 target=None;traitspan=None;classq=None
 for i in range(count):
  r.var();span=r.traits()
  if name(classes[i])==class_name or "".join(str(ord(c)) if 0<ord(c)<9 else c for c in name(classes[i])).replace("\\", "")==class_name:
   classq=classes[i];traitspan=span
   if any(name(t[0])==SLOT for t in span[3]):return b,True
   candidates=[t[2][1] for t in span[3] if t[1]&15==1 and name(methods[t[2][1]][0])=='void' and [name(n) for n in methods[t[2][1]][1]]==['flash.utils.ByteArray']]
   if len(candidates)!=1:raise ValueError('Native dispatch method is ambiguous')
   target=candidates[0]
 for _ in range(r.var()):r.var();r.traits()
 if target is None:return b,False
 # Add a public static callback slot and guard its invocation before native dispatch.
 public=next((i for i,ns in enumerate(namespaces) if ns and ns[0]==0x16 and strings[ns[1]]==''),None)
 if public is None:raise ValueError('Missing public namespace')
 encoded=SLOT.encode();edits.append((sp,se,u(sn+1)+b[ss:se]+u(len(encoded))+encoded))
 edits.append((mp,me,u(mn+1)+b[ms:me]+b'\x07'+u(public)+u(sn)))
 a,e,n,items=traitspan;header=a+len(u(n));edits.append((a,e,u(n+1)+b[header:e]+u(mn)+b'\x00'+u(0)+u(0)+u(0)))
 # getlex class; getproperty callback; dup; iffalse pop; pushnull; local1; call1; pop; jump end; pop
 call=b'\x20\xd1\x41\x01\x29';prefix=b'\x60'+u(classq)+b'\x66'+u(mn)+b'\x2a\x12'+(len(call)+4).to_bytes(3,'little')+call+b'\x10\x01\x00\x00\x29'
 found=False
 for _ in range(r.var()):
  start=r.p;mid=r.var();stack=r.var();locals_=r.var();scope=r.var();maxscope=r.var();length=r.var();code=b[r.p:r.p+length];r.skip(length)
  exceptions=[]
  for _ in range(r.var()):exceptions.append([r.var() for _ in range(5)])
  traits_start=r.p;r.traits()
  if mid==target:
   newcode=prefix+code
   value=u(mid)+u(max(stack,3))+u(locals_)+u(scope)+u(maxscope)+u(len(newcode))+newcode+u(len(exceptions))
   for fields in exceptions:value+=b''.join(u(v+len(prefix) if i<3 else v) for i,v in enumerate(fields))
   value+=b[traits_start:r.p];edits.append((start,r.p,value));found=True
 if not found or r.p!=len(b):raise ValueError('Invalid ABC body layout')
 for a,e,value in sorted(edits,reverse=True):b=b[:a]+value+b[e:]
 return b,True

def install(data,class_name):
 if data[:3] not in (b'CWS',b'FWS'):raise ValueError('Unsupported SWF')
 body=zlib.decompress(data[8:]) if data[:3]==b'CWS' else data[8:]
 pos=(5+4*(body[0]>>3)+7)//8+4;out=bytearray(body[:pos]);found=False
 while pos<len(body):
  h=struct.unpack_from('<H',body,pos)[0];pos+=2;code=h>>6;n=h&63
  if n==63:n=struct.unpack_from('<I',body,pos)[0];pos+=4
  chunk=body[pos:pos+n];pos+=n
  if code==82:
   cut=chunk.index(b'\0',4)+1;abc,hit=patch_abc(chunk[cut:],class_name)
   if hit:
    if found:raise ValueError('Multiple dispatcher classes')
    found=True;chunk=chunk[:cut]+abc
  out+=struct.pack('<HI',(code<<6)|63,len(chunk))+chunk
 if not found:raise ValueError('Native dispatcher class not found')
 return b'CWS'+data[3:4]+struct.pack('<I',len(out)+8)+zlib.compress(out)
