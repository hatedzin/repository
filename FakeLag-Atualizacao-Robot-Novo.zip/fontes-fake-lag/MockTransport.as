package disney {import flash.utils.ByteArray;
 public class FakeTransport {public static var main:FakeTransport;public static var bulle:FakeTransport;public static var sent:Array=[];public var socket:Object={connected:true};public var sequence:int=0;public var priority:Object;
 public function send(pkt:FakePacket):void{if(this.priority){var first:FakePacket=this.priority;this.priority=null;this.send(first);}sequence++;var b:ByteArray=pkt.bytes;var cursor:uint=b.position;b.position=0;var c:int=b.readUnsignedByte();var cc:int=b.readUnsignedByte();var payload:int=b.bytesAvailable?b.readUnsignedByte():-1;sent.push({owner:this,c:c,cc:cc,payload:payload,sequence:sequence,cipher:pkt.cipher,key:pkt.key});if(pkt.cipher){b.position=2;b.writeByte(255);}b.position=cursor;}}
}
