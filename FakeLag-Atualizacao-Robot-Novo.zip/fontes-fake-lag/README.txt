FAKE LAG — ATRASO ADICIONAL DE MOVIMENTOS

Base: o ZIP DisneyClient-Completo-Localhost-Robot-Novo.zip reenviado pelo usuario. Esta versao acrescenta fake lag; nao inclui o anti-lag nem alteracoes de interface Pgiex.

Menu > Jogador > Fake lag / atraso de movimentos (role a lista). DESLIGADO por padrao. Atraso inicial 250 ms, ajustavel entre 50 e 1000 ms.
Ao ligar, somente os pacotes nativos de movimento 4/4 recebem atraso adicional. Seu rato continua normal na sua tela; o atraso aparece no envio ao servidor. A faixa mostra fila, movimentos atrasados e liberados. Ping, login e chat nao recebem atraso intencional.
O atraso e aproximado: usa Timer de 25 ms e depende do Flash, do sistema e da rede. Nao e limite de FPS nem simulacao de travadas de imagem.

O callback entra ANTES da numeracao e criptografia nativas. Copias independentes dos pacotes aguardam na fila, mantendo a ordem. O jogo monta e envia o pacote somente quando chega a hora de libera-lo.
Mensagens prioritarias nativas e acoes de jogo como coleta, entrada na toca e agachamento liberam os movimentos anteriores antes da acao, evitando que ela ultrapasse esses movimentos. Por isso o atraso pode ser menor nesses pontos.
Ao morrer, renascer, mudar de mapa/sala ou trocar de conexao, movimentos antigos sao descartados. Desligar libera a fila ainda valida. Limite de 64 movimentos pendentes; atingir esse limite desliga o fake lag. Nao modifica posicoes, velocidades, fisica, rotas, qualidade visual, FPS-alvo ou flags do Robot.
O recurso altera deliberadamente o tempo de envio. O servidor pode rejeitar esse comportamento ou desconectar; nao ha garantia de compatibilidade com todo servidor.

INSTALACAO COMPLETA
Feche o Adobe Flash e a janela INICIAR_CLIENT.bat. Extraia o ZIP e use INICIAR_CLIENT.bat. Na mesma pasta, o preparador preserva .env, config.json e rotas. Em outra pasta, execute PREPARAR_PASTA.bat e copie a configuracao antes de iniciar. Mantido localhost 127.0.0.1.
E preciso reiniciar o PARSER e reabrir o Flash: a funcao depende de duas pontes adicionadas a copia do jogo baixada pelo parser. Ele registra "Fake lag native bridge ready" em logs-client/parser.log.
Se aparecer "Ponte nativa ausente", confirme que atualizou todos os arquivos e reiniciou o iniciador anterior. O recurso nao mostra ativado quando a ponte esta ausente. Uma versao de jogo nao reconhecida permanece sem alteracao e o fake lag fica indisponivel.

ATUALIZACAO MENOR
Com tudo fechado, extraia ao lado de INICIAR_CLIENT.bat. Precisa substituir quatro arquivos da pasta DisneyClient-Local-Robot-Novo:
 DisneyClient/public/ChargeurTransformice.swf
 DisneyParser/tfmparser/parser.py
 DisneyParser/tfmparser/room_observer.py
 DisneyParser/tfmparser/outgoing_observer.py
Nao basta trocar apenas a SWF.

VALIDACAO
32 verificacoes simuladas exercitam a interceptacao nativa, a fila, copias, metadados, numeracao, passagem de chat/conexao e invalidacao de movimentos. Verificados os prefixos na copia de jogo disponivel: instrucoes originais preservadas e pilha/escopo validos. Inclui fontes. Nao foi testado no Adobe Flash conectado ao servidor real. Nenhuma SWF privada do jogo esta no pacote; o parser prepara a copia baixada em sua instalacao.
