# Python / gerar_hash.py / Python 3.11+ / standalone administrator hash compatible with the supplied client
import getpass
import hashlib
import secrets
import sys
from pathlib import Path

def make_hash(password, salt=None):
    if len(password) < 12:
        raise ValueError('A senha precisa ter pelo menos 12 caracteres.')
    salt = salt or secrets.token_hex(16)
    value = hashlib.scrypt(password.encode('utf-8'), salt=bytes.fromhex(salt), n=16384, r=8, p=1).hex()
    return 'scrypt$'+salt+'$'+value

def main():
    print('GERADOR DE HASH SDDS - nao precisa de MySQL nem das dependencias do client.')
    password = getpass.getpass('Digite a NOVA senha administrativa (minimo 12 caracteres): ')
    confirm = getpass.getpass('Repita a senha: ')
    if password != confirm:
        raise ValueError('As senhas nao coincidem.')
    output = make_hash(password)
    path = Path(__file__).resolve().parent / 'HASH_ADMIN.txt'
    path.write_text('ADMIN_PASSWORD_HASH='+output+'\n', encoding='utf-8')
    print('\nHash gerado. Copie a linha abaixo para DisneyClient/.env, substituindo ADMIN_PASSWORD_HASH:')
    print('ADMIN_PASSWORD_HASH='+output)
    print('\nA mesma linha foi salva em '+str(path))
    print('Guarde a senha digitada: sera usada no admin.py create-key. O arquivo .env nao foi alterado automaticamente.')
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, EOFError, KeyboardInterrupt) as error:
        print('\nERRO: '+str(error),file=sys.stderr)
        sys.exit(1)
