@rem Batch / GERAR_HASH.bat / Windows CMD / standalone password hash launcher
@echo off
setlocal
where py >nul 2>&1
if not errorlevel 1 goto usar_py
where python >nul 2>&1
if not errorlevel 1 goto usar_python
echo ERRO: Python nao encontrado. Instale Python 3.11 ou superior.
goto fim
:usar_py
py -3 "%~dp0gerar_hash.py"
goto fim
:usar_python
python "%~dp0gerar_hash.py"
:fim
echo.
pause
