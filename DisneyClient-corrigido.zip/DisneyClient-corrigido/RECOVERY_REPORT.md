# Relatório de recuperação — 27/10/2026

## Resultado comprovado

Backend executado com Python 3.11.17, aiohttp 3.14.5, asyncmy 0.2.17 e MySQL
Community Server 8.4.13. **12 testes aprovados, zero falhas e zero testes pulados**
na execução final (`12 passed in 11.23s`). O processo real `server.py` iniciou a
partir de outro diretório, respondeu `/health` com banco funcional e encerrou por
SIGINT sem traceback ou avisos de conexões abertas. O helper de inicialização
cloud também foi executado e `/health` retornou `{"status":"ok","database":"ok"}`.
Não houve teste em Windows real; há guia de instalação e dependências para
Python 3.11, sem dependência de mysqlclient/compilação nativa do cliente MySQL.

## Problemas encontrados e correções

- `ClientSession()` global e loop criado na importação: removidos. Uma única
  sessão é criada em cleanup context assíncrono do aiohttp, com timeout e
  fechamento garantido mesmo em falha de inicialização.
- Dependência obrigatória de Discord em imports, startup e logs: removida do
  caminho de execução. O bot não inicia e nenhuma key/token é enviado ao Discord.
  `/api/discord` retorna apenas lista vazia para compatibilidade com a interface.
- Importação de Google Sheets abria credenciais mesmo sem usar o recurso:
  utilitários passaram a ser carregados sob demanda; planilhas não bloqueiam o
  servidor. Listas locais de records continuam disponíveis. Sincronização com
  Sheets é opcional/manual e não foi validada.
- Banco SQLAlchemy síncrono global, inicializadores duplicados, `self.self`,
  métodos obsoletos e reconexão referenciando atributos ausentes: substituídos
  no caminho ativo por `database.py`, com asyncmy, pool e transações curtas.
  Os módulos antigos foram conservados como referência, fora do runtime novo.
- Keys em texto puro como chave primária: novo schema guarda SHA-256 de keys
  criptograficamente aleatórias (256 bits), hashes de tokens e identificadores
  de ativação. Senha administrativa usa scrypt com salt aleatório e comparação
  constante. Não existe senha de usuário porque o login usa licença.
- Adicionadas licenças permanentes ou de 1/7/30/90 dias, expiração, revogação,
  renovação, limite de ativações transacional e bloqueio/desbloqueio de usuários.
  Nenhum token é aceito apenas por compartilhar IP com outro usuário.
- Sessões persistidas no MySQL; cada acesso consulta status da licença/usuário e
  validade. Revogar, renovar ou bloquear invalida sessões. Cookies HttpOnly e
  SameSite; cabeçalhos X-Forwarded-For arbitrários não identificam o usuário.
- Rate limit antes da autenticação: oito falhas bloqueiam o IP por quatro minutos.
  Authorization malformado retorna 400, e keys inválidas/expiradas retornam 401.
- Uso removido de `aiohttp.streamer`; downloads usam FileResponse/Response.
  Dados de configuração, mapas e soft usam armazenamento por usuário. As rotas,
  níveis e formatos comprimidos foram mantidos nos fluxos novos.
- O dashboard usa cookies, sem exigir recuperação de keys/tokens brutos do banco.
- Download parcial de SWF podia provocar espera infinita: validação mínima do
  formato e substituição atômica mantêm o último arquivo íntegro. Parser ausente
  retorna 503; falhas externas retornam 502, sem impedir inicialização do backend.
- Dependências revisadas: incluídos aiohttp e cryptography, exigida pelo login
  caching_sha2_password do MySQL 8; retiradas dependências obrigatórias de Discord,
  Google Sheets, mysqlclient e SQLAlchemy. Não há asyncio externo no requirements.
- Migração SQL inicial, `.env.example`, administrador autenticado, guia Windows,
  requirements com versões testadas e instruções cloud adicionados.

## Testes executados

1. Importação sem loop ativo e sem carregar Discord/Google Sheets.
2. Inicialização, reutilização e fechamento da ClientSession.
3. Hash administrativo com salt e rejeição de senha errada.
4. Keys válidas, inválidas, expiradas e revogadas; bloqueio/desbloqueio; hashes e
   auditoria no MySQL real.
5. Disputa concorrente por uma ativação, vínculo de flash_token e expiração de
   sessões: somente uma ativação concorrente é aceita.
6. API HTTP: health, index, login, dashboard, fetch, configurações, loader SWF,
   metadados de compatibilidade, parser ausente e bloqueio por tentativas.
7. Limpeza de recursos quando o startup falha.
8. CLI administrativo como subprocesso: geração de key, uso da key no banco e
   rejeição de senha administrativa incorreta.
9. Todas as durações de licença e listagens administrativas sem key_hash.
10. Persistência de sessão após fechar e reabrir o pool.
11. Gravação/leitura/remoção de soft e mapas, permissões e JSON inválido.
12. Processo real do servidor, request funcional e SIGINT com saída limpa.

Também executado `compileall` nos arquivos Python de DisneyClient e DisneyParser.
Isso verifica sintaxe; não prova execução ou compatibilidade do parser legado.
O primeiro teste ampliado de armazenamento revelou uma suposição errada no teste:
o cliente de teste estava autenticado por cookie. O teste foi corrigido para
limpar cookies antes de verificar acesso anônimo. A execução final passou.
A inicialização inicial do container ainda não estava pronta; após prontidão real,
o erro de autenticação revelou a dependência cryptography faltante, corrigida sem
alterar o mecanismo de autenticação ou desabilitar verificações.
Uma credencial temporária de banco apareceu no traceback de uma dependência durante
a investigação e foi rotacionada no MySQL e no `.env` antes da validação final.

## SWF, parser e limites

Foram recebidas quatro SWFs. Os comprimentos declarados conferem após descompressão;
os hashes, tamanhos e versões de FORMATO estão em `SWF_INSPECTION.json`. Versões
12/14 do formato SWF não identificam a versão 158 do Transformice. O loader contém
referências locais a localhost/127.0.0.1 (além de adobe.com); essa inspeção estática
não comprova que todos os contratos do binário sejam compatíveis.

A resposta HTTP de `/transformice` contém o loader original; **o jogo não foi
executado e a SWF 158 não foi validada**. Não há runtime Flash/launcher nem fonte do
builder para validar esse fluxo completo. O parser legado foi mantido sem alterações
em extração de símbolos, código de bypass ou autenticação de terceiros. Um endpoint
compatível/autorizado e seu token são necessários para validar `/get_keys` e o jogo.
Não foram inventados nomes de classes, offsets ou símbolos.

O schema novo deve ser instalado em banco NOVO. Não há conversão automática de dados
legados ou atribuição automática de identidades antigas. Faça backup antes de qualquer
migração e transfira dados explicitamente. O servidor recusa a tabela users antiga.

Não foram validados deploy público, TLS/proxy confiável, testes de carga, restauração
em nova tarefa cloud ou execução nativa no Windows. O banco do ambiente atual é apenas
de desenvolvimento/teste. O administrador deve definir seu próprio ADMIN_PASSWORD_HASH
antes do uso pessoal; o CLI foi testado com uma credencial exclusivamente de teste.

## Entrega e configuração

Os arquivos foram modificados de fato em `/workspace/repository`; não houve push nem
criação de commits. Como o remoto estava vazio, o código permanece não rastreado até
que o usuário decida versioná-lo. O README antigo foi preservado em docs/README_LEGACY.md.
O ZIP final exclui `.env`, credenciais de serviço Google, tokens do parser, caches,
logs e metadados Git. Os originais recebidos não foram expostos no relatório.

Os campos `install_script` e `start_skill` foram salvos no rascunho de configuração
cloud. Isso não publica o ambiente. Para reutilização pelo produto, revise e salve
as configurações e publique o ambiente. Processos precisam ser reiniciados e a
restauração do volume Docker em outra tarefa não foi verificada.
