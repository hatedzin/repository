from aiohttp import web
from .common import authorize

class Transformice(web.View):
    async def get(self):
        root = self.request.app['root']
        if 'swf' in self.request.query:
            path = root / 'tfm.swf'
            if not path.is_file():
                return web.json_response({'success': False, 'error': 'SWF not configured'}, status=503)
            return web.FileResponse(path)
        await authorize(self.request)
        return web.FileResponse(root / 'public/ChargeurTransformice.swf')
