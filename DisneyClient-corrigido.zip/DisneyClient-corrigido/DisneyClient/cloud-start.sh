#!/usr/bin/env bash
# Helper for this Codex cloud machine. Windows instructions are in INSTALL_WINDOWS.md.
set -eu
cd /workspace/repository/DisneyClient
if docker inspect disneyclient-mysql >/dev/null 2>&1; then
    docker start disneyclient-mysql >/dev/null
else
    # This creates a LOCAL DEVELOPMENT database, never a replacement for production.
    test -f .env
    docker run -d --name disneyclient-mysql --env-file .env \
      --publish 127.0.0.1:3306:3306 \
      --mount type=volume,source=disneyclient-mysql-data,target=/var/lib/mysql \
      mysql@sha256:76f0358884cb92d9a086d24e5671c38048d3fef40f2588703d73eb55392d6b69 >/dev/null
fi
/workspace/venv-disney/bin/python - <<'PY'
import asyncio
import asyncmy
import infrastructure
from database import Database
async def ready():
    for attempt in range(30):
        db=Database()
        try:
            await db.open()
            return
        except (OSError, asyncmy.errors.OperationalError) as exc:
            # Retry readiness only, never application operations.
            if attempt == 29:
                raise RuntimeError('Local MySQL readiness failed') from exc
            await asyncio.sleep(2)
        finally:
            await db.close()
asyncio.run(ready())
PY
exec /workspace/venv-disney/bin/python server.py
