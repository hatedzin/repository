import asyncio
import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
import infrastructure
from admin import password_hash, verify_password


def test_import_without_event_loop_or_discord():
    assert infrastructure.session is None
    assert 'discordbot' not in sys.modules
    import server
    assert callable(server.create_app)
    assert 'gspread' not in sys.modules
    assert 'discord' not in sys.modules


@pytest.mark.asyncio
async def test_http_session_lifecycle():
    with pytest.raises(RuntimeError, match='not initialized'):
        infrastructure.get_session()
    first = await infrastructure.init_session()
    assert infrastructure.get_session() is first
    assert await infrastructure.init_session() is first
    await infrastructure.close_session()
    assert first.closed
    assert infrastructure.session is None
    await infrastructure.close_session()


def test_administrator_password_hash():
    hashed = password_hash('test-admin-passphrase')
    assert verify_password('test-admin-passphrase', hashed)
    assert not verify_password('wrong-passphrase', hashed)
    assert not verify_password('test-admin-passphrase', '')
    assert hashed != password_hash('test-admin-passphrase')
