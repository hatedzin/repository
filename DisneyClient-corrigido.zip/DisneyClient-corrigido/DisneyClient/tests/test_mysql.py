"""Integration tests: use a dedicated MYSQL_DATABASE ending in _test."""
import asyncio
import base64
import json
import os
import secrets
import sys
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
import pytest_asyncio
from aiohttp.test_utils import TestClient, TestServer
import infrastructure
from database import Database, AuthError, digest, utcnow
from admin import execute
from server import create_app

@pytest_asyncio.fixture
async def db():
    if not os.getenv('MYSQL_DATABASE','').endswith('_test'):
        pytest.skip('Set MYSQL_DATABASE to a dedicated *_test database for real MySQL tests')
    d = Database()
    await d.open()
    await d.migrate()
    yield d
    await d.close()

async def license(db, **kwargs):
    return await db.create_key('test-' + secrets.token_hex(10), **dict(days=30, **kwargs))

@pytest.mark.asyncio
async def test_valid_invalid_expired_revoked_blocked_and_hashes(db):
    lid, key = await license(db)
    cookie, access, level = await db.authenticate(key,'device-a','127.0.0.1')
    assert level == 'GOLD_II'
    row = await db.session(access,'127.0.0.1')
    assert row and row['session_token_hash'] == digest(cookie)
    assert row['access_token_hash'] == digest(access)
    assert row['key_hash'] == digest(key)
    assert not await db.session('wrong-token','127.0.0.1')
    assert not await db.session(access,'192.0.2.10')
    for invalid in ['wrong-key',"' OR 1=1 --"]:
        with pytest.raises(AuthError, match='invalid'):
            await db.authenticate(invalid,'device-a','127.0.0.1')
    with pytest.raises(AuthError, match='activation limit'):
        await db.authenticate(key,'device-b','127.0.0.1')
    async with db.transaction() as c:
        await c.execute('UPDATE license_keys SET expires_at=%s WHERE id=%s',(utcnow()-timedelta(days=1),lid))
    with pytest.raises(AuthError, match='expired'):
        await db.authenticate(key,'device-a','127.0.0.1')
    assert not await db.session(access,'127.0.0.1')
    await execute(SimpleNamespace(command='renew-key',id=lid,days=7),db)
    cookie, access, _ = await db.authenticate(key,'device-a','127.0.0.1')
    await execute(SimpleNamespace(command='block-user',id=row['user_id']),db)
    assert not await db.session(access,'127.0.0.1')
    with pytest.raises(AuthError, match='blocked'):
        await db.authenticate(key,'device-a','127.0.0.1')
    await execute(SimpleNamespace(command='unblock-user',id=row['user_id']),db)
    await db.authenticate(key,'device-a','127.0.0.1')
    await execute(SimpleNamespace(command='revoke-key',id=lid),db)
    with pytest.raises(AuthError, match='blocked'):
        await db.authenticate(key,'device-a','127.0.0.1')
    async with db.transaction() as c:
        await c.execute('SELECT action FROM audit_logs WHERE user_id=%s',(row['user_id'],))
        actions = {r['action'] for r in await c.fetchall()}
        assert {'auth.accepted','auth.denied','admin.revoke-key','admin.block-user'} <= actions

@pytest.mark.asyncio
async def test_activation_race_and_session_expiration(db):
    lid,key = await license(db)
    result = await asyncio.gather(*(db.authenticate(key,'device-' + str(n),'127.0.0.1') for n in range(5)),return_exceptions=True)
    assert sum(isinstance(r,tuple) for r in result) == 1
    assert sum(isinstance(r,AuthError) for r in result) == 4
    cookie,access,_ = next(r for r in result if isinstance(r,tuple))
    assert await db.session(access,'127.0.0.1',flash='flash-a')
    assert not await db.session(access,'127.0.0.1',flash='flash-b')
    async with db.transaction() as c:
        await c.execute('UPDATE sessions SET expires_at=%s WHERE license_id=%s',(utcnow()-timedelta(seconds=1),lid))
    assert not await db.session(cookie,'127.0.0.1',cookie=True)

@pytest.mark.asyncio
async def test_http_backend_and_cleanup(db):
    lid,key = await license(db)
    app = create_app()
    async with TestClient(TestServer(app)) as client:
        r = await client.get('/health'); assert r.status == 200
        assert (await r.json())['database'] == 'ok'
        r = await client.get('/'); assert r.status == 200
        from html.parser import HTMLParser
        class KeyField(HTMLParser):
            limit = None
            def handle_starttag(self, tag, attrs):
                attrs = dict(attrs)
                if tag == 'input' and attrs.get('id') == 'key-text':
                    self.limit = int(attrs['maxlength'])
        field = KeyField()
        field.feed(await r.text())
        assert field.limit is not None and len(key) <= field.limit
        r = await client.get('/auth',headers={'Authorization':'Basic !!!'})
        assert r.status == 400
        header={'Authorization':'Basic '+base64.b64encode(key.encode()).decode(),'X-Device-ID':'browser-a'}
        r = await client.get('/api/auth',headers=header)
        assert r.status == 200
        auth = await r.json(); assert auth['success']
        assert r.cookies['session']['httponly']
        # Use explicit cookies to exercise the legacy dashboard request contract.
        cookie=r.cookies['session'].value
        headers={'Cookie':'session='+cookie}
        r = await client.get('/dashboard',headers=headers); assert r.status == 200
        r = await client.get('/api/fetch',headers=headers); assert r.status == 200
        fetched=await r.json(); assert fetched['success'] and key not in json.dumps(fetched)
        access=auth['access_token']
        r=await client.post('/data',params={'access_token':access},data={'config':json.dumps({'volume':10})})
        assert r.status == 204
        r=await client.get('/data',params={'access_token':access,'config':'1'})
        assert await r.json() == {'volume':10}
        r=await client.get('/get_keys',params={'access_token':access,'flash_token':'flash-a'})
        assert r.status == 503 and (await r.json())['error'] == 'parser not configured'
        r=await client.get('/transformice',params={'access_token':access})
        assert r.status == 200 and (await r.read())[:3] in (b'FWS',b'CWS',b'ZWS')
        r=await client.get('/api/discord'); assert await r.json() == {'names':[]}
        for _ in range(8):
            r=await client.get('/auth',headers={'Authorization':'Bearer bad'})
            assert r.status == 401
        r=await client.get('/auth',headers=header); assert r.status == 429
    assert infrastructure.session is None
    assert app['db'].pool is None

@pytest.mark.asyncio
async def test_startup_failure_closes_resources(db,monkeypatch):
    monkeypatch.setenv('MYSQL_PORT','1')
    app=create_app()
    with pytest.raises(Exception):
        async with TestClient(TestServer(app)):
            pass
    assert app['db'].pool is None
    assert infrastructure.session is None

@pytest.mark.asyncio
async def test_real_admin_cli_and_authentication(db):
    from admin import password_hash
    env=dict(os.environ, ADMIN_PASSWORD_HASH=password_hash('temporary-admin-test-passphrase'))
    script=str(Path(__file__).resolve().parents[1]/'admin.py')
    child=await asyncio.create_subprocess_exec(sys.executable,script,'--password-stdin','create-key','--days','30',stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,env=env)
    out,err=await child.communicate(b'temporary-admin-test-passphrase\n')
    assert child.returncode == 0, err.decode()
    result=json.loads(out)
    assert result['id'] and result['key']
    assert await db.authenticate(result['key'],'cli-device','127.0.0.1')
    child=await asyncio.create_subprocess_exec(sys.executable,script,'--password-stdin','list-keys',stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,env=env)
    out,err=await child.communicate(b'wrong-password\n')
    assert child.returncode == 1
    assert not out

@pytest.mark.asyncio
async def test_license_durations_and_admin_lists(db):
    for days in [0,1,7,30,90]:
        lid,key=await db.create_key('duration-'+secrets.token_hex(10),days)
        async with db.transaction() as c:
            await c.execute('SELECT expires_at FROM license_keys WHERE id=%s',(lid,))
            expiry=(await c.fetchone())['expires_at']
            if days:
                assert abs((expiry-utcnow()).total_seconds()-days*86400)<5
            else:
                assert expiry is None
        assert await db.authenticate(key,'duration-device','127.0.0.1')
    for command in ['list-keys','list-users','audit']:
        result=await execute(SimpleNamespace(command=command),db)
        assert result
        assert 'key_hash' not in json.dumps(result,default=str)

@pytest.mark.asyncio
async def test_persistence_after_pool_restart(db):
    lid,key=await license(db)
    cookie,access,_=await db.authenticate(key,'persist-device','127.0.0.1')
    await db.close()
    await db.open()
    assert await db.session(cookie,'127.0.0.1',cookie=True)
    assert await db.session(access,'127.0.0.1')

@pytest.mark.asyncio
async def test_storage_and_permissions(db):
    from utils import cryptjson
    lid,key=await license(db,level='PLATINUM')
    app=create_app()
    async with TestClient(TestServer(app)) as client:
        r=await client.get('/auth',headers={'Authorization':'Bearer '+key,'X-Device-ID':'storage-device'})
        assert r.status == 200
        access=(await r.json())['access_token']
        params={'access_token':access}
        r=await client.post('/data',params=params,data={'soft':cryptjson.json_zip({'@123':{'a':1}}).decode()})
        assert r.status == 204
        r=await client.get('/data',params=dict(params,soft='1'))
        assert cryptjson.json_unzip(await r.read()) == {'@123':{'a':1}}
        r=await client.post('/data',params=params,data={'soft':cryptjson.json_zip({'@123':{}}).decode()})
        assert r.status == 204
        r=await client.get('/data',params=dict(params,soft='1'))
        assert cryptjson.json_unzip(await r.read()) == {}
        r=await client.get('/data/soft',params=params); assert r.status == 200
        r=await client.get('/mapstorage',params=params); assert r.status == 200
        r=await client.post('/mapstorage',params=dict(params,method='save'),data={'code':'@123','info':cryptjson.text_encode(b'route-data').decode()})
        assert r.status == 204
        # Private-map fetching is controlled by the existing config flag.
        app['config']['map_storage_fetch']=True
        r=await client.get('/mapstorage',params=params)
        assert cryptjson.text_decode(await r.read()) == b'@123:route-data'
        r=await client.post('/mapstorage',params=dict(params,method='del'),data={'code':'@123'})
        assert r.status == 204
        client.session.cookie_jar.clear()
        r=await client.get('/data'); assert r.status == 401
        r=await client.post('/data',params=params,data={'config':'{bad'})
        assert r.status == 400

@pytest.mark.asyncio
async def test_real_server_process(db):
    import signal
    import socket
    import aiohttp
    with socket.socket() as s:
        s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
    env=dict(os.environ,SERVER_PORT=str(port),TFM_PARSER_ENDPOINT='')
    script=str(Path(__file__).resolve().parents[1]/'server.py')
    child=await asyncio.create_subprocess_exec(sys.executable,script,cwd='/tmp',env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
    try:
        healthy=False
        async with aiohttp.ClientSession() as http:
            for _ in range(100):
                if child.returncode is not None:
                    break
                try:
                    async with http.get(f'http://127.0.0.1:{port}/health') as r:
                        healthy=r.status == 200 and (await r.json())['database']=='ok'
                        if healthy:
                            break
                except aiohttp.ClientError:
                    await asyncio.sleep(0.1)
        assert healthy
    finally:
        if child.returncode is None:
            child.send_signal(signal.SIGINT)
        out,err=await asyncio.wait_for(child.communicate(),timeout=15)
    assert child.returncode == 0,err.decode()
    assert b'Traceback' not in err
    assert b'Unclosed' not in err
    assert b'no running event loop' not in err
