# DisneyClient — backend recuperado

O backend foi atualizado para Python 3.11 e MySQL 8.0+ ou MariaDB 10.4+ (XAMPP), com administração local
de licenças e sem dependência de Discord, Google Sheets ou Heroku na inicialização.

- [SQL completo para phpMyAdmin/XAMPP](DisneyClient/setup_xampp.sql)
- [Exemplo de configuração local do XAMPP](DisneyClient/.env.xampp.example)
- [Instalação no Windows e comandos administrativos](DisneyClient/INSTALL_WINDOWS.md)
- [Relatório de alterações, testes e limitações](RECOVERY_REPORT.md)
- [Inventário das SWFs recebidas](SWF_INSPECTION.json)
- [README original arquivado](docs/README_LEGACY.md)

O guia antigo descreve infraestrutura histórica e não deve ser seguido para o
backend novo. `MARIADB_ENDPOINT` foi substituído por `MYSQL_*`; `PORT` permanece
como fallback de `SERVER_PORT`. IDs e tokens do Discord não são utilizados.
`createmariadb.py` agora chama a migração com autenticação administrativa.

## Início rápido

Crie um banco MySQL novo, copie `DisneyClient/.env.example` para `.env` e
preencha suas credenciais locais. Na pasta `DisneyClient`:

```console
python -m pip install -r requirements.txt
python admin.py hash-password
# Guarde o hash em ADMIN_PASSWORD_HASH no .env
python admin.py migrate
python admin.py create-key --days 30
python server.py
```

O parser continua sendo um componente separado. O login e o armazenamento
funcionam sem ele; a integração com o jogo depende de um parser autorizado
compatível e de um runtime Flash. A execução da SWF 158 não foi validada.
Não foram implementados bypasses de proteção ou autenticação de terceiros.

No ambiente Codex preparado, `bash DisneyClient/cloud-start.sh` inicia o MySQL
local de desenvolvimento e o servidor. O `.env` local e os bancos de teste não
integram o pacote de entrega. A restauração do volume Docker em outra tarefa
não foi verificada; use backups para dados que devam ser preservados.
