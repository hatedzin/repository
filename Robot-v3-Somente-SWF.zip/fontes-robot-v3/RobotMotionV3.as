package disney {
 import flash.display.MovieClip;import flash.utils.Dictionary;
 public class RobotMotionV3 {
  private static var drivers:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var shared:NativeMotion;
  public function RobotMotionV3(value:MovieClip){root=value;shared=NativeMotion.get(value);}
  public static function get(value:MovieClip):RobotMotionV3{if(!drivers[value])drivers[value]=new RobotMotionV3(value);return drivers[value];}
  public function observeWith(callback:Function):void{shared.observeWith(callback);}
  public function finished():Boolean{return shared.finished();}
  public function release(token:Object):void{shared.release(token);}
  public function movement(token:Object,l:Boolean,r:Boolean,j:Boolean):void{shared.movement(token,l,r,j);}
  public function crouch(token:Object,down:Boolean):void{shared.crouch(token,down);}
  private function read(o:Object,p:*):*{try{if(o && p!=null && p in o)return o[p];}catch(e:Error){}return null;}
  public function routeSample(token:Object,state:Object):void{
   if(finished()){release(token);return;}
   var k:Object=root["Keys"];var local:Object=k && root["tfm"] ? root["tfm"][k.player] : null;
   var body:Object=local && k.player_physics ? local[k.player_physics] : null;
   if(!local || !body || !state || !isFinite(Number(state.vx)) || !isFinite(Number(state.vy)))throw new Error("Estado de movimento indisponivel",2410);
   var getter:Function=read(body,read(k,"get_linear_velocity")) as Function;
   var velocity:Object=getter!=null ? getter.apply(body,[]) : read(body,read(k,"physics_state"));
   var vx:* =read(k,"physics_state_vx");var vy:* =read(k,"physics_state_vy");
   var jump:Function=read(local,read(k,"jump")) as Function;
   if(!velocity || vx==null || vy==null || !(vx in velocity) || !(vy in velocity) || jump==null)throw new Error("Fisica da rota nao mapeada",2410);
   shared.movement(token,Boolean(state.ml),Boolean(state.mr),false);
   if(finished())return;
   if(root["tfm"][k.player]!==local || local[k.player_physics]!==body || (k.is_dead && local[k.is_dead]))throw new Error("Jogador mudou durante movimento",2410);
   jump.apply(local,[Boolean(state.jump),int(state.frame)]);
   // JSON stores signed velocity * 100; decodeMovement already divided by100.
   // The old *10 applied to a packet field, not to this Box2D vector.
   velocity[vx]=Number(state.vx);velocity[vy]=Number(state.vy);
  }

 }
}
