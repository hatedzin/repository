package disney {
 import ChargeurTransformice_fla.MainTimeline;import ChargeurTransformice_fla.Statements;import flash.display.MovieClip;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.geom.Point;import flash.net.URLLoader;import flash.net.URLRequest;import flash.text.TextField;import flash.external.ExternalInterface;import flash.utils.setTimeout;import flash.utils.ByteArray;import flash.display.Sprite;
 public class RgbMouseTests {
  private static var count:int=0;private static function check(ok:Boolean,s:String):void{if(!ok)throw new Error(s);count++;}
  private static function walk(x:Number=395,delay:Number=100,j:Boolean=true):Array{return [{x:x,y:1102,vx:345,vy:65036,mr:true,ml:false,jump:j,frame:2},"walk",delay];}
  private static function fixture(display:MovieClip,steps:Array=null,sealedRoot:Boolean=false):Object{
   var r:MovieClip=sealedRoot ? new SealedRobotRoot() : new MovieClip();display.addChild(r);r.stage.focus=r.stage;var calls:Array=[];var jumps:Array=[];var markers:Array=[];var syncs:Array=[];var keys:Array=[];
   var velocity:Object={vx:0,vy:0};var body:Object={velocity:velocity,getVelocity:function():Object{return velocity;},setPosition:function(p:Point,angle:Number):Boolean{calls.push({x:p.x,y:p.y});return true;}};
   var p:Object={x:118.5,y:330.6,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true,jump:function(on:Boolean,frame:int=0):void{jumps.push({on:on,frame:frame});},crouch:function(s:Boolean):void{},stand:function(s:Boolean):void{}};
   var map:Object={number:{value:123},container:{mirror:false}};
   if(steps && steps[0][1]=="walk"){var initial:Object=RobotPlaybackV3.decodeMovement(steps[0][0]);p.x=initial.x;p.y=initial.y;}
   r.Keys={packet_handler_class:{receive:function(bytes:ByteArray):void{syncs.push(bytes);}},packet_handler:"receive",player:"mouse",player_list:"players",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",get_linear_velocity:"getVelocity",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{return Point;}}},map_class:{current:map,width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"mirror",bot_map_width:"width",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked"};
   r.tfm={mouse:p,players:[]};r.Interface={status_field:new TextField()};r.Statements={send_cheese_packet:function():void{markers.push("cheese");},send_hole_packet:function():void{markers.push("hole");}};r.host_url="";r.auto_play=true;r.auto_play_disable_on_move=true;
   var bot:RobotPlaybackV3=new RobotPlaybackV3(r);var library:Object={};library["@123"]=steps ? steps : [walk(395,442),walk(430,100,false),["cheese",37],["hole",410]];bot.setRoutes(library);bot.setTiming(new RouteTiming(1,false));
   r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(!NativeMotion.isSynthetic(r) && r.auto_play_disable_on_move && e.keyCode==39)bot.pause();});
   r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(r))keys.push({code:e.keyCode,down:true});});
   r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(r))keys.push({code:e.keyCode,down:false});});
   return {keys:keys,root:r,bot:bot,body:body,player:p,map:map,calls:calls,jumps:jumps,markers:markers,library:library,syncs:syncs};
  }
  private static function positiveJumps(f:Object):int{var n:int=0;for each(var j:Object in f.jumps)if(j.on)n++;return n;}
  private static function until(bot:RobotPlaybackV3,from:int,to:int):void{for(var n:int=from+50;n<to;n+=50)bot.advance(n);bot.advance(to);}
  private static function noTeleport(f:Object,label:String):void{check(f.calls.length==0 && f.syncs.length==0,label);}
  private static function verifyLoader(display:MovieClip,finished:Function):void{
   var f:Object=fixture(display);f.map.number.value=1628732;f.player.x=193.8;f.player.y=381;var bot:RobotPlaybackV3=new RobotPlaybackV3(f.root);bot.setTiming(new RouteTiming(1,false));bot.loadRoutes();var clock:int=1100;var tries:int=0;
   f.root.auto_play=false;var initial:int=int(ExternalInterface.call("routeRequests"));bot.advance(0);
   setTimeout(function():void{try{
    check(int(ExternalInterface.call("routeRequests"))==initial,"disabled Robot startup performs zero route requests");
    f.root.auto_play=true;f.player.body=null;bot.advance(1000);
    setTimeout(function():void{try{
     check(int(ExternalInterface.call("routeRequests"))==initial,"animation/player initialization performs zero route requests");
     f.player.body=f.body;
     var tick:Function=function():void{try{bot.advance(clock);clock+=100;tries++;
      if(f.jumps.length>0){check(f.player.x==193.8 && f.player.y==381 && f.player.left && !f.player.right,"production @1628732 route applies first native direction without relocating player");check(int(ExternalInterface.call("routeRequests"))==initial+1,"only one small per-map request is needed");noTeleport(f,"real per-map loader makes no physics-position or synthetic teleport calls");f.root.auto_play=false;bot.advance(clock);finished();}
      else if(tries>=2000)throw new Error("Production loader did not become ready: "+bot.message);
      else setTimeout(tick,1);
     }catch(error:Error){ExternalInterface.call("recordTest","FAIL: production loader "+error.message+" #"+error.errorID);}};tick();
    }catch(error:Error){ExternalInterface.call("recordTest","FAIL: boot "+error.message);}},100);
   }catch(error:Error){ExternalInterface.call("recordTest","FAIL: boot "+error.message);}},100);
  }
  public static function run(display:MovieClip):void{
   try{
    var f:Object=fixture(display);var originalX:Number=f.player.x;var originalY:Number=f.player.y;f.bot.advance(0);f.bot.advance(300);until(f.bot,300,741);check(f.jumps.length==0,"first recorded delay respected with regular display ticks");f.bot.advance(742);
    check(f.jumps.length==1 && f.jumps[0].on && f.jumps[0].frame==2,"recorded jump and animation frame restored at deadline");check(Math.abs(f.body.velocity.vx-3.45)<0.00001 && f.body.velocity.vy==-5,"unsigned JSON short velocities restored in signed native units");check(f.player.right && !f.player.left,"native horizontal movement flags applied");check(f.player.x==originalX && f.player.y==originalY,"sample does not assign visual position");
    var upKeys:int=0;for each(var key:Object in f.keys)if(key.code==38 && key.down)upKeys++;check(upKeys==0,"recorded jump does not also synthesize a second jump key");
    f.bot.advance(792);check(f.jumps.length==1 && f.player.x==originalX && f.player.y==originalY,"no speculative coordinate or jump updates between timestamps");
    // Simulate a real physics interval using the actual vector the Robot changed.
    f.player.x+=f.body.velocity.vx*30*0.1;f.player.y+=f.body.velocity.vy*30*0.1;var simulatedX:Number=f.player.x;var simulatedY:Number=f.player.y;f.bot.advance(842);check(f.player.x==simulatedX && f.player.y==simulatedY && !f.jumps[f.jumps.length-1].on,"engine-driven motion retained through recorded jump release");
    until(f.bot,842,1289);check(!f.player.right && f.markers.length==0 && f.bot.message.indexOf("confirmacao")>=0,"terminal hole releases input and waits for native confirmation");noTeleport(f,"full playback and hole wait never invoke position or initial-sync APIs");
    var hud:TextField=f.root.stage.getChildByName("sddsRobotV3Status") as TextField;check(hud!=null && hud.visible && hud.text.indexOf("Robot v3:")==0 && !hud.mouseEnabled,"visible versioned Robot status does not capture input");
    f.root.auto_play=false;f.bot.advance(1400);check(!hud.visible,"Robot status hides when disabled");

    f=fixture(display,[walk(395,0),["hole",100]]);delete f.root.Keys.bot_set_position;delete f.root.Keys.b2vec2;delete f.root.Keys.get_linear_velocity;f.bot.advance(0);f.bot.advance(300);check(f.player.right && f.body.velocity.vy==-5,"typed native vector fallback works without teleport or vector-constructor mappings");noTeleport(f,"fallback uses no positioning API");
    f=fixture(display,[walk(395,0),["hole",100]]);delete f.root.Keys.physics_state_vx;f.bot.advance(0);f.bot.advance(300);check(f.bot.message.indexOf("erro")>=0 || f.bot.message.indexOf("pausado")>=0 || f.bot.message.indexOf("simbolo ausente")>=0,"missing required native velocity symbol reports failure");noTeleport(f,"missing velocity mapping cannot fall back to teleport");
    f=fixture(display,[walk(1000,0,false),walk(1000,100,false),["hole",100]]);f.map.container.mirror=true;f.player.x=500;f.bot.advance(0);f.bot.advance(300);check(f.player.x==500 && f.player.left && !f.player.right && Math.abs(f.body.velocity.vx+3.45)<0.00001,"mirror swaps direction and native horizontal velocity without changing position");noTeleport(f,"mirroring remains free of coordinate writes");

    var cluster:Array=[walk(395,0),walk(395,20),walk(395,20),walk(395,20),["hole",200]];cluster[1][0].frame=3;cluster[2][0].frame=4;cluster[3][0].frame=5;f=fixture(display,cluster);f.bot.advance(0);f.bot.advance(300);f.bot.advance(400);check(positiveJumps(f)==4 && f.jumps[1].frame==3 && f.jumps[2].frame==4 && f.jumps[3].frame==5,"overdue samples processed in timestamp order within one display frame");noTeleport(f,"overdue samples do not snap across recorded positions");
    f=fixture(display,[walk(395,0),walk(395,100),["hole",100]]);f.bot.advance(0);f.bot.advance(300);f.bot.advance(1000);check(positiveJumps(f)==1 && f.bot.message.indexOf("pausado")<0,"long render gap stretches clock instead of bursting old samples");f.bot.advance(1050);check(positiveJumps(f)==2,"stretched clock resumes next recorded sample at new deadline");

    f=fixture(display,[walk(395,0),["hole",100]]);f.player.x=-500;f.bot.advance(0);f.bot.advance(300);check(f.jumps.length==0 && f.player.x==-500 && f.bot.message.indexOf("aguardando renascer")>=0,"distant initial spawn waits without teleporting to route");noTeleport(f,"distant spawn has zero hidden sync calls");
    f=fixture(display,[walk(395,0),walk(1500,100),["hole",100]]);f.bot.advance(0);f.bot.advance(300);f.bot.advance(400);check(positiveJumps(f)==1 && f.player.x==118.5 && f.bot.message.indexOf("aguardando renascer")>=0 && !f.player.right,"later route divergence releases controls and waits without snapping");noTeleport(f,"divergent route cannot relocate native or visual player");

    f=fixture(display,[walk(395,0),walk(395,100),["hole",100]]);f.bot.advance(0);f.bot.advance(300);f.bot.setFocused(false);f.bot.advance(350);f.bot.advance(400);check(positiveJumps(f)==2 && f.player.right,"Robot continues scheduled samples when window loses focus");f.bot.setFocused(true);f.root.auto_play=false;f.bot.advance(450);var disabledSamples:int=positiveJumps(f);f.bot.advance(9000);check(!f.player.right && positiveJumps(f)==disabledSamples,"explicit disable releases input and prevents later movement");
    f=fixture(display,[walk(395,0),walk(395,200),["hole",100]]);f.bot.advance(0);f.bot.advance(300);var input:TextField=new TextField();input.type="input";f.root.addChild(input);f.root.stage.focus=input;f.bot.advance(350);var typedSamples:int=positiveJumps(f);f.bot.advance(1000);check(positiveJumps(f)==typedSamples && !f.player.right,"chat typing still pauses clock and releases native movement");f.root.stage.focus=f.root.stage;f.bot.advance(1100);check(f.player.right && f.body.velocity.vy==-5,"leaving chat restores saved native movement and velocity");var resumedSamples:int=positiveJumps(f);f.bot.advance(1200);check(positiveJumps(f)==resumedSamples,"chat suspension does not consume future samples early");f.bot.advance(1250);check(positiveJumps(f)==resumedSamples+1,"chat suspension shifts recorded deadline by paused duration");

    f=fixture(display,[walk(395,0),["hole",100]]);f.root.current_round_code=1;f.root.Keys.player_id="pid";f.player.pid=7;f.bot.advance(0);f.bot.advance(300);f.root.current_round_code=2;f.bot.advance(350);f.bot.advance(600);check(positiveJumps(f)==2,"same map/body with new round token restarts route");var birth:ByteArray=new ByteArray();birth.writeByte(144);birth.writeByte(2);birth.writeUTF("Self#0001");birth.writeInt(7);birth.position=1;NativeMotion.observe(f.root,birth);f.bot.advance(650);f.bot.advance(900);check(positiveJumps(f)==3 && birth.position==1,"local respawn restarts without missing dead frame or modifying packet cursor");noTeleport(f,"round and respawn transitions never synchronize by teleport");
    f=fixture(display,[walk(395,0),["hole",100]]);f.root.Keys.player_id="pid";f.player.pid=7;f.bot.advance(0);f.bot.advance(300);f.bot.advance(400);var victory:ByteArray=new ByteArray();victory.writeByte(8);victory.writeByte(6);victory.writeByte(0);victory.writeInt(99);victory.position=1;NativeMotion.observe(f.root,victory);f.bot.advance(450);check(f.bot.message.indexOf("vitoria confirmada")<0,"other player's victory does not complete Robot");victory.position=3;victory.writeInt(7);victory.position=1;NativeMotion.observe(f.root,victory);f.bot.advance(500);check(f.bot.message.indexOf("vitoria confirmada")>=0 && victory.position==1 && !f.player.right,"server local victory ends playback and preserves packet cursor");
    f=fixture(display,[walk(395,0),["hole",100]]);var shared:NativeMotion=NativeMotion.get(f.root);var previousOwner:Object={};shared.movement(previousOwner,true,false,false);f.bot.advance(0);f.bot.advance(300);check(shared.inputBusy() && !shared.busyExcept(f.bot) && f.player.right && !f.player.left,"Robot reuses original movement ownership");shared.release(previousOwner);check(f.player.right && shared.inputBusy(),"old Follow owner cannot release Robot controls");f.root.auto_play=false;f.bot.advance(350);check(!shared.inputBusy() && !f.player.right,"Robot disable releases original shared driver for Follow or AutoBest");
    f=fixture(display,[walk(395,0),["hole",100]],true);f.bot.advance(0);f.bot.advance(300);check(f.player.right && f.body.velocity.vy==-5 && !NativeMotion.isSynthetic(f.root),"native movement and velocity work on sealed document root without #1056");noTeleport(f,"sealed root also never receives synthetic teleport");

    MainTimeline.instance=display as MainTimeline;var old:Statements=new Statements();old.current_timeout=-1;old.play_map();old.play_sequence();old.step(null,"walk");old.player_victory();old.player_death();old.kill_player();old.send_cheese_packet();old.send_hole_packet();old.send_mort_packet();old.move_player(1,2);old.handle_preview_btn();check(old.current_timeout==-1 && old.new_cheese_packet(1,true)==null && old.new_victory_packet(0,1,0,1,1)==null,"retired execution and forced-packet functions stay inert");RoutePlayer.attach(display);check(true,"old RoutePlayer entry remains inert");
    f=fixture(display,[walk(395,0,false),["hole",20]]);for(var n:int=0;n<120;n++){var base:int=n*1000;f.player.dead=true;f.bot.advance(base);f.player.dead=false;f.bot.advance(base+100);f.bot.advance(base+400);f.bot.advance(base+420);}var respawnSamples:int=0;for each(var sample:Object in f.jumps)if(sample.frame==2)respawnSamples++;check(respawnSamples==120 && f.markers.length==0,"120 simulated respawns retain exactly one native sample per attempt and no forced markers");noTeleport(f,"120 respawns never use position or initial-sync APIs");

    var loader:URLLoader=new URLLoader();loader.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void{ExternalInterface.call("recordTest","FAIL: full route library could not load");});
    loader.addEventListener(Event.COMPLETE,function(e:Event):void{
     var catalog:RouteLibrary=new RouteLibrary(String(loader.data));loader.data="";var codes:Array=[];var cursor:int=0;var totalSteps:int=0;
     var batch:Function=function():void{try{
      if(!catalog.done){catalog.step(131072);if(catalog.done){for(var name:String in catalog.entries)codes.push(name);ExternalInterface.call("recordProgress","Indexed "+codes.length+" map entries");}}
      else {var limit:int=Math.min(codes.length,cursor+4);while(cursor<limit){var route:Array=RobotPlaybackV3.decodeRoute(String(catalog.entries[codes[cursor]]));totalSteps+=route.length;cursor++;if(cursor%200==0)ExternalInterface.call("recordProgress","Validated "+cursor+" routes");}}
      if(catalog.done && cursor==codes.length){check(cursor==2359,"all 2359 maps parsed incrementally with native ActionScript decoder");verifyLoader(display,function():void{ExternalInterface.call("recordTest","PASS: "+count+" native Robot checks; "+cursor+" routes / "+totalSteps+" steps validated");});}else setTimeout(batch,1);
     }catch(error:Error){ExternalInterface.call("recordTest","FAIL: full library "+error.message+" #"+error.errorID);}};batch();
    });loader.load(new URLRequest("public/rotas_decodificadas.json"));
   }catch(error:Error){ExternalInterface.call("recordTest","FAIL: "+error.message+" #"+error.errorID);}
  }
 }
}
class SealedRobotRoot extends flash.display.MovieClip {
 public var Keys:Object;public var tfm:Object;public var Interface:Object;public var Statements:Object;
 public var auto_play:Boolean=false;public var auto_play_disable_on_move:Boolean=false;public var host_url:String="";
 public var current_map_code:String="";public var current_map_code_int:int=0;public var player_has_cheese:Boolean=false;
}
