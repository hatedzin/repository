# ASTRO V4 — correção de morrer quando alguém entrar na toca

Este é o projeto completo DisneyClient-Completo-ASTRO-V4-Menu-Moderno-FPS do commit 358018944923435df5eedcd5641c893f2ab86398, com correção pontual da opção em Jogador. Não é a versão SWF independente.

Extraia o ZIP em uma pasta nova e execute INICIAR_TUDO.bat como antes. Em Jogador, marque Morrer quando alguém entrar na toca. O aviso local deve mostrar ligado (V4-R2). Ao receber uma vitória elegível, mostra morte solicitada após vitória de ID; esse aviso comprova o envio, não a confirmação de morte pelo servidor.

A opção agora envia o comando nativo mort pela classe de pacote e pelo socket principal resolvidos pelo parser do próprio projeto, ao receber a vitória confirmada de outro jogador. Ignora a própria vitória, pacotes incompletos, personagem ausente ou morto e eventos repetidos. Rearma no renascimento e pelo evento nativo de mapa. A versão anterior esperava a atualização dos campos de rodada do loader e podia ficar permanentemente desarmada; essa dependência foi removida. Não depende do Farm Time nem do Auto mort temporizado.

O site, as contas, as skins, o parser e os inicializadores foram preservados. Somente o ponto de inicialização do loader recebeu o novo controlador; os demais métodos existentes permanecem byte a byte iguais.

Validação: 22 verificações AS3 de eventos executadas no Ruffle, 1933 métodos com limites de pilha/escopo válidos e conferência dos arquivos do projeto. O envio foi testado com transporte simulado; ainda falta validar a resposta de uma sala online no Flash Player do Windows.
