// C++ / client.cpp / Windows x86 + MSVC or Zig / Transformice standalone host and user-supplied AoB patches.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <commdlg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
#ifndef __clang__
#pragma comment(lib,"user32.lib")
#pragma comment(lib,"gdi32.lib")
#pragma comment(lib,"comdlg32.lib")
#endif
static_assert(sizeof(void*)==4,"Build x86; this client hosts x86 game runtimes.");
constexpr int MaxBytes=160, MaxPatches=24;
struct Definition {const wchar_t* name;const char* aob;const char* on;};
Definition defaults[]={
 {L"CN nao afeta","F2 0F 5E C1 66 0F D6 86 ?? 00 00 00 8B ** ** ** ** ** **","F2 0F 10"},
 {L"Crazy spawn","8B ?? ?? 89 ?? ?? 85 ?? 74 17 8B ?? ?? FB FF FF 85 ?? 0F 84 ?? ?? ?? ?? 8B ?? ?? ?? 00 00 89 ?? ?? 8B ?? ?? 85 ?? 0F 84 ?? ?? 00 00 8B","8D"},
 {L"Elevator","F2 0F 59 CB F2 0F 59 C2 F2 0F 58 C8 66","F3 0F 00"},
 {L"Floor","F3 0F 7E ** ** F2 0F 59 C1 66 0F D6 ** ** F3 0F 7E ** ** 00 00 00 66 0F D6 ** ** FE FF FF ** ** ** ** 00 00","F2 0F 5D"},
 {L"Fly / Left","F3 0F 7E ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? F3 0F 7E ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 8D 8F","F3 0F 00"},
 {L"Fly / Center","F3 0F 7E ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? F3 0F 7E ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 8D 8F","F3 0F 10"},
 {L"Ghost","F2 0F 58 ?? 85 DB 0F 84 ?? 01 00 00 66 0F D6 43 ?? 8B","F2 0F 59"},
 {L"Instant cheese","8B 7E 18 85 ?? 0F ?? ?? ?? ?? ?? ?? ?? ?? 66 0F 57 C0 F2 0F 2A C6 ?? ?? ?? ??","8B 7E 18 85 FF 0F 84 53 CD 00 00 8B 77 4C 66 0F 57 C0 F2 0F 2A C6 66 0F 10"},
 {L"Mapa 0","8B 50 18 B8 04 00 00 00 3B CA 0F 84","89 50 1C"},
 {L"Matrix","F3 0F 6F 06 66 0F 6F 0F F3 0F 70 D0 FF F2 0F 70 D2 FF 66 0F 6F DC 66 0F D9 DA 66 0F D5 D9 66 0F 71 D3 08 66 0F FD D8 66 0F 7F 1F 83 C6 10 83 C7 10","F3 0F 10"},
 {L"Rato agil","F3 0F 7E ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? F3 0F 7E 8E ?? ?? ?? ?? F2 0F 5E ??","F2 0F 5E 85"},
 {L"Rato atrito","F2 0F 59 C1 85 C0 0F 84 ?? ?? 00 00 8B 50 08 8B ?? ?? 89 ??","F2 0F 00"},
 {L"Rato imortal","F2 0F 2A ?? 66 0F 2E C1 0F 97 ?? 0F B6 ?? 89 ?? ?? 8B ?? ?? 85 ?? 0F 84 ?? 01 00 00","F2 0F 40"},
 {L"Rato invisivel","F3 0F 7E 45 D8 66 0F D6 41 20 F3 0F 7E 45 E0 66 0F","F3 0F 00"},
 {L"Rato rosa","F3 0F 7E 8D 50 FF FF FF F3 0F 7E 85","F3 0F 04"},
 {L"Rato verde","F3 0F 7E 8D 50 FF FF FF F3 0F 7E 85","F3 0F 03"},
 {L"Rato voador","F2 0F 59 C1 66 0F D6 ?? ?? F3 0F 7E ?? ?? 00 00 00 66 0F D6 ?? ?? FE FF FF","F2 0F 5D"},
 {L"Shaman invisivel","F3 0F 7E 45 D8 66 0F D6 41 20 F3 0F 7E 45 E0 66 0F","F3 0F 00"},
 {L"Shaman no range","00 ?? 5E 40 9A ?? ?? ?? 99 99 C9 3F ?? 00 00 00","00 00 A0 40 9A 99 99 99 99 99 C9 3F 9A 99 99 99"},
 {L"Shaman wind speed","F2 0F 59 C1 66 0F D6 40 ?? 8D ?? ?? ?? 00 00 8D ??","F2 0F 2A"},
 {L"WJ Fly","F3 0F 7E 40 10 66 0F D6 45 ?? 8D ?? ?? ?? 00 00 8D 55 ?? E8 ?? ?? ?? ?? F3 0F 7E 4D ?? 8B D0 8B 45 ?? 8B 4A 10","F3 0F 7E 45"}
};
struct Patch {
 wchar_t name[128]; char patternText[1024],onText[512];
 BYTE pattern[MaxBytes],mask[MaxBytes],on[MaxBytes],original[MaxBytes];
 int length,onLength;bool valid,active,uncertain;uintptr_t address;int matches;
};
Patch patches[MaxPatches];int patchCount=0;
HWND mainWindow,list,details,status,openButton,scanButton,onButton,offButton,allButton,gameArea,pathLabel;
HWND gameWindow=nullptr,oldParent=nullptr;LONG_PTR oldStyle=0,oldExStyle=0;bool embedded=false;
HANDLE gameProcess=nullptr,scanThread=nullptr,cancelEvent=nullptr;DWORD gamePid=0,launchTime=0;
HINSTANCE app;HFONT font;wchar_t ini[MAX_PATH],gamePath[MAX_PATH];bool scanning=false;
enum{Open=101,Scan,EnablePatch,DisablePatch,RestoreAll,PatchList,ScanFinished=WM_APP+1};
struct Job{HANDLE process;int index;Patch spec;};
struct Result{int index,hits;uintptr_t address;bool cancelled,failed;uint64_t bytes;};
void Status(const wchar_t* text){SetWindowTextW(status,text);}
int Hex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
bool Parse(const char* text,BYTE* bytes,BYTE* mask,int& length,bool wildcard){
 length=0;const char* s=text;
 while(*s){while(*s==' '||*s=='\t'||*s=='\r'||*s=='\n')++s;if(!*s)break;
  const char* t=s;while(*s&&*s!=' '&&*s!='\t'&&*s!='\r'&&*s!='\n')++s;
  size_t n=s-t;if(length>=MaxBytes)return false;
  bool wild=(n==1&&(t[0]=='?'||t[0]=='*'))||(n==2&&((t[0]=='?'&&t[1]=='?')||(t[0]=='*'&&t[1]=='*')));
  if(wild){if(!wildcard)return false;bytes[length]=0;mask[length]=0;}
  else{if(n!=2||Hex(t[0])<0||Hex(t[1])<0)return false;bytes[length]=BYTE(Hex(t[0])*16+Hex(t[1]));mask[length]=255;}
  ++length;
 }return length>0;
}
bool Match(const BYTE* memory,const Patch& p){for(int i=0;i<p.length;++i)if(p.mask[i]&&memory[i]!=p.pattern[i])return false;return true;}
int FindInBuffer(const BYTE* buffer,SIZE_T n,SIZE_T primary,const Patch& p,SIZE_T& first,int limit){
 if(p.length<=0||n<SIZE_T(p.length)||limit<1)return 0;
 int anchor=0;while(anchor<p.length&&!p.mask[anchor])++anchor;if(anchor==p.length)return 0;
 SIZE_T possible=n-p.length+1;if(possible>primary)possible=primary;SIZE_T k=0;int hits=0;
 while(k<possible){const BYTE* hit=static_cast<const BYTE*>(memchr(buffer+k+anchor,p.pattern[anchor],possible-k));if(!hit)break;k=SIZE_T(hit-buffer)-anchor;
  if(Match(buffer+k,p)){if(!hits)first=k;if(++hits>=limit)break;}++k;
 }return hits;
}
bool Read(HANDLE process,uintptr_t address,void* data,SIZE_T length){SIZE_T n=0;return ReadProcessMemory(process,reinterpret_cast<void*>(address),data,length,&n)&&n==length;}
bool Write(HANDLE process,uintptr_t address,const BYTE* data,SIZE_T length){
 MEMORY_BASIC_INFORMATION m{};if(!VirtualQueryEx(process,reinterpret_cast<void*>(address),&m,sizeof(m))||m.State!=MEM_COMMIT)return false;
 uint64_t end=uint64_t(reinterpret_cast<uintptr_t>(m.BaseAddress))+m.RegionSize;
 if(uint64_t(address)+length>end)return false;
 DWORD old=0;if(!VirtualProtectEx(process,reinterpret_cast<void*>(address),length,PAGE_EXECUTE_READWRITE,&old))return false;
 SIZE_T n=0;BOOL written=WriteProcessMemory(process,reinterpret_cast<void*>(address),data,length,&n);
 BOOL flushed=FlushInstructionCache(process,reinterpret_cast<void*>(address),length);DWORD ignored=0;
 BOOL restored=VirtualProtectEx(process,reinterpret_cast<void*>(address),length,old,&ignored);
 return written&&n==length&&flushed&&restored;
}
bool Alive(){return gameProcess&&WaitForSingleObject(gameProcess,0)==WAIT_TIMEOUT;}
int Selected(){return int(SendMessageW(list,LB_GETCURSEL,0,0));}
void Controls(){bool live=Alive();EnableWindow(openButton,!scanning&&!live);EnableWindow(scanButton,!scanning&&live);EnableWindow(onButton,!scanning&&live);EnableWindow(offButton,!scanning&&live);EnableWindow(allButton,!scanning&&live);}
void Refresh(){
 int selected=Selected();SendMessageW(list,LB_RESETCONTENT,0,0);
 for(int i=0;i<patchCount;++i){wchar_t line[256];Patch& p=patches[i];
  const wchar_t* state=!p.valid?L"erro na definicao":p.active?(p.uncertain?L"verificar restauracao":L"ON"):p.matches>1?L"multiplos":p.address?L"localizado":L"nao localizado";
  swprintf_s(line,256,L"%ls  [%ls]",p.name,state);SendMessageW(list,LB_ADDSTRING,0,reinterpret_cast<LPARAM>(line));
 }SendMessageW(list,LB_SETCURSEL,selected>=0?selected:0,0);Controls();
}
void Details(){int i=Selected();if(i<0||i>=patchCount)return;Patch& p=patches[i];wchar_t text[2300];
 swprintf_s(text,2300,L"%ls\r\nEndereco: 0x%08lX\r\n\r\nAoB:\r\n%hs\r\n\r\nON:\r\n%hs\r\n\r\nOFF: bytes originais capturados.\r\n\r\nPadroes e efeitos fornecidos pelo usuario; compatibilidade nao verificada.",p.name,(unsigned long)p.address,p.patternText,p.onText);SetWindowTextW(details,text);
}
void LoadDefinitions(){
 patchCount=int(sizeof(defaults)/sizeof(defaults[0]));
 for(int i=0;i<patchCount;++i){Patch& p=patches[i];wchar_t section[32];swprintf_s(section,32,L"Patch%d",i);
  GetPrivateProfileStringW(section,L"Name",defaults[i].name,p.name,128,ini);
  // INI is Unicode-path aware; byte patterns are converted through wide strings.
  wchar_t wide[1024],fallback[1024];MultiByteToWideChar(CP_UTF8,0,defaults[i].aob,-1,fallback,1024);
  GetPrivateProfileStringW(section,L"Aob",fallback,wide,1024,ini);WideCharToMultiByte(CP_UTF8,0,wide,-1,p.patternText,1024,nullptr,nullptr);
  MultiByteToWideChar(CP_UTF8,0,defaults[i].on,-1,fallback,1024);GetPrivateProfileStringW(section,L"On",fallback,wide,1024,ini);WideCharToMultiByte(CP_UTF8,0,wide,-1,p.onText,512,nullptr,nullptr);
  BYTE mask[MaxBytes];p.valid=Parse(p.patternText,p.pattern,p.mask,p.length,true)&&Parse(p.onText,p.on,mask,p.onLength,false)&&p.onLength<=p.length;
 }
 Patch& p=patches[patchCount++];wcscpy_s(p.name,128,L"Rato leve (double exato)");double from=16.6666666666667,to=14.1;memcpy(p.pattern,&from,8);memcpy(p.on,&to,8);memset(p.mask,255,8);p.length=p.onLength=8;p.valid=true;
 strcpy_s(p.patternText,1024,"IEEE754 double: 16.6666666666667");strcpy_s(p.onText,512,"IEEE754 double: 14.1");
}
DWORD WINAPI Search(void* argument){
 Job job=*static_cast<Job*>(argument);HeapFree(GetProcessHeap(),0,argument);Result* result=static_cast<Result*>(HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(Result)));
 if(!result){CloseHandle(job.process);PostMessageW(mainWindow,ScanFinished,0,0);return 0;}
 result->index=job.index;Patch p=job.spec;const SIZE_T chunk=1024*1024;
 BYTE* buffer=static_cast<BYTE*>(HeapAlloc(GetProcessHeap(),0,chunk+MaxBytes));
 if(!buffer)result->failed=true;
 int anchor=0;while(anchor<p.length&&!p.mask[anchor])++anchor;
 if(anchor==p.length)result->failed=true;
 uint64_t cursor=0x10000;
 while(!result->failed&&result->hits<2&&cursor<0x100000000ULL){
  if(WaitForSingleObject(cancelEvent,0)==WAIT_OBJECT_0){result->cancelled=true;break;}
  MEMORY_BASIC_INFORMATION m{};if(!VirtualQueryEx(job.process,reinterpret_cast<void*>(uintptr_t(cursor)),&m,sizeof(m)))break;
  uint64_t base=reinterpret_cast<uintptr_t>(m.BaseAddress),end=base+uint64_t(m.RegionSize);if(end<=cursor)break;
  DWORD protect=m.Protect&255;
  bool readable=protect==PAGE_READONLY||protect==PAGE_READWRITE||protect==PAGE_WRITECOPY||protect==PAGE_EXECUTE_READ||protect==PAGE_EXECUTE_READWRITE||protect==PAGE_EXECUTE_WRITECOPY;
  if(m.State==MEM_COMMIT&&!(m.Protect&PAGE_GUARD)&&readable){
   for(uint64_t pos=base;pos<end&&pos<0x100000000ULL&&result->hits<2;pos+=chunk){
    if(WaitForSingleObject(cancelEvent,0)==WAIT_OBJECT_0){result->cancelled=true;break;}
    uint64_t remain=end-pos;SIZE_T primary=remain<chunk?SIZE_T(remain):chunk;
    SIZE_T want=remain<chunk+p.length-1?SIZE_T(remain):chunk+p.length-1,n=0;
    ReadProcessMemory(job.process,reinterpret_cast<void*>(uintptr_t(pos)),buffer,want,&n);result->bytes+=n;
    SIZE_T first=0;int hits=FindInBuffer(buffer,n,primary,p,first,2-result->hits);
    if(hits){result->address=uintptr_t(pos+first);result->hits+=hits;}
   }
  }if(result->cancelled)break;cursor=end;
 }
 if(buffer)HeapFree(GetProcessHeap(),0,buffer);CloseHandle(job.process);
 if(!PostMessageW(mainWindow,ScanFinished,0,reinterpret_cast<LPARAM>(result)))HeapFree(GetProcessHeap(),0,result);return 0;
}
void StartScan(){
 int i=Selected();if(i<0||i>=patchCount||!Alive()||scanning)return;
 if(!patches[i].valid){Status(L"Definicao invalida; confira o arquivo INI.");return;}
 for(int n=0;n<patchCount;++n)if(patches[n].active){Status(L"Restaure os patches ativos antes de uma nova busca.");return;}
 Job* job=static_cast<Job*>(HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(Job)));if(!job){Status(L"Sem memoria para iniciar a busca.");return;}
 if(!DuplicateHandle(GetCurrentProcess(),gameProcess,GetCurrentProcess(),&job->process,0,FALSE,DUPLICATE_SAME_ACCESS)){HeapFree(GetProcessHeap(),0,job);Status(L"Falha ao duplicar handle do jogo.");return;}
 job->index=i;job->spec=patches[i];ResetEvent(cancelEvent);scanning=true;Controls();Status(L"Procurando AoB na memoria do jogo...");
 scanThread=CreateThread(nullptr,0,Search,job,0,nullptr);
 if(!scanThread){CloseHandle(job->process);HeapFree(GetProcessHeap(),0,job);scanning=false;Controls();Status(L"Falha ao iniciar busca.");}
}
bool Restore(Patch& p){
 if(!p.active)return true;if(!Alive()){p.active=false;p.address=0;return true;}
 BYTE current[MaxBytes];if(!Read(gameProcess,p.address,current,p.onLength))return false;
 if(!memcmp(current,p.original,p.onLength)){p.active=p.uncertain=false;return true;}
 if(!p.uncertain&&memcmp(current,p.on,p.onLength))return false;
 if(!Write(gameProcess,p.address,p.original,p.onLength))return false;
 if(!Read(gameProcess,p.address,current,p.onLength)||memcmp(current,p.original,p.onLength))return false;
 p.active=p.uncertain=false;return true;
}
bool RestoreEverything(){bool ok=true;for(int i=0;i<patchCount;++i)if(!Restore(patches[i]))ok=false;return ok;}
void Apply(){
 int i=Selected();if(i<0||i>=patchCount||!Alive()||scanning)return;Patch& p=patches[i];if(p.active)return;
 if(!p.valid||!p.address||p.matches!=1){Status(L"Primeiro localize uma unica correspondencia.");return;}
 for(int n=0;n<patchCount;++n){Patch& q=patches[n];if(q.active&&uint64_t(p.address)<uint64_t(q.address)+q.onLength&&uint64_t(q.address)<uint64_t(p.address)+p.onLength){Status(L"Conflito com outro patch ativo no mesmo intervalo.");return;}}
 BYTE current[MaxBytes];if(!Read(gameProcess,p.address,current,p.length)||!Match(current,p)){p.address=0;Status(L"O codigo mudou; procure o AoB novamente.");Refresh();Details();return;}
 memcpy(p.original,current,p.onLength);p.active=true;p.uncertain=true;
 if(!Write(gameProcess,p.address,p.on,p.onLength)||!Read(gameProcess,p.address,current,p.onLength)||memcmp(current,p.on,p.onLength)){
  bool rolledBack=Restore(p);Status(rolledBack?L"Falha na escrita; bytes originais restaurados.":L"Falha na escrita/restauracao. Reinicie o jogo antes de continuar.");
 }else{p.uncertain=false;Status(L"Patch aplicado. Compatibilidade do efeito nao foi verificada.");}
 Refresh();Details();
}
BOOL CALLBACK FindGame(HWND window,LPARAM parameter){DWORD pid=0;GetWindowThreadProcessId(window,&pid);RECT r{};GetClientRect(window,&r);
 if(pid==DWORD(parameter)&&IsWindowVisible(window)&&!GetWindow(window,GW_OWNER)&&r.right>200&&r.bottom>150){gameWindow=window;return FALSE;}return TRUE;
}
void ResizeGame(){if(embedded&&IsWindow(gameWindow)){RECT r{};GetClientRect(gameArea,&r);MoveWindow(gameWindow,0,0,r.right,r.bottom,TRUE);}}
void Embed(){
 if(embedded||!Alive())return;gameWindow=nullptr;EnumWindows(FindGame,gamePid);if(!gameWindow)return;
 oldParent=GetParent(gameWindow);oldStyle=GetWindowLongPtrW(gameWindow,GWL_STYLE);oldExStyle=GetWindowLongPtrW(gameWindow,GWL_EXSTYLE);
 LONG_PTR style=(oldStyle&~(WS_POPUP|WS_CAPTION|WS_THICKFRAME|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_SYSMENU))|WS_CHILD|WS_VISIBLE;
 SetLastError(0);SetWindowLongPtrW(gameWindow,GWL_STYLE,style);DWORD styleError=GetLastError();
 SetLastError(0);HWND previous=SetParent(gameWindow,gameArea);DWORD parentError=GetLastError();
 if(styleError||(!previous&&parentError)){SetWindowLongPtrW(gameWindow,GWL_STYLE,oldStyle);gameWindow=nullptr;Status(L"Nao foi possivel embutir a janela; jogo permanece separado.");return;}
 SetWindowLongPtrW(gameWindow,GWL_EXSTYLE,oldExStyle&~WS_EX_APPWINDOW);embedded=true;
 SetWindowPos(gameWindow,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_FRAMECHANGED);ResizeGame();Status(L"Jogo carregado. Aguarde a sala carregar e localize um AoB.");
}
void Detach(){if(embedded&&IsWindow(gameWindow)){SetParent(gameWindow,oldParent);SetWindowLongPtrW(gameWindow,GWL_STYLE,oldStyle);SetWindowLongPtrW(gameWindow,GWL_EXSTYLE,oldExStyle);ShowWindow(gameWindow,SW_RESTORE);SetWindowPos(gameWindow,nullptr,80,80,1000,700,SWP_NOZORDER|SWP_FRAMECHANGED);}embedded=false;gameWindow=nullptr;}
void Launch(){
 if(scanning||Alive())return;
 OPENFILENAMEW of{};of.lStructSize=sizeof(of);of.hwndOwner=mainWindow;of.lpstrFilter=L"Transformice standalone (*.exe)\0*.exe\0\0";of.lpstrFile=gamePath;of.nMaxFile=MAX_PATH;of.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;of.lpstrTitle=L"Selecione o executavel x86 do Transformice, nao um instalador";
 if(!GetOpenFileNameW(&of))return;
 wchar_t command[MAX_PATH+4],directory[MAX_PATH];swprintf_s(command,MAX_PATH+4,L"\"%ls\"",gamePath);wcscpy_s(directory,MAX_PATH,gamePath);wchar_t* slash=wcsrchr(directory,L'\\');if(slash)*slash=0;
 STARTUPINFOW startup{};startup.cb=sizeof(startup);PROCESS_INFORMATION process{};
 if(!CreateProcessW(gamePath,command,nullptr,nullptr,FALSE,0,nullptr,directory,&startup,&process)){wchar_t text[128];swprintf_s(text,128,L"Falha ao abrir o jogo. Erro Windows: %lu",GetLastError());Status(text);return;}
 CloseHandle(process.hThread);gameProcess=process.hProcess;gamePid=process.dwProcessId;launchTime=GetTickCount();
 BOOL selfWow=FALSE,targetWow=FALSE;BOOL architecture=IsWow64Process(GetCurrentProcess(),&selfWow)&&IsWow64Process(gameProcess,&targetWow);
 if(!architecture||selfWow!=targetWow){CloseHandle(gameProcess);gameProcess=nullptr;gamePid=0;Status(L"Runtime de arquitetura diferente; use o executavel x86. O processo aberto continua separado.");return;}
 for(int i=0;i<patchCount;++i){patches[i].address=0;patches[i].matches=0;patches[i].active=patches[i].uncertain=false;}
 WritePrivateProfileStringW(L"Client",L"GamePath",gamePath,ini);SetWindowTextW(pathLabel,gamePath);Status(L"Aguardando a janela do jogo...");Refresh();Details();
}
HWND Control(const wchar_t* cls,const wchar_t* text,DWORD style,int id){HWND w=CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,0,0,10,10,mainWindow,reinterpret_cast<HMENU>(INT_PTR(id)),app,nullptr);SendMessageW(w,WM_SETFONT,reinterpret_cast<WPARAM>(font),TRUE);return w;}
void Layout(){RECT r{};GetClientRect(mainWindow,&r);int left=305;MoveWindow(openButton,10,10,180,30,TRUE);MoveWindow(pathLabel,200,14,r.right-210,24,TRUE);
 int listHeight=(r.bottom-240)/2;if(listHeight<150)listHeight=150;MoveWindow(list,10,50,left-20,listHeight,TRUE);
 MoveWindow(scanButton,10,60+listHeight,138,30,TRUE);MoveWindow(onButton,155,60+listHeight,140,30,TRUE);
 MoveWindow(offButton,10,95+listHeight,138,30,TRUE);MoveWindow(allButton,155,95+listHeight,140,30,TRUE);
 MoveWindow(details,10,135+listHeight,left-20,r.bottom-listHeight-185,TRUE);
 MoveWindow(gameArea,left+5,50,r.right-left-15,r.bottom-95,TRUE);MoveWindow(status,10,r.bottom-35,r.right-20,28,TRUE);ResizeGame();}
LRESULT CALLBACK WindowProc(HWND window,UINT message,WPARAM wparam,LPARAM lparam){
 switch(message){
 case WM_CREATE:
  mainWindow=window;font=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
  openButton=Control(L"BUTTON",L"Abrir Transformice.exe",WS_TABSTOP,Open);pathLabel=Control(L"STATIC",L"Selecione sua instalacao do jogo",SS_LEFT,0);
  list=Control(L"LISTBOX",L"",LBS_NOTIFY|WS_BORDER|WS_VSCROLL|WS_TABSTOP,PatchList);
  scanButton=Control(L"BUTTON",L"Procurar AoB",WS_TABSTOP,Scan);onButton=Control(L"BUTTON",L"Ativar",WS_TABSTOP,EnablePatch);
  offButton=Control(L"BUTTON",L"Restaurar",WS_TABSTOP,DisablePatch);allButton=Control(L"BUTTON",L"Restaurar todos",WS_TABSTOP,RestoreAll);
  details=Control(L"EDIT",L"",ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL|WS_VSCROLL|WS_BORDER,0);gameArea=Control(L"STATIC",L"",SS_BLACKRECT|WS_CLIPCHILDREN,0);status=Control(L"STATIC",L"Escolha o runtime standalone x86. Nenhum patch e ativado automaticamente.",SS_LEFT,0);
  cancelEvent=CreateEventW(nullptr,TRUE,FALSE,nullptr);if(!cancelEvent)return -1;LoadDefinitions();Refresh();Details();SetTimer(window,1,250,nullptr);return 0;
 case WM_SIZE:Layout();return 0;
 case WM_GETMINMAXINFO:reinterpret_cast<MINMAXINFO*>(lparam)->ptMinTrackSize={900,620};return 0;
 case WM_COMMAND:
  switch(LOWORD(wparam)){
  case Open:Launch();break;
  case Scan:StartScan();break;
  case EnablePatch:Apply();break;
  case DisablePatch:{int i=Selected();if(i>=0&&i<patchCount){Status(Restore(patches[i])?L"Bytes originais restaurados.":L"Restauracao falhou: memoria mudou ou acesso negado.");Refresh();Details();}}break;
  case RestoreAll:Status(RestoreEverything()?L"Todos os patches foram restaurados.":L"Alguns patches nao puderam ser restaurados.");Refresh();Details();break;
  case PatchList:if(HIWORD(wparam)==LBN_SELCHANGE)Details();break;
  }return 0;
 case ScanFinished:{
  if(scanThread){WaitForSingleObject(scanThread,INFINITE);CloseHandle(scanThread);scanThread=nullptr;}scanning=false;
  Result* result=reinterpret_cast<Result*>(lparam);
  if(result){
   if(Alive()&&!result->cancelled&&!result->failed){Patch& p=patches[result->index];p.matches=result->hits;p.address=result->hits==1?result->address:0;
    wchar_t text[256];swprintf_s(text,256,L"Busca: %ls | %.1f MiB lidos.",result->hits==0?L"nenhuma correspondencia":result->hits==1?L"uma correspondencia":L"multiplas correspondencias; refine o AoB",double(result->bytes)/1048576.0);Status(text);
   }else Status(result->cancelled?L"Busca cancelada.":L"Busca falhou ou o jogo encerrou.");HeapFree(GetProcessHeap(),0,result);
  }else Status(L"Falha ao alocar resultado da busca.");Refresh();Details();return 0;}
 case WM_TIMER:
  if(gameProcess&&!Alive()){SetEvent(cancelEvent);Detach();CloseHandle(gameProcess);gameProcess=nullptr;gamePid=0;for(int i=0;i<patchCount;++i){patches[i].active=patches[i].uncertain=false;patches[i].address=0;patches[i].matches=0;}Status(L"O processo do jogo encerrou.");Refresh();Details();}
  else if(Alive()&&!embedded&&GetTickCount()-launchTime<30000)Embed();return 0;
 case WM_CLOSE:
  KillTimer(window,1);if(cancelEvent)SetEvent(cancelEvent);
  if(scanThread){WaitForSingleObject(scanThread,INFINITE);CloseHandle(scanThread);scanThread=nullptr;}
  {MSG pending;while(PeekMessageW(&pending,window,ScanFinished,ScanFinished,PM_REMOVE))if(pending.lParam)HeapFree(GetProcessHeap(),0,reinterpret_cast<void*>(pending.lParam));}
  if(!RestoreEverything())MessageBoxW(window,L"Alguns bytes nao puderam ser restaurados. Reinicie o jogo antes de continuar.",L"Falha na restauracao",MB_OK|MB_ICONERROR);
  Detach();if(gameProcess)CloseHandle(gameProcess);gameProcess=nullptr;if(cancelEvent)CloseHandle(cancelEvent);cancelEvent=nullptr;DestroyWindow(window);return 0;
 case WM_DESTROY:if(font)DeleteObject(font);PostQuitMessage(0);return 0;
 }return DefWindowProcW(window,message,wparam,lparam);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int show){
 app=instance;SetProcessDPIAware();GetModuleFileNameW(nullptr,ini,MAX_PATH);wchar_t* dot=wcsrchr(ini,L'.');if(dot)wcscpy_s(dot,MAX_PATH-(dot-ini),L".ini");
 GetPrivateProfileStringW(L"Client",L"GamePath",L"",gamePath,MAX_PATH,ini);
 WNDCLASSW wc{};wc.hInstance=instance;wc.lpfnWndProc=WindowProc;wc.lpszClassName=L"TFMEmbeddedAobClient";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_BTNFACE+1);
 if(!RegisterClassW(&wc))return 1;
 int width=GetSystemMetrics(SM_CXSCREEN)-80,height=GetSystemMetrics(SM_CYSCREEN)-80;if(width>1360)width=1360;if(height>900)height=900;
 HWND window=CreateWindowExW(0,wc.lpszClassName,L"Transformice Client | AoB",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,width,height,nullptr,nullptr,instance,nullptr);if(!window)return 2;
 ShowWindow(window,show);UpdateWindow(window);MSG message;while(GetMessageW(&message,nullptr,0,0)>0){if(!IsDialogMessageW(window,&message)){TranslateMessage(&message);DispatchMessageW(&message);}}return int(message.wParam);
}

extern "C" void WINAPI ClientEntry(){ExitProcess(wWinMain(GetModuleHandleW(nullptr),nullptr,GetCommandLineW(),SW_SHOWNORMAL));}
