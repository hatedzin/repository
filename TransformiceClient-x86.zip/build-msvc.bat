@rem Batch / build-msvc.bat / MSVC x86 + Windows SDK / Transformice Client
@echo off
cl /nologo /utf-8 /std:c++17 /O2 /EHsc /DUNICODE /D_UNICODE client.cpp /Fe:TransformiceClient.exe /link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib comdlg32.lib
if errorlevel 1 exit /b 1
