# Transformice Client x86

Cliente Win32 que abre o executavel standalone x86 selecionado pelo usuario e tenta embutir a janela do jogo, com menu flutuante sobre a area do jogo para os AoBs fornecidos nesta conversa.

## Uso

1. Extraia o ZIP e abra TransformiceClient.exe no Windows.
2. Clique em Abrir Transformice.exe e selecione o executavel x86 da sua instalacao, nao um instalador ou launcher de outra arquitetura.
3. O menu aparece automaticamente quando a janela do jogo e incorporada. Insert mostra/esconde; o botao - esconde; arraste o cabecalho para mover. Selecione uma entrada e clique em Procurar AoB.
4. Ativar exige uma unica correspondencia. Restaurar recupera os bytes originais capturados.
5. Fechar o cliente tenta restaurar os patches e desanexa a janela do jogo, mantendo o processo do jogo aberto.

A abertura do menu acompanha a incorporacao da janela inicial, nao um evento interno de login. Nao foi validada a identificacao da tela de login em um runtime real.

O jogo e o runtime Flash nao estao incluidos. Nenhum patch e aplicado automaticamente. Variantes que alteram o mesmo intervalo nao podem ficar ativas simultaneamente. As definicoes podem ser substituidas em TransformiceClient.ini, secoes Patch0 a Patch20, chaves Name, Aob e On. A entrada numerica Rato leve usa o double exato fornecido no fonte.

## Estado da verificacao

- Executavel compilado e formato Windows GUI PE32/i386 conferido.
- Testes do parser, curingas, limites, unicidade e busca entre blocos passaram com ASan/UBSan. LeakSanitizer foi desativado por incompatibilidade do ambiente.
- Interface no Windows, incorporacao da janela e efeitos no jogo NAO foram testados.
- Os AoBs foram fornecidos pelo usuario; nao estao confirmados para a build atual de 2026. Encontrar um padrao nao valida as instrucoes de substituicao nem o efeito anunciado.
- Nao ha bypass de anticheat. Requer Windows com Universal CRT e APIs de Windows 10 utilizadas no fonte.

## Compilacao do fonte

Use o x86 Native Tools Command Prompt do Visual Studio com Windows SDK e execute build-msvc.bat. O binario incluido foi produzido com Zig/Clang, sem incluir o runtime de inicializacao do MSVC. O fonte incluido pode usar a inicializacao padrao do MSVC.

## SHA-256 do executavel incluido

1ffe741ee2a2db4d95bd5c518feb50b49682baa25fd8c37460c5092adde4a0cb
