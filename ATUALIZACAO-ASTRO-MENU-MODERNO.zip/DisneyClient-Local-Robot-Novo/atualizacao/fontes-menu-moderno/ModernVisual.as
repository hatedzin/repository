package disney {
 import flash.display.*;import flash.events.*;import flash.text.*;import flash.filters.DropShadowFilter;import flash.geom.Rectangle;import flash.geom.Point;import flash.utils.Dictionary;import flash.utils.getTimer;
 public class ModernVisual {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var panel:Sprite;private var botDone:Dictionary=new Dictionary(true);private var title:TextField;private var last:int=-1000;private var tab:String="";
  private var viewport:Sprite;private var rail:Sprite;private var thumb:Sprite;private var scrollMax:Number=0;private var scrollHeld:Boolean=false;private var surfaceOpacity:Number=1;
  private var opacityHeld:Boolean=false;private var opacityTrack:Sprite;private var opacityKnob:Sprite;private var opacityLabel:TextField;
  public function ModernVisual(value:MovieClip){root=value;}
  public static function attach(value:MovieClip):void{if(!value || !value.stage || instances[value])return;LocalServerLog.attach(value);MusicPlayer.attach(value);FollowAutoBest.attach(value);FlyController.attach(value);var view:ModernVisual=new ModernVisual(value);instances[value]=view;try{view.update();}catch(initialError:Error){}value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{try{if(getTimer()-view.last>=150 || view.currentTab()!=view.tab)view.update();else view.chrome();}catch(renderError:Error){}},false,-10000);value.stage.addEventListener(Event.RESIZE,function(e:Event):void{try{view.fit(false);}catch(resizeError:Error){}});value.stage.addEventListener(MouseEvent.MOUSE_WHEEL,view.wheel,true,150000);}
  private function currentTab():String{var ui:Object=root["Interface"];return ui ? String(ui["last_tab"]) : "";}
  private function field(text:String,size:int,color:uint):TextField{var t:TextField=new TextField();t.defaultTextFormat=new TextFormat("Segoe UI",size,color,true);t.text=text;t.selectable=false;t.mouseEnabled=false;return t;}
  private function top(node:DisplayObject,parent:DisplayObjectContainer):DisplayObject{if(!node)return null;var n:int=0;while(node.parent && node.parent!==parent && n++<20)node=node.parent;return node.parent===parent ? node : null;}
  private function layoutBot(ui:Object):void{
   var bot:DisplayObjectContainer=ui["bot_ui"] as DisplayObjectContainer;if(!bot || botDone[bot])return;
   var auto:DisplayObject=top(ui["auto_play_check_box"] as DisplayObject,bot);var stop:DisplayObject=top(ui["stop_play_check_box"] as DisplayObject,bot);var status:DisplayObject=top(ui["status_field"] as DisplayObject,bot);var buttons:DisplayObject=top(ui["rec_button"] as DisplayObject,bot);var maps:DisplayObject=top(ui["ls_maps_button"] as DisplayObject,bot);
   var parts:Array=[auto,stop,status,buttons,maps];var seen:Dictionary=new Dictionary(true);for each(var node:DisplayObject in parts){if(!node || seen[node])return;seen[node]=true;}
   bot.scrollRect=null;bot.mask=null;var options:DisplayObject=ui["options_ui"] as DisplayObject;if(options)options.scrollRect=null;
   var body:Sprite=new Sprite();body.name="astroRobotContent";
   while(bot.numChildren)bot.removeChildAt(0);
   var ys:Array=[0,32,68,124,160];for(var n:int=0;n<parts.length;n++){node=parts[n];node.x=0;node.y=ys[n];body.addChild(node);}
   var text:TextField=ui["status_field"] as TextField;if(text){text.width=512;text.height=44;text.wordWrap=true;text.multiline=true;text.background=true;text.backgroundColor=0x17191F;}
   bot.addChild(body);botDone[bot]=true;
   var preview:DisplayObject=ui["preview_button"] as DisplayObject;if(preview){preview.visible=false;if(preview is InteractiveObject)InteractiveObject(preview).mouseEnabled=false;}
  }
  private function textStyle(node:DisplayObject,depth:int=0):void{
   if(depth>12 || node.name=="astroSkinPreviewArt")return;
   if(node is TextField){var t:TextField=node as TextField;var f:TextFormat=t.getTextFormat();f.font="Segoe UI";if(Number(f.size)<11)f.size=11;f.color=t.type==TextFieldType.INPUT ? 0xF2F3F6 : 0xD6D8E0;t.embedFonts=false;t.defaultTextFormat=f;t.setTextFormat(f);
    if(t.type==TextFieldType.INPUT){t.background=true;t.backgroundColor=0x111318;t.border=true;t.borderColor=0x3D404B;}
    else{if(t.text=="DISNEY")t.text="ASTRO";if(t.text=="Bot")t.text="Robot";}
   }
   if(node is DisplayObjectContainer){var c:DisplayObjectContainer=node as DisplayObjectContainer;for(var i:int=0;i<c.numChildren;i++)textStyle(c.getChildAt(i),depth+1);}
  }
  private function drawPanel():void{
   var g:Graphics=panel.graphics;g.clear();g.lineStyle(1,0x363943);g.beginFill(0x14161C,surfaceOpacity);g.drawRoundRect(0,0,760,430,16);g.endFill();g.lineStyle();g.beginFill(0x101216,surfaceOpacity);g.drawRoundRect(1,1,758,62,16);g.drawRect(1,32,758,30);g.drawRect(1,63,171,334);g.endFill();g.lineStyle(1,0x2D3039);g.moveTo(1,62);g.lineTo(759,62);g.moveTo(173,62);g.lineTo(173,398);g.moveTo(18,398);g.lineTo(742,398);g.lineStyle();
   g.beginFill(0xEF626C);g.drawRoundRect(21,21,4,22,3);g.drawRoundRect(29,17,4,26,3);g.endFill();g.lineStyle(1,0x2E313A);g.beginFill(0x1B1D24,surfaceOpacity);g.drawRoundRect(187,119,555,268,10);g.endFill();g.lineStyle(1,0x32363D);g.beginFill(0x191E23);g.drawRoundRect(303,20,138,24,12);g.endFill();g.lineStyle();g.beginFill(0x74C7A3);g.drawCircle(315,32,3);g.endFill();
  }
  private function paintNav(button:Sprite,id:String,ui:Object,hover:Boolean=false):void{
   var active:Boolean=String(ui["last_tab"])==id;var g:Graphics=button.graphics;g.clear();g.beginFill(active ? 0x352128 : hover ? 0x24262E : 0x101216);g.drawRoundRect(0,0,142,40,8);g.endFill();if(active){g.beginFill(0xF16A72);g.drawRoundRect(0,12,3,16,3);g.endFill();}
   var color:uint=active ? 0xF3868D : 0xA5A9B5;g.lineStyle(1.4,color);var x:Number=17;var y:Number=12;
   if(id=="general"){g.drawCircle(x+6,y+4,3);g.moveTo(x,y+16);g.curveTo(x,y+9,x+6,y+9);g.curveTo(x+12,y+9,x+12,y+16);}
   else if(id=="farm"){g.drawRoundRect(x,y+2,13,13,3);g.moveTo(x+4,y+2);g.lineTo(x+4,y+15);g.moveTo(x+8,y+2);g.lineTo(x+8,y+15);}
   else if(id=="bot"){g.drawRoundRect(x,y+3,14,11,3);g.moveTo(x+7,y);g.lineTo(x+7,y+3);g.drawCircle(x+4,y+8,0.8);g.drawCircle(x+10,y+8,0.8);g.moveTo(x+4,y+12);g.lineTo(x+10,y+12);}
   else if(id=="follow"){g.drawCircle(x+3,y+4,3);g.drawCircle(x+11,y+4,3);g.moveTo(x-1,y+15);g.curveTo(x-1,y+9,x+4,y+9);g.moveTo(x+7,y+9);g.curveTo(x+15,y+8,x+15,y+15);}
   else if(id=="keyboard"){g.drawRoundRect(x-1,y+2,16,12,3);g.moveTo(x+2,y+6);g.lineTo(x+12,y+6);g.moveTo(x+3,y+10);g.lineTo(x+11,y+10);}
   else{g.drawCircle(x+7,y+8,6);g.drawCircle(x+7,y+8,2);g.moveTo(x+7,y-1);g.lineTo(x+7,y+2);g.moveTo(x+7,y+14);g.lineTo(x+7,y+17);g.moveTo(x-2,y+8);g.lineTo(x+1,y+8);g.moveTo(x+13,y+8);g.lineTo(x+16,y+8);}
   g.lineStyle();var t:TextField=button.getChildAt(0) as TextField;if(t){if(id=="bot")t.text="Robot";t.x=41;t.y=10;t.width=96;var f:TextFormat=new TextFormat("Segoe UI",13,active ? 0xFFE8EA : 0xB4B7C2,active);t.defaultTextFormat=f;t.setTextFormat(f);}
  }
  private function setupPanel(ui:Object):void{
   panel.filters=[new DropShadowFilter(10,90,0,0.3,20,20,1,1)];surfaceOpacity=1;try{var saved:Number=Number(root["tfmdisney"].data.astroModernSurface);if(isFinite(saved) && saved>=0.9 && saved<=1)surfaceOpacity=saved;}catch(ignored:Error){}
   var old:DisplayObject=panel.getChildByName("astroOpacity");if(old && old.parent)old.parent.removeChild(old);buildOpacity();drawPanel();
   for(var i:int=0;i<panel.numChildren;i++){var node:DisplayObject=panel.getChildAt(i);var t:TextField=node as TextField;if(t){if(t.text=="ASTRO"){t.x=46;t.y=14;t.width=190;t.height=34;var f:TextFormat=new TextFormat("Segoe UI",22,0xF2F3F6,true);t.defaultTextFormat=f;t.setTextFormat(f);}else if(t.text=="CENTRAL DO CLIENTE" || t.text=="MODULOS" || t.text=="ROLE PARA VER MAIS" || t.text=="ARRASTE O TOPO")t.visible=false;}
    var nav:Sprite=node as Sprite;if(nav && nav.x==16 && nav.numChildren && nav.getChildAt(0) is TextField)bindNav(nav,ui);
   }
   viewport=ui["options_ui"] ? ui["options_ui"].parent as Sprite : null;
   rail=new Sprite();rail.name="astroPanelScroll";rail.x=730;rail.y=127;rail.graphics.beginFill(0,0);rail.graphics.drawRect(0,0,13,258);rail.graphics.endFill();rail.graphics.beginFill(0x30333D);rail.graphics.drawRoundRect(5,0,3,258,3);rail.graphics.endFill();panel.addChild(rail);thumb=new Sprite();thumb.name="astroPanelScrollThumb";rail.addChild(thumb);rail.buttonMode=true;rail.addEventListener(MouseEvent.MOUSE_DOWN,startScroll);
   var close:Sprite;for(i=0;i<panel.numChildren;i++){var s:Sprite=panel.getChildAt(i) as Sprite;if(s && s.x==710 && s.y==16){close=s;break;}}
   if(close){close.graphics.clear();close.graphics.lineStyle(1,0x3A3D47);close.graphics.beginFill(0x22252D);close.graphics.drawRoundRect(0,0,30,30,8);close.graphics.endFill();}
  }
  private function buildOpacity():void{
   var holder:Sprite=new Sprite();holder.name="astroOpacity";holder.x=512;holder.y=14;panel.addChild(holder);opacityLabel=field("",10,0xA7ABB6);opacityLabel.width=145;opacityLabel.height=17;holder.addChild(opacityLabel);opacityTrack=new Sprite();opacityTrack.name="astroOpacityTrack";opacityTrack.y=23;opacityTrack.graphics.lineStyle(3,0x383B46);opacityTrack.graphics.moveTo(0,3);opacityTrack.graphics.lineTo(128,3);opacityTrack.graphics.lineStyle();opacityTrack.graphics.beginFill(0,0);opacityTrack.graphics.drawRect(-4,-8,136,23);opacityTrack.graphics.endFill();holder.addChild(opacityTrack);opacityKnob=new Sprite();opacityKnob.mouseEnabled=false;opacityKnob.graphics.beginFill(0xF16A72);opacityKnob.graphics.drawCircle(0,3,5);opacityKnob.graphics.endFill();opacityTrack.addChild(opacityKnob);paintOpacity();opacityTrack.addEventListener(MouseEvent.MOUSE_DOWN,function(e:MouseEvent):void{opacityHeld=true;moveOpacity();root.stage.addEventListener(MouseEvent.MOUSE_MOVE,moveOpacity);root.stage.addEventListener(MouseEvent.MOUSE_UP,stopOpacity);root.stage.addEventListener(Event.DEACTIVATE,stopOpacity);e.stopImmediatePropagation();});
  }
  private function paintOpacity():void{if(opacityKnob)opacityKnob.x=(surfaceOpacity-0.9)/0.1*128;if(opacityLabel)opacityLabel.text="Fundo  "+Math.round(surfaceOpacity*100)+"%";}
  public function setSurface(value:Number):void{if(!isFinite(value))return;surfaceOpacity=Math.max(0.9,Math.min(1,value));paintOpacity();if(panel){panel.alpha=1;drawPanel();}}
  private function moveOpacity(e:MouseEvent=null):void{if(opacityHeld)setSurface(0.9+Math.max(0,Math.min(128,opacityTrack.mouseX))/128*0.1);if(e)e.stopImmediatePropagation();}
  private function stopOpacity(e:Event):void{opacityHeld=false;root.stage.removeEventListener(MouseEvent.MOUSE_MOVE,moveOpacity);root.stage.removeEventListener(MouseEvent.MOUSE_UP,stopOpacity);root.stage.removeEventListener(Event.DEACTIVATE,stopOpacity);try{root["tfmdisney"].data.astroModernSurface=surfaceOpacity;root["tfmdisney"].flush();}catch(ignored:Error){}}
  private function startScroll(e:MouseEvent):void{scrollHeld=true;dragScroll(e);root.stage.addEventListener(MouseEvent.MOUSE_MOVE,dragScroll);root.stage.addEventListener(MouseEvent.MOUSE_UP,stopScroll);root.stage.addEventListener(Event.DEACTIVATE,stopScroll);e.stopImmediatePropagation();}
  private function dragScroll(e:MouseEvent):void{if(!scrollHeld || !thumb || !rail)return;var travel:Number=258-thumb.height;var ratio:Number=travel>0 ? Math.max(0,Math.min(1,(rail.mouseY-thumb.height/2)/travel)) : 0;setScroll(ratio*scrollMax);e.stopImmediatePropagation();e.updateAfterEvent();}
  private function stopScroll(e:Event):void{scrollHeld=false;root.stage.removeEventListener(MouseEvent.MOUSE_MOVE,dragScroll);root.stage.removeEventListener(MouseEvent.MOUSE_UP,stopScroll);root.stage.removeEventListener(Event.DEACTIVATE,stopScroll);}
  public function setScroll(value:Number):void{if(!viewport || !viewport.scrollRect)return;var y:Number=Math.max(0,Math.min(scrollMax,value));if(!WheelScrollFixV3.setPosition(root,viewport,y)){var rect:Rectangle=viewport.scrollRect;viewport.scrollRect=new Rectangle(0,y,rect.width,rect.height);}paintScroll();}
  private function paintScroll():void{if(!viewport || !viewport.scrollRect || !rail)return;var ui:Object=root["Interface"];var options:DisplayObject=ui["options_ui"] as DisplayObject;var height:Number=options ? options.getBounds(options).bottom : 0;scrollMax=Math.max(0,height-258+8);rail.visible=scrollMax>1;var size:Number=Math.max(26,258*258/Math.max(258,height));thumb.graphics.clear();thumb.graphics.beginFill(scrollHeld ? 0xF16A72 : 0x8A8F9D);thumb.graphics.drawRoundRect(3,0,7,size,6);thumb.graphics.endFill();thumb.y=scrollMax>0 ? Math.max(0,Math.min(1,viewport.scrollRect.y/scrollMax))*(258-size) : 0;}
  private function wheel(e:MouseEvent):void{if(!viewport || !viewport.stage || !panel || !panel.parent || !(e.target is DisplayObject))return;var node:DisplayObject=e.target as DisplayObject;var cursor:DisplayObject=node;while(cursor && cursor!==viewport){if(cursor.name=="astroPlayerList" || cursor.name=="sddsFixedDropdown")return;cursor=cursor.parent;}if(!viewport.contains(node))return;paintScroll();setScroll(viewport.scrollRect.y-e.delta*26);e.preventDefault();e.stopImmediatePropagation();}
  private function navId(text:String):String{var ids:Object={"Jogador":"general","Farm":"farm","Bot":"bot","Robot":"bot","Atalhos":"keyboard","Ajustes":"settings","Follow":"follow"};return String(ids[text] || "");}
  private function bindNav(nav:Sprite,ui:Object):void{nav.addEventListener(MouseEvent.MOUSE_OVER,function(e:MouseEvent):void{var t:TextField=nav.getChildAt(0) as TextField;paintNav(nav,navId(t.text),ui,true);},false,-100);nav.addEventListener(MouseEvent.MOUSE_OUT,function(e:MouseEvent):void{var t:TextField=nav.getChildAt(0) as TextField;paintNav(nav,navId(t.text),ui);},false,-100);}
  private function chrome():void{
   if(!panel || !panel.parent)return;panel.alpha=1;var ui:Object=root["Interface"];if(!ui)return;
   for(var i:int=0;i<panel.numChildren;i++){var node:DisplayObject=panel.getChildAt(i);var t:TextField=node as TextField;if(t){if(t.x==193 && t.y==105)t.visible=false;if(t.x==193 && t.y==76){if(t.text=="Bot")t.text="Robot";var f:TextFormat=new TextFormat("Segoe UI",22,0xF2F3F6,true);t.defaultTextFormat=f;t.setTextFormat(f);t.height=33;}}
    var nav:Sprite=node as Sprite;if(nav && nav.x==16 && nav.numChildren && nav.getChildAt(0) is TextField){var text:TextField=nav.getChildAt(0) as TextField;var id:String=navId(text.text);if(id!="")paintNav(nav,id,ui);}
   }
   if(viewport && viewport.scrollRect){viewport.y=126;var rect:Rectangle=viewport.scrollRect;if(rect.height!=258)viewport.scrollRect=new Rectangle(rect.x,rect.y,535,258);}paintScroll();
  }
  public function fit(center:Boolean):void{if(!panel || !root.stage)return;var factor:Number=Math.max(0.2,Math.min(1,(root.stage.stageWidth-24)/760,(root.stage.stageHeight-72)/430));panel.scaleX=factor;panel.scaleY=factor;if(center){panel.x=(root.stage.stageWidth-760*factor)/2;panel.y=Math.max(44,(root.stage.stageHeight-430*factor)/2);}panel.x=Math.max(8,Math.min(panel.x,root.stage.stageWidth-760*factor-8));panel.y=Math.max(44,Math.min(panel.y,root.stage.stageHeight-430*factor-8));if(title)title.x=Math.max(112,(root.stage.stageWidth-title.width)/2);}
  public function update():void{
   last=getTimer();if(!root.stage)return;
   if(!title){title=field("ASTRO MENU",15,0xCBD0DF);title.name="astroClientTitle";title.width=180;title.height=27;title.y=9;var fmt:TextFormat=title.getTextFormat();fmt.align="center";title.setTextFormat(fmt);root.stage.addChild(title);}title.x=Math.max(112,(root.stage.stageWidth-title.width)/2);
   var button:Sprite=root.stage.getChildByName("disneyMenuButton") as Sprite;if(button){button.graphics.clear();button.graphics.lineStyle(1,0x3B3E48);button.graphics.beginFill(0x171920);button.graphics.drawRoundRect(0,0,100,28,7);button.graphics.endFill();button.graphics.lineStyle(1.4,0xF16A72);for(var n:int=0;n<3;n++){button.graphics.moveTo(13,9+n*5);button.graphics.lineTo(23,9+n*5);}for(var k:int=0;k<button.numChildren;k++){var label:TextField=button.getChildAt(k) as TextField;if(label){label.text="Menu";label.x=29;label.y=3;label.width=64;var format:TextFormat=new TextFormat("Segoe UI",12,0xE7E9EF,true);label.defaultTextFormat=format;label.setTextFormat(format);}}}
   var ui:Object=root["Interface"];if(!ui)return;var next:Sprite=ui["menu_ui"] as Sprite;if(!next || !next.parent || !next.visible)return;
   if(panel!==next){panel=next;setupPanel(ui);fit(true);}tab=String(ui["last_tab"]);layoutBot(ui);textStyle(ui["options_ui"] as DisplayObject);chrome();
   var badge:TextField=panel.getChildByName("astroSessionBadge") as TextField;if(!badge){badge=field("",10,0xC7D7CE);badge.name="astroSessionBadge";badge.x=325;badge.y=23;badge.width=111;badge.height=20;panel.addChild(badge);}var keys:Object=root["Keys"];badge.text=keys && root["tfm"] && root["tfm"][keys.player] ? "CONECTADO" : "AGUARDANDO";
  }
 }
}
