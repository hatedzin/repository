"""Python 3.11 / training.py / local authenticated training data; no game packet bypass."""
import asyncio, hashlib, json, math, re, sqlite3, time, uuid, zlib
from pathlib import Path
from aiohttp import web
from .common import authorize
from .github_routes import validate_route

MAX_FRAMES=12000
ALLOWED_KEYS={32,37,38,39,40,65,68,83,87}
DEFAULTS={'theme':'neon','accent':'8e9fff','opacity':0.95,'ghost_alpha':0.35,'ghost_speed':1.0,'ghost':False,'scanner':False,'trail':False,'markers':False,'tracker':False,'hud':True,'records':True,'smart':False,'retry':False,'retry_command':'mort','menu_key':119,'macro_key':120,'stop_key':27,'menu_x':24,'menu_y':20,'track_names':[]}

def compact(value):return json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))
def finite(v,low,high):return type(v) in (int,float) and math.isfinite(v) and low<=v<=high
def map_id(code):
 if not isinstance(code,str) or not re.fullmatch(r'@[1-9][0-9]{0,9}',code):raise ValueError('Codigo de mapa invalido')
 return code
def object_id(value):
 if not isinstance(value,str) or not re.fullmatch(r'[a-f0-9]{32}',value):raise ValueError('Identificador invalido')
 return value
def clean_settings(value):
 if not isinstance(value,dict) or set(value)-set(DEFAULTS):raise ValueError('Configuracao desconhecida')
 out=dict(DEFAULTS);out.update(value)
 for key in ['ghost','scanner','trail','markers','tracker','hud','records','smart','retry']:
  if type(out[key]) is not bool:raise ValueError('Opcao deve ser booleana: '+key)
 if out['theme'] not in ('neon','rgb','red','dark'):raise ValueError('Tema invalido')
 if not isinstance(out['accent'],str) or not re.fullmatch(r'[a-fA-F0-9]{6}',out['accent']):raise ValueError('Cor hexadecimal invalida')
 for key,lo,hi in [('opacity',.35,1),('ghost_alpha',.05,.9),('ghost_speed',.25,4)]:
  if not finite(out[key],lo,hi):raise ValueError('Valor invalido: '+key)
 for key in ('menu_x','menu_y'):
  if not finite(out[key],0,4000):raise ValueError('Posicao de menu invalida')
 for key in ('menu_key','macro_key','stop_key'):
  if type(out[key]) is not int or not 1<=out[key]<=255:raise ValueError('Atalho invalido')
 if len({out[k] for k in ('menu_key','macro_key','stop_key')})!=3:raise ValueError('Atalhos devem ser diferentes')
 if not isinstance(out['track_names'],list) or len(out['track_names'])>16 or any(not isinstance(n,str) or len(n)>50 for n in out['track_names']):raise ValueError('Jogadores invalidos')
 if not isinstance(out['retry_command'],str) or not re.fullmatch(r'mort|(?:map|np) @[1-9][0-9]{0,9}',out['retry_command']):raise ValueError('Comando de treino nao permitido')
 return out

def validate_macro(value):
 if not isinstance(value,list) or not 1<=len(value)<=4000:raise ValueError('Macro deve ter entre 1 e 4000 eventos')
 previous=-1
 for e in value:
  if not isinstance(e,dict) or set(e)!={'t','key','down'} or type(e['key']) is not int or e['key'] not in ALLOWED_KEYS or type(e['down']) is not bool or not finite(e['t'],0,300000) or e['t']<previous:raise ValueError('Evento de macro invalido')
  previous=e['t']
 return value

def validate_frames(frames,duration):
 if not isinstance(frames,list) or len(frames)>MAX_FRAMES:raise ValueError('Historico de posicoes excede o limite')
 previous=-1
 for f in frames:
  if not isinstance(f,dict) or set(f)-{'t','x','y','vx','vy','air'} or not all(finite(f.get(k),-1000000,1000000) for k in ('x','y')) or not finite(f.get('t'),0,duration+1000) or f['t']<previous:raise ValueError('Posicao gravada invalida')
  for key in ('vx','vy'):
   if key in f and not finite(f[key],-10000,10000):raise ValueError('Velocidade invalida')
  if 'air' in f and type(f['air']) is not bool:raise ValueError('Estado de pulo invalido')
  previous=f['t']
 return frames

class TrainingStore:
 def __init__(self,root):self.root=Path(root);self.path=self.root/'data'/'training.sqlite';self.lock=asyncio.Lock();self.ready=False
 def connection(self):
  self.path.parent.mkdir(parents=True,exist_ok=True)
  db=sqlite3.connect(self.path,timeout=5);db.row_factory=sqlite3.Row;db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA foreign_keys=ON')
  db.executescript('''
  CREATE TABLE IF NOT EXISTS settings(uid INTEGER PRIMARY KEY,data TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS routes(id TEXT PRIMARY KEY,uid INTEGER NOT NULL,map TEXT NOT NULL,name TEXT NOT NULL,data TEXT NOT NULL,version INTEGER NOT NULL,updated REAL NOT NULL);
  CREATE INDEX IF NOT EXISTS route_owner ON routes(uid,map);
  CREATE TABLE IF NOT EXISTS backups(id INTEGER PRIMARY KEY,uid INTEGER NOT NULL,route_id TEXT NOT NULL,name TEXT NOT NULL,map TEXT NOT NULL,data TEXT NOT NULL,version INTEGER NOT NULL,created REAL NOT NULL);
  CREATE TABLE IF NOT EXISTS macros(id TEXT PRIMARY KEY,uid INTEGER NOT NULL,name TEXT NOT NULL,data TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS attempts(id TEXT PRIMARY KEY,uid INTEGER NOT NULL,map TEXT NOT NULL,route_id TEXT NOT NULL,version TEXT NOT NULL,duration INTEGER NOT NULL,result TEXT NOT NULL,created REAL NOT NULL,frames BLOB NOT NULL,summary TEXT NOT NULL);
  CREATE INDEX IF NOT EXISTS attempt_owner ON attempts(uid,map,created);
  CREATE TABLE IF NOT EXISTS failures(uid INTEGER NOT NULL,map TEXT NOT NULL,route_id TEXT NOT NULL,version TEXT NOT NULL,step INTEGER NOT NULL,reason TEXT NOT NULL,count INTEGER NOT NULL,last REAL NOT NULL,PRIMARY KEY(uid,map,route_id,version,step,reason));
  CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY,uid INTEGER NOT NULL,created REAL NOT NULL,event TEXT NOT NULL,map TEXT NOT NULL,message TEXT NOT NULL);
  ''');return db
 async def run(self,uid,op,data=None):
  async with self.lock:return await asyncio.to_thread(self.execute,int(uid),op,data or {})
 def execute(self,uid,op,value):
  db=self.connection()
  try:
   with db:return self.dispatch(db,uid,op,value)
  finally:db.close()
 def dispatch(self,db,uid,op,v):
  if op=='settings':
   row=db.execute('SELECT data FROM settings WHERE uid=?',(uid,)).fetchone();return clean_settings(json.loads(row['data'])) if row else dict(DEFAULTS)
  if op=='settings_save':
   data=clean_settings(v.get('settings'));db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(uid,compact(data)));return data
  if op=='routes':
   args=[uid];query='SELECT id,map,name,version,updated FROM routes WHERE uid=?'
   if v.get('map'):query+=' AND map=?';args.append(map_id(v['map']))
   rows=[dict(r) for r in db.execute(query+' ORDER BY updated DESC LIMIT 512',args)]
   for row in rows:
    stats=db.execute("SELECT count(*) total,sum(result='won') wins FROM attempts WHERE uid=? AND route_id=? AND version=? AND result IN ('won','dead','failed')",(uid,row['id'],str(row['version']))).fetchone();row['tests']=stats['total'];row['wins']=stats['wins'] or 0;row['success_rate']=row['wins']/row['tests'] if row['tests'] else None
   return rows
  if op in ('route','route_delete','backups','restore'):
   rid=object_id(v.get('id'));row=db.execute('SELECT * FROM routes WHERE uid=? AND id=?',(uid,rid)).fetchone()
   if not row:raise KeyError('Rota nao encontrada')
   if op=='route':out=dict(row);out['steps']=json.loads(out.pop('data'));out.pop('uid');return out
   if op=='backups':return [dict(r) for r in db.execute('SELECT id,version,created FROM backups WHERE uid=? AND route_id=? ORDER BY id DESC LIMIT 20',(uid,rid))]
   self.backup(db,uid,row)
   if op=='route_delete':db.execute('DELETE FROM routes WHERE uid=? AND id=?',(uid,rid));return {'deleted':True}
   backup=db.execute('SELECT * FROM backups WHERE uid=? AND route_id=? AND id=?',(uid,rid,int(v.get('backup',0)))).fetchone()
   if not backup:raise KeyError('Backup nao encontrado')
   db.execute('UPDATE routes SET name=?,map=?,data=?,version=version+1,updated=? WHERE uid=? AND id=?',(backup['name'],backup['map'],backup['data'],time.time(),uid,rid));return self.dispatch(db,uid,'route',{'id':rid})
  if op=='route_save':
   code=map_id(v.get('map'));name=v.get('name');steps=validate_route(v.get('steps'))
   if not isinstance(name,str) or not 1<=len(name.strip())<=80:raise ValueError('Nome de rota invalido')
   rid=v.get('id') or uuid.uuid4().hex;object_id(rid);row=db.execute('SELECT * FROM routes WHERE uid=? AND id=?',(uid,rid)).fetchone()
   if row:
    if v.get('version')!=row['version']:raise RuntimeError('A rota foi alterada; recarregue antes de salvar')
    self.backup(db,uid,row);db.execute('UPDATE routes SET name=?,map=?,data=?,version=version+1,updated=? WHERE uid=? AND id=?',(name.strip(),code,compact(steps),time.time(),uid,rid))
   else:
    if db.execute('SELECT count(*) FROM routes WHERE uid=?',(uid,)).fetchone()[0]>=512:raise ValueError('Limite de 512 rotas pessoais')
    db.execute('INSERT INTO routes VALUES(?,?,?,?,?,?,?)',(rid,uid,code,name.strip(),compact(steps),1,time.time()))
   return self.dispatch(db,uid,'route',{'id':rid})
  if op=='compare':
   a=self.dispatch(db,uid,'route',{'id':v.get('a')});b=self.dispatch(db,uid,'route',{'id':v.get('b')})
   differences=[i for i in range(max(len(a['steps']),len(b['steps']))) if i>=len(a['steps']) or i>=len(b['steps']) or a['steps'][i]!=b['steps'][i]]
   return {'same_map':a['map']==b['map'],'a_steps':len(a['steps']),'b_steps':len(b['steps']),'a_ms':sum(s[-1] for s in a['steps']),'b_ms':sum(s[-1] for s in b['steps']),'different_steps':differences[:200],'comparison':'por indice; nao e alinhamento geometrico'}
  if op in ('macros','macro','macro_save','macro_delete'):
   if op=='macros':return [dict(r) for r in db.execute('SELECT id,name FROM macros WHERE uid=? ORDER BY name',(uid,))]
   if op=='macro_save':
    name=v.get('name');events=validate_macro(v.get('events'))
    if not isinstance(name,str) or not 1<=len(name.strip())<=80:raise ValueError('Nome de macro invalido')
    mid=v.get('id') or uuid.uuid4().hex;object_id(mid)
    if not db.execute('SELECT id FROM macros WHERE uid=? AND id=?',(uid,mid)).fetchone() and db.execute('SELECT count(*) FROM macros WHERE uid=?',(uid,)).fetchone()[0]>=64:raise ValueError('Limite de macros')
    owner=db.execute('SELECT uid FROM macros WHERE id=?',(mid,)).fetchone()
    if owner and owner['uid']!=uid:raise RuntimeError('Identificador ja utilizado')
    db.execute('INSERT OR REPLACE INTO macros VALUES(?,?,?,?)',(mid,uid,name.strip(),compact(events)));return {'id':mid,'name':name.strip(),'events':events}
   mid=object_id(v.get('id'));row=db.execute('SELECT id,name,data FROM macros WHERE uid=? AND id=?',(uid,mid)).fetchone()
   if not row:raise KeyError('Macro nao encontrada')
   if op=='macro_delete':db.execute('DELETE FROM macros WHERE uid=? AND id=?',(uid,mid));return {'deleted':True}
   return {'id':mid,'name':row['name'],'events':json.loads(row['data'])}
  if op=='attempt':
   code=map_id(v.get('map'));duration=v.get('duration');result=v.get('result');rid=v.get('route_id','');version=str(v.get('version',''))[:80]
   if not finite(duration,0,600000) or type(duration) is not int or result not in ('won','dead','round_end','stopped','failed'):raise ValueError('Tentativa invalida')
   if not isinstance(rid,str) or len(rid)>80:raise ValueError('Rota invalida')
   frames=validate_frames(v.get('frames',[]),duration);summary=v.get('summary',{})
   if not isinstance(summary,dict) or len(compact(summary))>4096:raise ValueError('Resumo invalido')
   aid=v.get('id') or uuid.uuid4().hex;object_id(aid)
   inserted=db.execute('INSERT OR IGNORE INTO attempts VALUES(?,?,?,?,?,?,?,?,?,?)',(aid,uid,code,rid,version,duration,result,time.time(),zlib.compress(compact(frames).encode()),compact(summary)))
   if inserted.rowcount==0:return {'id':aid,'stats':self.stats(db,uid,code),'best':self.best(db,uid,code,False)}
   if result=='failed':
    step=summary.get('step',0);reason=str(summary.get('reason','falha'))[:160]
    if type(step) is not int or not 0<=step<=100000:raise ValueError('Etapa invalida')
    db.execute('INSERT INTO failures VALUES(?,?,?,?,?,?,1,?) ON CONFLICT(uid,map,route_id,version,step,reason) DO UPDATE SET count=count+1,last=excluded.last',(uid,code,rid,version,step,reason,time.time()))
   db.execute('DELETE FROM failures WHERE uid=? AND rowid NOT IN (SELECT rowid FROM failures WHERE uid=? ORDER BY last DESC LIMIT 2000)',(uid,uid))
   # Retain best wins for up to 128 maps, plus recent attempts; bounded local history.
   best_ids=[r[0] for r in db.execute("SELECT a.id FROM attempts a WHERE uid=? AND result='won' AND a.id=(SELECT b.id FROM attempts b WHERE b.uid=a.uid AND b.map=a.map AND b.result='won' ORDER BY b.duration,b.created LIMIT 1)",(uid,))]
   keep=[r[0] for r in db.execute('SELECT id FROM attempts WHERE uid=? ORDER BY created DESC LIMIT 400',(uid,))]+best_ids[:128]
   if keep:db.execute('DELETE FROM attempts WHERE uid=? AND id NOT IN ('+','.join('?' for _ in keep)+')',[uid]+keep)
   return {'id':aid,'stats':self.stats(db,uid,code),'best':self.best(db,uid,code,False)}
  if op in ('statistics','export'):
   code=map_id(v['map']) if v.get('map') else None
   return self.stats(db,uid,code,history=True)
  if op=='ghost':return self.best(db,uid,map_id(v.get('map')),True)
  if op=='best_route':
   code=map_id(v.get('map'));routes=self.dispatch(db,uid,'routes',{'map':code})
   if not routes:return None
   # Laplace smoothing avoids treating one lucky win as a proven perfect route.
   best=max(routes,key=lambda r:((r['wins']+1)/(r['tests']+2),r['tests'],r['updated']))
   data=self.dispatch(db,uid,'route',{'id':best['id']});data['selection']='taxa de sucesso suavizada, testes e atualizacao';return data
  if op=='logs':return [dict(r) for r in db.execute('SELECT created,event,map,message FROM logs WHERE uid=? ORDER BY id DESC LIMIT 200',(uid,))]
  if op=='log':
   event=str(v.get('event','info'))[:40];code=str(v.get('map',''))[:20];message=str(v.get('message',''))[:1000]
   message=re.sub(r'github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9]+', '[redacted]',message);message=re.sub(r'(access_token|flash_token|token)=([^&\s]+)',r'\1=[redacted]',message,flags=re.I)
   db.execute('INSERT INTO logs(uid,created,event,map,message) VALUES(?,?,?,?,?)',(uid,time.time(),event,code,message));db.execute('DELETE FROM logs WHERE uid=? AND id NOT IN (SELECT id FROM logs WHERE uid=? ORDER BY id DESC LIMIT 1000)',(uid,uid))
   folder=self.root.parent/'logs-client';folder.mkdir(parents=True,exist_ok=True);path=folder/('training-'+str(uid)+'.jsonl')
   if path.exists() and path.stat().st_size>=2*1024*1024:path.replace(path.with_suffix('.previous.jsonl'))
   with path.open('a',encoding='utf-8') as stream:stream.write(compact({'created':time.time(),'event':event,'map':code,'message':message})+'\n')
   return {'saved':True}
  raise ValueError('Operacao desconhecida')
 def backup(self,db,uid,row):
  db.execute('INSERT INTO backups(uid,route_id,name,map,data,version,created) VALUES(?,?,?,?,?,?,?)',(uid,row['id'],row['name'],row['map'],row['data'],row['version'],time.time()));db.execute('DELETE FROM backups WHERE uid=? AND route_id=? AND id NOT IN (SELECT id FROM backups WHERE uid=? AND route_id=? ORDER BY id DESC LIMIT 20)',(uid,row['id'],uid,row['id']))
 def best(self,db,uid,code,frames):
  row=db.execute("SELECT * FROM attempts WHERE uid=? AND map=? AND result='won' ORDER BY duration,created LIMIT 1",(uid,code)).fetchone()
  if not row:return None
  out={k:row[k] for k in ('id','map','duration','route_id','version')}
  out['summary']=json.loads(row['summary'])
  if frames:out['frames']=json.loads(zlib.decompress(row['frames']))
  return out
 def stats(self,db,uid,code,history=False):
  condition='uid=?'+(' AND map=?' if code else '');args=[uid]+([code] if code else [])
  row=db.execute("SELECT count(*) attempts,sum(result='won') wins,sum(result IN ('dead','failed')) losses,min(CASE WHEN result='won' THEN duration END) best_ms FROM attempts WHERE "+condition,args).fetchone();out=dict(row);out['wins']=out['wins'] or 0;out['losses']=out['losses'] or 0
  out['failures']=[dict(r) for r in db.execute('SELECT map,route_id,version,step,reason,count FROM failures WHERE '+condition+' ORDER BY count DESC LIMIT 30',args)]
  if history:out['history']=[dict(r) for r in db.execute('SELECT id,map,duration,result,created,route_id,version,summary FROM attempts WHERE '+condition+' ORDER BY created DESC LIMIT 200',args)]
  return out

READ={'settings','routes','route','backups','compare','macros','macro','statistics','export','ghost','best_route','logs'}
WRITE={'settings_save','route_save','route_delete','restore','macro_save','macro_delete','attempt','log'}
class TrainingAPI(web.View):
 async def get(self):return await self.handle(False)
 async def post(self):return await self.handle(True)
 async def handle(self,write):
  user=await authorize(self.request,allow_cookie=True);uid=int(user['user_id']);op=self.request.query.get('op','')
  if op not in (WRITE if write else READ):raise web.HTTPBadRequest(reason='Operacao de treino invalida')
  try:
   if write:
    form=await self.request.post();text=form.get('data','{}')
    if not isinstance(text,str) or len(text)>3*1024*1024:raise ValueError('Dados excedem o limite')
    values=json.loads(text)
   else:values=dict(self.request.query)
   if not isinstance(values,dict):raise ValueError('Objeto JSON requerido')
   store=self.request.app.get('training_store')
   if store is None:store=TrainingStore(self.request.app['root']);self.request.app['training_store']=store
   result=await store.run(uid,op,values)
   return web.json_response({'ok':True,'result':result},headers={'Cache-Control':'no-store'})
  except KeyError:raise web.HTTPNotFound(reason='Registro nao encontrado') from None
  except sqlite3.IntegrityError:raise web.HTTPConflict(reason='Identificador ja utilizado') from None
  except RuntimeError as exc:raise web.HTTPConflict(reason=str(exc)) from None
  except (ValueError,TypeError,OverflowError,zlib.error) as exc:raise web.HTTPBadRequest(reason=str(exc)[:160]) from None
