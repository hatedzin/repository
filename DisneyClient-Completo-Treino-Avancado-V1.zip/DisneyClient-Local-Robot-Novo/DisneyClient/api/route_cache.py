"""Bounded route cache. Only validated data is persisted; stale data never blocks input."""
import asyncio
from collections import OrderedDict, Counter
import hashlib
import json
import logging
import os
from pathlib import Path
import re
import tempfile
import time
import zlib

log = logging.getLogger(__name__)
MAX_ROUTE = 262144


def payload(route):
    return json.dumps(route, ensure_ascii=False, allow_nan=False, separators=(',', ':'))


def envelope(code, route, revision='', source='local', stale=False):
    data = payload(route)
    digest = hashlib.sha256(data.encode()).hexdigest()
    return {'schema': 2, 'code': code, 'revision': revision or digest,
            'data': data, 'sha256': digest, 'checksum': '%08x' % (zlib.crc32(data.encode()) & 0xffffffff),
            'source': source, 'stale': bool(stale)}


class RouteCache:
    def __init__(self, remote, folder, validate, *, ttl=60, memory_limit=64, disk_limit=128, disk_bytes=32*1024*1024, clock=time.time, bundle_folder=None):
        self.remote, self.folder, self.validate = remote, Path(folder), validate
        self.bundle_folder=Path(bundle_folder) if bundle_folder else None
        self.bundle_index=None
        self.retired=set()
        self.ttl, self.memory_limit, self.disk_limit, self.disk_bytes, self.clock = ttl, memory_limit, disk_limit, disk_bytes, clock
        self.entries = OrderedDict()
        self.missing = {}
        self.retry = {}
        self.inflight = {}
        self.started = {}
        self.priorities = {}
        self.foreground = asyncio.Semaphore(2)
        self.background = asyncio.Semaphore(1)
        self.closed = False
        self.disk_lock=asyncio.Lock()
        self.epochs={}
        self.last_maps = OrderedDict()
        self.transitions = {}
        self.warmed = False
        self.stats = Counter()

    def path(self, code):
        if not re.fullmatch(r'@[1-9][0-9]*', code):
            raise ValueError('Codigo invalido')
        return self.folder / (code[1:] + '.json')

    def remember(self, code, entry):
        self.entries[code] = entry
        self.entries.move_to_end(code)
        while len(self.entries) > self.memory_limit:
            self.entries.popitem(last=False)

    def read_disk(self, code):
        try:
            path = self.path(code)
            if path.stat().st_size > MAX_ROUTE + 4096:
                return None
            entry = json.loads(path.read_bytes())
            self.validate(entry['route'])
            expected = hashlib.sha256(payload(entry['route']).encode()).hexdigest()
            if entry.get('code') != code or entry.get('digest') != expected:
                return None
            if not re.fullmatch(r'[a-f0-9]{40}|[a-f0-9]{64}', entry.get('revision', '')):
                return None
            if not isinstance(entry.get('checked'), (int, float)) or not 0 <= entry['checked'] <= self.clock()+60:
                return None
            if not isinstance(entry.get('etag',''),str) or len(entry.get('etag','')) > 256 or any(c in entry.get('etag','') for c in '\r\n'):
                return None
            return entry
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def read_bundle(self,code):
        if self.bundle_folder is None or code in self.retired or self.path(code).with_suffix('.gone').exists():return None
        try:
            if self.bundle_index is None:
                index_path=self.bundle_folder/'index.json'
                if index_path.stat().st_size>2*1024*1024:return None
                index=json.loads(index_path.read_bytes())
                if index.get('schema')!=1 or not isinstance(index.get('files'),dict):return None
                self.bundle_index=index['files']
            metadata=self.bundle_index.get(code)
            if not metadata:return None
            path=self.bundle_folder/(code[1:]+'.json')
            if path.stat().st_size>MAX_ROUTE:return None
            raw=path.read_bytes()
            if hashlib.sha256(raw).hexdigest()!=metadata.get('sha256'):return None
            route=self.validate(json.loads(raw))
            return {'code':code,'route':route,'digest':hashlib.sha256(payload(route).encode()).hexdigest(),'revision':metadata['sha256'],'etag':'','checked':0}
        except (OSError,ValueError,KeyError,TypeError):return None

    def write_disk(self, code, entry):
        self.folder.mkdir(parents=True, exist_ok=True)
        name = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=self.folder, prefix='.route-', delete=False) as stream:
                name = stream.name
                json.dump(entry, stream, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
            os.replace(name, self.path(code))
            name = None
            files = sorted((p for p in self.folder.glob('*.json') if re.fullmatch(r'[1-9][0-9]*\.json', p.name)), key=lambda p:p.stat().st_mtime, reverse=True)
            size = 0
            for i,p in enumerate(files):
                size += p.stat().st_size
                if i >= self.disk_limit or size > self.disk_bytes:
                    p.unlink(missing_ok=True)
        finally:
            if name:
                Path(name).unlink(missing_ok=True)

    async def seed(self, code, route, revision='', checked=None, etag='', authoritative=False):
        self.path(code)
        if authoritative:self.epochs[code]=self.epochs.get(code,0)+1
        self.validate(route)
        # Deep copy prevents a recording caller or a response from modifying cache contents.
        route = json.loads(payload(route))
        digest = hashlib.sha256(payload(route).encode()).hexdigest()
        revision = revision if isinstance(revision,str) and re.fullmatch(r'[a-f0-9]{40}|[a-f0-9]{64}',revision) else digest
        entry = {'code':code,'route':route,'digest':digest,'revision':revision,'etag':etag,'checked':self.clock() if checked is None else checked}
        self.remember(code, entry)
        self.missing.pop(code, None)
        self.retired.discard(code)
        try:
            await self.persist(code,entry)
        except OSError:
            self.stats['disk_write_error'] += 1
        return entry

    async def persist(self,code,entry):
        async with self.disk_lock:
            if self.entries.get(code) is entry:
                await asyncio.to_thread(self.write_disk,code,entry)
                await asyncio.to_thread(self.path(code).with_suffix('.gone').unlink,missing_ok=True)

    def schedule(self, code, foreground=False):
        if self.closed or self.missing.get(code,0)>self.clock():
            return None
        task = self.inflight.get(code)
        if task:
            if foreground and not self.priorities.get(code,False) and self.started.get(code) is not task:
                task.cancel()
                self.inflight.pop(code,None)
                self.stats['promoted']+=1
            else:
                self.stats['deduplicated'] += 1
                return task
        if self.clock() < self.retry.get(code,0):
            return None
        async def runner():
            try:return await self.refresh(code,foreground)
            finally:
                if self.started.get(code) is asyncio.current_task():self.started.pop(code,None)
        task = asyncio.create_task(runner())
        self.inflight[code] = task
        self.priorities[code] = foreground
        def finished(completed):
            if self.inflight.get(code) is completed:
                self.inflight.pop(code,None)
                self.priorities.pop(code,None)
            # Consume exception even if all requesting SWFs disconnected.
            if not completed.cancelled():
                completed.exception()
        task.add_done_callback(finished)
        return task

    async def fetch(self,code,etag):
        async with asyncio.timeout(22):
            result=await self.remote.read_versioned(code,etag)
            if result is None:
                try:legacy,_=await self.remote.read()
                except Exception as exc:
                    if getattr(exc,'status',None)!=404:raise
                    legacy={}
                if code in legacy:result={'route':legacy[code]}
            return result

    async def refresh(self, code, foreground=False):
        async with self.foreground if foreground else self.background:
            self.started[code]=asyncio.current_task()
            epoch=self.epochs.get(code,0)
            previous = self.entries.get(code)
            if previous is None and code not in self.retired and not self.path(code).with_suffix('.gone').exists():
                previous = await asyncio.to_thread(self.read_disk, code)
                if previous:
                    previous=self.entries.get(code,previous)
                    self.remember(code, previous)
            if epoch!=self.epochs.get(code,0):return self.entries.get(code)
            self.stats['checks'] += 1
            try:
                result = await self.fetch(code,previous.get('etag','') if previous else '')
                if epoch!=self.epochs.get(code,0):return self.entries.get(code)
                if result is None:
                    async with self.disk_lock:
                        if epoch!=self.epochs.get(code,0):return self.entries.get(code)
                        self.entries.pop(code,None)
                        self.missing[code] = self.clock()+30
                        while len(self.missing)>256:self.missing.pop(next(iter(self.missing)))
                        bundled=bool(self.bundle_folder and (self.bundle_folder/(code[1:]+'.json')).exists())
                        if previous or bundled:self.retired.add(code)
                        try:
                            await asyncio.to_thread(self.path(code).unlink,missing_ok=True)
                            if bundled:
                                self.folder.mkdir(parents=True,exist_ok=True)
                                await asyncio.to_thread(self.path(code).with_suffix('.gone').write_text,'removed',encoding='ascii')
                        except OSError:self.stats['disk_write_error']+=1
                    self.stats['missing'] += 1
                    return None
                if result.get('unchanged'):
                    if not previous:
                        raise ValueError('304 sem cache valido')
                    previous = dict(previous,checked=self.clock())
                    self.remember(code,previous)
                    try:await self.persist(code,previous)
                    except OSError:self.stats['disk_write_error']+=1
                    self.stats['not_modified']+=1
                    return previous
                entry = await self.seed(code,result['route'],result.get('revision',''),etag=result.get('etag',''))
                self.stats['downloads']+=1
                self.retry.pop(code,None)
                log.info('route_cache map=%s revision=%s source=github',code,entry['revision'][:12])
                return entry
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.warning('route_cache map=%s error=%s',code,type(exc).__name__)
                # Failure never overwrites a previously validated route.
                self.retry[code]=self.clock()+15
                while len(self.retry)>256:self.retry.pop(next(iter(self.retry)))
                self.stats['remote_error']+=1
                if previous:
                    return previous
                raise

    async def get(self, code):
        self.path(code)
        if self.missing.get(code,0)>self.clock():return None
        entry=self.entries.get(code)
        if entry is None and self.path(code).with_suffix('.gone').exists():self.retired.add(code)
        source='memory'
        if entry is None and code not in self.retired:
            entry=await asyncio.to_thread(self.read_disk,code)
            source='disk'
            if entry:
                entry=self.entries.get(code,entry)
                self.remember(code,entry)
        if entry is None:entry=self.entries.get(code)
        if entry is None:
            entry=await asyncio.to_thread(self.read_bundle,code)
            if entry:
                entry=self.entries.get(code,entry)
                self.remember(code,entry)
                source='bundle'
        if entry is None:entry=self.entries.get(code)
        if entry:
            self.entries.move_to_end(code)
            stale=self.clock()-entry['checked']>=self.ttl
            if stale:
                self.schedule(code)
            self.stats[source+'_hit']+=1
            return envelope(code,entry['route'],entry['revision'],source,stale)
        if self.missing.get(code,0)>self.clock():
            return None
        task=self.schedule(code,True)
        if task is None:
            raise ValueError('Consulta indisponivel; tente novamente em instantes')
        entry=await asyncio.shield(task)
        return envelope(code,entry['route'],entry['revision'],'github',False) if entry else None

    def observe(self, user, code):
        previous=self.last_maps.get(user)
        if previous and previous!=code:
            successors=self.transitions.setdefault(previous,Counter())
            successors[code]+=1
            if len(successors)>8:self.transitions[previous]=Counter(dict(successors.most_common(8)))
            if len(self.transitions)>128:
                self.transitions.pop(next(iter(self.transitions)))
        self.last_maps[user]=code
        self.last_maps.move_to_end(user)
        while len(self.last_maps)>128:self.last_maps.popitem(last=False)
        for candidate,_ in self.transitions.get(code,{}).most_common(2) if code in self.transitions else []:
            entry=self.entries.get(candidate)
            if entry is None or self.clock()-entry['checked']>=self.ttl:self.schedule(candidate)

    async def warm_recent(self):
        if self.warmed:return
        self.warmed=True
        def recent():
            if not self.folder.exists():return []
            return [p.stem for p in sorted(self.folder.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:4] if re.fullmatch(r'[1-9][0-9]*',p.stem)]
        for code in await asyncio.to_thread(recent):
            key='@'+code
            if key in self.entries:continue
            entry=await asyncio.to_thread(self.read_disk,key)
            if entry:
                entry=self.entries.get(key,entry)
                self.remember(key,entry)
                if self.clock()-entry['checked']>=self.ttl:self.schedule(key)

    async def close(self):
        self.closed=True
        tasks=list(self.inflight.values())
        for task in tasks:task.cancel()
        if tasks:await asyncio.gather(*tasks,return_exceptions=True)
        self.inflight.clear()
