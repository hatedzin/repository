package disney {

 // Route data only. This class does not control input, physics, packets, or UI.
 public class RobotRouteReviewed {
  private static const MAX_STEPS:int=100000;
  private static const MAX_XML_LENGTH:int=262144;

  private static function whole(value:*,low:Number,high:Number):Boolean {
   return value is Number && isFinite(Number(value)) && Number(value)==Math.floor(Number(value)) && Number(value)>=low && Number(value)<=high;
  }
  private static function walkPayload(value:Object):Object {
   if(!value || value is Array || !whole(value.x,-2147483648,4294967295) || !whole(value.y,-2147483648,4294967295) || !whole(value.vx,-32768,65535) || !whole(value.vy,-32768,65535) || !whole(value.frame,-128,255) || !(value.mr is Boolean) || !(value.ml is Boolean) || !(value.jump is Boolean))throw new Error("Movimento da rota invalido",2706);
   // Own the validated values so callers cannot alter the original decoded JSON.
   if("up" in value && !(value.up is Boolean))throw new Error("Tecla de pulo invalida",2706);
   var result:Object={x:Number(value.x),y:Number(value.y),vx:Number(value.vx),vy:Number(value.vy),frame:Number(value.frame),mr:Boolean(value.mr),ml:Boolean(value.ml),jump:Boolean(value.jump)};if("up" in value)result.up=Boolean(value.up);return result;
  }
  public static function decode(text:String):Array {
   if(text==null || text.length==0)throw new Error("Rota vazia",2701);
   var decoded:Object=com.adobe.serialization.json.JSON.decode(text);
   if(!(decoded is Array))throw new Error("A rota deve ser uma lista",2701);
   return validate(decoded as Array);
  }
  public static function validate(value:Array):Array {
   if(!value || value.length==0 || value.length>MAX_STEPS)throw new Error("Lista de passos invalida",2701);
   var result:Array=[];
   for(var index:int=0;index<value.length;index++) {
    var step:Array=value[index] as Array;
    if(!step || (step.length!=2 && step.length!=3))throw new Error("Formato de passo invalido",2702);
    var actionValue:* =step[step.length-2];
    if(!(actionValue is String))throw new Error("Acao da rota invalida",2704);
    var action:String=String(actionValue);
    if(["walk","cheese","hole","crouch","duck","emote"].indexOf(action)<0)throw new Error("Acao da rota desconhecida",2704);
    var delay:* =step[step.length-1];
    if(!whole(delay,0,3600000))throw new Error("Intervalo de passo invalido",2703);
    if(step.length==2 && action!="cheese" && action!="hole")throw new Error("Passo sem dados",2705);
    var payload:Object=step.length==3 ? step[0] : null;
    if(action=="walk")payload=walkPayload(payload);
    if((action=="crouch" || action=="duck") && !whole(payload,0,1))throw new Error("Estado de agachamento invalido",2705);
    result.push([payload,action,Number(delay)]);
   }
   return result;
  }
  private static function signed(value:Number,bits:int):Number {
   var boundary:Number=Math.pow(2,bits-1);
   return value>=boundary ? value-Math.pow(2,bits) : value;
  }
  public static function movement(payload:Object,mirror:Boolean=false,width:Number=800):Object {
   var p:Object=walkPayload(payload);
   if(mirror && (!isFinite(width) || width<=0))throw new Error("Largura do mapa invalida",2707);
   var x:Number=signed(Number(p.x),32)/100*30;
   var y:Number=signed(Number(p.y),32)/100*30;
   var vx:Number=signed(Number(p.vx),16)/100;
   var vy:Number=signed(Number(p.vy),16)/100;
   var result:Object={x:mirror ? width-x : x,y:y,vx:mirror ? -vx : vx,vy:vy,frame:int(signed(Number(p.frame),8)),mr:mirror ? Boolean(p.ml) : Boolean(p.mr),ml:mirror ? Boolean(p.mr) : Boolean(p.ml),jump:Boolean(p.jump)};if("up" in p)result.up=Boolean(p.up);return result;
  }
  private static function point(value:Object):Object {
   if(!value || !("x" in value) || !("y" in value) || !(value.x is Number) || !(value.y is Number))return null;
   var x:Number=Number(value.x);
   var y:Number=Number(value.y);
   return isFinite(x) && isFinite(y) ? {x:x,y:y} : null;
  }
  public static function target(xmlText:String,tag:String,mirror:Boolean,width:Number,x:Number,y:Number,fallback:Object):Object {
   // Fallback has already been converted to world coordinates by the caller.
   var best:Object=point(fallback);
   if((tag!="F" && tag!="T") || !isFinite(x) || !isFinite(y) || (mirror && (!isFinite(width) || width<=0)))return best;
   if(xmlText==null || xmlText.length==0 || xmlText.length>MAX_XML_LENGTH || /<!\s*(?:DOCTYPE|ENTITY)\b/i.test(xmlText))return best;
   try {
    var map:XML=new XML(xmlText);
    var nearest:Number=Number.POSITIVE_INFINITY;
    for each(var node:XML in map.descendants(tag)) {
     var attributeX:XMLList=node.attribute("X");
     var attributeY:XMLList=node.attribute("Y");
     if(attributeX.length()!=1 || attributeY.length()!=1)continue;
     var textX:String=String(attributeX).replace(/^\s+|\s+$/g,"");
     var textY:String=String(attributeY).replace(/^\s+|\s+$/g,"");
     if(textX.length==0 || textY.length==0)continue;
     var tx:Number=Number(textX);
     var ty:Number=Number(textY);
     if(!isFinite(tx) || !isFinite(ty))continue;
     if(mirror)tx=width-tx;
     var dx:Number=tx-x;
     var dy:Number=ty-y;
     var distance:Number=dx*dx+dy*dy;
     if(distance<nearest){nearest=distance;best={x:tx,y:ty};}
    }
   }catch(error:Error){}
   return best;
  }
 }
}
