package disney {
 import flash.display.MovieClip;import flash.display.Stage;import flash.events.*;import flash.utils.*;import flash.net.*;import flash.text.TextField;
 import com.hurlant.util.Base64;
 public class RouteRecorderReviewed {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var timer:Timer;private var incoming:Object;private var outgoing:Object;private var tracks:Object={};private var map:Object;private var round:String="";private var code:String="";private var reversed:Boolean=false;private var width:Number=800;
  private var started:int=0;private var completedCode:String="";private var completedData:String="";private var pending:URLLoader;private var nextUI:int=0;private var saveGeneration:uint=0;private var restoreTried:Boolean=false;private var restoring:URLLoader;
  private var recorderStage:Stage;private var keyListener:Function;private var blurListener:Function;private var frameListener:Function;private var waiting:Boolean=false;private var held:Object={};private var keyboardSeen:Boolean=false;private var restoreStarted:int=0;
  public var active:Boolean=false;public var message:String="Gravador: parado";public var completed:Array;
  public function RouteRecorderReviewed(r:MovieClip){root=r;keyListener=keyEdge;blurListener=blur;frameListener=function(e:Event):void{maintain();};timer=new Timer(10);timer.addEventListener(TimerEvent.TIMER,function(e:TimerEvent):void{tick(getTimer());});r.addEventListener(Event.ADDED_TO_STAGE,function(e:Event):void{if(e.target===r)listen();});if(r.stage)listen();r.addEventListener(Event.REMOVED_FROM_STAGE,function(e:Event):void{if(e.target===r){stop("documento fechado");unlisten();}});}
  public static function attach(r:MovieClip):void{if(!r || !r.stage || instances[r])return;var recorder:RouteRecorderReviewed=get(r);recorder.listen();}
  private function listen():void{recorderStage=root.stage;if(!recorderStage)return;recorderStage.addEventListener(KeyboardEvent.KEY_DOWN,keyListener,false,-1000,true);recorderStage.addEventListener(KeyboardEvent.KEY_UP,keyListener,false,-1000,true);recorderStage.addEventListener(Event.DEACTIVATE,blurListener,false,0,true);recorderStage.addEventListener(Event.ENTER_FRAME,frameListener,false,0,true);}
  private function unlisten():void{if(restoring){try{restoring.close();}catch(ignored:Error){}restoring=null;}if(!recorderStage)return;recorderStage.removeEventListener(KeyboardEvent.KEY_DOWN,keyListener);recorderStage.removeEventListener(KeyboardEvent.KEY_UP,keyListener);recorderStage.removeEventListener(Event.DEACTIVATE,blurListener);recorderStage.removeEventListener(Event.ENTER_FRAME,frameListener);recorderStage=null;}
  private function permitted():Boolean{var k:Object=keys();return !k || ((!k.move_class || k.move_class[k.move_free]) && (!k.timer_class || !k.timer_class[k.timer_prop]));}
  private function blur(e:Event):void{held={};if(active && keyboardSeen)captureLocal(getTimer(),true);}
  private function keyEdge(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root) || [37,38,39,40,65,68,83,87].indexOf(e.keyCode)<0)return;var text:TextField=root.stage.focus as TextField;if(text && text.type=="input" && e.type==KeyboardEvent.KEY_DOWN)return;var on:Boolean=e.type==KeyboardEvent.KEY_DOWN;if(Boolean(held[e.keyCode])==on)return;held[e.keyCode]=on;keyboardSeen=true;if(active)captureLocal(getTimer(),true);}
  private function maintain():void{var now:int=getTimer();if(restoring && now-restoreStarted>25000){try{restoring.close();}catch(ignored:Error){}restoring=null;}if(!root.stage || now<nextUI)return;nextUI=now+250;try{var k:Object=keys();var ui:Object=root["Interface"];if(k && ui && k.text_field2 && ui.auto_play_check_box){var label:Object=ui.auto_play_check_box[k.text_field2];if(label && "text" in label)label.text="Robot (cache automatico) [F2]";}}catch(ignored:Error){}if(!active && completed==null && !restoreTried)restorePending();button("rec_button",true);button("save_button",completed!=null && pending==null);}
  private function endpoint(method:String):String{var token:String="";if(root["tfmdisney"] && root["tfmdisney"].data)token=String(root["tfmdisney"].data.flash_token);return String(root["host_url"])+"github-routes?method="+method+"&access_token="+encodeURIComponent(String(root["access_token"]))+"&flash_token="+encodeURIComponent(token);}
  public function restorePending():void{
   if(restoreTried || restoring || completed || active)return;var access:* =root["access_token"];if(access==null || String(access)=="")return;
   restoreTried=true;var loader:URLLoader=new URLLoader();restoring=loader;restoreStarted=getTimer();
   var failed:Function=function(e:Event):void{if(restoring===loader)restoring=null;};
   loader.addEventListener(IOErrorEvent.IO_ERROR,failed);loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{if(restoring!==loader)return;restoring=null;if(active || completed)return;try{var data:Object=com.adobe.serialization.json.JSON.decode(String(loader.data));if(!data || !/^@[1-9][0-9]*$/.test(String(data.code)))return;var steps:Array=RobotRouteReviewed.validate(data.route as Array);completed=steps;completedCode=String(data.code);completedData=com.adobe.serialization.json.JSON.encode(steps);root["current_map_data"]=completedData;var recovered:Object={};recovered[completedCode]=steps;RobotControllerReviewed.get(root).setRoutes(recovered);button("save_button",true);say("rascunho "+completedCode+" recuperado; clique SAVE para publicar");}catch(ignored:Error){}});
   try{loader.load(new URLRequest(endpoint("draft")));}catch(e:Error){failed(new Event("error"));}
  }
  private function explainFailure():void{
   var expected:uint=saveGeneration;var loader:URLLoader=new URLLoader();loader.addEventListener(IOErrorEvent.IO_ERROR,function(e:Event):void{});loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,function(e:Event):void{});
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{if(pending || expected!=saveGeneration)return;try{var state:Object=com.adobe.serialization.json.JSON.decode(String(loader.data));var suffix:String=state.draft_saved ? " Rascunho salvo." : " Rota mantida.";
    if(!state.configured || state.reason=="missing_token")say("GitHub sem token: abra CONFIGURAR-GITHUB-ROTAS.bat."+suffix);
    else if(state.reason=="denied")say("GitHub recusou o token/permissao Contents."+suffix);
    else if(state.reason=="timeout")say("GitHub demorou; confira o JSON antes de repetir SAVE."+suffix);
    else if(state.reason=="disk")say("Nao foi possivel gravar o rascunho no disco. Rota mantida.");
    else say("GitHub indisponivel; tente SAVE novamente."+suffix);
   }catch(ignored:Error){}});try{loader.load(new URLRequest(endpoint("status")));}catch(ignored:Error){}
  }
  public static function get(r:MovieClip):RouteRecorderReviewed{if(!instances[r])instances[r]=new RouteRecorderReviewed(r);return instances[r] as RouteRecorderReviewed;}
  public static function toggleFrom(owner:Object):void{var r:MovieClip=owner["main_instance"] as MovieClip;if(r)get(r).toggle();}
  public static function saveFrom(owner:Object):void{var r:MovieClip=owner["main_instance"] as MovieClip;if(r)get(r).save();}
  private function keys():Object{return root["Keys"];}
  private function currentMap():Object{var k:Object=keys();return k && k.map_class ? k.map_class[k.map_instance] : null;}
  private function local():Object{var k:Object=keys();var g:Object=root["tfm"];return k && g ? g[k.player] : null;}
  private function name(p:Object):String{var k:Object=keys();return k.player_name && p && p[k.player_name]!=null ? String(p[k.player_name]) : "voce";}
  private function button(which:String,on:Boolean):void{try{var k:Object=keys();var ui:Object=root["Interface"];if(ui && ui[which] && k.set_button_state)ui[which][k.set_button_state](on);}catch(e:Error){}}
  private function say(s:String):void{message="Gravador: "+s;try{var ui:Object=root["Interface"];if(ui && ui.status_field)ui.status_field.text=message;}catch(e:Error){}}
  private function bind():Boolean{
   try{var k:Object=keys();var into:Object=k ? k.packet_handler_class : null;var out:Object=k ? k.socket_class : null;
    if(!into || !out || !("astroRoomObserverV1" in into) || !("astroMoveDelayV1" in out))return false;
    if(incoming!==into){var previous:Function=into["astroRoomObserverV1"] as Function;into["astroRoomObserverV1"]=function(b:ByteArray):void{if(!b)return;var cursor:uint=b.position;try{b.position=0;receive(b,getTimer());}catch(ignored:Error){}finally{b.position=cursor;}try{if(previous!=null)previous(b);}finally{b.position=cursor;}};incoming=into;}
    if(outgoing!==out){var prior:Function=out["astroMoveDelayV1"] as Function;out["astroMoveDelayV1"]=function(owner:Object,pkt:Object,priority:Boolean=false):Boolean{
     try{var bytes:ByteArray=pkt ? pkt[k.packet_out_bytes] as ByteArray : null;if(active && bytes && bytes.length>=2){var cursor:uint=bytes.position;try{bytes.position=0;if(bytes.readUnsignedByte()==4 && bytes.readUnsignedByte()==4)captureLocal(getTimer());}finally{bytes.position=cursor;}}}catch(ignored:Error){}
     return prior!=null ? prior(owner,pkt,priority) : false;
    };outgoing=out;}
    return true;
   }catch(e:Error){return false;}
  }
  public function toggle(now:int=-1):void{
   if(now<0)now=getTimer();if(restoring){try{restoring.close();}catch(ignored:Error){}restoring=null;}if(active){stop("gravacao interrompida; tentativa incompleta descartada");return;}
   var k:Object=keys();var p:Object=local();map=currentMap();var object:Object=map && k && k.bot_map_code_object ? map[k.bot_map_code_object] : null;var n:Number=object ? Number(object[k.bot_map_code_value]) : NaN;
   if(!p || !map || !isFinite(n) || n<=0 || n!=Math.floor(n)){say("aguardando rato e codigo do mapa");return;}
   if(!bind()){say("ponte nativa ausente; reinicie parser e Flash atualizados");return;}
   width=Number(k.map_class[k.bot_map_width]);if(!isFinite(width)||width<=0){say("largura do mapa indisponivel");return;}
   reversed=Boolean(map[k.obj_container][k.bot_reverse]);round="current_round_code" in root ? String(root["current_round_code"]) : "";code="@"+n.toFixed(0);tracks={};started=now;waiting=!permitted();
   // Existing /stalk selections remain supported. Without a selection, record self.
   var selected:Object=root["stalked_players"];var players:Object=root["tfm"][k.player_list];var selectedAny:Boolean=false;
   if(selected && players)for each(var other:Object in players){if(other && selected[name(other)]){add(other);selectedAny=true;}}
   if(!selectedAny)add(p);
   var found:Boolean=false;for(var id:String in tracks)found=true;if(!found){say("nenhum rato pronto para gravar");return;}
   root["auto_play"]=false;FollowControllerV13Shared.stopForRobot(root);RobotControllerReviewed.get(root).advance(now);
   // Keep the retired frame recorder off: only this recorder owns these samples.
   root["recording"]=false;active=true;timer.start();button("rec_button",true);button("save_button",completed!=null);
   tick(now);say("gravando "+code+"; conclua a toca para habilitar Salvar");
  }
  private function add(p:Object):void{var k:Object=keys();if(!p || !k.player_id || p[k.is_dead] || !p[k.player_physics] || !p[k.player_clip])return;var id:int=int(p[k.player_id]);tracks[String(id)]={id:id,player:p,name:name(p),steps:[],lastTime:started,last:null,down:false,cheese:Number(p[k.player_cheese])>0};}
  private function snapshot(p:Object):Object{
   var k:Object=keys();var body:Object=p ? p[k.player_physics] : null;if(!body || p[k.is_dead])return null;
   var x:Number=Number(p.x)/30*100;var y:Number=Number(p.y)/30*100;
   if(k.get_x_form && body[k.get_x_form] is Function){var transform:Object=body[k.get_x_form]();x=Number(transform.position[k.pos_x])*100;y=Number(transform.position[k.pos_y])*100;}
   var velocity:Object=k.get_linear_velocity && body[k.get_linear_velocity] is Function ? body[k.get_linear_velocity]() : k.physics_state ? body[k.physics_state] : null;
   if(!velocity)return null;var vx:Number=Number(velocity[k.pos_x ? k.pos_x : k.physics_state_vx])*100;var vy:Number=Number(velocity[k.pos_y ? k.pos_y : k.physics_state_vy])*100;
   if(!isFinite(x)||!isFinite(y)||!isFinite(vx)||!isFinite(vy))return null;
   var mr:Boolean=Boolean(p[k.player_moving_right]);var ml:Boolean=Boolean(p[k.player_moving_left]);
   if(reversed){x=width/30*100-x;vx=-vx;var swap:Boolean=mr;mr=ml;ml=swap;}
   var frame:Number=k.current_frame ? Number(p[k.current_frame]) : 0;if(!isFinite(frame))frame=0;
   return {x:int(x),y:int(y),vx:int(vx),vy:int(vy),frame:int(frame),mr:mr,ml:ml,jump:k.is_jumping ? Boolean(p[k.is_jumping]) : false};
  }
  private function append(t:Object,data:Object,action:String,now:int):void{if(t.steps.length>=1800){stop("limite da gravacao; tentativa incompleta descartada");return;}t.steps.push([data,action,Math.max(0,now-int(t.lastTime))]);t.lastTime=now;}
  private function capture(t:Object,now:int,force:Boolean=false):void{
   if(!active || !t || !permitted())return;var k:Object=keys();var current:Object=local();var list:Object=root["tfm"][k.player_list];if(current && int(current[k.player_id])==t.id)t.player=current;
   var s:Object=snapshot(t.player);if(!s)return;
   if(t.player===current){s.up=Boolean(held[38] || held[87]);if(keyboardSeen){s.ml=Boolean(held[37] || held[65]);s.mr=Boolean(held[39] || held[68]);if(reversed){var direction:Boolean=s.ml;s.ml=s.mr;s.mr=direction;}}}var prev:Object=t.last;
   if(force || !prev || s.ml!=prev.ml || s.mr!=prev.mr || s.jump!=prev.jump || s.up!=prev.up || s.jump && s.vy<=-450 && prev.vy-s.vy>100 || now-int(t.lastTime)>=100){append(t,s,"walk",now);t.last=s;}
   var down:Boolean=k.is_down ? Boolean(t.player[k.is_down]) : false;if(down!=t.down){append(t,down?1:0,"crouch",now);t.down=down;}
  }
  private function captureLocal(now:int,force:Boolean=false):void{var p:Object=local();var k:Object=keys();if(p && k.player_id)capture(tracks[String(int(p[k.player_id]))],now,force);}
  public function tick(now:int=-1):void{
   if(!active)return;if(now<0)now=getTimer();var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";
   if(!root.stage || currentMap()!==map || token!=round){stop("mapa/rodada mudou; tentativa incompleta descartada");return;}
   if(now-started>180000){stop("tempo limite de gravacao");return;}
   if(!permitted()){waiting=true;return;}if(waiting){waiting=false;started=now;for each(var waitingTrack:Object in tracks){waitingTrack.steps=[];waitingTrack.last=null;waitingTrack.lastTime=now;}}
   try{var k:Object=keys();var players:Object=root["tfm"][k.player_list];if(players)for each(var live:Object in players)if(live && tracks[String(int(live[k.player_id]))])tracks[String(int(live[k.player_id]))].player=live;for each(var t:Object in tracks)capture(t,now);}catch(e:Error){stop("nao foi possivel ler o movimento nativo #"+e.errorID);}
  }
  public function receive(b:ByteArray,now:int=-1):void{
   if(!active || !b || b.bytesAvailable<2)return;if(now<0)now=getTimer();var c:int=b.readUnsignedByte();var cc:int=b.readUnsignedByte();var id:int;var t:Object;
   if(c==5 && (cc==2 || cc==21)){stop("nova rodada/sala; tentativa incompleta descartada");return;}
   if(c==144 && cc==2){b.readUTF();if(b.bytesAvailable>=4 && tracks[String(b.readInt())])stop("rato renasceu; tentativa incompleta descartada");return;}
   if(c==144 && cc==6 && b.bytesAvailable>=5){id=b.readInt();var quantity:int=b.readByte();t=tracks[String(id)];if(t){if(quantity>0 && !t.cheese){append(t,0,"cheese",now);}t.cheese=quantity>0;}return;}
   if(c==8 && cc==6 && b.bytesAvailable>=5){b.readByte();id=b.readInt();t=tracks[String(id)];if(!t)return;if(!t.last){stop("movimento nativo indisponivel; tentativa descartada");return;}capture(t,now,true);if(!active)return;append(t,0,"hole",now);if(!active)return;
    var validated:Array=RobotRouteReviewed.validate(t.steps);var encoded:String=com.adobe.serialization.json.JSON.encode(validated);if(encoded.length>262144){stop("rota excede o tamanho permitido");return;}
    completed=validated;completedCode=code;completedData=encoded;root["current_map_data"]=encoded;var freshRoutes:Object={};freshRoutes[completedCode]=validated;RobotControllerReviewed.get(root).setRoutes(freshRoutes);active=false;timer.stop();button("save_button",true);say("rota concluida por "+t.name+" | "+code+"; clique Salvar");return;
   }
   if(c==1 && cc==1){var fields:Array=b.readUTF().split(String.fromCharCode(1));var header:String=String(fields[0]);if(header.length==2 && header.charCodeAt(0)==8 && header.charCodeAt(1)==5 && fields.length>1){id=int(fields[1]);delete tracks[String(id)];var any:Boolean=false;for(var key:String in tracks)any=true;if(!any)stop("rato morreu; tentativa incompleta descartada");}}
  }
  public function stop(reason:String):void{active=false;timer.stop();tracks={};root["recording"]=false;button("save_button",completed!=null);say(reason);}
  public function save():void{
   if(pending){say("salvamento em andamento");return;}if(!completed || completedCode=="" || completedData==""){say("conclua uma gravacao na toca antes de salvar");return;}
   saveGeneration++;var savedCode:String=completedCode;var savedData:String=completedData;var savedSteps:Array=RobotRouteReviewed.validate(completed);var status:int=0;var details:String="";var loader:URLLoader=new URLLoader();var deadline:Timer=new Timer(30000,1);pending=loader;button("save_button",false);say("publicando no GitHub "+savedCode);
   loader.addEventListener(HTTPStatusEvent.HTTP_STATUS,function(e:HTTPStatusEvent):void{status=e.status;});
   var failed:Function=function(e:Event):void{if(pending!==loader)return;deadline.stop();pending=null;button("save_button",true);say("falha ao salvar no GitHub (HTTP "+status+"). Rota mantida.");explainFailure();};
   loader.addEventListener(IOErrorEvent.IO_ERROR,failed);loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{if(pending!==loader)return;if(status!=204){failed(e);return;}deadline.stop();pending=null;var k:Object=keys();if(k){if(!k.maps)k.maps={};var existed:Boolean=k.maps[savedCode]!=null;k.maps[savedCode]=savedData;if(!existed && "maps_len" in k)k.maps_len++;}var routes:Object={};routes[savedCode]=savedSteps;if(completedCode!=savedCode || completedData==savedData)RobotControllerReviewed.get(root).installPublished(savedCode,savedSteps);button("save_button",completedData!=savedData);say("salvo "+savedCode+" no GitHub; reative o Robot no inicio da rota");});
   deadline.addEventListener(TimerEvent.TIMER_COMPLETE,function(e:TimerEvent):void{if(pending!==loader)return;try{loader.close();}catch(ignored:Error){}failed(new Event("timeout"));});
   try{var q:URLRequest=new URLRequest(String(root["host_url"])+"github-routes?access_token="+encodeURIComponent(String(root["access_token"]))+"&flash_token="+encodeURIComponent(String(root["tfmdisney"].data.flash_token))+"&method=save");var form:URLVariables=new URLVariables();form.code=savedCode;var bytes:ByteArray=new ByteArray();bytes.writeUTFBytes(savedData);bytes.compress("zlib");form.info=Base64.encodeByteArray(bytes);q.data=form;q.method=URLRequestMethod.POST;deadline.start();loader.load(q);}catch(e:Error){failed(new Event("error"));}
  }
 }
}
