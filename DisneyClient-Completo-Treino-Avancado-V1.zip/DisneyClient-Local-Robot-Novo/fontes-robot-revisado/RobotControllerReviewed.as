package disney {
 import flash.display.MovieClip;import flash.display.Stage;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.events.HTTPStatusEvent;import flash.events.SecurityErrorEvent;import flash.net.URLLoader;import flash.net.URLRequest;import flash.net.URLVariables;import flash.text.TextField;import flash.text.TextFormat;import flash.utils.ByteArray;import flash.utils.Dictionary;import flash.utils.getTimer;import flash.utils.Timer;import flash.events.TimerEvent;
 public class RobotControllerReviewed {
  private static var instances:Dictionary=new Dictionary(true);
  public var phase:String="off";public var message:String="Robot novo 6: desligado";
  public var diagnostics:Array=[];private var loggedPhase:String="";private var bootstrap:Boolean=false;private var requestStarted:int=0;private var stationary:int=0;private var progressX:Number=NaN;private var progressY:Number=NaN;private var recoveryCount:int=0;private var waitForRound:Boolean=false;private var roundLocked:Boolean=false;
  private var lifeStarted:int=0;private var pendingStart:int=-1;private var failedAttempt:Object;
  private var lastFrame:int=-1;private var frameWindow:int=-1;private var frameCount:int=0;private var fpsX10:int=0;private var frameGap:int=0;private var nextTiming:int=0;
  private var logLoader:URLLoader;private var logStarted:int=0;private var logWindow:int=0;private var logCount:int=0;
  private var routeStale:Object={};private var routeVersions:Object={};private var routeSources:Object={};private var routeChecks:Object={};private static var crcTable:Array;
  private var recorded:Object={};private var githubRoutes:Object={};private var githubChecked:Object={};private var scheduler:Timer;private var observedDispatcher:Object;
  private var stageHandlers:Array=[];private var attachedStage:Stage;
  private var root:MovieClip;private var input:RobotInputReviewed;private var hud:TextField;private var enabled:Boolean=false;private var focused:Boolean=true;private var manual:Boolean=false;
  private var map:Object;private var player:Object;private var lifeBody:Object;private var deathSeen:Boolean=false;private var code:String="";private var round:String="";private var localId:int=0;private var idKnown:Boolean=false;
  private var birthPending:Boolean=false;private var newRound:Boolean=false;private var terminal:Boolean=false;private var nativeWon:Boolean=false;private var nativeDead:Boolean=false;private var deathReason:String="";
  private var cache:Object={};private var order:Array=[];private var request:URLLoader;private var requestCode:String="";private var requestError:String="";
  private var route:Array;private var index:int=0;private var clock:Number=0;private var due:Number=0;private var lastNow:int=-1;private var blocked:Boolean=false;
  private var lastSample:Object;private var lastRecord:Object;private var crouched:Boolean=false;private var needsCheese:Boolean=false;private var cheeseKnown:Boolean=false;private var cheeseCount:int=0;
  private var goal:Object;private var goalElapsed:int=0;private var fault:String="";private var mirror:Boolean=false;private var width:Number=800;
  public function RobotControllerReviewed(value:MovieClip){root=value;input=new RobotInputReviewed(value);NativeMotion.get(value).observeWith(receive);}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var bot:RobotControllerReviewed=new RobotControllerReviewed(value);instances[value]=bot;bot.bootstrap=true;
   // The watchdog observes lifecycle only; input edges advance on ENTER_FRAME.
   bot.scheduler=new Timer(10);
   bot.scheduler.addEventListener(TimerEvent.TIMER,function(e:TimerEvent):void{if(value.stage)bot.advance(getTimer(),false);});
   bot.listenStage(Event.ENTER_FRAME,function(e:Event):void{if(value.stage)bot.advance(getTimer());});
   value.addEventListener(Event.REMOVED_FROM_STAGE,function(e:Event):void{if(e.target===value){bot.scheduler.stop();bot.input.release();bot.detachStage();}});
   value.addEventListener(Event.ADDED_TO_STAGE,function(e:Event):void{if(e.target===value){bot.lastNow=-1;bot.lastFrame=-1;bot.restoreStage();bot.scheduler.start();}});
   bot.scheduler.start();
   bot.listenStage(Event.ACTIVATE,function(e:Event):void{bot.focused=true;});bot.listenStage(Event.DEACTIVATE,function(e:Event):void{bot.focused=false;});
   var manualKey:Function=function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(value) || !value["auto_play"] || !value["auto_play_disable_on_move"])return;var text:TextField=value.stage.focus as TextField;if(text && text.type=="input")return;if([37,38,39,40,65,68,83,87].indexOf(e.keyCode)>=0)bot.pause();};bot.listenStage(KeyboardEvent.KEY_DOWN,manualKey,true,2200);bot.listenStage(KeyboardEvent.KEY_DOWN,manualKey,false,2200);
  }
  private function listenStage(type:String,callback:Function,capture:Boolean=false,priority:int=0):void{var item:Object={type:type,callback:callback,capture:capture,priority:priority};stageHandlers.push(item);attachedStage=root.stage;attachedStage.addEventListener(type,callback,capture,priority,true);}
  private function detachStage():void{cancelRequest();if(logLoader){try{logLoader.close();}catch(ignored:Error){}logLoader=null;}if(!attachedStage)return;for each(var item:Object in stageHandlers)attachedStage.removeEventListener(item.type,item.callback,item.capture);attachedStage=null;if(hud && hud.parent)hud.parent.removeChild(hud);hud=null;}
  private function restoreStage():void{attachedStage=root.stage;if(!attachedStage)return;for each(var item:Object in stageHandlers)attachedStage.addEventListener(item.type,item.callback,item.capture,item.priority,true);}
  public static function get(value:MovieClip):RobotControllerReviewed{attach(value);return instances[value] as RobotControllerReviewed;}
  public function get loadingRoute():Boolean{return request!=null;}
  public function trainingSnapshot():Object{var next:Object=null;if(route && index<route.length && route[index][1]=="walk")next=RobotRouteReviewed.movement(route[index][0],mirror,width);return {phase:phase,map:code,step:index,total:route ? route.length : 0,reason:message,recoveries:recoveryCount,next:next,clock:clock,due:due};}
  public function cachedVersion(mapCode:String):String{return String(routeVersions[mapCode] || "");}
  public function setFocused(value:Boolean):void{focused=value;}
  public function pause():void{if(!enabled || manual)return;manual=true;phase="paused";input.release();show("pausado pela tecla; desligue e ligue para reiniciar");}
  public function setRoutes(routes:Object):void{if(!routes || routes is Array)throw new Error("Dicionario de rotas requerido");var total:int=0;for(var key:String in routes){if(!/^@[0-9]+$/.test(key))continue;cache[key]=RobotRouteReviewed.validate(routes[key] as Array);recorded[key]=true;githubChecked[key]=getTimer();total++;}if(total==0)throw new Error("Nenhuma rota numerica valida");}
  public function installPublished(mapCode:String,steps:Array):void{var valid:Array=RobotRouteReviewed.validate(steps);githubRoutes[mapCode]=valid;cache[mapCode]=valid;delete recorded[mapCode];githubChecked[mapCode]=getTimer();delete routeVersions[mapCode];routeChecks[mapCode]=0;routeSources[mapCode]="gravada";retain(mapCode);}
  private function retain(code:String):void{var previous:int=order.indexOf(code);if(previous>=0)order.splice(previous,1);order.push(code);while(order.length>64){var oldest:String=String(order.shift());delete githubRoutes[oldest];delete githubChecked[oldest];delete routeVersions[oldest];delete routeSources[oldest];delete routeChecks[oldest];delete routeStale[oldest];if(!recorded[oldest])delete cache[oldest];}}
  private function githubReady():Boolean{return code in githubChecked;}
  
  private function loadGithub():void{
   if(request)return;var wanted:String=code;var loader:URLLoader=new URLLoader();var httpStatus:int=0;loader.addEventListener(HTTPStatusEvent.HTTP_STATUS,function(e:HTTPStatusEvent):void{httpStatus=e.status;});request=loader;requestCode=wanted;requestStarted=getTimer();if(!route && !githubRoutes[wanted])phase="load";
   var finish:Function=function():void{if(request!==loader)return;request=null;requestCode="";githubChecked[wanted]=getTimer();routeChecks[wanted]=Math.max(0,lastNow)+(routeStale[wanted] && !route ? 1000 : 30000);retain(wanted);};
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{if(request!==loader)return;try{var text:String=String(loader.data);if(text.length>600000)throw new Error("Rota muito grande");githubRoutes[wanted]=decodeRoute(text,wanted);retain(wanted);}catch(error:Error){requestError="resposta de rota invalida";}finish();});
   var failed:Function=function(e:Event):void{if(request!==loader)return;if(httpStatus==404){delete githubRoutes[wanted];delete routeVersions[wanted];delete routeSources[wanted];if(!recorded[wanted])delete cache[wanted];requestError="mapa sem rota publicada";}else requestError="consulta indisponivel; cache valido preservado";finish();};loader.addEventListener(IOErrorEvent.IO_ERROR,failed);loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,failed);
   try{var token:String="";if(root["tfmdisney"] && root["tfmdisney"].data)token=String(root["tfmdisney"].data.flash_token);loader.load(new URLRequest(String(root["host_url"])+"github-routes?v=2&since="+encodeURIComponent(String(routeVersions[wanted] || ""))+"&code="+encodeURIComponent(wanted)+"&access_token="+encodeURIComponent(String(root["access_token"]))+"&flash_token="+encodeURIComponent(token)));}catch(error:Error){failed(new Event("error"));}
  }
  private static function checksum(text:String):String{if(!crcTable){crcTable=[];for(var n:int=0;n<256;n++){var c:uint=n;for(var bit:int=0;bit<8;bit++)c=(c&1)!=0 ? uint(0xedb88320)^(c>>>1) : c>>>1;crcTable[n]=c;}}var bytes:ByteArray=new ByteArray();bytes.writeUTFBytes(text);bytes.position=0;var crc:uint=0xffffffff;while(bytes.bytesAvailable)crc=uint(crcTable[(crc^bytes.readUnsignedByte())&255])^(crc>>>8);var result:String=uint(crc^0xffffffff).toString(16);while(result.length<8)result="0"+result;return result;}
  private function decodeRoute(text:String,wanted:String):Array{var data:Object=com.adobe.serialization.json.JSON.decode(text);if(data is Array){routeSources[wanted]="compatibilidade";return RobotRouteReviewed.validate(data as Array);}if(!data || data.schema!==2 || String(data.code)!=wanted || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(String(data.revision)))throw new Error("Envelope de rota invalido");routeStale[wanted]=data.stale===true;if(data.unchanged===true){if(!githubRoutes[wanted] || routeVersions[wanted]!=data.revision)throw new Error("Versao sem dados em cache");routeSources[wanted]=data.stale===true ? "cache em verificacao" : String(data.source || "memoria");return githubRoutes[wanted] as Array;}if(!(data.data is String) || String(data.data).length>262144 || checksum(String(data.data))!=String(data.checksum))throw new Error("Integridade da rota invalida");var valid:Array=RobotRouteReviewed.decode(String(data.data));routeVersions[wanted]=String(data.revision);routeSources[wanted]=data.stale===true ? "cache em verificacao" : String(data.source);return valid;}
  private function cancelRequest():void{if(request){try{request.close();}catch(e:Error){}request=null;}requestCode="";}
  private function show(text:String):void{
   if(loggedPhase!=phase){loggedPhase=phase;var record:Object={time:getTimer(),map:code,phase:phase,step:index,detail:text};diagnostics.push(record);if(diagnostics.length>100)diagnostics.shift();trace("[Robot] "+com.adobe.serialization.json.JSON.encode(record));try{writeLog();}catch(logError:Error){}}
   var nextMessage:String="Robot cache v3: "+text;if(message==nextMessage && ((!hud && !root["auto_play"]) || hud && hud.visible==Boolean(root["auto_play"])))return;message=nextMessage;var ui:Object=root["Interface"];if(ui && ui["status_field"])ui["status_field"].text=message;
   if(!root.stage)return;if(!root["auto_play"]){if(hud)hud.visible=false;return;}
   if(!hud){hud=new TextField();hud.name="robotNovoStatus";hud.defaultTextFormat=new TextFormat("_sans",12,0xA9F7E4);hud.background=true;hud.backgroundColor=0x141B2A;hud.height=24;hud.selectable=false;hud.mouseEnabled=false;root.stage.addChild(hud);}
   hud.text=message;hud.visible=true;hud.x=8;hud.y=Math.max(60,root.stage.stageHeight-48);hud.width=Math.max(100,Math.min(740,root.stage.stageWidth-16));root.stage.setChildIndex(hud,root.stage.numChildren-1);
  }
  private function writeLog():void{var now:int=getTimer();if(logLoader && now-logStarted>5000){try{logLoader.close();}catch(ignored:Error){}logLoader=null;}if(now-logWindow>=60000){logWindow=now;logCount=0;}if(logLoader || logCount>=60 || !("access_token" in root) || !root["access_token"])return;
   var loader:URLLoader=new URLLoader();logLoader=loader;logStarted=now;logCount++;var clear:Function=function(e:Event):void{if(logLoader===loader)logLoader=null;};loader.addEventListener(Event.COMPLETE,clear);loader.addEventListener(IOErrorEvent.IO_ERROR,clear);loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,clear);
   try{var request:URLRequest=new URLRequest(String(root["host_url"])+"client_diagnostics?access_token="+encodeURIComponent(String(root["access_token"])));var values:URLVariables=new URLVariables();values.event="robot";values.channel="client";values.code=0;values.elapsed=now;values.phase=phase;values.map=code;values.step=index;values.fps_x10=fpsX10;values.target_fps_x10=root.stage ? Math.round(root.stage.frameRate*10) : 0;values.frame_ms=frameGap;values.late_ms=Math.min(3600000,Math.max(0,Math.round(clock-due)));values.error_px=positionError();request.data=values;request.method="POST";loader.load(request);}catch(ignored:Error){logLoader=null;}
  }
  private function positionError():int{if(!player || !lastSample)return 0;var dx:Number=Number(player.x)-Number(lastSample.x);var dy:Number=Number(player.y)-Number(lastSample.y);var distance:Number=Math.sqrt(dx*dx+dy*dy);return isFinite(distance) ? Math.min(10000000,Math.round(distance)) : 0;}
  private function timing(now:int):void{if(now<nextTiming)return;nextTiming=now+2000;var record:Object={time:now,map:code,phase:phase,step:index,fps_x10:fpsX10,frame_ms:frameGap,late_ms:Math.max(0,Math.round(clock-due)),error_px:positionError()};diagnostics.push(record);if(diagnostics.length>100)diagnostics.shift();trace("[Robot timing] "+com.adobe.serialization.json.JSON.encode(record));try{writeLog();}catch(ignored:Error){}}
  private function resetLife(now:int):void{
   lifeStarted=pendingStart>=0 ? pendingStart : now;pendingStart=-1;input.reset();route=null;index=0;clock=0;due=0;lastSample=null;lastRecord=null;goal=null;goalElapsed=0;fault="";manual=false;terminal=false;nativeWon=false;nativeDead=false;deathReason="";birthPending=false;newRound=false;cheeseKnown=false;cheeseCount=0;deathSeen=false;stationary=0;progressX=NaN;progressY=NaN;recoveryCount=0;blocked=true;crouched=false;needsCheese=false;phase="wait";requestError="";
  }
  private function remember(k:Object,p:Object):void{if(!p || !k.player_id || !(k.player_id in p))return;var value:* =p[k.player_id];if(!(value is Number))return;var id:Number=Number(value);if(isFinite(id) && id==Math.floor(id)){localId=int(id);idKnown=true;}}
  public function receive(bytes:ByteArray,observedAt:int=-1):void{if(observedAt<0)observedAt=getTimer();
   if(!enabled || !bytes || bytes.bytesAvailable<2)return;var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
   if(c==5 && (cc==2 || cc==21)){pendingStart=observedAt;waitForRound=true;roundLocked=false;newRound=true;phase="wait";input.release();return;}var k:Object=root["Keys"];var g:Object=root["tfm"];if(k && g)remember(k,g[k.player]);if(!idKnown)return;
   if(c==144 && cc==6 && bytes.bytesAvailable>=5){var id:int=bytes.readInt();var count:int=bytes.readByte();if(id==localId){cheeseKnown=true;cheeseCount=count;}return;}
   if(c==144 && cc==2){bytes.readUTF();if(bytes.bytesAvailable>=6){var born:int=bytes.readInt();bytes.readBoolean();var dead:int=bytes.readUnsignedByte();if(born==localId && dead==0 && (nativeDead || nativeWon || deathSeen || newRound || terminal)){birthPending=true;pendingStart=observedAt;}}return;}
   if(c==8 && cc==6 && bytes.bytesAvailable>=5){bytes.readUnsignedByte();if(bytes.readInt()==localId){nativeWon=true;terminal=true;phase="won";input.release();show("vitoria confirmada; aguardando renascer | "+code);}return;}
   if(c==1 && cc==1){var fields:Array=bytes.readUTF().split(String.fromCharCode(1));var header:String=String(fields[0]);if(header.length==2 && header.charCodeAt(0)==8 && header.charCodeAt(1)==5 && fields.length>1 && /^-?[0-9]+$/.test(String(fields[1])) && int(fields[1])==localId){nativeDead=true;deathReason=fields.length>4 ? " (motivo "+String(fields[4])+")" : "";terminal=true;phase="dead";input.release();show("morte nativa"+deathReason+"; aguardando renascer | "+code);}}
  }
  private function hasCheese(k:Object):Boolean{if(cheeseKnown)return cheeseCount>0;return player && k.player_cheese && k.player_cheese in player && Number(player[k.player_cheese])>0;}
  private function sameLife(k:Object):Boolean{
   try{var g:Object=root["tfm"];var p:Object=g ? g[k.player] : null;var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";
    var valid:Boolean=root["Keys"]===k && !terminal && !nativeWon && !nativeDead && !birthPending && !newRound && p===player && p && p[k.player_physics]===lifeBody && k.map_class[k.map_instance]===map && token==round && input.ready();
    if(valid)return true;
   }catch(error:Error){}input.release();return false;
  }
  private function fail(text:String):void{failedAttempt={map:map,code:code,round:round,body:lifeBody,message:text};fault=text;phase="error";input.release();show(text+" | "+code+" | aguarde renascer ou nova rodada");}
  private function bindNative():void{
   try{var k:Object=root["Keys"];var dispatcher:Object=k ? k.packet_handler_class : null;
    if(!dispatcher || dispatcher===observedDispatcher || !("astroRoomObserverV1" in dispatcher))return;
    var previous:Function=dispatcher["astroRoomObserverV1"] as Function;
    dispatcher["astroRoomObserverV1"]=function(bytes:ByteArray):void{
     if(!bytes)return;var cursor:uint=bytes.position;
     try{if(previous!=null)previous(bytes);}catch(ignored:Error){}
     try{bytes.position=0;NativeMotion.observe(root,bytes);}finally{bytes.position=cursor;}
    };observedDispatcher=dispatcher;
   }catch(error:Error){}
  }
  private function point(tag:String):Object{
   var reference:Object=lastSample ? lastSample : player;var k:Object=root["Keys"];var nativePoint:Object;
   try{
    if(tag=="F" && k.clip_fromage){var cheese:Object=map[k.clip_fromage];if(cheese && isFinite(Number(cheese.x)) && isFinite(Number(cheese.y)))nativePoint={x:Number(cheese.x),y:Number(cheese.y)};}
    if(tag=="T" && k.hole_list){var container:Object=map[k.obj_container];var holes:Object=container ? container[k.hole_list] : null;var nearest:Number=Number.POSITIVE_INFINITY;
     if(holes && holes.length%3==0)for(var h:int=0;h<holes.length;h+=3){var x:Number=Number(holes[h+1]);var y:Number=Number(holes[h+2]);if(!isFinite(x)||!isFinite(y))continue;var dx:Number=x-Number(reference.x);var dy:Number=y-Number(reference.y);var distance:Number=dx*dx+dy*dy;if(distance<nearest){nearest=distance;nativePoint={x:x,y:y};}}
    }
   }catch(error:Error){}
   if(nativePoint)return nativePoint;
   return RobotRouteReviewed.target(String(root["current_map_xml"]),tag,mirror,width,Number(reference.x),Number(reference.y),null);
  }
  private function startGoal(kind:String,target:Object):void{if(kind=="recover" && ++recoveryCount>3){fail("limite de recuperacoes nesta vida");return;}input.release();goal=target;goalElapsed=0;phase=kind;if(!goal){fail("sem referencia para "+kind);return;}input.steer(goal.x,goal.y,lastNow);if(!sameLife(root["Keys"]))return;show(kind=="cheese" ? "buscando coleta real do queijo | "+code : kind=="hole" ? "aproximando da toca; aguardando vitoria | "+code : "retomando rota pelos controles | "+code);}
  private function resumeInput(k:Object,now:int):Boolean{if(lastSample)input.resume(lastSample,now);else input.release();if(!sameLife(k))return false;if(crouched){input.crouch(true);if(!sameLife(k))return false;}return true;}
  private function nextStep():void{index++;if(index<route.length)due+=Number(route[index][2]);}
  private function goals(k:Object,now:int,dt:int):Boolean{
   if(phase!="cheese" && phase!="hole" && phase!="recover")return false;
   if(phase=="cheese" && hasCheese(k)){if(index<route.length && route[index][1]=="cheese")nextStep();phase="play";goal=null;if(!resumeInput(k,now))return true;return false;}
   if(phase=="recover"){var dx:Number=Number(player.x)-goal.x;var dy:Number=Number(player.y)-goal.y;if(dx*dx+dy*dy<=576){phase="play";goal=null;stationary=0;if(!resumeInput(k,now))return true;return false;}}
   goalElapsed+=dt;if(goalElapsed>4000){fail(phase=="cheese" ? "queijo nao confirmado; rota incompativel" : phase=="hole" ? "entrada na toca nao confirmada" : "nao foi possivel retomar a rota");return true;}
   input.steer(goal.x,goal.y,now);if(!sameLife(k))return true;show(phase=="cheese" ? "buscando coleta real do queijo | "+code : phase=="hole" ? "aproximando da toca; aguardando vitoria | "+code : "retomando rota pelos controles | "+code);return true;
  }
  private function play(now:int,dt:int,k:Object):void{
   clock+=dt;var pending:Object;var requestJump:Boolean=false;var steps:int=0;
   while(index<route.length && clock>=due && steps<256){
    var step:Array=route[index];var action:String=String(step[1]);
    if(action=="walk"){
     var sample:Object=RobotRouteReviewed.movement(step[0],mirror,width);
     // Preserve input edges across scheduler turns, without shifting the
     // absolute deadlines of the remaining recording.
     if(pending && (sample.ml!=pending.ml || sample.mr!=pending.mr || sample.jump!=pending.jump || sample.up!=pending.up || (sample.jump && sample.vy<=-4.5 && pending.vy-sample.vy>1)))break;
     var dx:Number=sample.x-Number(player.x);var dy:Number=sample.y-Number(player.y);var distance:Number=Math.sqrt(dx*dx+dy*dy);
     if(!isFinite(distance)){fail("posicao local indisponivel");return;}
     if(distance>(lastSample ? 160 : 96)){if(pending){if(!sameLife(k))return;input.play(pending,now);if(!sameLife(k))return;}if(distance<=224 && Math.abs(dy)<=96)startGoal("recover",{x:sample.x,y:sample.y});else fail("fora da rota por "+Math.round(distance)+"px; sem teleporte");return;}
     if(sample.jump && (!lastRecord || !lastRecord.jump || (sample.vy<=-4.5 && lastRecord.vy-sample.vy>1)))requestJump=true;if(!sample.jump)requestJump=false;
     sample.requestJump=requestJump;pending=sample;lastSample=sample;lastRecord=sample;var emitted:Number=due;nextStep();if(index<route.length && clock>=due)clock=emitted;break;
    }else{
     if(pending)break;
     if(action=="cheese" && !hasCheese(k)){startGoal("cheese",point("F"));return;}
     if(action=="hole"){if(needsCheese && !hasCheese(k))startGoal("cheese",point("F"));else startGoal("hole",point("T"));return;}
     if(action=="crouch" || action=="duck"){crouched=Number(step[0])!=0;input.crouch(crouched);if(!sameLife(k))return;}
     nextStep();
    }
    steps++;
   }
   if(pending){if(!sameLife(k))return;input.play(pending,now);if(!sameLife(k))return;}
   if(index>=route.length){phase="finished";input.release();show("fim da rota; aguardando confirmacao nativa ou proximo mapa | "+code);return;}
   if(steps>=256 && clock>=due){fail("excesso de estados vencidos na rota");return;}
   show("executando "+code+" | "+index+"/"+route.length+" | "+String(routeSources[code] || "gravacao local"));
  }
  public function advance(now:int,render:Boolean=true):void{try{update(now,render);}catch(error:Error){input.release();fail("erro #"+error.errorID+": "+error.message);}}
  private function update(now:int,render:Boolean):void{
   if(lastNow==now && (!render || lastFrame==now))return;
   var frameDelta:int=render && lastFrame>=0 ? Math.max(0,now-lastFrame) : 0;
   if(render){lastFrame=now;frameGap=Math.min(60000,frameDelta);if(frameWindow<0)frameWindow=now;else frameCount++;if(now-frameWindow>=1000){fpsX10=Math.min(2400,Math.round(frameCount*10000/(now-frameWindow)));frameCount=0;frameWindow=now;}}
   if(bootstrap){var initialUI:Object=root["Interface"];var initialKeys:Object=root["Keys"];if(initialUI && initialUI["auto_play_check_box"] && initialKeys && initialKeys.check_button_exec){bootstrap=false;if(!root["auto_play"] && !RouteRecorderReviewed.get(root).active && (!TrainingSuite.bound(root) || TrainingSuite.allowed(root))){var button:Object=initialUI["auto_play_check_box"];button[initialKeys.check_button_exec](new flash.events.MouseEvent("mouseDown"));}}}
   if(request && getTimer()-requestStarted>=25000){var expired:String=requestCode;cancelRequest();githubChecked[expired]=getTimer();requestError="tempo limite da consulta; reative F2 para tentar novamente";}
   if(TrainingSuite.bound(root) && !TrainingSuite.allowed(root)){root["auto_play"]=false;input.release();}
   bindNative();
   var raw:int=frameDelta;lastNow=now;var dt:int=raw;
   if(!root["auto_play"]){if(scheduler && scheduler.running)scheduler.stop();if(enabled){cancelRequest();input.reset();if(!githubRoutes[code])delete githubChecked[code];}enabled=false;phase="off";show("desligado");return;}
   if(scheduler && !scheduler.running)scheduler.start();
   if(!enabled){enabled=true;manual=false;resetLife(now);FollowControllerV13Shared.stopForRobot(root);LocalServerLog.emit(root,"Robot novo 6: ligado; controles nativos e coleta confirmada");}
   var k:Object=root["Keys"];var g:Object=root["tfm"];if(!k || !g || !k.map_class){input.release();show("aguardando jogo");return;}
   var m:Object=k.map_class[k.map_instance];var n:Object=m && k.bot_map_code_object ? m[k.bot_map_code_object] : null;var number:Number=n ? Number(n[k.bot_map_code_value]) : NaN;
   if(!m || !isFinite(number) || number<=0 || number!=Math.floor(number)){input.release();show("aguardando codigo do mapa");return;}
   var nextCode:String="@"+number.toFixed(0);var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";var p:Object=g[k.player];var b:Object=p && k.player_physics ? p[k.player_physics] : null;
   var alive:Boolean=p && b && (!k.player_clip || p[k.player_clip]) && (!k.is_dead || !p[k.is_dead]);var changed:Boolean=m!==map || nextCode!=code || token!=round;
   var recoveredLife:Boolean=alive && deathSeen;
   var replacement:Boolean=alive && lifeBody!=null && (b!==lifeBody || (player && p!==player));
   if(waitForRound && !changed && !birthPending && !recoveredLife && (!b || b===lifeBody)){
    var locked:Boolean=(k.move_class && !k.move_class[k.move_free]) || (k.timer_class && k.timer_class[k.timer_prop]);if(locked)roundLocked=true;
    if(!roundLocked || locked || !alive){input.release();blocked=true;show("aguardando o novo mapa ser instalado | "+code);return;}
   }
   if(!alive && p && k.is_dead && p[k.is_dead])deathSeen=true;
   if(failedAttempt){
    if(changed || newRound || recoveredLife || (birthPending && (nativeDead || nativeWon || deathSeen || terminal)))failedAttempt=null;
    else{input.release();fault=String(failedAttempt.message);phase="error";show(fault+" | "+code+" | tentativa encerrada; aguarde renascer ou nova rodada");return;}
   }
   if(changed || newRound || birthPending || recoveredLife || (terminal && replacement)){var waited:Boolean=waitForRound;waitForRound=false;cancelRequest();requestError="";map=m;code=nextCode;round=token;resetLife(now);if(changed || waited)routeChecks[code]=0;replacement=false;}
   if(!recorded[code] && !request && (!githubReady() || (githubRoutes[code] && now>=int(routeChecks[code])) || (!githubRoutes[code] && getTimer()-int(githubChecked[code])>=30000)))loadGithub();
   if(p){player=p;remember(k,p);}if(!alive && p && k.is_dead && p[k.is_dead])deathSeen=true;
   if(alive){lifeBody=b;if(replacement){input.reset();blocked=true;}}
   if(nativeWon || NativeMotion.get(root).finished()){terminal=true;phase="won";input.release();show("vitoria confirmada; aguardando renascer | "+code);return;}
   if(nativeDead){terminal=true;phase="dead";input.release();show("morte nativa"+deathReason+"; aguardando renascer | "+code);return;}
   if(!alive){blocked=true;input.release();if(phase=="hole" || phase=="confirm"){phase="confirm";terminal=true;show("aguardando confirmacao nativa da toca | "+code);}else show("aguardando renascer | "+code);return;}
   if(terminal){input.release();show("aguardando confirmacao nativa ou renascimento | "+code);return;}
   if(manual){input.release();show("pausado pela tecla; desligue e ligue para reiniciar");return;}
   var editing:Boolean=focused && root.stage && root.stage.focus is TextField && TextField(root.stage.focus).type=="input";
   var gate:Boolean= !k.move_class || !k.move_class[k.move_free] || (k.timer_class && k.timer_class[k.timer_prop]);
   if(editing || gate){blocked=true;stationary=0;input.release();show(editing ? "pausado para digitar no chat" : "aguardando liberacao da rodada | "+code);return;}
   if(!render)return;
   if(blocked){blocked=false;dt=0;if(phase=="play"){if(!resumeInput(k,now))return;}else if(crouched){input.crouch(true);if(!sameLife(k))return;}}
   input.tick(now);if(!sameLife(k))return;
   if(raw>500 && route && phase=="play"){dt=0;if(lastSample)input.resume(lastSample,now);stationary=0;}
   if(phase=="play" && lastSample && (lastSample.ml || lastSample.mr)){
    var px:Number=Number(player.x);var py:Number=Number(player.y);
    if(isFinite(progressX) && Math.abs(px-progressX)+Math.abs(py-progressY)<2)stationary+=dt;else{stationary=0;progressX=px;progressY=py;}
    if(stationary>1500){stationary=0;var expected:Object=index<route.length && route[index][1]=="walk" ? RobotRouteReviewed.movement(route[index][0],mirror,width) : lastSample;startGoal("recover",{x:expected.x,y:expected.y});return;}
   }else{stationary=0;progressX=NaN;progressY=NaN;}
   width=Number(k.map_class[k.bot_map_width]);if(!isFinite(width)||width<1||width>100000){fail("largura do mapa indisponivel");return;}mirror=Boolean(m[k.obj_container][k.bot_reverse]);
   if(fault!=""){input.release();show(fault+" | "+code+" | aguarde renascer ou nova rodada");return;}
   if(!route){if(!githubReady() && !recorded[code]){loadGithub();show("preparando rota do GitHub/cache local | "+code);return;}var saved:Array=recorded[code] ? cache[code] as Array : githubRoutes[code] as Array;
    if(!saved)saved=cache[code] as Array;
    if(!saved){phase="unrecorded";input.release();show((requestError!="" ? requestError+" | " : "")+"sem rota nova para "+code+"; use REC para gravar");return;}
    route=RobotRouteReviewed.validate(saved);index=0;clock=0;due=Number(route[0][2]);if(!recorded[code]){if(route[0][1]=="walk" && !("up" in route[0][0]))due=0;else due=Math.max(0,due-Math.max(0,now-lifeStarted));}needsCheese=false;for each(var entry:Array in route)if(entry[1]=="cheese")needsCheese=true;if(point("F")!=null)needsCheese=true;phase="play";dt=0;}
   var wasGoal:Boolean=phase=="cheese" || phase=="hole" || phase=="recover";if(goals(k,now,dt))return;if(wasGoal)dt=0;
   if(phase=="finished"){input.release();show("fim da rota; aguardando confirmacao nativa ou proximo mapa | "+code);return;}
   if(phase=="play"){play(now,dt,k);timing(now);}
  }
 }
}
