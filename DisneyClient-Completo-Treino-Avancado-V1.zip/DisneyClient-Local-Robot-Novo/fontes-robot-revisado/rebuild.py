"""Rebuild only from this uploaded base and the reviewed source files. Java21 + FFDec."""
import os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=root/'fontes-robot-revisado'
jar=Path(os.environ['FFDEC_JAR']).resolve()
classpath=str(jar)+os.pathsep+str(jar.parent/'lib/*')
def java(script,*args):
 subprocess.run(['java','-cp',classpath,str(script),*[str(x) for x in args]],check=True,cwd=root)
base=source/'ChargeurTransformice-base.swf'
output=root/'DisneyClient/public/ChargeurTransformice.swf'
java(source/'BuildReviewed.java',base,source,output)
java(source/'VerifyReviewed.java',base,output)
fixtures=source/'tests/fixtures';fixtures.mkdir(exist_ok=True)
for name in ('RobotTests','RecorderTests','FakeLagTests','CacheTests','RouteExecutionTests','TrainingTests','TrainingLifecycleTests'):
 extra=[]
 if name=='FakeLagTests':extra=[root/'fontes-fake-lag'/x for x in ('FakePacket.as','MockTransport.as','FakeIncoming.as')]
 java(root/'fontes-fake-lag/BuildFakeFixture.java',output,source/'tests'/f'{name}.as',fixtures/f'{name}.swf',*extra)
subprocess.run([os.sys.executable,str(source/'tests/patch_fixture.py')],check=True)
