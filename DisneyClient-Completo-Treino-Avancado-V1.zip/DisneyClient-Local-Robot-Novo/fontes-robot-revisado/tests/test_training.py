"""Real SQLite and aiohttp tests; no remote game/Windows runtime required."""
import asyncio, importlib.util, json, sys, tempfile, types, unittest
from pathlib import Path
from unittest.mock import AsyncMock
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
ROOT=Path(__file__).resolve().parents[2]/'DisneyClient'
pkg=types.ModuleType('training_test_api');pkg.__path__=[str(ROOT/'api')];sys.modules[pkg.__name__]=pkg
common=types.ModuleType(pkg.__name__+'.common');common.authorize=AsyncMock(return_value={'user_id':1});sys.modules[common.__name__]=common
sys.modules.setdefault('infrastructure',types.ModuleType('infrastructure'))
def load(name):
 spec=importlib.util.spec_from_file_location(pkg.__name__+'.'+name,ROOT/'api'/f'{name}.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
load('github_routes');t=load('training')
def steps():return [[{'x':400,'y':1100,'vx':330,'vy':0,'frame':0,'ml':False,'mr':True,'jump':False},'walk',0],[0,'hole',100]]
class StoreTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'client';self.store=t.TrainingStore(self.root)
 async def asyncTearDown(self):self.tmp.cleanup()
 async def call(self,op,v=None,uid=1):return await self.store.run(uid,op,v)
 async def route(self,name='test'):return await self.call('route_save',{'map':'@123','name':name,'steps':steps()})
 async def test_settings_validation_and_restart(self):
  d=t.clean_settings({'theme':'rgb','ghost':True});await self.call('settings_save',{'settings':d});self.assertEqual((await t.TrainingStore(self.root).run(1,'settings'))['theme'],'rgb')
  self.assertFalse((await self.call('settings',uid=2))['ghost'])
  for v in ({'ghost':'yes'},{'menu_key':27},{'extra':True},{'opacity':float('nan')},{'retry_command':'kill all'}):
   with self.assertRaises(ValueError):t.clean_settings(v)
 async def test_route_update_conflict_backup_restore_and_isolation(self):
  a=await self.route();saved=await self.call('route_save',{**a,'name':'edited'});self.assertEqual(saved['version'],2)
  with self.assertRaises(RuntimeError):await self.call('route_save',a)
  with self.assertRaises(KeyError):await self.call('route',{'id':a['id']},uid=2)
  backups=await self.call('backups',{'id':a['id']});self.assertEqual(len(backups),1)
  restored=await self.call('restore',{'id':a['id'],'backup':backups[0]['id']});self.assertEqual(restored['name'],'test');self.assertEqual(restored['version'],3)
  await self.call('route_delete',{'id':a['id']});self.assertEqual(await self.call('routes'),[])
 async def test_backup_limit_and_comparison(self):
  a=await self.route();b=await self.route('B');b['steps'][1][-1]=200;b=await self.call('route_save',b)
  diff=await self.call('compare',{'a':a['id'],'b':b['id']});self.assertEqual(diff['different_steps'],[1]);self.assertEqual(diff['b_ms'],200)
  for n in range(24):a=await self.call('route_save',{**a,'name':str(n)})
  self.assertEqual(len(await self.call('backups',{'id':a['id']})),20)
 async def test_ghost_best_winning_only_and_repeated_attempt(self):
  failed={'map':'@123','duration':100,'result':'failed','frames':[],'summary':{'step':2,'reason':'stuck'},'id':'a'*32}
  await self.call('attempt',failed);await self.call('attempt',failed);self.assertIsNone(await self.call('ghost',{'map':'@123'}));stats=await self.call('statistics');self.assertEqual(stats['attempts'],1);self.assertEqual(stats['failures'][0]['count'],1)
  for duration in [500,300,400]:await self.call('attempt',{'map':'@123','duration':duration,'result':'won','frames':[{'t':0,'x':1,'y':2},{'t':duration,'x':3,'y':4}],'summary':{'mirror':True}})
  ghost=await self.call('ghost',{'map':'@123'});self.assertEqual(ghost['duration'],300);self.assertTrue(ghost['summary']['mirror']);self.assertEqual(len(ghost['frames']),2)
  self.assertIsNone(await self.call('ghost',{'map':'@123'},uid=2))
 async def test_ranking_is_versioned(self):
  a=await self.route('A');b=await self.route('B')
  for result,r in [('failed',a),('failed',a),('won',b)]:await self.call('attempt',{'map':'@123','duration':100,'result':result,'route_id':r['id'],'version':str(r['version'])})
  self.assertEqual((await self.call('best_route',{'map':'@123'}))['id'],b['id'])
  b=await self.call('route_save',b);self.assertEqual([r for r in await self.call('routes') if r['id']==b['id']][0]['tests'],0)
 async def test_macro_validation_and_no_cross_user_overwrite(self):
  macro=await self.call('macro_save',{'name':'test','events':[{'t':0,'key':39,'down':True},{'t':100,'key':39,'down':False}]})
  with self.assertRaises(RuntimeError):await self.call('macro_save',macro,uid=2)
  self.assertEqual((await self.call('macro',{'id':macro['id']}))['name'],'test')
  for events in ([{'t':0,'key':13,'down':True}],[{'t':10,'key':39,'down':True},{'t':5,'key':39,'down':False}],[]):
   with self.assertRaises(ValueError):t.validate_macro(events)
 async def test_invalid_frames_and_routes(self):
  for frames in ([{'t':0,'x':float('inf'),'y':2}],[{'t':10,'x':1,'y':2},{'t':0,'x':1,'y':2}]):
   with self.assertRaises(ValueError):t.validate_frames(frames,100)
  with self.assertRaises(ValueError):await self.call('route_save',{'map':'@bad','name':'test','steps':steps()})
 async def test_logs_redact_and_rotate(self):
  await self.call('log',{'message':'access_token=secret github_pat_example123','event':'test'})
  path=Path(self.tmp.name)/'logs-client/training-1.jsonl';content=path.read_text();self.assertNotIn('secret',content);self.assertNotIn('github_pat_',content)
  path.write_text('x'*(2*1024*1024));await self.call('log',{'message':'next'});self.assertTrue(path.with_suffix('.previous.jsonl').exists());self.assertLess(path.stat().st_size,1000)
class HTTPTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();app=web.Application();app['root']=Path(self.tmp.name)/'client';app.router.add_view('/training_api',t.TrainingAPI);self.client=TestClient(TestServer(app));await self.client.start_server()
 async def asyncTearDown(self):await self.client.close();self.tmp.cleanup()
 async def test_real_http_crud_and_errors(self):
  response=await self.client.get('/training_api?op=settings');self.assertEqual(response.status,200);self.assertTrue((await response.json())['ok'])
  response=await self.client.post('/training_api?op=route_save',data={'data':json.dumps({'map':'@123','name':'HTTP','steps':steps()})});self.assertEqual(response.status,200);saved=(await response.json())['result']
  response=await self.client.get('/training_api?op=route&id='+saved['id']);self.assertEqual((await response.json())['result']['name'],'HTTP')
  for payload,status in [('not json',400),(json.dumps({'map':'@123','name':'x','steps':[]}),400)]:
   response=await self.client.post('/training_api?op=route_save',data={'data':payload});self.assertEqual(response.status,status)
  self.assertEqual((await self.client.get('/training_api?op=route&id='+'f'*32)).status,404)
  self.assertEqual((await self.client.get('/training_api?op=attempt')).status,400)
if __name__=='__main__':unittest.main(verbosity=2)
