import importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
path=Path(__file__).with_name('fixtures')/'FakeLagTests.swf'
data=path.read_bytes()
for module,args in [('outgoing_observer',('disney.FakeTransport','send')),('room_observer',('disney.FakeIncoming',))]:
 spec=importlib.util.spec_from_file_location(module,ROOT/'DisneyParser/tfmparser'/f'{module}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);data=m.install(data,*args)
path.write_bytes(data);print('Fixture patched using uploaded parser hooks')
