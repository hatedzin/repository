import asyncio,base64,importlib.util,json,sys,tempfile,types,unittest,zlib
from pathlib import Path
from unittest.mock import AsyncMock,patch
from aiohttp import web
from aiohttp.test_utils import TestServer,TestClient
ROOT=Path(__file__).resolve().parents[2]/'DisneyClient'
package=types.ModuleType('review_api');package.__path__=[str(ROOT/'api')];sys.modules['review_api']=package
common=types.ModuleType('review_api.common');common.authorize=AsyncMock(return_value={'user_id':1,'level':1});sys.modules[common.__name__]=common
sys.modules.setdefault('infrastructure',types.ModuleType('infrastructure'))
spec=importlib.util.spec_from_file_location('review_api.github_routes',ROOT/'api/github_routes.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def route(up=None):
 p=dict(x=400,y=1100,vx=330,vy=0,frame=0,ml=False,mr=True,jump=False)
 if up is not None:p['up']=up
 return [[p,'walk',0],[0,'hole',100]]
class Validation(unittest.TestCase):
 def test_legacy_and_physical_keys(self):
  for r in (route(),route(True),route(False)):
   self.assertEqual(m.validate_route(r),r)
   raw=base64.b64encode(zlib.compress(json.dumps(r).encode())).decode();self.assertEqual(m.decode_route(raw),r)
 def test_invalid_input_and_compression(self):
  for mutation in ('invalid_up','unknown','no_hole','negative_time','nonboolean','oversize'):
   r=route()
   if mutation=='invalid_up':r[0][0]['up']=1
   if mutation=='unknown':r[0][0]['extra']=True
   if mutation=='no_hole':r.pop()
   if mutation=='negative_time':r[0][2]=-1
   if mutation=='nonboolean':r[0][0]['mr']=1
   if mutation=='oversize':r*=1000
   with self.subTest(mutation=mutation),self.assertRaises(ValueError):m.validate_route(r)
  for raw in (b'x'*300000,b'[]'+b'x'*300000):
   with self.assertRaises(ValueError):m.decode_route(base64.b64encode(zlib.compress(raw)).decode())
class ImportedProtocol(unittest.IsolatedAsyncioTestCase):
 async def test_small_github_file_and_rejection(self):
  cat=m.Catalog(None);raw=json.dumps(route()).encode();cat.request=AsyncMock(return_value=(200,{'encoding':'base64','content':base64.b64encode(raw).decode()}))
  self.assertEqual(await cat.read_imported('@123'),route());self.assertIn('/contents/rotas-mapas/123.json',cat.request.call_args.args)
  cat.request.return_value=(404,{})
  self.assertIsNone(await cat.read_imported('@123'))
  cat.request.return_value=(200,{'encoding':'base64','content':base64.b64encode(b'[]').decode()})
  with self.assertRaises(m.CatalogError):await cat.read_imported('@123')

class PerMapPublish(unittest.IsolatedAsyncioTestCase):
 async def test_save_creates_only_current_map_file(self):
  cat=m.Catalog(None,token='test');cat.request=AsyncMock(side_effect=[(404,{}),(201,{})]);await cat.publish('@123',route())
  self.assertEqual([call.args[1] for call in cat.request.call_args_list],['/contents/rotas-mapas/123.json']*2)
  self.assertNotIn('sha',cat.request.call_args.kwargs['json'])
 async def test_conflict_reloads_sha_without_overwriting_other_maps(self):
  cat=m.Catalog(None,token='test');cat.request=AsyncMock(side_effect=[(200,{'sha':'a'*40}),(409,{}),(200,{'sha':'b'*40}),(200,{})]);await cat.publish('@456',route())
  self.assertEqual(cat.request.call_count,4);self.assertEqual(cat.request.call_args.kwargs['json']['sha'],'b'*40)
  self.assertTrue(all(call.args[1]=='/contents/rotas-mapas/456.json' for call in cat.request.call_args_list))

class Persistence(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.app=web.Application();self.app['root']=self.tmp.name;self.app['config']={'storage_allowed_levels':[1]};self.app.router.add_view('/github-routes',m.GitHubRoutes)
  self.cat=types.SimpleNamespace(read_imported=AsyncMock(return_value=None),read=AsyncMock(side_effect=m.CatalogError('offline',503,'network')),publish=AsyncMock(side_effect=m.CatalogError('offline',503,'network')))
  self.patcher=patch.object(m,'catalog',return_value=self.cat);self.patcher.start();self.client=TestClient(TestServer(self.app));await self.client.start_server()
 async def asyncTearDown(self):
  await self.client.close();self.patcher.stop();self.tmp.cleanup()
 async def save(self,code,r):
  info=base64.b64encode(zlib.compress(json.dumps(r).encode())).decode();return await self.client.post('/github-routes?method=save',data={'code':code,'info':info})
 async def test_failed_saves_preserve_multiple_maps_and_restart(self):
  for code in ('@123','@456'):
   response=await self.save(code,route(True));self.assertEqual(response.status,503)
  for code in ('@123','@456'):
   response=await self.client.get('/github-routes?code='+code);self.assertEqual(response.status,200);self.assertEqual(await response.json(),route(True));self.assertEqual(response.headers['X-Route-Source'],'local-pending')
  request=types.SimpleNamespace(app=self.app);self.assertEqual(m.archived_route(request,{'user_id':1},'@123'),route(True));self.assertIsNone(m.archived_route(request,{'user_id':2},'@123'))
 async def test_success_publishes_and_preserves_local_copy(self):
  self.cat.publish.side_effect=None
  response=await self.save('@123',route(False));self.assertEqual(response.status,204);self.cat.publish.assert_awaited_once_with('@123',route(False))
  self.assertFalse((Path(self.tmp.name)/'data/rotas-pendentes/1.json').exists())
  response=await self.client.get('/github-routes?code=@123');self.assertEqual(await response.json(),route(False))
 async def test_remote_missing_falls_back_but_remote_present_wins(self):
  await self.save('@123',route(True));self.cat.read.side_effect=None;self.cat.read.return_value=({},'sha')
  response=await self.client.get('/github-routes?code=@123');self.assertEqual(await response.json(),route(True))
  request=types.SimpleNamespace(app=self.app);m.archive_route(request,{'user_id':1},'@123',route(True),pending=False)
  self.cat.read.return_value=({'@123':route(False)},'sha');response=await self.client.get('/github-routes?code=@123');self.assertEqual(await response.json(),route(False))
 async def test_pending_new_route_wins_over_older_remote_after_restart(self):
  await self.save('@123',route(True));self.cat.read.side_effect=None;self.cat.read.return_value=({'@123':route(False)},'sha')
  response=await self.client.get('/github-routes?code=@123');self.assertEqual(await response.json(),route(True));self.cat.read.assert_not_awaited()
 async def test_imported_map_is_downloaded_individually(self):
  self.cat.read.side_effect=None;self.cat.read.return_value=({},'sha');self.cat.read_imported.return_value=route()
  response=await self.client.get('/github-routes?code=@123');self.assertEqual(response.status,200);self.assertEqual(await response.json(),route());self.cat.read_imported.assert_awaited_once_with('@123');self.cat.read.assert_not_awaited();self.assertEqual(response.headers['X-Route-Source'],'github-map')
 async def test_bad_route_does_not_publish(self):
  response=await self.save('@123',[]);self.assertEqual(response.status,400);self.cat.publish.assert_not_awaited()
 async def test_map_path_rejects_traversal(self):
  response=await self.save('../../x',route());self.assertEqual(response.status,400);self.cat.publish.assert_not_awaited()
if __name__=='__main__':unittest.main(verbosity=2)
