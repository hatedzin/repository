import time
import asyncio,importlib.util,sys,types,tempfile,json
from pathlib import Path
import aiohttp
root=Path(__file__).resolve().parents[2]/'DisneyClient/api'
p=types.ModuleType('live_api');p.__path__=[str(root)];sys.modules['live_api']=p
common=types.ModuleType('live_api.common');common.authorize=lambda r:None;sys.modules['live_api.common']=common;sys.modules.setdefault('infrastructure',types.ModuleType('infrastructure'))
for name in ('github_routes','route_cache'):
 spec=importlib.util.spec_from_file_location('live_api.'+name,root/(name+'.py'));m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
async def main():
 gh=sys.modules['live_api.github_routes'];rc=sys.modules['live_api.route_cache']
 async with aiohttp.ClientSession(trust_env=True,timeout=aiohttp.ClientTimeout(total=15)) as session:
  cat=gh.Catalog(session)
  with tempfile.TemporaryDirectory() as folder:
   cache=rc.RouteCache(cat,folder,gh.validate_route)
   try:
    started=time.perf_counter();first=await cache.get('@1628732');cold_ms=(time.perf_counter()-started)*1000;started=time.perf_counter();second=await cache.get('@1628732');hot_ms=(time.perf_counter()-started)*1000;assert first['revision']==second['revision'];assert second['source']=='memory';result={'map':first['code'],'steps':len(json.loads(first['data'])),'revision':first['revision'],'second_source':second['source'],'downloads':cache.stats['downloads'],'cold_ms':round(cold_ms,3),'memory_ms':round(hot_ms,3)}
    cache.entries['@1628732']['checked']=0;await cache.get('@1628732');await asyncio.gather(*list(cache.inflight.values()));result['conditional_304']=cache.stats['not_modified'];assert result['conditional_304']==1
    with tempfile.TemporaryDirectory() as clean_folder:
     bundled=rc.RouteCache(cat,clean_folder,gh.validate_route,bundle_folder=root.parent/'data/rotas-iniciais')
     try:
      started=time.perf_counter();initial=await bundled.get('@1628732');result['initial_bundle_ms']=round((time.perf_counter()-started)*1000,3);result['initial_bundle_source']=initial['source'];assert initial['source']=='bundle'
     finally:await bundled.close()
    print(json.dumps({'PASS':result}))
   finally:await cache.close()
asyncio.run(main())
