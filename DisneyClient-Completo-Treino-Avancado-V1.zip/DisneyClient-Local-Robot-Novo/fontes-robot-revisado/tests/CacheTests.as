package disney {
 import ChargeurTransformice_fla.MainTimeline;import ChargeurTransformice_fla.Statements;import flash.display.MovieClip;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.geom.Point;import flash.net.URLLoader;import flash.net.URLRequest;import flash.text.TextField;import flash.external.ExternalInterface;import flash.utils.setTimeout;import flash.utils.ByteArray;import flash.utils.getTimer;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,label:String):void{if(!ok)throw new Error(label);count++;}
  private static function rejects(callback:Function,label:String):void{var rejected:Boolean=false;try{callback();}catch(error:Error){rejected=true;}check(rejected,label);}
  private static function walk(x:Number=395,delay:Number=100,jump:Boolean=false,vy:Number=0):Array{return [{x:x,y:1102,vx:345,vy:vy,frame:2,mr:true,ml:false,jump:jump},"walk",delay];}
  private static function fixture(display:MovieClip,steps:Array=null,sealedRoot:Boolean=false):Object{
   var r:MovieClip=sealedRoot ? new FreshSealedRoot() : new MovieClip();display.addChild(r);r.stage.focus=r.stage;
   var keys:Array=[];var positions:Array=[];var animations:Array=[];var forced:Array=[];var syncs:Array=[];
   var body:Object={velocity:{vx:0,vy:0},contacts:{ground:true},setPosition:function(p:Point,angle:Number):Boolean{positions.push(p);return true;}};
   var player:Object={x:118.5,y:330.6,pid:7,qty:0,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true,jumpReady:true,jumpStamp:0,jump:function(on:Boolean,frame:int=0):void{animations.push({on:on,frame:frame});},crouch:function(side:Boolean):void{},stand:function(side:Boolean):void{}};
   if(steps && steps[0][1]=="walk"){var first:Object=RobotRouteReviewed.movement(steps[0][0]);player.x=first.x;player.y=first.y;}
   var map:Object={number:{value:123},container:{mirror:false}};
   r.Keys={player:"mouse",player_id:"pid",player_cheese:"qty",player_list:"players",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",map_class:{current:map,width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",bot_map_width:"width",obj_container:"container",bot_reverse:"mirror",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(name:String):Class{return Point;}}},packet_handler_class:{astroRoomObserverV1:function(bytes:ByteArray):void{syncs.push(bytes.position);},receive:function(bytes:ByteArray):void{syncs.push(bytes);}},packet_handler:"receive"};
   r.tfm={mouse:player,players:[]};r.Interface={status_field:new TextField()};r.Statements={send_cheese_packet:function():void{forced.push("cheese");},send_hole_packet:function():void{forced.push("hole");},send_mort_packet:function():void{forced.push("death");}};r.host_url="";r.auto_play=true;r.auto_play_disable_on_move=true;r.current_round_code=1;r.round_start_time=0;r.current_map_xml='<C><Z><D><F X="80" Y="330.6"/><T X="180" Y="330.6"/></D></Z></C>';
   var bot:RobotControllerReviewed=new RobotControllerReviewed(r);var routes:Object={};routes["@123"]=steps ? steps : [walk(395,0),["cheese",100],["hole",100]];bot.setRoutes(routes);
   var f:Object={root:r,bot:bot,player:player,body:body,map:map,keys:keys,positions:positions,animations:animations,forced:forced,syncs:syncs,nativeInput:true,onKey:null,startX:player.x,startY:player.y};
   r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(!NativeMotion.isSynthetic(r))return;keys.push({code:e.keyCode,down:true});if(!f.nativeInput)return;if(e.keyCode==37)body.velocity.vx=-3.3;if(e.keyCode==39)body.velocity.vx=3.3;if(e.keyCode==38 && body.contacts.ground && player.jumpReady){body.velocity.vy=-5;body.contacts.ground=false;player.jumpReady=false;player.jumpStamp++;}if(f.onKey is Function)f.onKey(e);});
   r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(!NativeMotion.isSynthetic(r))return;keys.push({code:e.keyCode,down:false});if(f.nativeInput && (e.keyCode==37 || e.keyCode==39))body.velocity.vx=0;});
   return f;
  }
  private static function presses(f:Object,code:int,down:Boolean=true):int{var n:int=0;for each(var key:Object in f.keys)if(key.code==code && key.down==down)n++;return n;}
  private static function nativeOnly(f:Object,label:String):void{var directJump:int=0;for each(var call:Object in f.animations)if(call.on)directJump++;check(f.positions.length==0 && f.syncs.length==0 && f.forced.length==0 && directJump==0,label);}
  private static function deliver(f:Object,bytes:ByteArray):void{bytes.position=1;NativeMotion.observe(f.root,bytes);check(bytes.position==1,"observer preserves incoming cursor");}
  private static function cheese(id:int,quantity:int):ByteArray{var b:ByteArray=new ByteArray();b.writeByte(144);b.writeByte(6);b.writeInt(id);b.writeByte(quantity);return b;}
  private static function birth(id:int,deadState:int=0):ByteArray{var b:ByteArray=new ByteArray();b.writeByte(144);b.writeByte(2);b.writeUTF("Player#0001");b.writeInt(id);b.writeBoolean(false);b.writeByte(deadState);b.writeShort(0);b.writeByte(0);return b;}
  private static function win(id:int):ByteArray{var b:ByteArray=new ByteArray();b.writeByte(8);b.writeByte(6);b.writeByte(0);b.writeInt(id);b.writeShort(10);b.writeByte(1);b.writeShort(999);return b;}
  private static function dead(id:int,reason:int=3):ByteArray{var b:ByteArray=new ByteArray();b.writeByte(1);b.writeByte(1);b.writeUTF(String.fromCharCode(8,5,1)+id+String.fromCharCode(1)+"0"+String.fromCharCode(1)+"10"+String.fromCharCode(1)+reason);return b;}
  private static function awaitState(test:Function,done:Function,label:String):void{var end:int=getTimer()+5000;var poll:Function=function():void{try{if(test()){done();return;}if(getTimer()>end)throw new Error(label);setTimeout(poll,20);}catch(e:Error){ExternalInterface.call("recordTest","FAIL: "+e.message);}};poll();}
  public static function run(display:MovieClip):void{try{var f:Object=fixture(display);f.map.number.value=555;f.root.access_token="v1";var clock:int=1000;f.bot.advance(clock);
   awaitState(function():Boolean{f.bot.advance(++clock);return f.player.right;},function():void{
    check(f.bot.phase=="play" && int(ExternalInterface.call("cacheRequests","@555"))==1,"v2 envelope validated and executed through real SWF HTTP loader");f.root.access_token="v2";clock+=31000;f.bot.advance(clock);
    check(f.bot.phase=="play" && f.player.right,"background refresh keeps active route pinned");
    awaitState(function():Boolean{f.bot.advance(++clock);return f.bot.cachedVersion("@555")=="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";},function():void{
     check(f.player.right && !f.player.left,"new version cannot replace controls during active attempt");f.root.current_round_code++;f.bot.advance(++clock);check(f.player.left && f.bot.phase=="play","next round uses updated route immediately from SWF cache");check(f.bot.cachedVersion("@555")=="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","same-map restart keeps validated cached revision");
     awaitState(function():Boolean{f.bot.advance(++clock);return !f.bot.loadingRoute;},function():void{f.root.access_token="corrupt";clock+=31000;f.bot.advance(clock);
     awaitState(function():Boolean{f.bot.advance(++clock);return !f.bot.loadingRoute && int(ExternalInterface.call("tokenRequests","corrupt"))>=1;},function():void{
      f.root.current_round_code++;f.bot.advance(++clock);check(f.player.left && f.bot.phase=="play","corrupt update cannot poison validated memory cache");f.root.auto_play=false;f.bot.advance(++clock);ExternalInterface.call("recordTest","PASS: "+count+" versioned SWF cache and pinned execution checks");
     },"corrupt update did not complete");},"same-map background check did not complete");
    },"background version check did not complete");
   },"v2 route did not start: "+f.bot.message);
  }catch(e:Error){ExternalInterface.call("recordTest","FAIL: "+e.message);}}
 }
}
class FreshSealedRoot extends flash.display.MovieClip {
 public var Keys:Object;public var tfm:Object;public var Interface:Object;public var Statements:Object;
 public var auto_play:Boolean=false;public var auto_play_disable_on_move:Boolean=false;public var host_url:String="";
 public var current_map_code:String="";public var current_map_code_int:int=0;public var player_has_cheese:Boolean=false;
 public var current_round_code:int=1;public var round_start_time:int=0;public var current_map_xml:String="";
}
