import asyncio,threading,base64,hashlib,importlib.util,json,sys,tempfile,types,unittest,zlib
from pathlib import Path
from unittest.mock import AsyncMock,patch
from aiohttp import web,ClientSession
from aiohttp.test_utils import TestServer,TestClient
ROOT=Path(__file__).resolve().parents[2]/'DisneyClient'
pkg=types.ModuleType('cache_api');pkg.__path__=[str(ROOT/'api')];sys.modules[pkg.__name__]=pkg
common=types.ModuleType('cache_api.common');common.authorize=AsyncMock(return_value={'user_id':1,'level':1});sys.modules[common.__name__]=common
sys.modules.setdefault('infrastructure',types.ModuleType('infrastructure'))
def module(name):
 spec=importlib.util.spec_from_file_location('cache_api.'+name,ROOT/'api'/f'{name}.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
gh=module('github_routes');cache=module('route_cache')
def route(left=False):return [[dict(x=400,y=1100,vx=330,vy=0,frame=0,ml=left,mr=not left,jump=False,up=False),'walk',0],[0,'hole',100]]
def version(r):return hashlib.sha256(cache.payload(r).encode()).hexdigest()
class Clock:
 def __init__(self):self.now=1000
 def __call__(self):return self.now
class MemoryCache(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.clock=Clock();self.remote=types.SimpleNamespace(read_versioned=AsyncMock(return_value={'route':route(),'revision':'a'*40,'etag':'"a"'}),read=AsyncMock(return_value=({},None)))
  self.c=cache.RouteCache(self.remote,self.tmp.name,gh.validate_route,clock=self.clock)
 async def asyncTearDown(self):await self.c.close();self.tmp.cleanup()
 async def settle(self):
  tasks=list(self.c.inflight.values())
  if tasks:await asyncio.gather(*tasks,return_exceptions=True)
 async def test_download_memory_and_restart_disk_without_network(self):
  first=await self.c.get('@123');again=await self.c.get('@123');self.assertEqual(first['data'],again['data']);self.assertEqual(again['source'],'memory');self.remote.read_versioned.assert_awaited_once()
  fresh=cache.RouteCache(self.remote,self.tmp.name,gh.validate_route,clock=self.clock)
  try:self.assertEqual((await fresh.get('@123'))['source'],'disk');self.remote.read_versioned.assert_awaited_once()
  finally:await fresh.close()
 async def test_stale_returns_before_background_download_and_updates_next_read(self):
  await self.c.get('@123');self.clock.now+=61;gate=asyncio.Event()
  async def delayed(*args):await gate.wait();return {'route':route(True),'revision':'b'*40,'etag':'"b"'}
  self.remote.read_versioned.side_effect=delayed
  old=await asyncio.wait_for(self.c.get('@123'),.2);self.assertEqual(json.loads(old['data']),route());self.assertTrue(old['stale']);gate.set();await self.settle()
  self.assertEqual(json.loads((await self.c.get('@123'))['data']),route(True));self.assertEqual(self.c.entries['@123']['revision'],'b'*40)
 async def test_304_preserves_data_and_sends_previous_etag(self):
  await self.c.get('@123');self.clock.now+=61;self.remote.read_versioned.return_value={'unchanged':True}
  await self.c.get('@123');await self.settle();self.remote.read_versioned.assert_awaited_with('@123','"a"');self.assertEqual(self.c.stats['not_modified'],1);self.assertEqual(self.c.stats['downloads'],1)
 async def test_network_loss_retains_verified_disk(self):
  await self.c.get('@123');self.clock.now+=61;self.remote.read_versioned.side_effect=gh.CatalogError('offline')
  value=await self.c.get('@123');await self.settle();self.assertEqual(json.loads(value['data']),route());self.assertEqual(self.c.stats['remote_error'],1)
 async def test_missing_map_negative_cache_and_confirmed_deletion(self):
  self.remote.read_versioned.return_value=None
  self.assertIsNone(await self.c.get('@123'));self.assertIsNone(await self.c.get('@123'));self.remote.read_versioned.assert_awaited_once()
  self.clock.now+=31;await self.c.seed('@123',route(),checked=0);await self.c.get('@123');await self.settle();self.assertNotIn('@123',self.c.entries);self.assertFalse(self.c.path('@123').exists())
 async def test_concurrent_requests_share_one_download(self):
  gate=asyncio.Event()
  async def delayed(*args):await gate.wait();return {'route':route(),'revision':'a'*40}
  self.remote.read_versioned.side_effect=delayed;tasks=[asyncio.create_task(self.c.get('@123')) for _ in range(8)]
  await asyncio.sleep(.03);gate.set();values=await asyncio.gather(*tasks);self.assertEqual(len(values),8);self.remote.read_versioned.assert_awaited_once()
 async def test_fast_map_switch_cancelled_waiter_does_not_destroy_download(self):
  gate=asyncio.Event()
  async def delayed(code,*args):
   if code=='@123':await gate.wait()
   return {'route':route(code=='@456'),'revision':('a' if code=='@123' else 'b')*40}
  self.remote.read_versioned.side_effect=delayed;old=asyncio.create_task(self.c.get('@123'));await asyncio.sleep(.02);old.cancel()
  with self.assertRaises(asyncio.CancelledError):await old
  new=await self.c.get('@456');self.assertEqual(json.loads(new['data']),route(True));gate.set();await self.settle();self.assertEqual(json.loads((await self.c.get('@123'))['data']),route())
 async def test_corrupt_cache_is_not_executed(self):
  await self.c.seed('@123',route());path=self.c.path('@123');data=json.loads(path.read_text());data['route'][0][0]['x']=999;path.write_text(json.dumps(data));self.c.entries.clear();self.remote.read_versioned.side_effect=gh.CatalogError('offline')
  with self.assertRaises(gh.CatalogError):await self.c.get('@123')
 async def test_lru_and_disk_limits(self):
  self.c.memory_limit=2;self.c.disk_limit=3
  for n in range(1,7):await self.c.seed('@'+str(n),route())
  self.assertEqual(len(self.c.entries),2);self.assertEqual(len(list(Path(self.tmp.name).glob('*.json'))),3)
 async def test_disk_unavailable_still_uses_memory(self):
  with patch.object(self.c,'write_disk',side_effect=OSError('denied')):await self.c.seed('@123',route())
  self.assertEqual((await self.c.get('@123'))['source'],'memory');self.assertEqual(self.c.stats['disk_write_error'],1)
 async def test_old_response_cannot_overwrite_successful_save(self):
  gate=asyncio.Event()
  async def old(*args):await gate.wait();return {'route':route(),'revision':'a'*40}
  self.remote.read_versioned.side_effect=old;request=asyncio.create_task(self.c.get('@123'));await asyncio.sleep(.02);await self.c.seed('@123',route(True),'b'*40,authoritative=True);gate.set();await request
  self.assertEqual(json.loads((await self.c.get('@123'))['data']),route(True));self.assertEqual(self.c.read_disk('@123')['revision'],'b'*40)
 async def test_saved_route_wins_while_initial_disk_read_is_pending(self):
  entered=threading.Event();release=threading.Event()
  def slow_read(code):entered.set();release.wait(3);return None
  with patch.object(self.c,'read_disk',side_effect=slow_read):
   task=asyncio.create_task(self.c.get('@123'))
   try:
    self.assertTrue(await asyncio.to_thread(entered.wait,2))
    await self.c.seed('@123',route(True),'b'*40,authoritative=True);release.set()
    result=await task;self.assertEqual(json.loads(result['data']),route(True));self.remote.read_versioned.assert_not_awaited()
   finally:release.set();await asyncio.gather(task,return_exceptions=True)
 async def test_recent_warming_and_learned_successor_prefetch(self):
  await self.c.seed('@123',route());await self.c.seed('@456',route());self.c.entries.clear();await self.c.warm_recent();self.assertIn('@123',self.c.entries);self.assertIn('@456',self.c.entries)
  self.c.observe(1,'@123');self.c.observe(1,'@456');self.clock.now+=61;self.c.observe(1,'@123');await self.settle();self.assertGreaterEqual(self.c.stats['checks'],1)
class InitialBundle(unittest.IsolatedAsyncioTestCase):
 async def test_first_use_offline_reads_only_selected_validated_route(self):
  with tempfile.TemporaryDirectory() as tmp:
   folder=Path(tmp);bundle=folder/'bundle';bundle.mkdir();raw=(cache.payload(route())+'\n').encode();(bundle/'123.json').write_bytes(raw);(bundle/'index.json').write_text(json.dumps({'schema':1,'files':{'@123':{'sha256':hashlib.sha256(raw).hexdigest()}}}))
   remote=types.SimpleNamespace(read_versioned=AsyncMock(side_effect=gh.CatalogError('offline')),read=AsyncMock(return_value=({},None)))
   c=cache.RouteCache(remote,folder/'cache',gh.validate_route,bundle_folder=bundle)
   try:
    value=await c.get('@123');self.assertEqual(value['source'],'bundle');self.assertEqual(json.loads(value['data']),route());await asyncio.gather(*list(c.inflight.values()));self.assertEqual(c.stats['remote_error'],1)
   finally:await c.close()
 async def test_corrupt_bundle_rejected_and_removed_route_not_resurrected(self):
  with tempfile.TemporaryDirectory() as tmp:
   folder=Path(tmp);bundle=folder/'bundle';bundle.mkdir();raw=(cache.payload(route())+'\n').encode();(bundle/'123.json').write_bytes(raw);(bundle/'index.json').write_text(json.dumps({'schema':1,'files':{'@123':{'sha256':hashlib.sha256(raw).hexdigest()}}}))
   remote=types.SimpleNamespace(read_versioned=AsyncMock(return_value=None),read=AsyncMock(return_value=({},None)))
   c=cache.RouteCache(remote,folder/'cache',gh.validate_route,bundle_folder=bundle)
   try:
    self.assertIsNotNone(await c.get('@123'));await asyncio.gather(*list(c.inflight.values()));self.assertIsNone(await c.get('@123'));self.assertTrue(c.path('@123').with_suffix('.gone').exists())
   finally:await c.close()
   fresh=cache.RouteCache(remote,folder/'cache',gh.validate_route,bundle_folder=bundle)
   try:self.assertIsNone(await fresh.get('@123'))
   finally:await fresh.close()
   remote.read_versioned.return_value={'route':route(True),'revision':'b'*40}
   restored=cache.RouteCache(remote,folder/'cache',gh.validate_route,bundle_folder=bundle)
   try:
    self.assertEqual(json.loads((await restored.get('@123'))['data']),route(True));self.assertFalse(restored.path('@123').with_suffix('.gone').exists())
   finally:await restored.close()
   (bundle/'123.json').write_text('[]');(folder/'cache/123.gone').unlink(missing_ok=True)
   bad=cache.RouteCache(remote,folder/'cache',gh.validate_route,bundle_folder=bundle)
   try:self.assertIsNone(bad.read_bundle('@123'))
   finally:await bad.close()

class HttpCache(unittest.IsolatedAsyncioTestCase):
 async def test_real_http_etag_integrity_and_route_version(self):
  state={'route':route(),'requests':[]}
  async def contents(request):
   if state.get('down'):return web.Response(status=503)
   raw=(cache.payload(state['route'])+'\n').encode();sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();etag='"'+sha+'"';state['requests'].append(request.headers.get('If-None-Match',''))
   if request.headers.get('If-None-Match')==etag:return web.Response(status=304,headers={'ETag':etag})
   return web.json_response({'sha':sha,'encoding':'base64','content':base64.b64encode(raw).decode()},headers={'ETag':etag})
  app=web.Application();app.router.add_get('/contents/rotas-mapas/123.json',contents)
  with tempfile.TemporaryDirectory() as folder:
   async with TestServer(app) as server,ClientSession() as session:
    cat=gh.Catalog(session,api=str(server.make_url('')).rstrip('/'));clock=Clock();c=cache.RouteCache(cat,folder,gh.validate_route,clock=clock)
    try:
     value=await c.get('@123');self.assertEqual(value['checksum'],'%08x'%(zlib.crc32(value['data'].encode())&0xffffffff));clock.now+=61;await c.get('@123');await asyncio.gather(*list(c.inflight.values()));self.assertEqual(c.stats['not_modified'],1)
     state['route']=route(True);clock.now+=61;await c.get('@123');await asyncio.gather(*list(c.inflight.values()));self.assertEqual(json.loads((await c.get('@123'))['data']),route(True));self.assertEqual(len(state['requests']),3);state['down']=True;clock.now+=61;fallback=await c.get('@123');await asyncio.gather(*list(c.inflight.values()));self.assertEqual(json.loads(fallback['data']),route(True));self.assertEqual(c.stats['remote_error'],1)
    finally:await c.close()
 async def test_api_v2_disk_cache_and_small_unchanged_reply(self):
  with tempfile.TemporaryDirectory() as folder:
   remote=types.SimpleNamespace(read_versioned=AsyncMock(return_value={'route':route(),'revision':'a'*40}),read=AsyncMock(return_value=({},None)))
   app=web.Application();app['root']=folder;app['config']={'storage_allowed_levels':[1]};app.router.add_view('/github-routes',gh.GitHubRoutes)
   with patch.object(gh,'catalog',return_value=remote):
    async with TestClient(TestServer(app)) as client:
     first=await client.get('/github-routes?v=2&code=@123');data=await first.json();self.assertEqual(data['schema'],2);self.assertEqual(data['code'],'@123')
     again=await client.get('/github-routes?v=2&code=@123&since='+data['revision']);same=await again.json();self.assertTrue(same['unchanged']);self.assertNotIn('data',same);remote.read_versioned.assert_awaited_once();await app['github_route_cache'].close()
 async def test_bad_git_sha_is_rejected(self):
  cat=gh.Catalog(None,api='https://api.fixture.test');cat.request=AsyncMock(return_value=(200,{'encoding':'base64','content':base64.b64encode(json.dumps(route()).encode()).decode(),'sha':'f'*40},{}))
  with self.assertRaises(gh.CatalogError):await cat.read_versioned('@123')
if __name__=='__main__':unittest.main(verbosity=2)
