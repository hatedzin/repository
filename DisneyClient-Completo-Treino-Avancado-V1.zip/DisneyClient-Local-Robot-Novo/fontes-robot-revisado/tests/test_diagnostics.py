import importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import AsyncMock
from aiohttp import web
from aiohttp.test_utils import TestServer,TestClient
ROOT=Path(__file__).resolve().parents[2]/'DisneyClient'
package=types.ModuleType('review_diagnostics');package.__path__=[str(ROOT/'api')];sys.modules[package.__name__]=package
common=types.ModuleType('review_diagnostics.common');common.authorize=AsyncMock(return_value={'user_id':1});sys.modules[common.__name__]=common
spec=importlib.util.spec_from_file_location('review_diagnostics.diagnostics',ROOT/'api/diagnostics.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Diagnostics(unittest.IsolatedAsyncioTestCase):
 async def test_robot_logs_written_and_invalid_fields_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   app=web.Application();app['root']=Path(tmp)/'DisneyClient';app['root'].mkdir();app['diagnostics_rate']={};app.router.add_view('/client_diagnostics',m.Diagnostics)
   async with TestClient(TestServer(app)) as client:
    data=dict(event='robot',channel='client',phase='recover',map='@123',step='7',elapsed='1000',fps_x10='250',target_fps_x10='600',frame_ms='40',late_ms='15',error_px='12')
    response=await client.post('/client_diagnostics',data=data);self.assertEqual(response.status,200)
    record=json.loads((Path(tmp)/'logs-client/flash-diagnostics.jsonl').read_text());self.assertEqual(record['phase'],'recover');self.assertEqual(record['step'],7);self.assertNotIn('access_token',record);self.assertEqual(record['fps_x10'],250);self.assertEqual(record['frame_ms'],40)
    for field,value in [('phase','unknown'),('map','../../x'),('step','-1'),('fps_x10','NaN'),('frame_ms','-1'),('late_ms','3600001')]:
     invalid=dict(data);invalid[field]=value;response=await client.post('/client_diagnostics',data=invalid);self.assertEqual(response.status,400)
if __name__=='__main__':unittest.main(verbosity=2)
