package disney {import flash.display.MovieClip;public class RobotSuiteV3 {public static function attach(root:MovieClip):void{RobotControllerV3.attach(root);RouteRecorderV1.attach(root);}}}
