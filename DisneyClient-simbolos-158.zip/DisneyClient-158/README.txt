Atualizacao DisneyClient para a SWF 158 enviada

Instalacao (Python 3.11):
1. Feche os processos do DisneyClient e DisneyParser.
2. Extraia este ZIP em uma pasta separada.
3. No terminal dessa pasta, execute:
   py install.py "C:\caminho\DisneyClient-corrigido"
4. Inicie DisneyParser e o backend DisneyClient usando a configuracao que ja funcionava.
5. Entre pela pagina de login do DisneyClient. Nao abra tfm.swf diretamente.

O instalador salva os arquivos substituidos em backup-158-DATA e copia o mesmo jogo para os dois componentes. Seus tokens, credenciais, banco e configuracoes nao fazem parte deste ZIP e nao sao alterados.

Mudancas:
- 111 nomes de classes/propriedades extraidos da sua SWF 158, incluindo as duas rotinas de chat.
- Loader: metadado version 1.3 -> 1.7 para coincidir com a configuracao enviada.
- Parser usa snapshot local e valida SHA-256 da SWF. Arquivo errado ou snapshot incompleto resulta em HTTP 503, sem publicar simbolos antigos.
- Download automatico de outra versao desativado neste pacote. Ao atualizar o jogo novamente, e preciso regenerar o snapshot correspondente.
- O menu existente do DisneyClient continua sendo carregado pelo loader.

Verificacao:
py verify_update.py (requer aiohttp do projeto)
Sete testes passaram no ambiente de preparacao. As duas builds fornecidas produziram 111 simbolos cada. Isso verifica extracao e consistencia, nao confirma comportamento de cada funcao no jogo.

Limites exatos:
Nao foi realizado teste do Flash/AIR, login ou handshake com o servidor oficial. A compatibilidade e referente ao arquivo 158 fornecido, nao uma comprovacao de que e a versao atual do servidor em 2026.
A mensagem "Incorrect version" tambem aparece na rotina generica de desconexao antes da inicializacao do servidor. A correcao do metadado do loader e um problema separado; nao garante eliminar essa mensagem.
