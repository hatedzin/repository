# Python / test_update.py / Python 3.11 / DisneyParser snapshot validation
import asyncio, json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'payload/DisneyParser'))
from tfmparser.snapshot import load_snapshot
from tfmparser.parser import Parser
from tfmparser.chatmessage import ChatMessage
ROOT=Path(__file__).parent/'payload/DisneyParser'
class UpdateTests(unittest.TestCase):
 def test_matching_build(self):
  self.assertEqual(len(load_snapshot(ROOT/'keys.snapshot.json',ROOT/'tfm.swf')),111)
 def test_mismatch_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   wrong=Path(d)/'wrong.swf';wrong.write_bytes(b'CWS-not-the-game')
   with self.assertRaisesRegex(ValueError,'do not match'):load_snapshot(ROOT/'keys.snapshot.json',wrong)
 def test_partial_snapshot_rejected(self):
  data=json.loads((ROOT/'keys.snapshot.json').read_text());del data['symbols']['chat_message2']
  with tempfile.TemporaryDirectory() as d:
   target=Path(d)/'snapshot.json';target.write_text(json.dumps(data))
   with self.assertRaisesRegex(ValueError,'incomplete'):load_snapshot(target,ROOT/'tfm.swf')
 def test_parser_publishes_local_pair(self):
  parser=Parser();asyncio.run(parser.start());self.assertTrue(parser.ready);self.assertEqual(len(parser.fetched),111)
 def test_stale_data_cleared(self):
  parser=Parser();parser.fetched={'old':'value'};parser.output_swf='/nonexistent/tfm.swf'
  asyncio.run(parser.start());self.assertFalse(parser.ready);self.assertEqual(parser.fetched,{})
 def test_chat_signature_independent_of_register(self):
  lines=['class <q>[public]::Test extends <q>[public]::Object{','final  method <q>[public]::void <q>[public]::Message=(<q>[public]::String, <q>[public]::Boolean = false)(2 params, 1 optional)','getlocal r117']
  result=asyncio.run(ChatMessage().fetch(lines,'Test'));self.assertEqual(result['chat_message2'],'Message')
 def test_ambiguous_chat_not_published(self):
  lines=['class <q>[public]::Test extends <q>[public]::Object{']+['final  method <q>[public]::void <q>[public]::'+n+'=(<q>[public]::String, <q>[public]::Boolean = false)(2 params, 1 optional)' for n in ['First','Second']]
  self.assertNotIn('chat_message2',asyncio.run(ChatMessage().fetch(lines,'Test')))
if __name__=='__main__':unittest.main()
