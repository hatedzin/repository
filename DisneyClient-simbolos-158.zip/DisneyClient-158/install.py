# Python / install.py / Python 3.11 / existing DisneyClient-corrigido project
from pathlib import Path
import datetime, shutil, sys
source = Path(__file__).resolve().parent / "payload"
target = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
if not (target / "DisneyClient/config.json").is_file() or not (target / "DisneyParser/main.py").is_file():
    raise SystemExit('Usage: py install.py "C:/path/DisneyClient-corrigido"')
backup = target / ("backup-158-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
for item in source.rglob("*"):
    if not item.is_file():
        continue
    relative = item.relative_to(source)
    dest = target / relative
    if dest.exists():
        saved = backup / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dest, saved)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(item, dest)
dest = target / "DisneyClient/tfm.swf"
if dest.exists():
    saved = backup / "DisneyClient/tfm.swf"
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dest, saved)
shutil.copy2(target / "DisneyParser/tfm.swf", dest)
print("Installed. Backup:", backup)
print("Start DisneyParser and DisneyClient, then use the client's login page.")
