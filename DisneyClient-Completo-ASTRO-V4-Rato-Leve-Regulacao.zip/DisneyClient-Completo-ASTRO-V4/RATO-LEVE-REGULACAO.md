# ASTRO V4 — regulacao gradual do Rato leve

Feche o Flash Player e encerre o inicializador antigo com Ctrl+C. Extraia em uma pasta nova e execute INICIAR_TUDO.bat.
Build: astro-v4-rato-leve-regulacao-gradual-v1.

Jogador > Rato leve: o slider agora tem campo numerico de 0 a 100%.
Setas ajustam 1%; Shift+setas ajustam 10%; Home=0%; End=100%.
0% preserva o movimento original. A compensacao so atua enquanto o rato tem queijo.
O alvo e uma fracao da diferenca entre a velocidade original atual e a referencia normal de 100/30 unidades fisicas do cliente. 50% cobre metade dessa diferenca, 100% cobre toda a diferenca. A nova rotina nao usa mais o alvo antigo de 1.5x da referencia com intensidade 50%.
A transicao e gradual e usa tempo decorrido, em vez de depender do numero de frames. Movimento vertical, impulsos opostos e velocidades ja acima da referencia ficam preservados.

A compensacao e restaurada ao desligar, morrer, retirar o personagem do mapa, trocar personagem/corpo/rodada, ficar sem queijo ou pausar por Robot, gravacao ou Auto Win. A restauracao nao sobrescreve um impulso novo aplicado pelo jogo.

Nao e um bypass. Uma mudanca local de movimento ainda pode ser rejeitada pelo servidor. Esta entrega nao garante ausencia de morte ou DC em salas online.

Auto Win, Auto morte pelo chat com Tempo (ms), contas, keys, parser e skins preservados.
Testes: 19 verificacoes AS3 da regulacao, 24 de FPS e 23 de Auto morte/chat executadas no Ruffle com objetos e rede simulados. A resposta em sala real no Flash Player Windows nao foi validada.
