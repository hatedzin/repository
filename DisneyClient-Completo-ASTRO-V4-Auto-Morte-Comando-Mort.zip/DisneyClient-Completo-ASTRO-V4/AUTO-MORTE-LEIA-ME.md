# ASTRO V4 — Auto morte pelo comando /mort

Feche o Flash Player e encerre o inicializador anterior com Ctrl+C. Extraia o ZIP numa pasta nova e execute INICIAR_TUDO.bat dessa pasta. O parser precisa ser reiniciado nesta versao para resolver o metodo nativo do chat.
Build: astro-v4-auto-morte-ms-native-mort-v1.

Farm > abaixo de Opcoes desligadas > Auto morte > Tempo (ms).
5000 ms = 5 segundos. A faixa permanece 500 a 600000 ms.
Ao vencer o temporizador, o cliente executa o mesmo despachante nativo que recebe /mort no chat. O metodo e identificado pelo parser, sem nomes obfuscados fixos e sem envio direto do pacote mort.
O aviso /mort solicitado confirma que o metodo foi chamado; nao afirma que o servidor ja confirmou a morte.

Auto Win e Farm Time mantidos. O novo temporizador e independente.
Se aparecer /mort nativo indisponivel, confira se o parser anterior foi encerrado e abra a nova instalacao.

Testes: descoberta do despachante no bytecode do jogo fornecido; rejeicao de simbolo ausente; 21 verificacoes AS3 de tempo/ms e chamada nativa sem usar o envio direto antigo; 50 de regressao de Auto Win e Rato leve. Rede simulada nos testes. A resposta em sala real no Flash Player Windows ainda precisa ser confirmada.
