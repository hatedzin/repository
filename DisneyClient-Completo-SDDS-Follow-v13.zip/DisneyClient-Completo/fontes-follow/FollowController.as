// ActionScript 3 / FollowController.as / Flash Player 10.3+ / room-local nickname following with native movement keys
package disney {
 import flash.display.MovieClip;import flash.display.DisplayObject;import flash.geom.Point;import flash.events.Event;import flash.events.KeyboardEvent;import flash.text.TextField;import flash.text.TextFieldType;import flash.text.TextFormat;import flash.utils.Dictionary;import flash.utils.getTimer;
 public class FollowController {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var targetName:String="";private var hadTargetCheese:Boolean=false;private var roundFinished:Boolean=false;private var cheeseNotice:Boolean=false;private var owner:Object;private var left:Boolean=false;private var right:Boolean=false;private var jumping:Boolean=false;private var hud:TextField;private var state:String="";private var focused:Boolean=true;private var needsSync:Boolean=true;private var bodyOwner:Object;private var roundOwner:Object;private var roundCode:String="";private var retryAt:int=0;private var diagnostics:FollowDiagnostics;private var frameCount:int=0;private var syncCount:int=0;private var upCount:int=0;private var downCount:int=0;private var nativeOwner:Object;private var nativeKnown:Boolean=false;private var nativeMode:Boolean=false;private var sampleAt:int=0;private var pausePhase:String="";private var lastData:Object={};
  public function FollowController(value:MovieClip){root=value;diagnostics=new FollowDiagnostics(value);diagnostics.emit("ready");}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var follow:FollowController=new FollowController(value);instances[value]=follow;
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,follow.keyDown,true,2000);value.stage.addEventListener(KeyboardEvent.KEY_DOWN,follow.keyDown,false,2000);
   value.stage.addEventListener(Event.ENTER_FRAME,function(event:Event):void{follow.update();});
   value.stage.addEventListener(Event.ACTIVATE,function(event:Event):void{follow.focused=true;});
   value.stage.addEventListener(Event.DEACTIVATE,function(event:Event):void{follow.focused=false;follow.release();follow.notice("Follow: pausado ao perder foco");});
  }
  public function keyDown(event:KeyboardEvent):void{
   var input:TextField=root.stage.focus as TextField;
   if(event.keyCode==13 && input && input.type==TextFieldType.INPUT && /^\s*\/follow(?:\s|$)/i.test(input.text)){
    var requested:String=input.text;input.text="";root.stage.focus=root.stage;command(requested);update();event.preventDefault();event.stopImmediatePropagation();return;
   }
   if(event.keyCode==27 && targetName!="")stop("Follow: parado");
  }
  public function command(text:String):Boolean{
   if(!/^\s*\/follow(?:\s|$)/i.test(text))return false;
   var argument:String=text.replace(/^\s*\/follow\s*/i,"").replace(/\s+$/g,"");
   if(argument=="" || /^(?:off|stop|parar)$/i.test(argument)){stop("Follow: parado");return true;}
   if(!/^[^\s#]+#\d{4}$/.test(argument)){notice("Uso: /follow Nome#0000 | /follow off");return true;}
   var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
   if(local && String(local[k.player_name]).toLowerCase()==argument.toLowerCase()){stop("Follow: escolha outro jogador");return true;}
   release();hadTargetCheese=false;roundFinished=false;cheeseNotice=false;targetName=argument.toLowerCase();owner=null;root["auto_play"]=false;needsSync=true;retryAt=0;localChat("Boas-vindas do Sdds Menu! Você usou o comando para seguir o player "+argument);diagnostics.emit("start",0,"search");sampleAt=0;notice("Follow v13: procurando "+argument+" nesta sala");return true;
  }
  private function localChat(text:String):void{
   try{var k:Object=root["Keys"];var game:Object=root["tfm"];if(k && game && k.chat_message && game[k.chat_message] is Function){var safe:String=text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");game[k.chat_message]("<VP>"+safe+"</VP>");}}catch(ignored:Error){}
  }
  public function stop(message:String="Follow: parado"):void{release();targetName="";owner=null;diagnostics.emit("stop",0,"idle");notice(message);}
  private function notice(message:String):void{
   state=message;if(!root.stage)return;if(!hud){hud=new TextField();hud.name="sddsFollowStatus";hud.defaultTextFormat=new TextFormat("_sans",12,0xD7F5FF);hud.width=540;hud.height=22;hud.background=true;hud.backgroundColor=0x141B2A;hud.selectable=false;hud.mouseEnabled=false;root.stage.addChild(hud);}hud.x=8;hud.y=Math.max(60,root.stage.stageHeight-48);hud.text=message+(diagnostics ? " | diag: "+diagnostics.status : "");
  }
  private function key(code:uint,down:Boolean):void{if(code==38){if(down)upCount++;else downCount++;}if(root.stage)root.stage.dispatchEvent(new KeyboardEvent(down ? KeyboardEvent.KEY_DOWN : KeyboardEvent.KEY_UP,true,false,0,code));}
  private function movement(l:Boolean,r:Boolean,j:Boolean):void{
   if(left!=l){key(37,l);left=l;}if(right!=r){key(39,r);right=r;}if(jumping!=j){key(38,j);jumping=j;}
  }
  private function release():void{
   movement(false,false,false);
   if(nativeKnown && nativeMode && nativeOwner){try{var k:Object=root["Keys"];if(k && k.jump && nativeOwner[k.jump] is Function)nativeOwner[k.jump](false);}catch(ignored:Error){}}
   nativeOwner=null;nativeKnown=false;nativeMode=false;
  }
  private function applyJumpMode(local:Object,k:Object,mode:Boolean,available:Boolean):void{
   if(!available || !k.jump || !(local[k.jump] is Function))return;
   if(nativeOwner!==local || !nativeKnown || nativeMode!=mode || (local.hasOwnProperty(String(k.is_jumping)) && Boolean(local[k.is_jumping])!=mode)){local[k.jump](mode);nativeOwner=local;nativeKnown=true;nativeMode=mode;}
  }
  private function reportPause(message:String,phase:String,now:int):void{
   notice(message);if(pausePhase!=phase || now>=sampleAt){pausePhase=phase;sampleAt=now+3000;diagnostics.emit("paused",0,phase,stats());}
  }
  private function stats():Object{
   var data:Object={frame_count:frameCount,sync_count:syncCount,up_count:upCount,down_count:downCount};for(var name:String in lastData)data[name]=lastData[name];return data;
  }
  public function update(now:int=-1):void{
   if(now<0)now=getTimer();diagnostics.watch(now);
   if(targetName=="" || !focused)return;
   if(diagnostics.closed){release();reportPause("Follow v13: conexao encerrada","observe",now);return;}
   if(now<retryAt)return;var phase:String="local";
   try{
    var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
    if(local!==owner){release();owner=local;needsSync=true;}
    if(!local || (k.is_dead && local[k.is_dead])){needsSync=true;release();reportPause("Follow v13: aguardando renascer","local",now);return;}
    if(root.stage.focus is TextField && TextField(root.stage.focus).type==TextFieldType.INPUT){release();reportPause("Follow v13: pausado enquanto digita","input",now);return;}
    var found:Object=null;var list:Object=game[k.player_list];if(list)for each(var player:Object in list){if(player && String(player[k.player_name]).toLowerCase()==targetName){found=player;break;}}
    if(!found || found===local || (k.is_dead && found[k.is_dead]) || (found.hasOwnProperty("parent") && !found.parent)){release();reportPause("Follow v13: aguardando alvo nesta sala","target",now);return;}
    var body:Object=k.player_physics ? local[k.player_physics] : null;
    var round:Object=k.map_class && k.map_instance ? k.map_class[k.map_instance] : null;
    var roundNumber:Object=round && k.bot_map_code_object ? round[k.bot_map_code_object] : null;
    var code:String=roundNumber && k.bot_map_code_value ? String(roundNumber[k.bot_map_code_value]) : "";
    if(body!==bodyOwner || round!==roundOwner || code!=roundCode){needsSync=true;hadTargetCheese=false;roundFinished=false;cheeseNotice=false;release();bodyOwner=body;roundOwner=round;roundCode=code;}
    if(!body || (k.player_clip && !local[k.player_clip])){release();reportPause("Follow v13: aguardando rato pronto na rodada","body",now);return;}
    if(k.move_class && k.move_free && !k.move_class[k.move_free]){release();reportPause("Follow v13: aguardando liberacao da rodada","round",now);return;}
    if(!k.player_cheese || !local.hasOwnProperty(String(k.player_cheese)) || !found.hasOwnProperty(String(k.player_cheese))){release();reportPause("Follow: estado do queijo indisponivel","target",now);return;}
    var ownCheese:Boolean=Boolean(local[k.player_cheese]);var targetCheese:Boolean=Boolean(found[k.player_cheese]);
    if(hadTargetCheese && !targetCheese)roundFinished=true;
    hadTargetCheese=targetCheese;
    if(roundFinished){release();reportPause("Follow: alvo perdeu o queijo/encerrou; aguarde nova rodada","target",now);return;}
    if(targetCheese && !ownCheese){release();if(!cheeseNotice){localChat("Sdds Menu: Follow pausado. Colete o queijo normalmente para continuar seguindo.");cheeseNotice=true;}reportPause("Follow: colete o queijo para continuar","target",now);return;}
    cheeseNotice=false;
    phase="position";var point:Point=new Point(Number(found.x),Number(found.y));
    if(found is DisplayObject && local is DisplayObject){
     var source:DisplayObject=found as DisplayObject;var destination:DisplayObject=local as DisplayObject;
     if(!source.parent || !destination.parent){release();reportPause("Follow v13: aguardando mapa","map",now);return;}
     point=destination.parent.globalToLocal(source.parent.localToGlobal(point));
    }
    var x:Number=point.x;var y:Number=point.y;
    if(!isFinite(x) || !isFinite(y))throw new Error("Coordenadas indisponiveis");
    if(!body || !k.bot_set_position || !(body[k.bot_set_position] is Function))throw new Error("Fisica indisponivel",2201);
    var vectorClass:Class=k.app_domain.applicationDomain.getDefinition(String(k.b2vec2)) as Class;
    if(!vectorClass)throw new Error("Vetor indisponivel",2202);
    phase="velocity";var vx:Number=0;var vy:Number=0;var remoteBody:Object=k.player_physics ? found[k.player_physics] : null;
    var velocity:Object=remoteBody && k.physics_state ? remoteBody[k.physics_state] : null;
    if(velocity && k.physics_state_vx && k.physics_state_vy){vx=Number(velocity[k.physics_state_vx]);vy=Number(velocity[k.physics_state_vy]);}
    else{release();reportPause("Follow v13: velocidade nativa indisponivel","velocity",now);return;}
    if(velocity && found is DisplayObject && local is DisplayObject){
     var origin:Point=destination.parent.globalToLocal(source.parent.localToGlobal(new Point(0,0)));
     var endpoint:Point=destination.parent.globalToLocal(source.parent.localToGlobal(new Point(vx*30,vy*30)));
     vx=(endpoint.x-origin.x)/30;vy=(endpoint.y-origin.y)/30;
    }
    if(!isFinite(vx) || !isFinite(vy))throw new Error("Velocidade indisponivel",2203);
    var targetLeft:Boolean=k.player_moving_left ? Boolean(found[k.player_moving_left]) : vx < -0.05;
    var targetRight:Boolean=k.player_moving_right ? Boolean(found[k.player_moving_right]) : vx > 0.05;
    var targetJump:Boolean=false;
    if(k.is_jumping && found.hasOwnProperty(String(k.is_jumping)) && found[k.is_jumping] is Boolean)targetJump=Boolean(found[k.is_jumping]);
    // The replicated native mode is not an UP key: never add a physical jump impulse.
    movement(targetLeft,targetRight,false);
    lastData={x:Math.round(Number(local.x)),y:Math.round(Number(local.y)),target_x:Math.round(x),target_y:Math.round(y),vx:Math.round(vx*1000),vy:Math.round(vy*1000),jump_state:targetJump ? 1 : 0,alive:1,symbol_available:k.is_jumping ? 1 : 0};
    if(k.is_down){var down:Boolean=Boolean(found[k.is_down]);if(Boolean(local[k.is_down])!=down){local[k.is_down]=down;var crouch:String=down ? k.crouch : k.crouch2;if(crouch && local[crouch] is Function)local[crouch](local[k.static_side]);}}
    phase="sync";if(needsSync){
     if(!k.packet_handler_class || !k.packet_handler || !(k.packet_handler_class[k.packet_handler] is Function))throw new Error("Teleport nativo indisponivel",2206);
     k.packet_handler_class[k.packet_handler](LegacyOptionsV5.encodePosition(Math.round(x),Math.round(y)));needsSync=false;syncCount++;diagnostics.emit("initial_sync",0,"sync",stats());
    }
    if(body[k.bot_set_position](new vectorClass(x/30,y/30),0)===false)throw new Error("Fisica bloqueada",2204);
    var localVelocity:Object=body[k.physics_state];if(!localVelocity)throw new Error("Vetor local indisponivel",2205);
    localVelocity[k.physics_state_vx]=vx;localVelocity[k.physics_state_vy]=vy;local.x=x;local.y=y;
    applyJumpMode(local,k,targetJump,Boolean(k.is_jumping) && found.hasOwnProperty(String(k.is_jumping)) && found[k.is_jumping] is Boolean);frameCount++;pausePhase="active";
    if(now>=sampleAt){sampleAt=now+3000;diagnostics.emit("sample",0,"active",stats());}
    notice("Follow v13: copia nativa | "+targetName+(k.is_jumping ? " | modo de salto" : " | modo indisponivel"));

   }catch(error:Error){release();retryAt=now+500;diagnostics.emit("error",error.errorID,phase,stats());notice("Follow v13: falha local #"+error.errorID+" | "+phase);}
  }
 }
}
