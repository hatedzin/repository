@rem Batch / CRIAR_KEY.bat / Windows CMD / client admin with required project files
@echo off
setlocal
cd /d "%~dp0"
if not exist "DisneyClient\database.py" goto falta_projeto
if not exist "DisneyClient\.env" goto falta_env
if exist ".client-runtime\Scripts\python.exe" goto pronto
where py >nul 2>&1
if errorlevel 1 goto usar_python
py -3 -m venv ".client-runtime"
if errorlevel 1 goto fim
goto pronto
:usar_python
python -m venv ".client-runtime"
if errorlevel 1 goto fim
:pronto
".client-runtime\Scripts\python.exe" -m pip install --disable-pip-version-check -r "ADMIN_REQUIREMENTS.txt"
if errorlevel 1 goto fim
cd /d "%~dp0DisneyClient"
echo Digite a SENHA usada para gerar ADMIN_PASSWORD_HASH, nao o hash.
"..\.client-runtime\Scripts\python.exe" admin.py create-key --days 30 --level GOLD_II --max-activations 1
goto fim
:falta_projeto
echo ERRO: Extraia todas as pastas e arquivos do ZIP juntos, ao lado de INICIAR_CLIENT.bat.
goto fim
:falta_env
echo ERRO: Falta DisneyClient\.env. Extraia este pacote na pasta do client existente, ao lado de INICIAR_CLIENT.bat.
:fim
echo.
pause
