ROBOT - REPRODUCAO SEM TELEPORTE - 01/11/2026
Esta atualizacao e para o DisneyClient-Follow (1).zip enviado. Altera o Robot (Autoplay/F2), nao a movimentacao do comando /follow nem a reproducao gerenciada do AutoBest.

INSTALAR
Feche o Adobe Flash e o iniciador da VPS. Copie o conteudo da pasta DisneyClient-Completo deste ZIP para a sua pasta DisneyClient-Completo existente, aceitando substituir os arquivos. Preserve DisneyClient/.env e toda a pasta DisneyClient/public/rotas. Reinicie o iniciador e gere uma URL nova para abrir no Adobe. BUILD-ID: ASTRO-ROBOT-SEM-TELEPORTE-V2-2026-11-01.

CORRECOES
O Robot deixou de aplicar posicoes gravadas na fisica/na imagem e de chamar o sincronismo inicial que reposicionava o jogador. X/Y agora servem apenas de referencia para conferir a rota. A reproducao aplica a direcao, o estado/frame nativo de pulo e a velocidade assinada gravada no vetor real da fisica. Nao duplica o pulo com uma tecla sintetica adicional. Os pequenos deslocamentos e pausas aleatorias ficam desligados por padrao.
Trocar de janela nao desliga nem pausa o Robot. Ao digitar em um campo do Flash com a janela ativa, ele libera os controles e suspende o relogio da rota; sair do campo retoma os estados salvos. Atrasos grandes de renderizacao alongam o relogio, sem acumular uma rajada de movimentos antigos. Estados vencidos normais sao processados na ordem gravada.
Se for ativado longe do inicio (>96px) ou se o percurso divergir muito (>160px), o Robot libera os controles e aguarda renascer. Ele nao tenta corrigir a posicao por teleporte. Ative no inicio/renascimento de um mapa com rota salva. O estado aparece na aba Robot.
Corrigido tambem o aviso falso de Follow pausado ao perder foco quando o Follow ja estava desligado. Follow ativo continua com seu comportamento anterior de pausa ao perder foco.
Backend, IP da VPS, rotas, musica, visual e configuracoes existentes foram preservados. Nao houve instalacao remota na VPS.

VERIFICACAO E LIMITES
47 verificacoes Robot no AVM2/Ruffle, incluindo movimento sem escritas de posicao, pulo/velocidade, foco, edicao, atraso, espelhamento, divergencia, 120 renascimentos e #1056. Carregamento HTTP real de uma rota por mapa; 2359 entradas e 179813 passos validados. Mais 31 Follow, 18 visual, 32 Fly, 37 AutoBest e 37 interface: 202 verificacoes no total. Bytecode/pilha/escopo aprovados. As fontes originais recompilaram uma SWF identica a enviada antes da correcao, confirmando a base utilizada.
Esses testes usam objetos de jogo simulados. Falta validar no Adobe/VPS e no mapa real; gravacoes antigas podem divergir da fisica atual. Quando isso ocorre, a opcao segura desta versao e esperar renascer, sem forcar coordenadas ou vitoria.

--- DOCUMENTACAO ANTERIOR (HISTORICO) ---
ATUALIZAÇÃO MÚSICA: !p no SERVER abre o mini player. É obrigatório atualizar backend e instalar yt-dlp/FFmpeg. Consulte MUSICA-YOUTUBE-LEIA-ME.txt.

ATUALIZAÇÃO MÚSICA: !p no SERVER abre o mini player. É obrigatório atualizar backend e instalar yt-dlp/FFmpeg. Consulte MUSICA-YOUTUBE-LEIA-ME.txt.

ATUALIZAÇÃO INTERFACE (UPLOAD 8): Follow > Players, avisos locais no SERVER e opacidade do menu. Veja INTERFACE-PLAYERS-SERVER-LEIA-ME.txt e fontes-interface/VALIDACAO.json. Movimentação da base preservada.

ATUALIZAÇÃO FOLLOWAUTOBEST: consulte FOLLOWAUTOBEST-LEIA-ME.txt para o novo comando. Cinco fixtures; 157 verificações automatizadas em simulação, sem login no servidor real.

ATUALIZAÇÃO Y/TOCA: Fly agora usa Y e os controladores bloqueiam movimento após vitória local. Esta entrega restaura a base 02:49 e adiciona Fly. Consulte FLY-E-BASE-0249-LEIA-ME.txt. Anti-DC AOB: zero correspondências, nenhum patch aplicado.

ATUALIZAÇÃO: esta entrega restaura a base 02:49 e adiciona Fly. Consulte FLY-E-BASE-0249-LEIA-ME.txt. Anti-DC AOB: zero correspondências, nenhum patch aplicado.

ASTRO MENU — VISUAL ATUALIZADO E ROTAS SEM INTERPOLACAO

VISUAL
Tema escuro com contraste maior, destaque verde-agua, marca ASTRO no painel,
ASTRO MENU fixo no topo e botao Menu centralizado. A animacao RGB antiga nao
e mais iniciada. O painel se ajusta ao tamanho da janela e continua arrastavel.
Botoes de abas, fechamento e abertura preservam os eventos originais.
Campos numericos/texto continuam editaveis, com bordas e cores legiveis.

A aba Bot passa a se chamar Robot. A area foi reorganizada: ativacao, parada
por tecla, status com duas linhas, REC/SAVE/DELETE e lista de mapas. O antigo
campo Delay reduzido e o PREVIEW aposentado nao aparecem. O recorte interno
antigo foi removido dessa area; o recorte externo da janela e a rolagem foram
preservados. Ao trocar de aba, a rolagem retorna ao inicio.

SEM INTERPOLACAO
A funcao followFrame e o calculo de coordenadas intermediarias foram removidos
do controlador. Posicao fisica e visual so recebem a coordenada do registro
walk quando vence seu delay. Entre registros, a fisica e as teclas nativas
continuam funcionando; o rato nao e congelado na ultima posicao.
Mantem o mesmo NativeMotion.followSample compartilhado com /follow, sem
sobrescrever VX/VY ou impor frame gravado. Microajustes e microparadas pedidos
anteriormente permanecem nos trechos elegiveis. Nenhum dado do JSON foi alterado.

OUTRAS GARANTIAS DE ESCOPO
Robot antigo permanece retirado (23 corpos inertes, duas inscricoes removidas,
dez leituras de flags antigas eliminadas). Toca depende da confirmacao nativa,
sem pacotes forcados de coleta/vitoria/morte. Rodadas e renascimentos continuam
reiniciando o controlador. Foco/edicao de texto suspendem as teclas e o relogio.
Chat, emoji, login, protocolo e /follow foram preservados.

TESTES
43 verificacoes Robot, 27 Follow e 17 visuais/interacao no Ruffle. Verificou
que nenhuma coordenada e antecipada/interpolada, que os botoes mantem callbacks,
campos preservam valores/tipo de edicao, rolagem funciona e trocar de aba a zera.
Verificador do SWF exige ausencia de followFrame, mesmo driver no Follow/Robot,
corpos legados inertes e limites de pilha/escopo validos.
2359 entradas e 179813 passos do JSON foram lidos/validados.
A previa visual usa componentes simulados com o MenuBootstrap real em Ruffle;
nao e uma captura de partida autenticada. A validacao no Adobe/VPS e pendente.
Nao se afirma que esta mudanca resolva o DC do servidor.

FONTES / COMPILAR
fontes-visual/AstroVisual.as e a fonte canonica do visual; a copia em fontes-robot
e gerada pelo build. RoutePlayer.as em fontes-autoplay e a fonte do Robot.
python fontes-robot/build.py --ffdec /caminho/ffdec
Requer Python, Java21 e FFDec26.4.0 oficial. Nunca sobrescreva loader-base.swf.
RUFFLE_DIR=/caminho/ruffle node fontes-robot/run_tests.cjs
Testes: Node/Playwright/Chromium/Ruffle0.7.1. TEST_CASE=visual permite repetir
somente a verificacao visual; VISUAL_SCREENSHOT define o caminho da captura.

INSTALAR
Feche Flash e iniciador; substitua o pacote preservando sua .env, reinicie
INICIAR_CLIENT.bat e gere uma URL nova. IP mantido: 207.180.3.127:8080.
