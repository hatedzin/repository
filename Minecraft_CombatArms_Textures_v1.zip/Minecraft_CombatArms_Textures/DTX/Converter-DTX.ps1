﻿param(
    [Parameter(Mandatory=$true)] [string]$Converter
)
$ErrorActionPreference = 'Stop'
$converterPath = (Resolve-Path -LiteralPath $Converter).Path
$packRoot = Split-Path -Parent $PSScriptRoot
$destRoot = Join-Path $PSScriptRoot 'Converted'
$folders = @('512x512', '1024x512', '128x256', '256x256')
$converted = 0
$failed = @()
foreach ($folder in $folders) {
    $sourceDir = Join-Path $packRoot $folder
    $targetDir = Join-Path $destRoot $folder
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
    foreach ($sourceFile in (Get-ChildItem -LiteralPath $sourceDir -Filter '*.tga' -File)) {
        $targetFile = Join-Path $targetDir ($sourceFile.BaseName + '.dtx')
        # Write to a temporary path so a failed conversion cannot be mistaken for a complete DTX.
        $temporaryFile = $targetFile + '.pending.dtx'
        if (Test-Path -LiteralPath $targetFile) {
            throw "Arquivo de destino ja existe: $targetFile. Escolha outra pasta ou remova a conversao antiga explicitamente."
        }
        if (Test-Path -LiteralPath $temporaryFile) {
            throw "Conversao pendente encontrada: $temporaryFile. Verifique antes de repetir."
        }
        try {
            & $converterPath '-tga2dtx' $sourceFile.FullName $temporaryFile
            if ($LASTEXITCODE -ne 0) { throw "dtxutil retornou $LASTEXITCODE" }
            if (!(Test-Path -LiteralPath $temporaryFile)) { throw 'Conversor nao criou o arquivo' }
            if ((Get-Item -LiteralPath $temporaryFile).Length -le 164) { throw 'Arquivo pequeno demais para ser um DTX valido' }
            Move-Item -LiteralPath $temporaryFile -Destination $targetFile
            $converted++
        } catch {
            $failed += "$($sourceFile.Name): $($_.Exception.Message)"
            if (Test-Path -LiteralPath $temporaryFile) { Remove-Item -LiteralPath $temporaryFile }
        }
    }
}
Write-Host "$converted texturas convertidas em $destRoot"
if ($failed.Count -gt 0) {
    $failed | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'conversion-errors.txt') -Encoding UTF8
    throw "$($failed.Count) conversoes falharam. Consulte conversion-errors.txt."
}
Write-Host 'Conversao terminada. Abra os DTX no seu DEdit/DtxView e confira dimensoes, mipmaps e alpha.'
