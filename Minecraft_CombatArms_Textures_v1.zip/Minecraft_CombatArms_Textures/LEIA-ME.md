# Minecraft Combat Arms Textures — 1.0

80 texturas/variantes planas de pixel art original inspirada em materiais clássicos
Minecraft. Não foram extraídas texturas do jogo. Os arquivos de produção não têm
perspectiva, texto, marcas d'água ou espaço externo ao canvas.

## Organização

- `512x512/`: terrenos, alvenaria, madeiras, metais, concreto/lã e faces de blocos.
- `1024x512/`: 12 painéis com duas repetições completas do mesmo material, sem esticar.
- `128x256/`: portas, escada, grades, janela e placa sem texto.
- `256x256/`: folhas, vidro, alçapão, minérios, glowstone e lâmpadas.
- `Transparent/`: cópias PNG/TGA das dez texturas com alpha real para acesso fácil.
- `DTX/`: instruções e script de conversão usando seu `dtxutil.exe`; não contém DTX prontos.
- `Preview/`: contato com todos os materiais e exemplos de repetição 3×3.

Cada imagem de produção é um material individual. As prévias são apenas catálogos;
não são atlas para importar como uma textura de jogo.

## Formatos

Cada uma das 80 texturas tem PNG e TGA não comprimido. Materiais opacos têm também
BMP RGB de 24 bits. Os transparentes usam PNG RGBA e TGA de 32 bits: BMP antigo
não é usado para transportar alpha. Cores de fundo dos pixels transparentes não
substituem o canal alpha. O quadriculado aparece SOMENTE na prévia do catálogo.

Resoluções são exatamente 512×512, 1024×512, 128×256 ou 256×256. O desenho nasce
numa grade pixelada de 32×32 por face de bloco (32×64 para portas) e é rasterizado
por vizinho mais próximo. "HD" aqui descreve a resolução de entrega com pixels
crispados; não se trata de detalhe fotográfico ou albedo de alta frequência.

## Aplicação e escala

Comece usando 64 unidades LithTech por bloco, ajustando à escala do seu projeto.

| Imagem | Área de mundo sugerida | UV |
|---|---|---|
| 512×512 | 1×1 bloco | uma imagem por face |
| 1024×512 | 2×1 blocos | uma imagem cobrindo toda essa área |
| 128×256 | 1×2 blocos | uma imagem por porta/elemento vertical |
| 256×256 | 1×1 bloco | uma imagem por face/detalhe |

A resolução menor de um detalhe não significa que o objeto deve ter metade do
tamanho físico. Mantenha os pixels de desenho na mesma escala por bloco. Os painéis
1024×512 repetem duas vezes o material de 512×512, preservando a proporção.

Blocos com faces próprias:
- grama: `grass_top` acima, `grass_side` nas laterais, `dirt` abaixo;
- tronco: `oak_log_top` nas pontas e `oak_log_side` no comprimento;
- TNT: `tnt_top`, `tnt_side`, `tnt_bottom` (sem letras, conforme o pedido);
- bancada: `crafting_table_top`, `crafting_table_front`, `crafting_table_side`;
- fornalha: `furnace_front` ou `furnace_front_lit`, `furnace_side`, `furnace_top`.

Não acompanham geometria, colisão, entidades de porta ou animação: são imagens.

## Repetição contínua

O manifesto indica `wrap_u` e `wrap_v` por arquivo, e a validação compara exatamente
as bordas opostas nos eixos declarados. Os materiais de superfície e painéis são
periódicos nos dois eixos; há prévias 3×3 para conferir a continuidade visual.
A repetição do desenho ainda pode ser percebida em superfícies extensas.

`grass_side` tem grama em cima e terra embaixo: repete horizontalmente; aplicar
repetição vertical criaria faixas de grama. `grass_side_seamless` é uma alternativa
periódica nos dois eixos para paredes extensas. `tnt_side` também é uma face
orientada, não um piso genérico. Portas, alçapão, janela e placa são elementos
isolados; mapeie uma imagem no elemento, sem exigir repetição em todos os eixos.
A escada pode ser repetida verticalmente. Essas distinções preservam o desenho
funcional dos elementos em vez de alterar sua aparência apenas para igualar bordas.

## Materiais e alpha no DEdit

O caminho de importação TGA está confirmado no código enviado, em
`DEdit/TextureDlg.cpp`. Use a versão do editor e os módulos do seu projeto.
Consulte `DTX/LEIA-ME.txt` para conversão.

O manifesto/CSV classifica materiais como:
- `opaque`: sem transparência;
- `cutout`: alpha binário (0/255), adequado para recorte;
- `blend`: alpha parcial, requer transparência por mistura no material.

Configure o modo de renderização no DEdit; o alpha no arquivo não configura isso
sozinho. Folhas não têm colisão por pixel: trate geometria/colisão separadamente.
Água e lava são estáticas. Glowstone e lâmpadas não criam iluminação sozinhas.
Use filtragem por ponto para máxima pixelização; se optar por mipmaps/filtragem
para reduzir cintilação no FPS, confira o resultado em movimento e preserve alpha.

## Verificação entregue

`validation_report.json` registra dimensões, modos, alpha, equivalência PNG/TGA/BMP,
bordas dos eixos declarados e integridade do pacote. `manifest.json` inclui os
caminhos, dimensões, uso de UV e SHA-256 de cada PNG principal. `materiais.csv`
facilita a criação dos materiais no editor.

Não houve teste no cliente Combat Arms Classic nem execução dos conversores Windows
nesta sessão. Os DTX precisam ser gerados e validados na sua instalação. Nenhum
arquivo foi apenas renomeado para fingir uma conversão.
