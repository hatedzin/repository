"""Resolve native UI layout contracts without fixed instruction offsets.

No obfuscated name is baked in. Candidates must be unique and agree with the
native class, self-typed preset constants, initialization and method signatures.
"""
import re

P = r'<q>\[public\]::([^\s,:=<>]+)'
CLASS = re.compile(r'(?m)^[^\n]*\bclass '+P+r' extends ([^\n{]+)\{')
METHOD = re.compile(r'(?m)^\s*(?:(?:final|override|static)\s+)*method\s+(<q>\[public\](?:(?:[A-Za-z0-9_.]+)::|::)[^\s=]+)\s+'+P+r'=\(([^\n]*)\)\((\d+) params, (\d+) optional\)')
OP_PREFIX = re.compile(r'^\s*[0-9a-fA-F]+\)\s+\+\s+-?\d+:-?\d+\s+(.*)$')
OP_BARE = re.compile(r'^(?:getlocal(?:_\d+)?|setlocal(?:_\d+)?|getlex|getproperty|findproperty|findpropstrict|initproperty|setproperty|construct(?:prop|super)?|coerce|callpropvoid|callproperty|returnvalue|returnvoid|push\w*|pop|dup|nop|label|debug\w*)\b')


def _ops(text):
    result=[]
    for line in text.splitlines():
        match=OP_PREFIX.match(line)
        value=match.group(1).strip() if match else line.strip()
        if match or OP_BARE.match(value):
            if not re.match(r'^(?:nop|label|debug\w*)\b',value):
                result.append(value)
    return result


def _methods(body):
    headers=list(METHOD.finditer(body))
    for i,match in enumerate(headers):
        fragment=body[match.end():headers[i+1].start() if i+1<len(headers) else len(body)]
        yield match.group(1),match.group(2),match.group(3),int(match.group(4)),int(match.group(5)),fragment,_ops(fragment)


def _preset_constants(name,body):
    fields={int(slot):field for slot,field in re.findall(r'(?m)^\s*slot (\d+): const '+P+r':<q>\[public\]::'+re.escape(name)+r'\s*$',body)}
    if not {1,2,3,4}<=fields.keys() or len(set(fields.values()))!=len(fields):
        raise ValueError('UI style preset constants missing or ambiguous')
    match=re.search(r'(?ms)^\s*staticconstructor[^\n]*\n[^\n]*\n\s*\{\n(.*?)^    \}',body)
    if not match:
        raise ValueError('UI style static initializer missing')
    instructions=_ops(match.group(1))
    initialized=[]
    for i,op in enumerate(instructions):
        m=re.fullmatch(r'initproperty '+P,op)
        if m and m.group(1) in fields.values():
            nearby=instructions[max(0,i-5):i]
            if not any(x=='construct 0 params' or x=='constructprop <q>[public]::'+name+', 0 params' for x in nearby):
                raise ValueError('UI style preset is not natively constructed')
            initialized.append(m.group(1))
    expected=[fields[n] for n in sorted(fields)]
    if initialized!=expected:
        raise ValueError('UI preset initialization order disagrees with native constants')
    return fields


def extract_ui_layout(lines,ui_class):
    text='\n'.join(lines)
    headers=list(CLASS.finditer(text))
    classes={m.group(1):(m.group(2),text[m.start():headers[i+1].start() if i+1<len(headers) else len(text)]) for i,m in enumerate(headers)}
    if ui_class not in classes:
        aliases=[name for name in classes if name.replace('\\','')==ui_class.replace('\\','')]
        if len(aliases)!=1:
            raise ValueError('Native UI element class not found')
        ui_class=aliases[0]
    owners=[];current=ui_class
    while current in classes and len(owners)<8 and current not in owners:
        owners.append(current)
        parent=re.fullmatch(P,classes[current][0].strip())
        current=parent.group(1) if parent else ''
    setters=[];adders=[]
    for owner in owners:
        for result,name,params,count,optional,fragment,ops in _methods(classes[owner][1]):
            # Native child insertion accepts DisplayObject plus a rest array and
            # recursively adds each member. This separates it from remove/replace.
            if result=='<q>[public]::void' and params=='<q>[public]flash.display::DisplayObject' and count==1 and optional==0 and 'need_rest' in fragment:
                if 'callpropvoid <q>[public]::'+name+', 1 params' in ops:
                    adders.append(name)
            # Native skin application accepts a palette instance, optional width,
            # creates the skin wrapper and returns this UI element.
            arg=re.fullmatch(P+r'(?:, <q>\[public\]::int = -?\d+)?',params)
            if result!='<q>[public]::'+owner or not arg or count not in (1,2) or optional!=count-1:
                continue
            palette=arg.group(1)
            if palette not in classes or classes[palette][0].strip()!='<q>[public]::Object':
                continue
            if not any(re.fullmatch(r'constructprop '+P+r', [12] params',x) for x in ops):
                continue
            if not any(a in ('getlocal_0','getlocal r0','getlocal 0') and b=='returnvalue' for a,b in zip(ops,ops[1:])):
                continue
            try:
                presets=_preset_constants(palette,classes[palette][1])
            except ValueError:
                continue
            setters.append((palette,name,presets[1],presets[4]))
    unique=set(setters);children=set(adders)
    if len(unique)!=1 or len(children)!=1:
        raise ValueError('Native UI layout contracts ambiguous (skin=%s, children=%s)'%(len(unique),len(children)))
    palette,setter,first,fourth=unique.pop()
    return {'prep_ui_class_name':palette,'set_prep_ui':setter,'add_ui_element':children.pop(),'prep_ui1_instance':first,'prep_ui4_instance':fourth}
