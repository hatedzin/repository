"""Bounded SWF download with HTTPS defaults and independent endpoint retries."""
import time
from urllib.parse import urlsplit
import aiohttp

MAX_BYTES=64*1024*1024
OFFICIAL_URLS=('https://www.transformice.com/Transformice.swf','https://transformice.com/Transformice.swf')

class DownloadUnavailable(RuntimeError):
    pass


def sources(override):
    if override and override.strip():
        return (override.strip(),)
    return OFFICIAL_URLS


async def download(session,urls,headers=None,header_source=None,ready=False,progress=print):
    errors=[]
    for index,url in enumerate(urls,1):
        parsed=urlsplit(url)
        if parsed.scheme not in ('http','https') or not parsed.hostname:
            raise ValueError('TFM_SWF_URL precisa ser um endereco HTTP/HTTPS valido')
        progress('Parser: baixando SWF por %s (%s), tentativa %s/%s'%(parsed.scheme.upper(),parsed.hostname,index,len(urls)))
        request_headers=dict(headers or {}) if url==header_source and ready else {}
        try:
            async with session.get(url,headers=request_headers,timeout=aiohttp.ClientTimeout(total=45,sock_connect=12,sock_read=20),max_redirects=5) as response:
                if response.status==304 and ready and url==header_source:
                    return None,request_headers,url
                response.raise_for_status()
                if response.status!=200:
                    raise ValueError('Resposta SWF sem conteudo completo')
                if response.content_length and response.content_length>MAX_BYTES:
                    raise ValueError('SWF excede o limite de tamanho')
                chunks=[];size=0;next_size=1024*1024;last=time.monotonic()
                async for chunk in response.content.iter_chunked(65536):
                    size+=len(chunk)
                    if size>MAX_BYTES:raise ValueError('SWF excede o limite de tamanho')
                    chunks.append(chunk)
                    if size>=next_size or time.monotonic()-last>=10:
                        progress('Parser: recebidos %s KiB da SWF'%(size//1024));next_size=size+1024*1024;last=time.monotonic()
                data=b''.join(chunks)
                if len(data)<8 or data[:3] not in (b'FWS',b'CWS'):
                    raise ValueError('O endereco respondeu sem uma SWF reconhecida')
                result={}
                if response.headers.get('ETag'):result['If-None-Match']=response.headers['ETag']
                if response.headers.get('Last-Modified'):result['If-Modified-Since']=response.headers['Last-Modified']
                progress('Parser: download concluido (%s KiB); preparando leitura'%(size//1024))
                return data,result,url
        except (aiohttp.ClientError,OSError,TimeoutError,ValueError) as error:
            # Never include exception URLs, query strings, credentials or proxy data.
            reason=type(error).__name__
            if isinstance(error,aiohttp.ClientResponseError):reason+=' HTTP%s'%error.status
            errors.append(reason)
            progress('Parser: tentativa %s falhou (%s)'%(index,reason))
    raise DownloadUnavailable('Nao foi possivel baixar a SWF: '+', '.join(errors)+'. Teste o link oficial no navegador e confira sua conexao.')
