@echo off
cd /d "%~dp0"
echo Feche o Flash e o iniciador anterior antes de aplicar.
if exist ".client-runtime\Scripts\python.exe" (
  ".client-runtime\Scripts\python.exe" aplicar_correcao.py
) else if exist "DisneyClient-Local-Robot-Novo\.client-runtime\Scripts\python.exe" (
  "DisneyClient-Local-Robot-Novo\.client-runtime\Scripts\python.exe" aplicar_correcao.py
) else (
  py -3 aplicar_correcao.py
)
pause
