"""Apply just the two parser modules, keeping a local rollback copy."""
from datetime import datetime
from pathlib import Path
import os
import shutil
import tempfile


def locate(folder):
    for root in (folder,folder/'DisneyClient-Local-Robot-Novo',folder.parent):
        if (root/'DisneyParser/tfmparser/ui.py').is_file() and (root/'iniciar_client.py').is_file():
            return root.resolve()
    raise RuntimeError('Extraia a correcao na pasta do client, ao lado de INICIAR_CLIENT.bat, e tente novamente.')


def apply(folder):
    root=locate(folder)
    source=folder/'arquivos'
    for name in ('DisneyParser/tfmparser/ui.py','DisneyParser/tfmparser/ui_layout.py','DisneyParser/tfmparser/parser.py','DisneyParser/tfmparser/swf_download.py','iniciar_client.py'):
        compile((source/name).read_text(encoding='utf-8'),name,'exec')
    backup=root/('backup-parser-download-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    backup.mkdir()
    for name in ('DisneyParser/tfmparser/ui.py','DisneyParser/tfmparser/ui_layout.py','DisneyParser/tfmparser/parser.py','DisneyParser/tfmparser/swf_download.py','iniciar_client.py'):
        target=root/name
        if target.exists():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(dir=target.parent,prefix='.ui-fix-',delete=False) as stream:
                temporary=Path(stream.name);stream.write((source/name).read_bytes())
            temporary.replace(target);temporary=None
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)
    return root,backup


if __name__=='__main__':
    try:
        root,backup=apply(Path(__file__).resolve().parent)
        print('Correcao HTTPS do parser aplicada em:',root)
        print('Backup dos modulos anteriores:',backup.name)
        print('Reabra INICIAR_CLIENT.bat. O .env, tokens e gravacoes nao foram alterados.')
    except (OSError,RuntimeError,SyntaxError) as error:
        print('ERRO:',str(error))
        raise SystemExit(1)
