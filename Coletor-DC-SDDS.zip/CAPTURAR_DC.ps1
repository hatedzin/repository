# PowerShell / CAPTURAR_DC.ps1 / Windows PowerShell 5.1 / capture Adobe_10 process after disconnect
$ErrorActionPreference = 'Stop'
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Feche esta janela e execute CAPTURAR_DC.bat com o botao direito: Executar como administrador.'
    }
    if (-not [Environment]::Is64BitProcess -and [Environment]::Is64BitOperatingSystem) {
        throw 'Execute com o PowerShell de 64 bits para usar o coletor.'
    }
    $candidates = @(Get-Process | Where-Object { $_.ProcessName -match '^(Adobe_10|flashplayer.*|Adobe Flash Player.*)$' })
    if ($candidates.Count -eq 0) { throw 'Abra o jogo no Adobe_10.exe antes de executar o coletor.' }
    $candidates | Select-Object Id,ProcessName,StartTime,MainWindowTitle | Format-Table -AutoSize
    if ($candidates.Count -eq 1) { $targetId = $candidates[0].Id }
    else {
        $chosen = Read-Host 'Digite o ID do processo do jogo mostrado acima'
        $targetId = 0
        if (-not [int]::TryParse($chosen, [ref]$targetId)) { throw 'ID invalido.' }
        if ($targetId -notin $candidates.Id) { throw 'Escolha somente um dos processos Adobe listados.' }
    }
    $target = Get-Process -Id $targetId
    $started = $target.StartTime.ToUniversalTime()
    $output = Join-Path $PSScriptRoot ('dump-dc-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Path $output | Out-Null
    Write-Host 'Deixe o jogo aberto. Ative o Follow e aguarde aparecer a desconexao.' -ForegroundColor Cyan
    Read-Host 'Assim que o DC aparecer, volte aqui e pressione ENTER sem fechar o Adobe' | Out-Null
    $target = Get-Process -Id $targetId
    if ($target.StartTime.ToUniversalTime() -ne $started) { throw 'O processo mudou. Execute novamente.' }
    $capturedAt = (Get-Date).ToUniversalTime()
    $metadata = [ordered]@{
        captured_utc = $capturedAt.ToString('o'); process_id = $targetId
        process_name = $target.ProcessName; started_utc = $started.ToString('o')
        working_set_bytes = $target.WorkingSet64; private_bytes = $target.PrivateMemorySize64
        os_64bit = [Environment]::Is64BitOperatingSystem
        note = 'Captura manual apos DC; nao indica motivo de encerramento enviado pelo servidor.'
    }
    $metadata | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $output 'captura.json')
    Get-NetTCPConnection -OwningProcess $targetId -ErrorAction SilentlyContinue |
        Select-Object State,LocalAddress,LocalPort,RemoteAddress,RemotePort |
        Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $output 'conexoes.csv')
    $systemDir = Join-Path $env:WINDIR 'System32'
    $dumpPath = Join-Path $output 'Adobe_10.dmp'
    $dumpArgs = '"{0}", MiniDump {1} "{2}" full' -f (Join-Path $systemDir 'comsvcs.dll'), $targetId, $dumpPath
    Write-Host 'Salvando dump completo. O Adobe pode pausar durante a captura...'
    $dumpTool = Start-Process -FilePath (Join-Path $systemDir 'rundll32.exe') -ArgumentList $dumpArgs -Wait -PassThru
    if (-not (Test-Path $dumpPath)) { throw ('O Windows nao criou o dump. Codigo: ' + $dumpTool.ExitCode) }
    $dumpFile = Get-Item $dumpPath
    if ($dumpFile.Length -lt 32) { throw 'Dump vazio ou incompleto.' }
    $stream = [IO.File]::OpenRead($dumpPath)
    try { $header = New-Object byte[] 4; $null = $stream.Read($header,0,4) } finally { $stream.Dispose() }
    if ([Text.Encoding]::ASCII.GetString($header) -ne 'MDMP') { throw 'Arquivo sem assinatura de dump valida.' }
    $logInput = Read-Host 'Cole o caminho da pasta logs-client, ou ENTER para pular'
    $logInput = $logInput.Trim().Trim('"')
    if ($logInput) {
        if (Test-Path -LiteralPath $logInput -PathType Container) {
            $logOutput = Join-Path $output 'logs-client'; New-Item -ItemType Directory -Path $logOutput | Out-Null
            foreach ($name in @('backend.log','parser.log','flash-diagnostics.jsonl')) {
                $source = Join-Path $logInput $name
                if (Test-Path -LiteralPath $source -PathType Leaf) { Copy-Item -LiteralPath $source -Destination $logOutput }
            }
        } else { Write-Host 'Pasta de logs nao encontrada; o dump foi mantido.' }
    }
    Get-FileHash -Algorithm SHA256 -LiteralPath $dumpPath | Select-Object Hash | ConvertTo-Json |
        Set-Content -Encoding UTF8 (Join-Path $output 'dump-sha256.json')
    Write-Host ('Captura concluida: ' + $output) -ForegroundColor Green
    Write-Host 'Compacte essa pasta e envie aqui. Nao publique o dump no GitHub: ele pode conter dados da sessao.'
} catch {
    Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
