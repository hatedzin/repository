@rem Batch / CAPTURAR_DC.bat / Windows 10+ / launch disconnect dump collector
@echo off
setlocal
set "DC_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "DC_POWERSHELL=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%DC_POWERSHELL%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAPTURAR_DC.ps1"
pause
