@rem Batch / LIBERAR_RADMIN.bat / Windows 10+ / allow requested Radmin host TCP8080
@echo off
netsh advfirewall firewall delete rule name="SDDS Radmin 8080" >nul 2>&1
netsh advfirewall firewall add rule name="SDDS Radmin 8080" dir=in action=allow protocol=TCP localip=26.204.91.4 localport=8080 remoteip=26.0.0.0/8 profile=any
pause
