// ActionScript 3 / FollowController.as / Flash Player 10.3+ / room-local nickname following with native movement keys
package disney {
 import flash.display.MovieClip;import flash.display.DisplayObject;import flash.geom.Point;import flash.events.Event;import flash.events.KeyboardEvent;import flash.text.TextField;import flash.text.TextFieldType;import flash.text.TextFormat;import flash.utils.Dictionary;import flash.utils.getTimer;
 public class FollowController {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var targetName:String="";private var owner:Object;private var left:Boolean=false;private var right:Boolean=false;private var jumping:Boolean=false;private var nextJump:int=0;private var releaseJump:int=0;private var hud:TextField;private var state:String="";private var focused:Boolean=true;private var needsSync:Boolean=true;private var bodyOwner:Object;private var roundOwner:Object;private var roundCode:String="";private var retryAt:int=0;private var previousTarget:Object;private var previousX:Number=0;private var previousY:Number=0;private var previousTime:int=-1;
  public function FollowController(value:MovieClip){root=value;}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var follow:FollowController=new FollowController(value);instances[value]=follow;
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,follow.keyDown,true,2000);value.stage.addEventListener(KeyboardEvent.KEY_DOWN,follow.keyDown,false,2000);
   value.stage.addEventListener(Event.ENTER_FRAME,function(event:Event):void{follow.update();});
   value.stage.addEventListener(Event.ACTIVATE,function(event:Event):void{follow.focused=true;follow.needsSync=true;});
   value.stage.addEventListener(Event.DEACTIVATE,function(event:Event):void{follow.focused=false;follow.release();follow.notice("Follow: pausado ao perder foco");});
  }
  public function keyDown(event:KeyboardEvent):void{
   var input:TextField=root.stage.focus as TextField;
   if(event.keyCode==13 && input && input.type==TextFieldType.INPUT && /^\s*\/follow(?:\s|$)/i.test(input.text)){
    var requested:String=input.text;input.text="";root.stage.focus=root.stage;command(requested);update();event.preventDefault();event.stopImmediatePropagation();return;
   }
   if(event.keyCode==27 && targetName!="")stop("Follow: parado");
  }
  public function command(text:String):Boolean{
   if(!/^\s*\/follow(?:\s|$)/i.test(text))return false;
   var argument:String=text.replace(/^\s*\/follow\s*/i,"").replace(/\s+$/g,"");
   if(argument=="" || /^(?:off|stop|parar)$/i.test(argument)){stop("Follow: parado");return true;}
   if(!/^[^\s#]+#\d{4}$/.test(argument)){notice("Uso: /follow Nome#0000 | /follow off");return true;}
   var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
   if(local && String(local[k.player_name]).toLowerCase()==argument.toLowerCase()){stop("Follow: escolha outro jogador");return true;}
   release();targetName=argument.toLowerCase();owner=null;previousTarget=null;previousTime=-1;root["auto_play"]=false;nextJump=0;needsSync=true;retryAt=0;notice("Follow: procurando "+argument+" nesta sala");return true;
  }
  public function stop(message:String="Follow: parado"):void{release();targetName="";owner=null;notice(message);}
  private function notice(message:String):void{
   state=message;if(!root.stage)return;if(!hud){hud=new TextField();hud.name="sddsFollowStatus";hud.defaultTextFormat=new TextFormat("_sans",12,0xD7F5FF);hud.width=540;hud.height=22;hud.background=true;hud.backgroundColor=0x141B2A;hud.selectable=false;hud.mouseEnabled=false;root.stage.addChild(hud);}hud.x=8;hud.y=Math.max(60,root.stage.stageHeight-48);hud.text=message;
  }
  private function key(code:uint,down:Boolean):void{if(root.stage)root.stage.dispatchEvent(new KeyboardEvent(down ? KeyboardEvent.KEY_DOWN : KeyboardEvent.KEY_UP,true,false,0,code));}
  private function movement(l:Boolean,r:Boolean,j:Boolean):void{
   if(left!=l){key(37,l);left=l;}if(right!=r){key(39,r);right=r;}if(jumping!=j){key(38,j);jumping=j;}
  }
  private function release():void{movement(false,false,false);needsSync=true;previousTarget=null;previousTime=-1;}
  public function update(now:int=-1):void{
   if(targetName=="" || !focused)return;if(now<0)now=getTimer();if(now<retryAt)return;
   try{
    var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
    if(local!==owner){release();owner=local;}
    if(!local || (k.is_dead && local[k.is_dead])){release();notice("Follow: aguardando renascer");return;}
    if(root.stage.focus is TextField && TextField(root.stage.focus).type==TextFieldType.INPUT){release();notice("Follow: pausado enquanto digita");return;}
    var found:Object=null;var list:Object=game[k.player_list];if(list)for each(var player:Object in list){if(player && String(player[k.player_name]).toLowerCase()==targetName){found=player;break;}}
    if(!found || found===local || (k.is_dead && found[k.is_dead]) || (found.hasOwnProperty("parent") && !found.parent)){release();notice("Follow: aguardando "+targetName+" nesta sala");return;}
    var body:Object=k.player_physics ? local[k.player_physics] : null;
    var round:Object=k.map_class && k.map_instance ? k.map_class[k.map_instance] : null;
    var roundNumber:Object=round && k.bot_map_code_object ? round[k.bot_map_code_object] : null;
    var code:String=roundNumber && k.bot_map_code_value ? String(roundNumber[k.bot_map_code_value]) : "";
    if(body!==bodyOwner || round!==roundOwner || code!=roundCode){release();bodyOwner=body;roundOwner=round;roundCode=code;}
    if(!body || (k.player_clip && !local[k.player_clip])){release();notice("Follow: aguardando rato pronto na rodada");return;}
    if(k.move_class && k.move_free && !k.move_class[k.move_free]){release();notice("Follow: aguardando liberacao da rodada");return;}
    var point:Point=new Point(Number(found.x),Number(found.y));
    if(found is DisplayObject && local is DisplayObject){
     var source:DisplayObject=found as DisplayObject;var destination:DisplayObject=local as DisplayObject;
     if(!source.parent || !destination.parent){release();notice("Follow: aguardando mapa");return;}
     point=destination.parent.globalToLocal(source.parent.localToGlobal(point));
    }
    var x:Number=point.x;var y:Number=point.y;
    if(!isFinite(x) || !isFinite(y))throw new Error("Coordenadas indisponiveis");
    if(!body || !k.bot_set_position || !(body[k.bot_set_position] is Function))throw new Error("Fisica indisponivel",2201);
    var vectorClass:Class=k.app_domain.applicationDomain.getDefinition(String(k.b2vec2)) as Class;
    if(!vectorClass)throw new Error("Vetor indisponivel",2202);
    var vx:Number=0;var vy:Number=0;var remoteBody:Object=k.player_physics ? found[k.player_physics] : null;
    var velocity:Object=remoteBody && k.physics_state ? remoteBody[k.physics_state] : null;
    if(velocity && k.physics_state_vx && k.physics_state_vy){vx=Number(velocity[k.physics_state_vx]);vy=Number(velocity[k.physics_state_vy]);}
    else if(previousTarget===found && previousTime>=0 && now>previousTime){vx=(x-previousX)*1000/(30*(now-previousTime));vy=(y-previousY)*1000/(30*(now-previousTime));}
    if(velocity && found is DisplayObject && local is DisplayObject){
     var origin:Point=destination.parent.globalToLocal(source.parent.localToGlobal(new Point(0,0)));
     var endpoint:Point=destination.parent.globalToLocal(source.parent.localToGlobal(new Point(vx*30,vy*30)));
     vx=(endpoint.x-origin.x)/30;vy=(endpoint.y-origin.y)/30;
    }
    if(!isFinite(vx) || !isFinite(vy))throw new Error("Velocidade indisponivel",2203);
    var targetLeft:Boolean=k.player_moving_left ? Boolean(found[k.player_moving_left]) : vx < -0.05;
    var targetRight:Boolean=k.player_moving_right ? Boolean(found[k.player_moving_right]) : vx > 0.05;
    // Vertical velocity also changes on bounces, launches and slopes; it is not a jump button.
    var targetJump:Boolean=false;
    if(k.is_jumping && found.hasOwnProperty(String(k.is_jumping)) && found[k.is_jumping] is Boolean)targetJump=Boolean(found[k.is_jumping]);
    movement(targetLeft,targetRight,targetJump);
    if(k.is_down){var down:Boolean=Boolean(found[k.is_down]);if(Boolean(local[k.is_down])!=down){local[k.is_down]=down;var crouch:String=down ? k.crouch : k.crouch2;if(crouch && local[crouch] is Function)local[crouch](local[k.static_side]);}}
    if(needsSync){
     if(!k.packet_handler_class || !k.packet_handler || !(k.packet_handler_class[k.packet_handler] is Function))throw new Error("Teleport nativo indisponivel",2206);
     k.packet_handler_class[k.packet_handler](LegacyOptionsV5.encodePosition(Math.round(x),Math.round(y)));
    }
    if(body[k.bot_set_position](new vectorClass(x/30,y/30),0)===false)throw new Error("Fisica bloqueada",2204);
    var localVelocity:Object=body[k.physics_state];if(!localVelocity)throw new Error("Vetor local indisponivel",2205);
    localVelocity[k.physics_state_vx]=vx;localVelocity[k.physics_state_vy]=vy;local.x=x;local.y=y;
    needsSync=false;previousTarget=found;previousX=x;previousY=y;previousTime=now;
    notice("Follow: acompanhando ao vivo "+targetName);

   }catch(error:Error){release();retryAt=now+500;notice("Follow: aguardando sincronizacao #"+error.errorID);}
  }
 }
}
